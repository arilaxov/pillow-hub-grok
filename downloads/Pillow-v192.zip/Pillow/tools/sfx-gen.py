"""Pillow SFX - the sound library, synthesized from scratch (no samples,
no third-party audio: every sound is Pillow's own).

    python3 tools/sfx-gen.py

writes sfx/*.wav (48 kHz, 16-bit) and js/sfx-data.js (name, category,
file, length and a 26-bar waveform per sound) for js/sfx.js.
Needs numpy.
"""
import json
import math
import os
import wave

import numpy as np

SR = 48000
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "sfx")
rng = np.random.default_rng(7)


# ── building blocks ────────────────────────────────────────────────────
def t_axis(dur):
    return np.arange(int(dur * SR)) / SR


def white(n):
    return rng.standard_normal(n)


def pink(n):
    """1/f noise, shaped in the frequency domain."""
    spec = np.fft.rfft(rng.standard_normal(n))
    f = np.fft.rfftfreq(n, 1 / SR)
    f[0] = f[1]
    spec /= np.sqrt(f)
    x = np.fft.irfft(spec, n)
    return x / (np.max(np.abs(x)) + 1e-9)


def svf_bp(x, fc, q=1.2):
    """State-variable band-pass with a cutoff that may change every sample."""
    fc = np.broadcast_to(np.asarray(fc, dtype=float), x.shape)
    out = np.empty_like(x)
    lp = bp = 0.0
    k = 1.0 / q
    fmax = (2.0 - k) * 0.85          # the Chamberlin filter's stable range
    for i in range(len(x)):
        f = min(fmax, 2.0 * math.sin(math.pi * min(fc[i], SR * 0.22) / SR))
        hp = x[i] - lp - k * bp
        bp += f * hp
        lp += f * bp
        out[i] = bp
    return out


def onepole_lp(x, fc):
    fc = np.broadcast_to(np.asarray(fc, dtype=float), x.shape)
    out = np.empty_like(x)
    y = 0.0
    for i in range(len(x)):
        a = 1.0 - math.exp(-2 * math.pi * fc[i] / SR)
        y += a * (x[i] - y)
        out[i] = y
    return out


def fft_filter(x, lo=None, hi=None):
    """Static brick-ish filter with soft edges, in the frequency domain."""
    n = len(x)
    spec = np.fft.rfft(x)
    f = np.fft.rfftfreq(n, 1 / SR)
    g = np.ones_like(f)
    if lo:
        g *= 1 / (1 + (lo / np.maximum(f, 1)) ** 4)
    if hi:
        g *= 1 / (1 + (f / hi) ** 4)
    return np.fft.irfft(spec * g, n)


def sweep(f0, f1, dur, curve="exp"):
    t = t_axis(dur)
    u = t / dur
    if curve == "exp":
        return f0 * (f1 / f0) ** u
    return f0 + (f1 - f0) * u


def osc(freq, kind="sine"):
    ph = 2 * np.pi * np.cumsum(freq) / SR
    if kind == "sine":
        return np.sin(ph)
    if kind == "saw":
        return 2 * ((ph / (2 * np.pi)) % 1) - 1
    if kind == "tri":
        return 2 * np.abs(2 * ((ph / (2 * np.pi)) % 1) - 1) - 1
    raise ValueError(kind)


def env_ad(n, a, d, curve=4.0):
    """Attack (s) then an exponential-ish decay over the rest."""
    t = np.arange(n) / SR
    na = max(1, int(a * SR))
    e = np.ones(n)
    e[:na] = (np.arange(na) / na) ** 0.7
    rest = np.clip((t - a) / max(d, 1e-4), 0, 1)
    e[na:] = (1 - rest[na:]) ** curve
    return e


def bell(n, peak=0.5, width=0.28):
    u = np.linspace(0, 1, n)
    return np.exp(-((u - peak) / width) ** 2 * 2.2) * np.minimum(1, u * 40) * np.minimum(1, (1 - u) * 40)


def reverb(x, seconds=1.2, mix=0.25, bright=6000, pre=0.012):
    """Stereo room: convolution with decaying, decorrelated noise."""
    n = int(seconds * SR)
    t = np.arange(n) / SR
    tails = []
    for ch in range(2):
        ir = white(n) * np.exp(-6.9 * t / seconds)
        ir = fft_filter(ir, lo=120, hi=bright)
        ir[: int(pre * SR)] = 0
        ir /= np.sqrt(np.sum(ir ** 2)) + 1e-9
        tails.append(ir)
    mono = x if x.ndim == 1 else x.mean(axis=1)
    L = len(mono) + n
    size = 1 << (L - 1).bit_length()
    X = np.fft.rfft(mono, size)
    wet = np.stack([np.fft.irfft(X * np.fft.rfft(ir, size), size)[:L] for ir in tails], axis=1)
    dry = stereo(x)
    dry = np.vstack([dry, np.zeros((n, 2))])
    return dry * (1 - mix * 0.5) + wet * mix


def stereo(x, pan=None):
    if x.ndim == 2:
        return x
    if pan is None:
        return np.stack([x, x], axis=1)
    pan = np.broadcast_to(np.asarray(pan, dtype=float), x.shape)
    a = (pan + 1) * np.pi / 4
    return np.stack([x * np.cos(a), x * np.sin(a)], axis=1)


def sat(x, drive=1.5):
    return np.tanh(x * drive) / np.tanh(drive)


def fade(x, fin=0.002, fout=0.02):
    n = len(x)
    e = np.ones(n)
    a, b = int(fin * SR), int(fout * SR)
    if a:
        e[:a] = np.linspace(0, 1, a)
    if b:
        e[-b:] = np.minimum(e[-b:], np.linspace(1, 0, b))
    return x * (e if x.ndim == 1 else e[:, None])


def trim_tail(x, db=-50):
    """cut the tail where it has fallen to db below the peak"""
    m = np.abs(x if x.ndim == 1 else x.max(axis=1))
    thresh = m.max() * 10 ** (db / 20)
    idx = np.nonzero(m > thresh)[0]
    end = (idx[-1] + int(0.03 * SR)) if len(idx) else len(x)
    return x[: min(len(x), end)]


def master(x, peak_db=-1.0):
    x = stereo(x)
    x = x - x.mean(axis=0)
    x = trim_tail(x)
    x = fade(x, 0.0008, 0.03)
    pk = np.max(np.abs(x)) + 1e-9
    return x * (10 ** (peak_db / 20) / pk)


def mix(*parts):
    n = max(len(p) for p in parts)
    out = np.zeros((n, 2))
    for p in parts:
        p = stereo(p)
        out[: len(p)] += p
    return out


def at(x, sec, total=None):
    pad = np.zeros((int(sec * SR),) + x.shape[1:])
    return np.concatenate([pad, x])


# ── the sounds ─────────────────────────────────────────────────────────
def whoosh(dur=0.8, f0=350, f1=2600, peak=0.55, q=2.2, low=False, pan=(-0.7, 0.7), air=0.06):
    """air moving past: pink noise through a band that rises to f1 as the
    object passes (peak) and falls back, a little hiss on top, panned
    across; nothing above ~9 kHz, so it is a whoosh and not a hiss"""
    n = int(dur * SR)
    u = np.linspace(0, 1, n)
    fc = f0 + (f1 - f0) * np.exp(-((u - peak) / 0.22) ** 2)
    body = svf_bp(pink(n), fc, q)
    hiss = svf_bp(pink(n), fc * 1.8, 1.0) * air
    s = fft_filter((body + hiss) * bell(n, peak, 0.26), lo=90, hi=8500)
    if low:
        s += osc(sweep(90, 45, dur)) * bell(n, peak, 0.3) * 0.6
    s = stereo(s, np.linspace(pan[0], pan[1], n))
    return reverb(s, 0.9, 0.18)


def swipe(dur=0.32, f0=900, f1=3800, pan=(-0.5, 0.6)):
    n = int(dur * SR)
    u = np.linspace(0, 1, n)
    fc = f0 * (f1 / f0) ** u
    s = fft_filter(svf_bp(pink(n), fc, 2.6) * (np.sin(np.pi * u) ** 1.5), lo=200, hi=10000)
    click = np.zeros(n)
    click[:240] = white(240) * np.exp(-np.arange(240) / 30) * 0.4
    return stereo(s + click, np.linspace(pan[0], pan[1], n))


def impact(dur=1.6, f0=140, f1=42, body_decay=0.5, crack=0.6, room=1.4, wet=0.3, drive=1.8, bright=5000):
    n = int(dur * SR)
    t = t_axis(dur)
    thump = osc(f1 + (f0 - f1) * np.exp(-t / 0.06)) * np.exp(-t / body_decay)
    nb = fft_filter(white(n), hi=2400) * np.exp(-t / 0.05)
    ck = fft_filter(white(n), lo=1500, hi=9000) * np.exp(-t / 0.008) * crack
    s = sat(thump * 1.0 + nb * 0.5 + ck, drive)
    return reverb(s, room, wet, bright)


def sub_drop(dur=2.6, f0=95, f1=26):
    t = t_axis(dur)
    f = f1 + (f0 - f1) * np.exp(-t / (dur * 0.35))
    s = osc(f) * env_ad(len(t), 0.004, dur, 1.6)
    s = sat(s + 0.25 * osc(f * 2) * env_ad(len(t), 0.004, dur * 0.5, 2), 1.4)
    return s


def boom(dur=2.6):
    return mix(impact(dur, 110, 32, 0.8, 0.35, 1.9, 0.34, 2.2, 3200), sub_drop(dur * 0.8, 70, 24) * 0.5)


def metal_hit(dur=2.2):
    t = t_axis(dur)
    parts = [(220, 1.0, 1.1), (563, 0.6, 0.8), (1189, 0.45, 0.5), (1873, 0.3, 0.35), (2741, 0.2, 0.22)]
    s = sum(a * np.sin(2 * np.pi * f * t + rng.uniform(0, 6)) * np.exp(-t / d) for f, a, d in parts)
    s += fft_filter(white(len(t)), lo=2000) * np.exp(-t / 0.01) * 0.6
    return reverb(s * 0.5, 1.3, 0.26, 7000)


def pop(f0=1100, f1=380, dur=0.12, click=0.25):
    t = t_axis(dur)
    f = f1 + (f0 - f1) * np.exp(-t / 0.012)
    s = osc(f) * np.exp(-t / (dur * 0.35))
    s[:96] += white(96) * np.exp(-np.arange(96) / 14) * click
    return s


def bloop(f0=260, f1=900, dur=0.18):
    t = t_axis(dur)
    f = f0 * (f1 / f0) ** np.minimum(1, t / (dur * 0.6))
    return osc(f) * env_ad(len(t), 0.004, dur - 0.004, 2.2)


def tick(f=2600, dur=0.05, noise=0.3):
    t = t_axis(dur)
    s = np.sin(2 * np.pi * f * t) * np.exp(-t / 0.006)
    s += fft_filter(white(len(t)), lo=3000) * np.exp(-t / 0.002) * noise
    return s


def click(dur=0.06, lo=900, hi=7000, thock=0.0):
    t = t_axis(dur)
    s = fft_filter(white(len(t)), lo=lo, hi=hi) * np.exp(-t / 0.004)
    if thock:
        s += np.sin(2 * np.pi * 180 * t) * np.exp(-t / 0.018) * thock
    return s


def chime(notes, dur=1.4, gap=0.11, decay=0.55):
    out = np.zeros(int((dur + gap * len(notes)) * SR))
    for i, f in enumerate(notes):
        t = t_axis(dur)
        tone = (np.sin(2 * np.pi * f * t) + 0.35 * np.sin(2 * np.pi * f * 2.01 * t) * np.exp(-t / 0.15)
                + 0.15 * np.sin(2 * np.pi * f * 3.02 * t) * np.exp(-t / 0.08))
        tone *= np.exp(-t / decay) * np.minimum(1, t / 0.002)
        s = int(i * gap * SR)
        out[s:s + len(tone)] += tone
    return reverb(out * 0.4, 1.1, 0.22, 9000)


def buzz(dur=0.42):
    t = t_axis(dur)
    s = np.zeros(len(t))
    for st in (0.0, 0.2):
        tt = t - st
        m = (tt >= 0) & (tt < 0.15)
        s[m] += osc(np.full(m.sum(), 150), "saw") * np.sin(np.pi * tt[m] / 0.15)
    return fft_filter(s, hi=2200) * 0.7


def riser(dur=3.0, f0=180, f1=1400, tone=0.5):
    n = int(dur * SR)
    u = np.linspace(0, 1, n)
    hp = svf_bp(white(n), 400 * (14000 / 400) ** u, 0.7)
    f = f0 * (f1 / f0) ** (u ** 1.6)
    trem = 1 - 0.35 * (0.5 + 0.5 * np.sin(2 * np.pi * np.cumsum(3 + 22 * u ** 2) / SR))
    t1 = (osc(f, "saw") * 0.5 + osc(f * 1.007, "saw") * 0.5)
    t1 = onepole_lp(t1, 600 + 7000 * u ** 2)
    s = (fft_filter(hp, hi=9000) * (0.35 if tone else 0.6) + t1 * tone) * (u ** 2.2) * trem
    s = stereo(s, 0.6 * np.sin(2 * np.pi * u * 2))
    s = fade(s, 0.01, 0.006)
    return reverb(s, 1.4, 0.2)


def reverse_swell(dur=1.6):
    hit = impact(1.8, 160, 60, 0.4, 0.8, 1.6, 0.6, 1.6, 6000)
    sw = hit[::-1]
    sw = sw[-int(dur * SR):]
    return fade(sw, 0.05, 0.004)


def whoosh_hit():
    w = whoosh(0.7, 300, 2400, 0.75, 1.4)
    h = impact(1.4, 150, 45, 0.45, 0.7, 1.3, 0.28)
    return mix(w, at(h, 0.55))


def glide(dur=0.9, f0=300, f1=1800):
    t = t_axis(dur)
    u = t / dur
    f = f0 * (f1 / f0) ** (u ** 0.7)
    s = osc(f, "tri") * np.sin(np.pi * u) ** 1.4
    s = stereo(s, np.linspace(-0.6, 0.6, len(s)))
    return reverb(s * 0.6, 0.9, 0.25, 8000)


def glitch(dur=0.6, seed=0):
    r = np.random.default_rng(100 + seed)
    n = int(dur * SR)
    out = np.zeros(n)
    pos = 0
    while pos < n:
        ln = int(r.uniform(0.012, 0.07) * SR)
        kind = r.integers(0, 4)
        tt = np.arange(ln) / SR
        if kind == 0:
            seg = osc(np.full(ln, r.uniform(200, 2400)), "saw")
        elif kind == 1:
            seg = r.standard_normal(ln)
        elif kind == 2:
            seg = np.sign(np.sin(2 * np.pi * r.uniform(60, 900) * tt))
        else:
            seg = np.zeros(ln)
        rep = int(r.integers(1, 4))
        seg = np.resize(seg[: max(1, ln // rep)], ln)
        bits = r.integers(3, 7)
        seg = np.round(seg * 2 ** bits) / 2 ** bits
        m = max(0, min(ln, n - pos))
        out[pos:pos + m] = seg[:m] * r.uniform(0.4, 1)
        pos += ln
    hold = int(r.integers(2, 9))
    out = np.repeat(out[::hold], hold)[:n]
    return stereo(out * 0.6, r.uniform(-0.3, 0.3))


def shutter():
    a = click(0.05, 1500, 9000, 0.6)
    b = click(0.06, 900, 6000, 0.8)
    return mix(a, at(b, 0.085))


def typing(dur=1.4, seed=3):
    r = np.random.default_rng(seed)
    out = np.zeros(int(dur * SR))
    tpos = 0.02
    while tpos < dur - 0.08:
        k = click(0.05, r.uniform(700, 1400), 7000, r.uniform(0.4, 0.9)) * r.uniform(0.5, 1)
        s = int(tpos * SR)
        out[s:s + len(k)] += k[: len(out) - s]
        tpos += r.uniform(0.06, 0.16)
    return out


def heartbeat():
    def beat(f):
        t = t_axis(0.25)
        return np.sin(2 * np.pi * (f + 40 * np.exp(-t / 0.02)) * t) * np.exp(-t / 0.07)
    return mix(beat(55), at(beat(48) * 0.75, 0.22))


SOUNDS = [
    ("Whoosh Air", "Whoosh", lambda: whoosh(0.6, 500, 3400, 0.5, 2.0, air=0.12)),
    ("Whoosh Soft", "Whoosh", lambda: whoosh(0.9, 280, 1700, 0.55, 2.2)),
    ("Whoosh Heavy", "Whoosh", lambda: whoosh(1.2, 140, 1000, 0.6, 2.0, low=True)),
    ("Whoosh Fast", "Whoosh", lambda: whoosh(0.4, 600, 4000, 0.45, 2.4, pan=(-0.9, 0.9))),
    ("Whoosh Long", "Whoosh", lambda: whoosh(1.8, 240, 2100, 0.62, 2.2)),
    ("Whoosh Pass-by", "Whoosh", lambda: mix(whoosh(1.0, 380, 2500, 0.5, 2.2, pan=(-1, 1)),
                                            stereo(osc(sweep(520, 360, 1.0)) * bell(int(SR), 0.5, 0.18) * 0.25,
                                                   np.linspace(-1, 1, SR)))),
    ("Swipe Up", "Swipe", lambda: swipe(0.3, 900, 4000)),
    ("Swipe Down", "Swipe", lambda: swipe(0.3, 4000, 900, (0.6, -0.5))),
    ("Swipe Short", "Swipe", lambda: swipe(0.2, 1400, 5000, (-0.3, 0.3))),
    ("Swipe Wide", "Swipe", lambda: swipe(0.5, 700, 3600, (-1, 1))),
    ("Impact Punch", "Impact", lambda: impact(1.2, 160, 48, 0.35, 0.8, 1.1, 0.22)),
    ("Impact Soft", "Impact", lambda: impact(1.0, 120, 50, 0.3, 0.2, 0.9, 0.2, 1.2, 2500)),
    ("Impact Hard", "Impact", lambda: impact(1.6, 180, 40, 0.5, 1.0, 1.5, 0.3, 2.6, 7000)),
    ("Boom Cinematic", "Impact", boom),
    ("Metal Hit", "Impact", metal_hit),
    ("Sub Drop", "Impact", lambda: sub_drop(2.6)),
    ("Sub Drop Short", "Impact", lambda: sub_drop(1.2, 110, 34)),
    ("Pop", "Pop", lambda: pop()),
    ("Pop High", "Pop", lambda: pop(1800, 700, 0.09)),
    ("Pop Low", "Pop", lambda: pop(700, 220, 0.16, 0.15)),
    ("Bloop", "Pop", lambda: bloop()),
    ("Bubble", "Pop", lambda: mix(bloop(400, 1200, 0.12), at(bloop(500, 1500, 0.1) * 0.6, 0.09))),
    ("Click", "UI", lambda: click(0.05)),
    ("Click Soft", "UI", lambda: click(0.06, 500, 3500, 0.5)),
    ("Tick", "UI", lambda: tick()),
    ("Toggle", "UI", lambda: mix(tick(2200), at(tick(3000) * 0.7, 0.07))),
    ("Notify", "UI", lambda: chime([1318.5, 1975.5])),
    ("Success", "UI", lambda: chime([1046.5, 1318.5, 1568.0], 1.2, 0.09)),
    ("Error", "UI", buzz),
    ("Typing", "UI", typing),
    ("Shutter", "UI", shutter),
    ("Whoosh Hit", "Transition", whoosh_hit),
    ("Reverse Swell", "Transition", reverse_swell),
    ("Glide Up", "Transition", lambda: glide()),
    ("Glide Down", "Transition", lambda: glide(0.9, 1800, 300)),
    ("Riser", "Riser", lambda: riser(3.0)),
    ("Riser Short", "Riser", lambda: riser(1.6, 240, 1600)),
    ("Riser Noise", "Riser", lambda: riser(2.4, 200, 1200, 0.0)),
    ("Glitch", "Glitch", lambda: glitch(0.5, 0)),
    ("Glitch Burst", "Glitch", lambda: glitch(0.25, 1)),
    ("Glitch Long", "Glitch", lambda: glitch(1.0, 2)),
    ("Heartbeat", "Impact", heartbeat),
]


def slug(name):
    return name.lower().replace(" ", "-").replace("/", "-")


def write_wav(path, x):
    x = np.nan_to_num(np.clip(x, -1, 1))
    ch = 2
    if np.max(np.abs(x[:, 0] - x[:, 1])) < 1e-4:   # no stereo in it: mono file
        x, ch = x[:, :1], 1
    data = (x * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(ch)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())


def peaks(x, bars=26):
    m = np.abs(x).max(axis=1)
    seg = np.array_split(m, bars)
    v = np.array([s.max() if len(s) else 0 for s in seg])
    v = np.sqrt(v / (v.max() + 1e-9))
    return [round(float(a), 3) for a in v]


def main():
    os.makedirs(OUT, exist_ok=True)
    for f in os.listdir(OUT):
        if f.endswith(".wav"):
            os.remove(os.path.join(OUT, f))
    data = []
    for name, cat, fn in SOUNDS:
        x = master(fn())
        file = slug(name) + ".wav"
        write_wav(os.path.join(OUT, file), x)
        data.append({"name": name, "cat": cat, "file": "sfx/" + file,
                     "dur": round(len(x) / SR, 2), "peaks": peaks(x)})
        print("%-16s %-10s %.2fs" % (name, cat, len(x) / SR))
    js = ("/* Pillow SFX - generated by tools/sfx-gen.py: every sound is synthesized,\n"
          "   nothing third-party. Regenerate rather than edit by hand. */\n"
          "window.PILLOW_SFX = " + json.dumps(data, separators=(",", ":")) + ";\n")
    with open(os.path.join(ROOT, "js", "sfx-data.js"), "w") as f:
        f.write(js)


if __name__ == "__main__":
    main()
