/* Pillow host — ExtendScript for After Effects
 * All UI actions route through evalScript → these functions.
 * Pillow 2.2.1 — Liquid Glass + perf + theme
 */

/* older After Effects have no JSON in ExtendScript: a small writer for
   what the panel is sent (objects, arrays, strings, numbers, booleans) */
function pillowJsonWrite(v) {
  if (v === null || v === undefined) return "null";
  var t = typeof v, i, out;
  if (t === "number") return isFinite(v) ? String(v) : "null";
  if (t === "boolean") return v ? "true" : "false";
  if (t === "string") {
    out = "";
    for (i = 0; i < v.length; i++) {
      var c = v.charAt(i), k = v.charCodeAt(i);
      if (c === "\"" || c === "\\") out += "\\" + c;
      else if (k < 32 || k > 126) { var h = k.toString(16); while (h.length < 4) h = "0" + h; out += "\\u" + h; }
      else out += c;
    }
    return "\"" + out + "\"";
  }
  if (v instanceof Array) {
    out = [];
    for (i = 0; i < v.length; i++) out.push(pillowJsonWrite(v[i]));
    return "[" + out.join(",") + "]";
  }
  if (t === "object") {
    out = [];
    for (var key in v) if (v.hasOwnProperty(key) && typeof v[key] !== "function") out.push(pillowJsonWrite(String(key)) + ":" + pillowJsonWrite(v[key]));
    return "{" + out.join(",") + "}";
  }
  return "null";
}

function pillowJson(obj) {
  try {
    if (typeof JSON !== "undefined" && JSON.stringify) return JSON.stringify(obj);
    return pillowJsonWrite(obj);
  } catch (e) {
    return '{"ok":false,"error":"json"}';
  }
}

function pillowParse(str) {
  if (str == null || str === "") throw new Error("empty");
  try {
    if (typeof JSON !== "undefined" && JSON.parse) return JSON.parse(str);
  } catch (e1) {}
  return eval("(" + str + ")");
}

function pillowActiveComp() {
  try {
    if (!app || !app.project) return null;
    var item = app.project.activeItem;
    if (item && item instanceof CompItem) return item;
  } catch (e) {}
  return null;
}

/* No return from inside try/finally: ExtendScript can lose that value
   in bigger functions, and the panel then got an empty response. An
   error comes back as a readable message with its line. */
function pillowUndo(name, fn) {
  var out, err = null;
  app.beginUndoGroup("Pillow \u00b7 " + name);
  try {
    out = fn();
  } catch (e) {
    err = e;
  }
  try { app.endUndoGroup(); } catch (eEnd) {}
  if (err) {
    var msg = String(err && err.message ? err.message : err);
    try { if (err.line) msg += " (line " + err.line + ")"; } catch (eL) {}
    return pillowJson({ ok: false, error: msg });
  }
  if (out === undefined || out === null) return pillowJson({ ok: false, error: "No result from " + name });
  return out;
}

function pillowIsTextLayer(layer) {
  if (!layer) return false;
  try {
    if (layer instanceof TextLayer) return true;
  } catch (e1) {}
  try {
    if (layer.matchName === "ADBE Text Layer") return true;
  } catch (e2) {}
  try {
    return layer.property("Source Text") != null;
  } catch (e3) {}
  return false;
}

/** Set value with 2D or 3D array matching property dimensions. */
function pillowSetVec(prop, xy, zFallback) {
  if (!prop) return;
  var v = prop.value;
  if (v instanceof Array) {
    if (v.length >= 3) {
      prop.setValue([xy[0], xy[1], zFallback != null ? zFallback : (v[2] != null ? v[2] : 0)]);
    } else {
      prop.setValue([xy[0], xy[1]]);
    }
  } else {
    prop.setValue(xy[0]);
  }
}

function pillowEaseKeys(prop, t0, t1, easeIn, easeOut) {
  if (!prop) return;
  try {
    var k0 = prop.nearestKeyIndex(t0);
    var k1 = prop.nearestKeyIndex(t1);
    var dims = prop.keyInTemporalEase(k0).length;
    var ins = [], outs = [];
    for (var d = 0; d < dims; d++) {
      ins.push(easeIn);
      outs.push(easeOut);
    }
    prop.setTemporalEaseAtKey(k0, ins, outs);
    prop.setTemporalEaseAtKey(k1, ins, outs);
  } catch (e) {}
}

/* ─── Quick Create ─────────────────────────────────────────── */

/* Layers made by Quick Create say so: "Null Object (Pillow)", and each
   kind gets its own label colour, none of them After Effects' defaults
   (Red for solids / nulls / adjustment / text, Pink for cameras, Sandstone
   for precomps, Aqua for footage, Blue for shapes...), so they stand out
   on the timeline. Label numbers are AE's default label list:
   5 Lavender, 6 Peach, 10 Purple, 11 Orange, 13 Fuchsia, 14 Cyan. */
var PILLOW_LABELS = { adjustment: 11, nul: 10, camera: 14, solid: 13, text: 5, precomp: 6, flash: 13 };
function pillowMark(layer, base, kind) {
  var nm = String(base || "").replace(/\s*\(Pillow\)\s*$/, "");
  try { layer.name = nm + " (Pillow)"; } catch (e) {}
  pillowNameSource(layer, nm + " (Pillow)");
  try { layer.label = PILLOW_LABELS[kind]; } catch (e2) {}
}
/* a solid / null / adjustment layer shows its SOURCE's name in the
   Timeline's "Source Name" column ("Null 1", "Adjustment Layer"):
   its own solid gets the same name (only a solid no other layer uses) */
function pillowNameSource(layer, nm) {
  try {
    var src = layer.source;
    if (!src || !(src.mainSource instanceof SolidSource)) return;
    if (src.usedIn && src.usedIn.length > 1) return;
    src.name = nm;
  } catch (e) {}
}

/* "Fit to selected layer": the new layer takes the in and out point of
   the top selected layer and goes right above it in the stack (instead
   of the top of the comp, the whole comp long) */
function pillowFitRef(comp, fit) {
  if (!fit || !comp.selectedLayers.length) return null;
  var ref = comp.selectedLayers[0];
  for (var i = 1; i < comp.selectedLayers.length; i++) if (comp.selectedLayers[i].index < ref.index) ref = comp.selectedLayers[i];
  return ref;
}
function pillowFitToLayer(layer, ref) {
  if (!ref) return "";
  try {
    var inT = ref.inPoint, outT = ref.outPoint;
    layer.startTime = inT;
    if (inT >= layer.outPoint) { layer.outPoint = outT; layer.inPoint = inT; }
    else { layer.inPoint = inT; layer.outPoint = outT; }
  } catch (e) {}
  try { layer.moveBefore(ref); } catch (e2) {}
  return ref.name;
}

function pillowAddAdjustment(name, duration, parentSelected, fit) {
  return pillowUndo("Adjustment Layer", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var parentLayer = (parentSelected && comp.selectedLayers.length > 0) ? comp.selectedLayers[0] : null;
    var ref = pillowFitRef(comp, fit);
    var layer = comp.layers.addSolid(
      [1, 1, 1],
      name || "Adjustment Layer",
      comp.width,
      comp.height,
      comp.pixelAspect || 1,
      ref ? Math.max(comp.frameDuration, ref.outPoint - ref.inPoint) : (duration > 0 ? duration : comp.duration)
    );
    layer.adjustmentLayer = true;
    pillowMark(layer, name || "Adjustment Layer", "adjustment");
    var above = pillowFitToLayer(layer, ref);
    var parented = "";
    if (parentLayer) {
      try { layer.parent = parentLayer; parented = parentLayer.name; } catch (e) {}
    }
    return pillowJson({ ok: true, name: layer.name, parent: parented, above: above });
  });
}

function pillowAddNull(name, parentSelected, fit) {
  return pillowUndo("Null Object", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var parentLayer = (parentSelected && comp.selectedLayers.length > 0) ? comp.selectedLayers[0] : null;
    var ref = pillowFitRef(comp, fit);
    var layer = ref ? comp.layers.addNull(Math.max(comp.frameDuration, ref.outPoint - ref.inPoint)) : comp.layers.addNull();
    pillowMark(layer, name || "Null Object", "nul");
    var above = pillowFitToLayer(layer, ref);
    var parented = "";
    if (parentLayer) {
      try { layer.parent = parentLayer; parented = parentLayer.name; } catch (e) {}
    }
    return pillowJson({ ok: true, name: layer.name, parent: parented, above: above });
  });
}

function pillowAddCamera(name, twoNode, fit) {
  return pillowUndo("Camera", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var ref = pillowFitRef(comp, fit);
    var layer = comp.layers.addCamera(name || "Camera", [comp.width / 2, comp.height / 2]);
    pillowMark(layer, name || "Camera", "camera");
    var above = pillowFitToLayer(layer, ref);
    if (twoNode) {
      try {
        layer.autoOrient = AutoOrientType.CAMERA_OR_POINT_OF_INTEREST;
      } catch (e) {}
    }
    return pillowJson({ ok: true, name: layer.name, above: above });
  });
}

function pillowAddSolid(name, r, g, b, duration, parentSelected, fit) {
  return pillowUndo("Solid", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var parentLayer = (parentSelected && comp.selectedLayers.length > 0) ? comp.selectedLayers[0] : null;
    var ref = pillowFitRef(comp, fit);
    /* a white solid tinted to the colour: the colour stays a control
       (Tint > Map White To) the user can pick and animate */
    var layer = comp.layers.addSolid(
      [1, 1, 1],
      name || "Solid",
      comp.width,
      comp.height,
      comp.pixelAspect || 1,
      ref ? Math.max(comp.frameDuration, ref.outPoint - ref.inPoint) : (duration > 0 ? duration : comp.duration)
    );
    pillowMark(layer, name || "Solid", "solid");
    var above = pillowFitToLayer(layer, ref);
    try {
      var tint = layer.property("ADBE Effect Parade").addProperty("ADBE Tint");
      tint.property(1).setValue([0, 0, 0, 1]);
      tint.property(2).setValue([r, g, b, 1]);
      tint.property(3).setValue(100);
    } catch (eT) {
      try { layer.source.mainSource.color = [r, g, b]; } catch (eC) {}
    }
    var parented = "";
    if (parentLayer) {
      try { layer.parent = parentLayer; parented = parentLayer.name; } catch (e) {}
    }
    return pillowJson({ ok: true, name: layer.name, parent: parented, above: above });
  });
}

/* the layer a Create button would parent to, for the hover hint */
function pillowParentTarget() {
  var comp = pillowActiveComp();
  if (!comp) return pillowJson({ ok: false, error: "no comp" });
  var sel = comp.selectedLayers, top = pillowFitRef(comp, true);
  return pillowJson({ ok: true, name: sel.length ? sel[0].name : "", top: top ? top.name : "", count: sel.length });
}

/* ─── SFX ──────────────────────────────────────────────────────
 * A sound from Pillow's library (sfx/*.wav, inside the extension): it is
 * imported once into the project folder "Pillow SFX" (the same file is
 * reused next time) and, with a comp open, laid in at the playhead on a
 * new layer "<name> (Pillow)" at the top. */
function pillowAddSfx(json) {
  var o = {};
  try { o = pillowParse(decodeURIComponent(json)); } catch (e0) { return pillowJson({ ok: false, error: "Bad sound data." }); }
  var f = new File(o.file);
  if (!f.exists) return pillowJson({ ok: false, error: "Sound file not found: " + o.file });
  return pillowUndo("SFX \u00b7 " + (o.name || "Sound"), function () {
    var proj = app.project, i, item = null, folder = null;
    for (i = 1; i <= proj.numItems; i++) {
      var it = proj.item(i);
      if (!folder && it instanceof FolderItem && it.name === "Pillow SFX") folder = it;
      try { if (!item && it instanceof FootageItem && it.mainSource && it.mainSource.file && it.mainSource.file.fsName === f.fsName) item = it; } catch (eI) {}
    }
    if (!item) {
      item = proj.importFile(new ImportOptions(f));
      try { item.name = (o.name || item.name) + " (Pillow)"; } catch (eN) {}
      if (!folder) folder = proj.items.addFolder("Pillow SFX");
      try { item.parentFolder = folder; } catch (eF) {}
    }
    var comp = pillowActiveComp(), inComp = false, name = item.name;
    if (comp) {
      var L = comp.layers.add(item);
      L.startTime = comp.time;
      try { L.name = String(o.name || name).replace(/\s*\(Pillow\)\s*$/, "") + " (Pillow)"; } catch (eL) {}
      try { L.label = 14; } catch (eLb) {}
      inComp = true;
    }
    return pillowJson({ ok: true, name: name, inComp: inComp });
  });
}

/* ─── Anchor Point ─────────────────────────────────────────── */

var PILLOW_ANCHOR_POS = {
  tl: [0, 0],   tc: [0.5, 0],   tr: [1, 0],
  ml: [0, 0.5], mc: [0.5, 0.5], mr: [1, 0.5],
  bl: [0, 1],   bc: [0.5, 1],   br: [1, 1]
};

/* shift a property by d, keyframes included (setValue throws on a keyed property) */
function pillowShiftProp(prop, d) {
  function add(v) {
    if (!(v instanceof Array)) return v + d[0];
    var r = v.slice(0);
    for (var i = 0; i < r.length && i < d.length; i++) r[i] += d[i];
    return r;
  }
  if (prop.numKeys > 0) { for (var k = 1; k <= prop.numKeys; k++) prop.setValueAtKey(k, add(prop.keyValue(k))); }
  else prop.setValue(add(prop.value));
}

/* every selected layer (cameras and lights have no box) gets its anchor
   on the chosen point of its own box at the current time; Position takes
   the same shift through the layer's scale and rotation, so nothing moves */
function pillowSetAnchor(pos) {
  return pillowUndo("Anchor Point", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    if (comp.selectedLayers.length === 0) {
      return pillowJson({ ok: false, error: "Select a layer." });
    }
    var frac = PILLOW_ANCHOR_POS[pos];
    if (!frac) return pillowJson({ ok: false, error: "Unknown anchor position." });

    var sel = comp.selectedLayers, done = 0, first = "", skipped = 0;
    for (var li = 0; li < sel.length; li++) {
      var layer = sel[li];
      if (layer instanceof CameraLayer || layer instanceof LightLayer) { skipped++; continue; }
      try {
        var rect = layer.sourceRectAtTime(comp.time, false);
        var tg = layer.property("ADBE Transform Group");
        var anchorProp = tg.property("ADBE Anchor Point");
        var oldAnchor = anchorProp.valueAtTime(comp.time, false);
        var dLocalX = rect.left + rect.width * frac[0] - oldAnchor[0];
        var dLocalY = rect.top + rect.height * frac[1] - oldAnchor[1];
        if (Math.abs(dLocalX) < 1e-6 && Math.abs(dLocalY) < 1e-6) { done++; if (!first) first = layer.name; continue; }

        /* Position absorbs the same shift in the parent's space: the
           delta goes through the layer's own scale and rotation, as when
           the anchor tool is dragged by hand */
        var scale = tg.property("ADBE Scale").valueAtTime(comp.time, false);
        var sx = (scale[0] === 0 ? 0 : scale[0] || 100) / 100, sy = (scale[1] === 0 ? 0 : scale[1] || 100) / 100;
        var rotDeg = 0;
        try { rotDeg = tg.property("ADBE Rotate Z").valueAtTime(comp.time, false); } catch (eRot) {}
        var rad = (rotDeg || 0) * Math.PI / 180, cos = Math.cos(rad), sin = Math.sin(rad);
        var scaledX = dLocalX * sx, scaledY = dLocalY * sy;
        var dCompX = scaledX * cos - scaledY * sin;
        var dCompY = scaledX * sin + scaledY * cos;

        var posProp = tg.property("ADBE Position");
        if (posProp.dimensionsSeparated) {
          pillowShiftProp(tg.property("ADBE Position_0"), [dCompX]);
          pillowShiftProp(tg.property("ADBE Position_1"), [dCompY]);
        } else {
          pillowShiftProp(posProp, [dCompX, dCompY, 0]);
        }
        pillowShiftProp(anchorProp, [dLocalX, dLocalY, 0]);
        done++;
        if (!first) first = layer.name;
      } catch (eL) { skipped++; }
    }
    if (!done) return pillowJson({ ok: false, error: "These layers have no box to anchor to." });
    return pillowJson({ ok: true, pos: pos, name: first, count: done, skipped: skipped });
  });
}

function pillowPrecompose(name) {
  return pillowUndo("Pre-compose", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    if (comp.selectedLayers.length === 0) {
      return pillowJson({ ok: false, error: "Select one or more layers." });
    }
    var idxs = [];
    for (var i = 0; i < comp.selectedLayers.length; i++) {
      idxs.push(comp.selectedLayers[i].index);
    }
    idxs.sort(function (a, b) { return a - b; });
    var nm = String(name || "Pre-comp").replace(/\s*\(Pillow\)\s*$/, "") + " (Pillow)";
    comp.layers.precompose(idxs, nm, true);
    /* the new precomp layer sits where the top selected layer was */
    try { comp.layer(idxs[0]).label = PILLOW_LABELS.precomp; } catch (eL) {}
    return pillowJson({ ok: true, name: nm });
  });
}

/** Classic "stagger" / лесенка: the bottommost selected layer stays
 *  exactly where it is, and every layer above it is butted straight up
 *  against the one below — next layer's startTime = previous layer's
 *  (possibly already-moved) outPoint, no gap, no fixed offset. Order
 *  comes from layer.index (the Timeline's own stacking order — index 1
 *  is the topmost layer, so the bottommost selected layer has the
 *  highest index and goes first), never selection click order, since AE
 *  doesn't guarantee comp.selectedLayers reflects the order layers were
 *  clicked in. Each layer's own trimmed length (outPoint - startTime) is
 *  read before it's moved and re-applied after, so only startTime
 *  changes — duration, content, Position and every other property are
 *  untouched. A layer that fails to move (e.g. locked) is skipped
 *  without breaking the chain: the next one butts up against its actual,
 *  unmoved position instead. */
function pillowStagger() {
  return pillowUndo("Stagger", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var sel = comp.selectedLayers;
    if (!sel || sel.length < 2) {
      return pillowJson({ ok: false, error: "Select two or more layers to stagger." });
    }

    var layers = [];
    for (var i = 0; i < sel.length; i++) layers.push(sel[i]);
    layers.sort(function (a, b) { return b.index - a.index; });

    /* each clip's visible start (its in point) goes to where the one before
       it ends. The whole layer moves by that amount, so a clip trimmed at
       its head keeps its trim and there is no gap; the old code put the
       layer's start time there, and the trimmed head left a hole. */
    /* AE does not keep the trims of every layer when only its start time
       changes (a head-trimmed clip could come back untrimmed or keep its
       old in point), so each clip's visible span is written back
       explicitly: same trim, same length, on whole frames. Locked layers
       are unlocked for the move and locked again. */
    var fd = comp.frameDuration || (1 / 30);
    function snap(t) { return Math.round(t / fd) * fd; }
    var cursor = snap(layers[0].outPoint), skipped = 0;
    for (var j = 1; j < layers.length; j++) {
      var L = layers[j];
      var inP = L.inPoint, outP = L.outPoint, len = snap(outP - inP);
      var headTrim = inP - L.startTime;
      var wasLocked = false;
      try { wasLocked = L.locked; if (wasLocked) L.locked = false; } catch (eL) {}
      try {
        L.startTime = cursor - headTrim;
        if (Math.abs(L.inPoint - cursor) > fd / 4 || Math.abs(L.outPoint - (cursor + len)) > fd / 4) {
          /* outPoint first when moving later, inPoint first when moving earlier,
             so the span never inverts on the way */
          if (cursor > L.inPoint) { L.outPoint = cursor + len; L.inPoint = cursor; }
          else { L.inPoint = cursor; L.outPoint = cursor + len; }
        }
      } catch (e) { skipped++; }
      try { if (wasLocked) L.locked = true; } catch (eL2) {}
      cursor = snap(L.outPoint);
    }

    return pillowJson({ ok: true, count: layers.length, skipped: skipped });
  });
}

/* ─── Curves / Easing ──────────────────────────────────────── */

function pillowEaseOnLayer(layer, easeIn, easeOut) {
  var count = 0;
  function walk(group) {
    for (var i = 1; i <= group.numProperties; i++) {
      var p = group.property(i);
      if (!p) continue;
      if (p.propertyType === PropertyType.PROPERTY) {
        if (p.canSetExpression && p.numKeys > 0) {
          for (var k = 1; k <= p.numKeys; k++) {
            var selected = false;
            try { selected = p.keySelected(k); } catch (e) { selected = false; }
            if (selected) {
              try {
                var dims = p.keyInTemporalEase(k).length;
                var ins = [];
                var outs = [];
                for (var d = 0; d < dims; d++) {
                  ins.push(easeIn);
                  outs.push(easeOut);
                }
                p.setTemporalEaseAtKey(k, ins, outs);
                count++;
              } catch (e2) {}
            }
          }
        }
      } else if (
        p.propertyType === PropertyType.INDEXED_GROUP ||
        p.propertyType === PropertyType.NAMED_GROUP
      ) {
        try { walk(p); } catch (e3) {}
      }
    }
  }
  try { walk(layer); } catch (e) {}
  try {
    var t = layer.property("ADBE Transform Group");
    if (t) walk(t);
  } catch (e4) {}
  return count;
}

function pillowApplyCurve(curveJson) {
  return pillowUndo("Apply Curve", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    if (comp.selectedLayers.length === 0) {
      return pillowJson({ ok: false, error: "Select a layer with keyframes." });
    }

    var data;
    try {
      data = pillowParse(curveJson);
    } catch (eParse) {
      return pillowJson({ ok: false, error: "Bad curve data." });
    }

    if (data.mode === "ease") {
      var easeIn = new KeyframeEase(data.inSpeed || 0, Math.max(0.1, Math.min(100, data.inInfl || 33)));
      var easeOut = new KeyframeEase(data.outSpeed || 0, Math.max(0.1, Math.min(100, data.outInfl || 33)));
      var applied = 0;
      for (var li = 0; li < comp.selectedLayers.length; li++) {
        applied += pillowEaseOnLayer(comp.selectedLayers[li], easeIn, easeOut);
      }
      if (applied === 0) {
        return pillowJson({ ok: false, error: "No selected keys found. Select keys in the Timeline." });
      }
      return pillowJson({ ok: true, keys: applied, mode: "ease" });
    }

    if (data.mode === "bake") {
      var samples = data.samples || [];
      if (samples.length < 2) return pillowJson({ ok: false, error: "Not enough curve samples." });
      var baked = 0;
      for (var lj = 0; lj < comp.selectedLayers.length; lj++) {
        baked += pillowBakeCurveOnLayer(comp.selectedLayers[lj], samples);
      }
      if (baked === 0) {
        return pillowJson({ ok: false, error: "Select the start & end keyframes on a property first." });
      }
      return pillowJson({ ok: true, keys: baked, mode: "bake" });
    }

    return pillowJson({ ok: false, error: "Unknown curve mode." });
  });
}

function pillowBakeCurveOnLayer(layer, samples) {
  var count = 0;
  function walk(group) {
    for (var i = 1; i <= group.numProperties; i++) {
      var p = group.property(i);
      if (!p) continue;
      if (p.propertyType === PropertyType.PROPERTY) {
        if (p.canVaryOverTime && p.numKeys >= 2) {
          var selIdx = [];
          for (var k = 1; k <= p.numKeys; k++) {
            var selected = false;
            try { selected = p.keySelected(k); } catch (eSel) { selected = false; }
            if (selected) selIdx.push(k);
          }
          if (selIdx.length >= 2) {
            var firstK = selIdx[0];
            var lastK = selIdx[selIdx.length - 1];
            var t0 = p.keyTime(firstK);
            var t1 = p.keyTime(lastK);
            var v0 = p.keyValue(firstK);
            var v1 = p.keyValue(lastK);

            for (var rk = lastK - 1; rk > firstK; rk--) {
              try { p.removeKey(rk); } catch (eRem) {}
            }

            var isArray = v0 instanceof Array;
            for (var s = 0; s < samples.length; s++) {
              var t = t0 + (t1 - t0) * samples[s].t;
              var v = samples[s].v;
              var val;
              if (isArray) {
                val = [];
                for (var d = 0; d < v0.length; d++) {
                  val.push(v0[d] + (v1[d] - v0[d]) * v);
                }
              } else {
                val = v0 + (v1 - v0) * v;
              }
              try { p.setValueAtTime(t, val); } catch (eSet) {}
            }
            count++;
          }
        }
      } else if (
        p.propertyType === PropertyType.INDEXED_GROUP ||
        p.propertyType === PropertyType.NAMED_GROUP
      ) {
        try { walk(p); } catch (eWalk) {}
      }
    }
  }
  try { walk(layer); } catch (eTop) {}
  try {
    var t = layer.property("ADBE Transform Group");
    if (t) walk(t);
  } catch (eT) {}
  return count;
}

/* ─── Text Animations ─────────────────────────────────────────
 * Fixed in 2.0:
 *  - Reliable text-layer detection (not fragile instanceof alone)
 *  - 2D-safe Position / Scale / Blur vectors
 *  - Correct range-selector sweep (Start 0→100) for opacity reveal
 *  - Dimension-aware temporal ease
 *  - Robust JSON parse
 */

function pillowApplyTextPreset(payloadJson) {
  return pillowUndo("Text Animation", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });

    var data;
    try {
      data = pillowParse(payloadJson);
    } catch (eParse) {
      return pillowJson({ ok: false, error: "Bad animation data." });
    }

    var layer = null;
    var madeNew = false;

    if (comp.selectedLayers.length > 0 && pillowIsTextLayer(comp.selectedLayers[0])) {
      layer = comp.selectedLayers[0];
    } else {
      layer = comp.layers.addText(data.text || "Pillow");
      pillowMark(layer, data.layerName || "Text", "text");
      madeNew = true;
      try {
        var doc = layer.property("Source Text").value;
        doc.fontSize = Math.round(comp.height * 0.08);
        doc.fillColor = [0.96, 0.94, 0.91];
        doc.justification = ParagraphJustification.CENTER_JUSTIFY;
        layer.property("Source Text").setValue(doc);
      } catch (eDoc) {}
      try {
        layer.property("ADBE Transform Group").property("ADBE Position").setValue([
          comp.width / 2,
          comp.height / 2
        ]);
      } catch (ePos) {}
      /* a new layer starts at the playhead, so its In plays there */
      try { if (comp.time > 0 && comp.time < comp.duration - comp.frameDuration) layer.inPoint = comp.time; } catch (eIn) {}
    }

    if (!madeNew && data.text && data.updateText) {
      try {
        var docNow = layer.property("Source Text").value;
        if (String(docNow.text) !== String(data.text)) {
          docNow.text = data.text;
          layer.property("Source Text").setValue(docNow);
        }
      } catch (eText) {}
    }

    /* As in Animation Composer: In starts at the layer's in point, Out
       ends at its out point (both kept inside the comp); Delay moves In
       later / Out earlier. span = the whole animation, stagger included. */
    var dir = data.direction === "out" ? "out" : "in";
    var dur = Math.max(0.05, data.duration || 0.6);
    var span = dur;
    if (data.expr && data.basedOn !== "all") {
      span = dur + Math.max(0, data.stagger || 0) * (pillowTextUnitCount(layer, data.basedOn) - 1);
    }
    var lIn = Math.max(0, layer.inPoint), lOut = Math.min(comp.duration, layer.outPoint);
    if (lOut <= lIn) { lIn = layer.inPoint; lOut = layer.outPoint; }
    var delay = Math.max(0, data.delay || 0);
    var t0 = dir === "out" ? Math.max(lIn, lOut - delay - span) : Math.min(lIn + delay, Math.max(lIn, lOut - span));

    /* offsets and blur written for a 100 px font follow the layer's own
       font size, so the move keeps its proportions on any text */
    if (data.rel) {
      var fsz = 100;
      try { fsz = layer.property("ADBE Text Properties").property("ADBE Text Document").value.fontSize || 100; } catch (eFs) {}
      var kf = Math.max(0.2, Math.min(6, fsz / 100));
      if (data.dx) data.dx *= kf;
      if (data.dy) data.dy *= kf;
      if (data.blur) data.blur *= kf;
    }

    try {
      if (data.flicker) {
        pillowFlickerLayer(layer, t0, dur, dir);
      } else if (data.basedOn === "all") {
        pillowWholeLayerTextAnim(layer, data, dir, t0, dur);
      } else {
        pillowAnimatorTextSweep(layer, data, dir, t0, dur);
      }
    } catch (eApply) {
      return pillowJson({ ok: false, error: "Apply failed: " + String(eApply) });
    }

    /* the timing marker: In ends / Out starts here (drag it to retime).
       A per-letter animator replaces the previous one, so its markers go
       too; a whole-layer preset only replaces its own direction's. */
    var perUnit = !data.flicker && data.basedOn !== "all";
    try {
      pillowSetAnimMarker(layer, dir === "out" ? PILLOW_MK_OUT : PILLOW_MK_IN, dir === "out" ? t0 : t0 + span, perUnit);
    } catch (eMk) {}

    return pillowJson({
      ok: true,
      name: layer.name,
      preset: data.presetId,
      direction: dir,
      created: madeNew
    });
  });
}

function pillowWholeLayerTextAnim(layer, data, dir, t0, dur) {
  var tg = layer.property("ADBE Transform Group");
  var opac = tg.property("ADBE Opacity");
  var pos = tg.property("ADBE Position");
  var scaleP = tg.property("ADBE Scale");
  var rotP = tg.property("ADBE Rotate Z");

  var basePos = pos.value;
  var baseScale = scaleP.value;
  var baseRot = rotP ? rotP.value : 0;

  var offOpac = data.opacityFrom != null ? data.opacityFrom : 0;
  var onOpac = 100;
  var dx = data.dx || 0, dy = data.dy || 0;
  var scaleFrom = data.scaleFrom != null ? data.scaleFrom : null;
  var rotFrom = data.rotate != null ? data.rotate : null;

  var offPos, onPos;
  if (basePos.length >= 3) {
    offPos = [basePos[0] + dx, basePos[1] + dy, basePos[2]];
    onPos = [basePos[0], basePos[1], basePos[2]];
  } else {
    offPos = [basePos[0] + dx, basePos[1] + dy];
    onPos = [basePos[0], basePos[1]];
  }

  var offScale, onScale;
  if (baseScale.length >= 3) {
    offScale = scaleFrom != null ? [scaleFrom, scaleFrom, baseScale[2]] : baseScale;
    onScale = [baseScale[0], baseScale[1], baseScale[2]];
  } else {
    offScale = scaleFrom != null ? [scaleFrom, scaleFrom] : baseScale;
    onScale = [baseScale[0], baseScale[1]];
  }

  var offRot = rotFrom != null ? baseRot + rotFrom : baseRot;
  var onRot = baseRot;

  var startO = dir === "in" ? offOpac : onOpac;
  var endO = dir === "in" ? onOpac : offOpac;
  var startP = dir === "in" ? offPos : onPos;
  var endP = dir === "in" ? onPos : offPos;
  var startS = dir === "in" ? offScale : onScale;
  var endS = dir === "in" ? onScale : offScale;
  var startR = dir === "in" ? offRot : onRot;
  var endR = dir === "in" ? onRot : offRot;

  opac.setValueAtTime(t0, startO);
  opac.setValueAtTime(t0 + dur, endO);
  if (dx || dy) {
    pos.setValueAtTime(t0, startP);
    pos.setValueAtTime(t0 + dur, endP);
  }
  if (scaleFrom != null) {
    scaleP.setValueAtTime(t0, startS);
    scaleP.setValueAtTime(t0 + dur, endS);
  }
  if (rotFrom != null && rotP) {
    rotP.setValueAtTime(t0, startR);
    rotP.setValueAtTime(t0 + dur, endR);
  }

  /* the preset's own curve, as in the preview */
  pillowEaseBezier(opac, t0, t0 + dur, data.ease, dir);
  if (dx || dy) pillowEaseBezier(pos, t0, t0 + dur, data.ease, dir);
  if (scaleFrom != null) pillowEaseBezier(scaleP, t0, t0 + dur, data.ease, dir);
  if (rotFrom != null && rotP) pillowEaseBezier(rotP, t0, t0 + dur, data.ease, dir);
  pillowRetime(opac, dir, t0, t0 + dur);
  if (dx || dy) pillowRetime(pos, dir, t0, t0 + dur);
  if (scaleFrom != null) pillowRetime(scaleP, dir, t0, t0 + dur);
  if (rotFrom != null && rotP) pillowRetime(rotP, dir, t0, t0 + dur);

  // Optional layer blur via Fast Blur / Gaussian for "all" mode
  if (data.blur && data.blur > 0) {
    try {
      var fx = layer.property("ADBE Effect Parade");
      var blurFx = null;
      for (var bi = 1; bi <= fx.numProperties; bi++) {
        if (fx.property(bi).name.indexOf("Pillow Blur") === 0) {
          blurFx = fx.property(bi);
          break;
        }
      }
      if (!blurFx) {
        try {
          blurFx = fx.addProperty("ADBE Gaussian Blur 2");
        } catch (eG) {
          try { blurFx = fx.addProperty("ADBE Fast Blur"); } catch (eF) {}
        }
        if (blurFx) blurFx.name = "Pillow Blur";
      }
      if (blurFx) {
        var blurAmt = blurFx.property("Blurriness") || blurFx.property(1);
        if (blurAmt) {
          var bStart = dir === "in" ? data.blur : 0;
          var bEnd = dir === "in" ? 0 : data.blur;
          blurAmt.setValueAtTime(t0, bStart);
          blurAmt.setValueAtTime(t0 + dur, bEnd);
          pillowEaseBezier(blurAmt, t0, t0 + dur, data.ease, dir);
          pillowRetime(blurAmt, dir, t0, t0 + dur);
        }
      }
    } catch (eBlurLayer) {}
  }
}

/* Text animator matchNames, as AE knows them. Position and Scale are
   the 3D variants (the 2D names do not exist); Based On, Smoothness and
   Mode of a Range Selector live in its Advanced group. */
var PILLOW_TEXT_UNITS = { "char": 1, "word": 3, "line": 4 };

function pillowTextAddProp(props, names) {
  for (var i = 0; i < names.length; i++) {
    try { var p = props.addProperty(names[i]); if (p) return p; } catch (e) {}
  }
  return null;
}

/* the first Range Selector of an animator, made if it has none (a
   scripted animator starts with no selector at all; property(1) on the
   empty group throws "Unable to call property because of parameter 1") */
function pillowTextRangeSelector(animator) {
  var selectors = animator.property("ADBE Text Selectors");
  for (var i = 1; i <= selectors.numProperties; i++) {
    try { if (selectors.property(i).matchName === "ADBE Text Selector") return selectors.property(i); } catch (e) {}
  }
  return selectors.addProperty("ADBE Text Selector");
}

function pillowSetBasedOn(selector, basedOn) {
  var val = PILLOW_TEXT_UNITS[basedOn] || 1;
  try {
    var adv = selector.property("ADBE Text Range Advanced");
    if (adv) { adv.property("ADBE Text Range Type2").setValue(val); return; }
  } catch (e) {}
  try { selector.property("ADBE Text Range Type2").setValue(val); } catch (e2) {}
}

function pillowAnimatorTextSweep(layer, data, dir, t0, dur) {
  var textProp = layer.property("ADBE Text Properties");
  if (!textProp) throw new Error("Not a text layer.");
  var animators = textProp.property("ADBE Text Animators");
  if (!animators) throw new Error("No text animators group.");

  for (var a = animators.numProperties; a >= 1; a--) {
    try {
      if (animators.property(a).name.indexOf("Pillow") === 0) animators.property(a).remove();
    } catch (eRm) {}
  }

  var animator = animators.addProperty("ADBE Text Animator");
  animator.name = "Pillow \u00b7 " + (data.presetId || "anim");

  /* 1 - the animator's values: the "off" state of a selected character.
     Each value is set right after its property is added (adding the next
     one may invalidate the reference to the previous). */
  var props = animator.property("ADBE Text Animator Properties");
  var opac = pillowTextAddProp(props, ["ADBE Text Opacity"]);
  if (opac) opac.setValue(data.opacityFrom != null ? data.opacityFrom : 0);
  if (data.blur) {
    var blur = pillowTextAddProp(props, ["ADBE Text Blur"]);
    if (blur) { try { pillowSetVec(blur, [data.blur, data.blur], 0); } catch (eBlur) {} }
  }
  if (data.dx || data.dy) {
    var posP = pillowTextAddProp(props, ["ADBE Text Position 3D", "ADBE Text Position"]);
    if (posP) { try { pillowSetVec(posP, [data.dx || 0, data.dy || 0], 0); } catch (ePos2) {} }
  }
  /* scale: uniform (scaleFrom) or per axis (scaleXY, the squash of the
     Bounce presets: [100, 0] is a word flattened to a line) */
  if (data.scaleXY || data.scaleFrom != null) {
    var sxy = data.scaleXY || [data.scaleFrom, data.scaleFrom];
    var scP = pillowTextAddProp(props, ["ADBE Text Scale 3D", "ADBE Text Scale"]);
    if (scP) { try { pillowSetVec(scP, [sxy[0], sxy[1]], 100); } catch (eScale) {} }
  }
  if (data.rotate) {
    var rotP2 = pillowTextAddProp(props, ["ADBE Text Rotation"]);
    if (rotP2) { try { rotP2.setValue(data.rotate); } catch (eRot) {} }
  }
  if (data.tracking) {
    var trP = pillowTextAddProp(props, ["ADBE Text Tracking Amount"]);
    if (trP) { try { trP.setValue(data.tracking); } catch (eTrack) {} }
  }

  /* 2 - the Range Selector, fetched only now, after the properties */
  var selector = pillowTextRangeSelector(animator);
  pillowSetBasedOn(selector, data.basedOn);
  try {
    var smooth = data.smoothness != null ? data.smoothness : 60;
    selector.property("ADBE Text Range Advanced").property("ADBE Text Selector Smoothness").setValue(Math.max(0, Math.min(100, smooth)));
  } catch (eSmooth) {}
  try { selector.property("ADBE Text Percent Start").setValue(0); } catch (eS2) {}
  try { selector.property("ADBE Text Percent End").setValue(100); } catch (eE2) {}
  try { selector.property("ADBE Text Percent Offset").setValue(0); } catch (eO2) {}

  /* Bounce presets: no Start sweep; an Expression Selector drives each
     character's (word's) amount with a damped spring of its own, started
     one stagger after the previous one. The Range Selector stays and
     covers the whole text: the Expression Selector works in Intersect
     mode, and on its own (nothing above it to intersect with) it selects
     nothing, so the text would just stand still. */
  if (data.expr) {
    pillowTextSpringSelector(animator.property("ADBE Text Selectors"), data, dir, t0, dur, layer.startTime);
    return;
  }

  /* Opacity reveal: animator Opacity 0 = selected characters invisible.
   * IN:  Start 0 -> 100 (all selected -> none selected): invisible -> visible
   * OUT: Start 100 -> 0 (none -> all): visible -> invisible */
  var startProp = selector.property("ADBE Text Percent Start");
  if (dir === "in") {
    startProp.setValueAtTime(t0, 0);
    startProp.setValueAtTime(t0 + dur, 100);
  } else {
    startProp.setValueAtTime(t0, 100);
    startProp.setValueAtTime(t0 + dur, 0);
  }
  pillowEaseKeys(startProp, t0, t0 + dur, new KeyframeEase(0, 78), new KeyframeEase(0, 62));
  pillowRetime(startProp, dir, t0, t0 + dur);
}

/* --- Text timing markers (as in Animation Composer) ---------
 * Every text animation leaves a layer marker: "Pillow In" where the In
 * animation ends, "Pillow Out" where the Out animation starts. Dragging
 * the marker retimes the animation: keyframed presets get an expression
 * that stretches the time between their keys to the marker (their easing
 * is kept), the Bounce presets read the marker in their own expression.
 * Keys and markers belong to the layer, so moving the layer moves both.
 */
var PILLOW_MK_IN = "Pillow In";
var PILLOW_MK_OUT = "Pillow Out";
var PILLOW_TIMING_TAG = "// Pillow timing";

/* the expression lines that find both markers (layer marker, comp time) */
var PILLOW_MK_FIND =
  "var mIn = null, mOut = null, mk = thisLayer.marker;\n" +
  "for (var i = 1; i <= mk.numKeys; i++) {\n" +
  "  var cm = mk.key(i).comment;\n" +
  "  if (cm == \"" + PILLOW_MK_IN + "\" && mIn === null) mIn = mk.key(i).time;\n" +
  "  if (cm == \"" + PILLOW_MK_OUT + "\" && mOut === null) mOut = mk.key(i).time;\n" +
  "}\n";

function pillowSetAnimMarker(layer, comment, t, clearBoth) {
  var mk = layer.property("ADBE Marker");
  if (!mk) return;
  for (var i = mk.numKeys; i >= 1; i--) {
    var c = "";
    try { c = mk.keyValue(i).comment; } catch (e) {}
    if (c === comment || (clearBoth && (c === PILLOW_MK_IN || c === PILLOW_MK_OUT))) {
      try { mk.removeKey(i); } catch (e2) {}
    }
  }
  mk.setValueAtTime(t, new MarkerValue(comment));
}

/* In keys are the first IN_N keys of the property, Out keys the last OUT_N.
   Before the In marker the In keys are stretched to end at it; after the
   Out marker the Out keys are stretched to start at it; between the two
   the property holds. A missing marker leaves its keys as they are. */
function pillowTimingExpr(inN, outN) {
  return PILLOW_TIMING_TAG + " - drag the \"" + PILLOW_MK_IN + "\" / \"" + PILLOW_MK_OUT + "\" layer markers to retime\n" +
    "var IN_N = " + inN + ", OUT_N = " + outN + ";\n" +
    PILLOW_MK_FIND +
    "var n = numKeys, f = thisComp.frameDuration, T = time;\n" +
    "var hasIn = IN_N > 1 && mIn !== null && n >= IN_N;\n" +
    "var hasOut = OUT_N > 1 && mOut !== null && n >= OUT_N;\n" +
    "if (hasIn || hasOut) {\n" +
    "  var a = key(1).time, b = hasIn ? key(IN_N).time : a;\n" +
    "  var c = hasOut ? key(n - OUT_N + 1).time : b, d = key(n).time;\n" +
    "  var s = hasOut ? Math.min(mOut, d - f) : d;\n" +
    "  var e = hasIn ? Math.max(mIn, a + f) : a;\n" +
    "  if (hasOut && time >= s) T = d - (d - time) * (d - c) / (d - s);\n" +
    "  else if (hasIn && time <= e) T = time <= a ? time : a + (time - a) * (b - a) / (e - a);\n" +
    "  else if (hasIn && hasOut) T = b;\n" +
    "  else if (hasIn) T = Math.max(time, b);\n" +
    "  else T = Math.min(time, c);\n" +
    "}\n" +
    "valueAtTime(T);";
}

/* hang the timing expression on a property whose keys Pillow just wrote
   (t0..t1). A property with an expression of the user's own, or with keys
   that are not all Pillow's, is left alone. */
function pillowRetime(prop, dir, t0, t1) {
  if (!prop) return;
  try {
    if (!prop.canSetExpression || prop.numKeys < 2) return;
    var old = "";
    try { old = prop.expression || ""; } catch (eX) {}
    if (old && old.indexOf(PILLOW_TIMING_TAG) !== 0) return;
    var cnt = 0, k, m;
    for (k = 1; k <= prop.numKeys; k++) {
      var kt = prop.keyTime(k);
      if (kt >= t0 - 0.0005 && kt <= t1 + 0.0005) cnt++;
    }
    var inN = 0, outN = 0;
    if (old) {
      m = /IN_N = (\d+)/.exec(old); if (m) inN = parseInt(m[1], 10);
      m = /OUT_N = (\d+)/.exec(old); if (m) outN = parseInt(m[1], 10);
    }
    if (dir === "in") inN = cnt; else outN = cnt;
    if (inN + outN !== prop.numKeys) {
      /* the other segment's keys are gone or were never Pillow's: only
         this application's own keys can be retimed, if they are all */
      if (cnt !== prop.numKeys) return;
      if (dir === "in") outN = 0; else inN = 0;
    }
    prop.expression = pillowTimingExpr(inN, outN);
  } catch (e) {}
}

/* how many characters / words / lines the layer's text has (the Bounce
   marker goes where its last unit settles) */
function pillowTextUnitCount(layer, basedOn) {
  var txt = "";
  try { txt = String(layer.property("ADBE Text Properties").property("ADBE Text Document").value.text); } catch (e) {}
  if (!txt) return 1;
  if (basedOn === "word") { var w = txt.match(/\S+/g); return w ? w.length : 1; }
  if (basedOn === "line") return txt.split(/\r\n|\r|\n/).length;
  return txt.length;
}

/* a preset's easing as [x1, y1, x2, y2] (the panel's cubic-bezier) */
function pillowTextBezier(e) {
  if (e instanceof Array && e.length === 4) {
    var out = [], i;
    for (i = 0; i < 4; i++) out.push(Math.round(Number(e[i]) * 1000) / 1000);
    out[0] = Math.max(0.001, Math.min(1, out[0]));
    out[2] = Math.max(0, Math.min(0.999, out[2]));
    return out;
  }
  return [0.22, 1, 0.36, 1];
}

/* keys t0 -> t1 of prop eased on that curve, exactly: AE's temporal
   bezier is the curve itself when the first key leaves at influence x1
   with speed (y1 / x1) * change / time and the last arrives at
   influence 1 - x2 with speed ((1 - y2) / (1 - x2)) * change / time.
   Out uses the curve mirrored (slow away, then quick). */
function pillowEaseBezier(prop, t0, t1, ease, dir) {
  if (!prop) return;
  try {
    var b = pillowTextBezier(ease);
    if (dir === "out") b = [1 - b[2], 1 - b[3], 1 - b[0], 1 - b[1]];
    b[0] = Math.max(0.001, b[0]); b[2] = Math.min(0.999, b[2]);
    var k0 = prop.nearestKeyIndex(t0), k1 = prop.nearestKeyIndex(t1);
    if (k0 === k1) return;
    var v0 = prop.keyValue(k0), v1 = prop.keyValue(k1), dt = Math.max(0.001, prop.keyTime(k1) - prop.keyTime(k0));
    var deltas = [], d;
    if (prop.isSpatial) {
      var sq = 0;
      for (d = 0; d < v0.length; d++) sq += (v1[d] - v0[d]) * (v1[d] - v0[d]);
      deltas.push(Math.sqrt(sq));
    } else if (v0 instanceof Array) {
      for (d = 0; d < v0.length; d++) deltas.push(v1[d] - v0[d]);
    } else deltas.push(v1 - v0);
    var dims = prop.keyInTemporalEase(k0).length, a0i = [], a0o = [], a1i = [], a1o = [];
    for (d = 0; d < dims; d++) {
      var ch = (deltas.length > d ? deltas[d] : deltas[0]) / dt;
      a0i.push(new KeyframeEase(0, 33.33));
      a0o.push(new KeyframeEase(ch * b[1] / b[0], Math.max(0.1, Math.min(100, b[0] * 100))));
      a1i.push(new KeyframeEase(ch * (1 - b[3]) / (1 - b[2]), Math.max(0.1, Math.min(100, (1 - b[2]) * 100))));
      a1o.push(new KeyframeEase(0, 33.33));
    }
    prop.setTemporalEaseAtKey(k0, a0i, a0o);
    prop.setTemporalEaseAtKey(k1, a1i, a1o);
  } catch (e) {}
}

/* The amount of a Bounce preset, per character (word, line), 100 = the
 * animator's full "off" state, 0 = at rest; it swings past 0 and settles.
 *   drop:   100 * e^(-k t) * cos(2 pi f t)          (from 100, springs through)
 *   spring: 100 * a * cos(2 pi f t) / e^(k t)        (jumps to a, then springs)
 * k = 4.6 / duration (the swing is down to 1% by the end of the duration).
 * Out plays the same motion backwards, each unit leaving in turn.
 * The whole animation (stagger, swing, settle) is stretched so that In
 * ends at the "Pillow In" marker / Out starts at the "Pillow Out" marker;
 * its other end is pinned to the layer (start time + OFF), so it follows
 * the layer when the layer moves. */
function pillowTextSpringSelector(selectors, data, dir, t0, dur, layerStart) {
  var ex = selectors.addProperty("ADBE Text Expressible Selector");
  ex.name = "Pillow Bounce";
  try { ex.property("ADBE Text Selector Mode").setValue(3); } catch (eM) {}   /* Intersect (the default) */
  try { ex.property("ADBE Text Range Type2").setValue(PILLOW_TEXT_UNITS[data.basedOn] || 1); } catch (eB) {}
  var k = 4.6 / Math.max(0.05, dur);
  var f = data.freq || 2.5;
  var lag = Math.max(0, data.stagger != null ? data.stagger : 0.05);
  var amp = data.expr === "spring" ? (data.amp != null ? data.amp : 0.5) : 1;
  var head = "// Pillow Bounce (" + (data.presetId || "") + ") - drag the \"" + (dir === "out" ? PILLOW_MK_OUT : PILLOW_MK_IN) + "\" layer marker to retime\n" +
    "var OFF = " + (t0 - layerStart).toFixed(4) + ", DUR = " + dur.toFixed(4) + ", LAG = " + lag.toFixed(4) + ";\n" +
    "var K = " + k.toFixed(4) + ", F = " + f + ", A = " + amp + ";\n" +
    PILLOW_MK_FIND +
    "var fd = thisComp.frameDuration, N = Math.max(1, textTotal), TOT = DUR + LAG * (N - 1);\n" +
    "var P = thisLayer.startTime + OFF;\n";
  head += dir === "out" ?
    "var E = P + TOT, S = mOut === null ? P : Math.min(mOut, E - fd);\n" +
    "var tau = (time - S) * TOT / (E - S);\n" +
    "var t = (textIndex - 1) * LAG + DUR - tau;\n" :
    "var S = P, E = mIn === null ? P + TOT : Math.max(mIn, S + fd);\n" +
    "var tau = (time - S) * TOT / (E - S);\n" +
    "var t = tau - (textIndex - 1) * LAG;\n";
  var body;
  if (data.expr === "ease") {
    /* the preset's own curve (the preview's cubic-bezier), per unit, one
       stagger apart; Out plays the curve mirrored, so it leaves slowly
       and speeds away */
    var bz = pillowTextBezier(data.ease);
    body = "var X1 = " + bz[0] + ", Y1 = " + bz[1] + ", X2 = " + bz[2] + ", Y2 = " + bz[3] + ";\n" +
      "function bz(x) {\n" +
      "  var lo = 0, hi = 1, u = x;\n" +
      "  for (var j = 0; j < 22; j++) { u = (lo + hi) / 2; if (3 * X1 * u * (1 - u) * (1 - u) + 3 * X2 * u * u * (1 - u) + u * u * u < x) lo = u; else hi = u; }\n" +
      "  return 3 * Y1 * u * (1 - u) * (1 - u) + 3 * Y2 * u * u * (1 - u) + u * u * u;\n" +
      "}\n" +
      "var p = Math.min(1, Math.max(0, (tau - (textIndex - 1) * LAG) / DUR));\n" +
      (dir === "out" ? "var a = 100 * (1 - bz(1 - p));\n" : "var a = 100 * (1 - bz(p));\n");
    ex.name = "Pillow Ease";
    head = head.replace("// Pillow Bounce", "// Pillow Ease");
  } else {
    body = data.expr === "spring" ?
      "var a = t < 0 ? 100 : 100 * A * Math.cos(F * 2 * Math.PI * t) / Math.exp(K * t);\n" :
      "var a = t < 0 ? 100 : 100 * Math.exp(-K * t) * Math.cos(F * 2 * Math.PI * t);\n";
  }
  ex.property("ADBE Text Expressible Amount").expression = head + body + "[a, a, a];";
}

function pillowFlickerLayer(layer, t0, dur, dir) {
  var opac = layer.property("ADBE Transform Group").property("ADBE Opacity");
  var pattern = [0, 0.65, 0.15, 0.85, 0.3, 1];
  var target = dir === "in" ? 1 : 0;
  var n = pattern.length;
  /* six held values dur/6 apart, then the end state: a flicker, not a
     fade (every key Hold, as in the preview) */
  for (var i = 0; i < n; i++) {
    var v = dir === "in" ? pattern[i] : 1 - pattern[i];
    opac.setValueAtTime(t0 + (dur * i) / n, v * 100);
  }
  opac.setValueAtTime(t0 + dur, target * 100);
  for (var h = 0; h <= n; h++) {
    try {
      var kh = opac.nearestKeyIndex(t0 + (dur * h) / n);
      opac.setInterpolationTypeAtKey(kh, KeyframeInterpolationType.HOLD, KeyframeInterpolationType.HOLD);
    } catch (eHold) {}
  }
  pillowRetime(opac, dir, t0, t0 + dur);
}

/* ─── Bounce (procedural expression) ─────────────────────────
 * Writes ONE expression onto the selected property. It never adds,
 * removes, retimes or rewrites keyframes — the bounce is evaluated at
 * render time from the user's own keys and their velocity.
 */

var PILLOW_BOUNCE_TAG = "PILLOW-BOUNCE";

function pillowBounceTypeOk(prop) {
  try {
    if (prop.propertyType !== PropertyType.PROPERTY) return false;
    var vt = prop.propertyValueType;
    return (
      vt === PropertyValueType.OneD ||
      vt === PropertyValueType.TwoD ||
      vt === PropertyValueType.TwoD_SPATIAL ||
      vt === PropertyValueType.ThreeD ||
      vt === PropertyValueType.ThreeD_SPATIAL
    );
  } catch (e) {
    return false;
  }
}

/** Selected properties first; fall back to animated transform properties
 *  on the selected layer so the tool still works from a layer selection. */
function pillowBounceTargets(comp) {
  var out = [];
  var i;
  /* every selected layer counts (as BOUNCr does): its selected
     properties, or — when a layer has none selected — its animated
     transform properties */
  var layers = [];
  try { layers = comp.selectedLayers; } catch (eL0) {}
  for (var L = 0; L < layers.length; L++) {
    var mine = [];
    try {
      var sel = layers[L].selectedProperties;
      for (i = 0; i < sel.length; i++) {
        if (pillowBounceTypeOk(sel[i]) && sel[i].canSetExpression) mine.push(sel[i]);
      }
    } catch (eSel) {}
    if (!mine.length) {
      try {
        var tg = layers[L].property("ADBE Transform Group");
        for (i = 1; i <= tg.numProperties; i++) {
          var p = tg.property(i);
          if (pillowBounceTypeOk(p) && p.canSetExpression && p.numKeys > 1) mine.push(p);
        }
      } catch (eLay) {}
    }
    for (i = 0; i < mine.length; i++) out.push(mine[i]);
  }
  return out;
}

function pillowBouncePropInfo(prop) {
  var layerName = "";
  try {
    var pp = prop;
    while (pp && pp.parentProperty) pp = pp.parentProperty;
    layerName = pp && pp.name ? pp.name : "";
  } catch (e) {}
  var expr = "";
  try { expr = prop.expression || ""; } catch (eE) {}
  return {
    name: prop.name,
    layer: layerName,
    keys: prop.numKeys,
    hasExpr: expr !== "",
    pillow: expr.indexOf(PILLOW_BOUNCE_TAG) !== -1
  };
}

function pillowBounceInspect() {
  var comp = pillowActiveComp();
  if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
  var targets = pillowBounceTargets(comp);
  var out = [];
  for (var i = 0; i < targets.length; i++) out.push(pillowBouncePropInfo(targets[i]));
  return pillowJson({ ok: true, targets: out });
}

/** Keyframe the bounce starts from: the last SELECTED key if the user
 *  selected keys, otherwise the property's final key. Never modified. */
function pillowBounceKeyIndex(prop) {
  try {
    var sk = prop.selectedKeys;
    if (sk && sk.length) {
      var hi = 0;
      for (var i = 0; i < sk.length; i++) if (sk[i] > hi) hi = sk[i];
      if (hi > 1) return hi;
    }
  } catch (e) {}
  return prop.numKeys;
}

function pillowBounceApply(payloadJson) {
  var comp = pillowActiveComp();
  if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });

  var data;
  try {
    data = pillowParse(payloadJson);
  } catch (eParse) {
    return pillowJson({ ok: false, error: "Bad bounce data." });
  }
  if (!data.expression || data.expression.indexOf(PILLOW_BOUNCE_TAG) === -1) {
    return pillowJson({ ok: false, error: "Bad bounce expression." });
  }

  var targets = pillowBounceTargets(comp);
  if (!targets.length) {
    return pillowJson({ ok: false, error: "Select an animated property in the Timeline." });
  }

  var usable = [];
  var i;
  for (i = 0; i < targets.length; i++) {
    if (targets[i].numKeys > 1) usable.push(targets[i]);
  }
  if (!usable.length) return pillowJson({ ok: false, error: "Two keyframes required" });

  // Foreign expressions are never overwritten without confirmation.
  if (!data.force) {
    var blocked = [];
    for (i = 0; i < usable.length; i++) {
      var ex = "";
      try { ex = usable[i].expression || ""; } catch (eX) {}
      if (ex !== "" && ex.indexOf(PILLOW_BOUNCE_TAG) === -1) blocked.push(usable[i].name);
    }
    if (blocked.length) return pillowJson({ ok: false, conflict: blocked });
  }

  return pillowUndo("Bounce \u00b7 " + (data.label || "Apply"), function () {
    var applied = [];
    var skipped = [];
    /* the parameters live on the layer as sliders (like BOUNCr's
       controller). Adding effects can invalidate property references, so
       each target is remembered by its index path and found again after. */
    var paths = [], layersSeen = [], j;
    for (j = 0; j < usable.length; j++) {
      var pp = usable[j], chain = [];
      while (pp.parentProperty) { chain.unshift(pp.propertyIndex); pp = pp.parentProperty; }
      paths.push({ layer: pp, chain: chain, name: usable[j].name });
      var seen = false;
      for (var q = 0; q < layersSeen.length; q++) if (layersSeen[q] === pp) seen = true;
      if (!seen) layersSeen.push(pp);
    }
    if (data.params) {
      for (j = 0; j < layersSeen.length; j++) {
        for (var sn in data.params) {
          if (data.params.hasOwnProperty(sn)) { try { pillowBeatSlider(layersSeen[j], sn, data.params[sn]); } catch (eS) {} }
        }
      }
    }
    for (j = 0; j < paths.length; j++) {
      var prop = paths[j].layer;
      try { for (var c = 0; c < paths[j].chain.length; c++) prop = prop.property(paths[j].chain[c]); } catch (eR) { prop = null; }
      if (!prop) { skipped.push(paths[j].name); continue; }
      var expr = String(data.expression).replace("__KEY__", String(pillowBounceKeyIndex(prop)));
      try {
        prop.expression = expr;
        prop.expressionEnabled = true;
        applied.push(prop.name);
      } catch (eSet) {
        skipped.push(prop.name);
      }
    }
    if (!applied.length) {
      return pillowJson({ ok: false, error: "This property cannot take an expression." });
    }
    return pillowJson({
      ok: true,
      count: applied.length,
      names: applied,
      skipped: skipped,
      partial: targets.length - usable.length
    });
  });
}

function pillowBounceRemove() {
  var comp = pillowActiveComp();
  if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });

  var targets = pillowBounceTargets(comp);
  if (!targets.length) {
    // no property selection: sweep the selected layers' transform groups
    try {
      for (var L = 0; L < comp.selectedLayers.length; L++) {
        var tg = comp.selectedLayers[L].property("ADBE Transform Group");
        for (var i = 1; i <= tg.numProperties; i++) {
          var p = tg.property(i);
          if (pillowBounceTypeOk(p)) targets.push(p);
        }
      }
    } catch (eS) {}
  }
  if (!targets.length) return pillowJson({ ok: false, error: "Select a property or layer." });

  return pillowUndo("Remove Bounce", function () {
    var count = 0;
    for (var i = 0; i < targets.length; i++) {
      var ex = "";
      try { ex = targets[i].expression || ""; } catch (eX) {}
      if (ex !== "" && ex.indexOf(PILLOW_BOUNCE_TAG) !== -1) {
        try {
          targets[i].expression = "";
          count++;
        } catch (eC) {}
      }
    }
    /* drop the Bounce sliders from layers that no longer use them */
    try {
      var ls = comp.selectedLayers;
      for (var L2 = 0; L2 < ls.length; L2++) {
        var tg2 = ls[L2].property("ADBE Transform Group"), still = false;
        for (var k2 = 1; k2 <= tg2.numProperties; k2++) {
          var ex2 = "";
          try { ex2 = tg2.property(k2).expression || ""; } catch (eE2) {}
          if (ex2.indexOf(PILLOW_BOUNCE_TAG) !== -1) still = true;
        }
        if (still) continue;
        var fx2 = ls[L2].property("ADBE Effect Parade");
        for (var f2 = fx2.numProperties; f2 >= 1; f2--) {
          if (/^Bounce (Amplitude|Frequency|Decay|Floor|Elasticity|Gravity|Max)$/.test(fx2.property(f2).name)) fx2.property(f2).remove();
        }
      }
    } catch (eFx) {}
    return pillowJson({ ok: true, count: count });
  });
}

/* Ping for Connected status */
function pillowPing() {
  var comp = pillowActiveComp();
  return pillowJson({
    ok: true,
    connected: true,
    hasComp: !!comp,
    app: "AEFT",
    version: app.version
  });
}

/* ─── Legacy Apple Text (compat) ─────────────────────────────── */

/* ─── Relink ───────────────────────────────────────────────── */

function pillowFindMissing() {
  var missing = [];
  try {
    if (!app || !app.project) {
      return pillowJson({ ok: false, error: "No project open." });
    }
    var n = app.project.numItems;
    for (var i = 1; i <= n; i++) {
      var item = app.project.item(i);
      // Skip folders / comps early — only FootageItem can be missing
      if (!(item instanceof FootageItem)) continue;
      var isMissing = false;
      try {
        isMissing = item.footageMissing;
      } catch (e) {
        continue;
      }
      if (!isMissing) continue;
      var path = "";
      try {
        if (item.mainSource && item.mainSource.file) {
          path = item.mainSource.file.fsName;
        }
      } catch (e2) {}
      missing.push({
        id: item.id,
        name: item.name,
        path: path
      });
    }
  } catch (e3) {
    return pillowJson({ ok: false, error: String(e3).slice(0, 160) });
  }
  return pillowJson({ ok: true, items: missing, count: missing.length });
}

function pillowRelinkAll(rootPath, confirm) {
  if (!confirm) {
    return pillowJson({ ok: false, error: "Confirm required." });
  }
  try {
    if (!app || !app.project) {
      return pillowJson({ ok: false, error: "No project open." });
    }
  } catch (e0) {
    return pillowJson({ ok: false, error: "No project open." });
  }
  var root = new Folder(rootPath);
  if (!root.exists) {
    return pillowJson({ ok: false, error: "Folder not found: " + rootPath });
  }

  var fileMap = {};
  function walk(folder) {
    var files = folder.getFiles();
    for (var i = 0; i < files.length; i++) {
      var f = files[i];
      if (f instanceof Folder) {
        walk(f);
      } else if (f instanceof File) {
        var key = f.name.toLowerCase();
        if (!fileMap[key]) fileMap[key] = f;
      }
    }
  }
  walk(root);

  var linked = 0;
  var unfound = [];
  var matched = [];

  app.beginUndoGroup("Pillow \u00b7 Relink");
  try {
    for (var i = 1; i <= app.project.numItems; i++) {
      var item = app.project.item(i);
      if (!(item instanceof FootageItem)) continue;
      var isMissing = false;
      try { isMissing = item.footageMissing; } catch (e) {}
      if (!isMissing) continue;

      var key = item.name.toLowerCase();
      var file = fileMap[key];
      if (file && file.exists) {
        try {
          item.replace(file);
          linked++;
          matched.push(item.name);
        } catch (e2) {
          unfound.push(item.name);
        }
      } else {
        unfound.push(item.name);
      }
    }
  } finally {
    app.endUndoGroup();
  }

  return pillowJson({
    ok: true,
    linked: linked,
    matched: matched.length,
    unfound: unfound,
    scanned: matched.length + unfound.length
  });
}

function pillowPickFolder() {
  var folder = Folder.selectDialog("Pillow \u00b7 Choose folder to search");
  if (!folder) return pillowJson({ ok: false, cancelled: true });
  return pillowJson({ ok: true, path: folder.fsName });
}

/* ─── Audio: Auto Beat Marker ──────────────────────────────────────────────────────
 * Uses AE's own "Convert Audio to Keyframes" command to get a real
 * amplitude curve for the selected audio/footage layer, finds local
 * peaks above a sensitivity threshold, drops layer markers on the
 * source layer, then cleans up the temporary amplitude layer.
 * ───────────────────────────────────────────────────────────── */

function pillowGetAudioSelection() {
  var comp = pillowActiveComp();
  if (!comp) return pillowJson({ ok: false, error: "No active composition" });
  try {
    var sel = comp.selectedLayers;
    if (!sel || !sel.length) return pillowJson({ ok: false, error: "Select an audio layer" });
    var layer = sel[0];
    if (!layer.hasAudio) return pillowJson({ ok: false, error: "Selected layer has no audio" });
    return pillowJson({ ok: true, name: layer.name });
  } catch (e) {
    return pillowJson({ ok: false, error: "Could not read audio selection" });
  }
}

/* the selected audio layer, for the panel to analyse its file itself */
function pillowBeatAudioInfo() {
  var comp = pillowActiveComp();
  if (!comp) return pillowJson({ ok: false, error: "No active composition" });
  var sel = comp.selectedLayers;
  if (!sel || !sel.length) return pillowJson({ ok: false, error: "Select an audio or video layer with sound" });
  var layer = sel[0], hasAudio = false;
  try { hasAudio = !!layer.hasAudio; } catch (eH) {}
  if (!hasAudio) return pillowJson({ ok: false, error: "Selected layer has no audio" });
  var file = "", remap = false, stretch = 100;
  try { if (layer.source && layer.source.mainSource && layer.source.mainSource.file) file = layer.source.mainSource.file.fsName; } catch (eF) {}
  try { remap = !!layer.timeRemapEnabled; } catch (eR) {}
  try { stretch = layer.stretch; } catch (eS) {}
  return pillowJson({ ok: true, index: layer.index, name: layer.name, file: file,
    start: layer.startTime, inPoint: layer.inPoint, outPoint: layer.outPoint,
    stretch: stretch, remap: remap });
}

function pillowPlaceBeats(layer, times, clearExisting) {
  var markerProp = layer.property("Marker");
  /* "Replace existing beat markers": only Pillow's own "Beat N" markers go */
  if (clearExisting) {
    for (var om = markerProp.numKeys; om >= 1; om--) {
      var oc = "";
      try { oc = markerProp.keyValue(om).comment; } catch (eOC) {}
      if (/^Beat \d+/.test(oc)) { try { markerProp.removeKey(om); } catch (eOM) {} }
    }
  }
  var added = 0;
  for (var m = 0; m < times.length; m++) {
    try {
      markerProp.setValueAtTime(times[m], new MarkerValue("Beat " + (m + 1)));
      added++;
    } catch (eM) {}
  }
  return added;
}

/* beats the panel found: {index, name, times (comp seconds), clear} */
function pillowSetBeatMarkers(json) {
  var o = {};
  try { o = pillowParse(decodeURIComponent(json)); } catch (e0) { return pillowJson({ ok: false, error: "Bad beat data." }); }
  var comp = pillowActiveComp();
  if (!comp) return pillowJson({ ok: false, error: "No active composition" });
  var layer = null;
  try { layer = comp.layer(o.index); } catch (eL) {}
  if (!layer || layer.name !== o.name) return pillowJson({ ok: false, error: "The audio layer changed \u2014 select it and try again" });
  if (!o.times || !o.times.length) return pillowJson({ ok: false, error: "No beats detected \u2014 raise sensitivity or lower the minimum gap" });
  return pillowUndo("Auto Beat Marker", function () {
    var added = pillowPlaceBeats(layer, o.times, !!o.clear);
    return pillowJson({ ok: true, count: added, layerName: layer.name });
  });
}

/* fallback for layers whose file the panel can't read (precomps, codecs
   Web Audio can't decode): AE's Convert Audio to Keyframes */
function pillowAddBeatMarkers(sensitivity, minGapMs, clearExisting) {
  return pillowUndo("Auto Beat Marker", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "No active composition" });

    var sel = comp.selectedLayers;
    if (!sel || !sel.length) {
      return pillowJson({ ok: false, error: "Select an audio or video layer with sound" });
    }
    var layer = sel[0];
    var hasAudio = false;
    try { hasAudio = !!layer.hasAudio; } catch (eH) {}
    if (!hasAudio) return pillowJson({ ok: false, error: "Selected layer has no audio" });

    var cmdId = 0;
    try { cmdId = app.findMenuCommandId("Convert Audio to Keyframes"); } catch (eC) {}
    if (!cmdId) return pillowJson({ ok: false, error: "Couldn't read this audio \u2014 use a WAV or MP3 layer" });

    for (var i = 1; i <= comp.numLayers; i++) {
      try { comp.layer(i).selected = (comp.layer(i) === layer); } catch (eS) {}
    }

    var before = comp.numLayers;
    try { app.executeCommand(cmdId); } catch (eX) {
      return pillowJson({ ok: false, error: "Could not run Convert Audio to Keyframes" });
    }

    /* the new "Audio Amplitude" layer: by name, else the selection */
    var ampLayer = null;
    if (comp.numLayers > before) {
      for (var a = 1; a <= comp.numLayers; a++) {
        var La = comp.layer(a);
        if (La !== layer && La.property("ADBE Effect Parade") && La.property("ADBE Effect Parade").numProperties >= 3) {
          try { if (La.effect(1).matchName === "ADBE Slider Control") { ampLayer = La; break; } } catch (eE) {}
        }
      }
    }
    if (!ampLayer && comp.selectedLayers && comp.selectedLayers.length && comp.selectedLayers[0] !== layer) ampLayer = comp.selectedLayers[0];
    if (!ampLayer) {
      return pillowJson({ ok: false, error: "Couldn't read this audio \u2014 use a WAV or MP3 layer" });
    }

    /* "Both Channels" is the third slider in any AE language */
    var slider = null;
    try { slider = ampLayer.effect(3)(1); } catch (eA) {}
    if (!slider) { try { slider = ampLayer.effect(1)(1); } catch (eB) {} }

    if (!slider || slider.numKeys < 3) {
      try { ampLayer.remove(); } catch (eR1) {}
      return pillowJson({ ok: false, error: "No amplitude data was found on this layer" });
    }

    var n = slider.numKeys;
    var vals = [], times = [], maxV = 0;
    for (var k = 1; k <= n; k++) {
      var v = slider.keyValue(k);
      vals.push(v);
      times.push(slider.keyTime(k));
      if (v > maxV) maxV = v;
    }
    try { ampLayer.remove(); } catch (eR3) {}
    try { layer.selected = true; } catch (eSel) {}

    if (maxV <= 0) return pillowJson({ ok: false, error: "Track appears to be silent" });

    var s = Math.max(0.05, Math.min(0.95, sensitivity != null ? sensitivity : 0.5));
    var minGap = Math.max(0.02, (minGapMs != null ? minGapMs : 120) / 1000);
    /* a rise above the running average, not just loud frames */
    var peaks = [], lastPeakT = -999, W = 6;
    for (var j = 1; j < n - 1; j++) {
      var lo = Math.max(0, j - W), hi = Math.min(n - 1, j + W), sum = 0;
      for (var q = lo; q <= hi; q++) sum += vals[q];
      var mean = sum / (hi - lo + 1);
      var thresh = Math.max(maxV * (1 - s) * 0.5, mean * (1.05 + (1 - s) * 0.4));
      var rise = vals[j] - vals[j - 1];
      if (vals[j] >= thresh && vals[j] >= vals[j + 1] && rise > 0 && (times[j] - lastPeakT) >= minGap) {
        peaks.push(times[j]);
        lastPeakT = times[j];
      }
    }

    if (!peaks.length) {
      return pillowJson({ ok: false, error: "No beats detected \u2014 raise sensitivity or lower the minimum gap" });
    }
    var added = pillowPlaceBeats(layer, peaks, clearExisting);
    return pillowJson({ ok: true, count: added, layerName: layer.name });
  });
}


/* ─── Split Text (letters / words / lines) ──────────────────────
 * Each selected text layer is broken into one text layer per letter,
 * word or line, each sitting exactly where it was in the original.
 * Layout is measured on a scratch duplicate with sourceRectAtTime:
 *   – a unit's origin on its line = ink right edge of the line prefix
 *     that ends with the unit, minus the unit's own ink right edge
 *     (so tracking and kerning before it are included);
 *   – a line's baseline = top of "H" after j line breaks minus top of "H";
 *   – justification shift of a line = its left edge with the original
 *     justification minus its left edge when left-justified.
 * Every piece is left-justified, so its origin is that point. When the
 * transform is static the anchor goes to the piece's centre and the
 * position is baked through the original's toWorld (exact for parents
 * and 3D); otherwise only the anchor is offset, which keeps any
 * keyframed transform exact. The original is switched off, not deleted.
 * Point text only; per-character styling takes the first character's. */

function pillowTextDocProp(layer) {
  return layer.property("ADBE Text Properties").property("ADBE Text Document");
}

function pillowStripTextLayer(layer) {
  var st = pillowTextDocProp(layer);
  try { if (st.expression !== "") st.expression = ""; } catch (e0) {}
  try { while (st.numKeys > 0) st.removeKey(1); } catch (e1) {}
  try {
    var an = layer.property("ADBE Text Properties").property("ADBE Text Animators");
    for (var i = an.numProperties; i >= 1; i--) an.property(i).remove();
  } catch (e2) {}
}

function pillowSetLayerText(layer, str, just) {
  var p = pillowTextDocProp(layer);
  var td = p.value;
  td.text = str;
  if (just != null) td.justification = just;
  p.setValue(td);
}

function pillowPropAnimated(p) {
  if (!p) return false;
  try { if (p.numKeys > 0) return true; } catch (e0) {}
  try { if (p.expressionEnabled && p.expression !== "") return true; } catch (e1) {}
  return false;
}

function pillowSplitUnits(line, mode) {
  var out = [], m, re;
  if (mode === "lines") {
    m = /\S[\s\S]*\S|\S/.exec(line);
    if (m) out.push({ a: m.index, b: m.index + m[0].length, s: m[0] });
    return out;
  }
  if (mode === "words") {
    re = /\S+/g;
    while ((m = re.exec(line))) out.push({ a: m.index, b: m.index + m[0].length, s: m[0] });
    return out;
  }
  for (var i = 0; i < line.length; i++) {
    var n = 1, c = line.charCodeAt(i);
    if (c >= 0xd800 && c <= 0xdbff && i + 1 < line.length) n = 2;
    var ch = line.substr(i, n);
    if (!/^\s+$/.test(ch)) out.push({ a: i, b: i + n, s: ch });
    i += n - 1;
  }
  return out;
}

function pillowSplitOne(comp, layer, mode, t) {
  var docProp = pillowTextDocProp(layer);
  var td0 = docProp.value;
  if (td0.boxText) return { error: "\u201c" + layer.name + "\u201d is paragraph text \u2014 right-click it \u2192 Convert to Point Text, then split." };
  try {
    var pathOpt = layer.property("ADBE Text Properties").property("ADBE Text Path Options").property("ADBE Text Path");
    if (pathOpt && pathOpt.value) return { error: "\u201c" + layer.name + "\u201d is text on a path \u2014 not supported." };
  } catch (ePath) {}

  var LEFT = ParagraphJustification.LEFT_JUSTIFY;
  var just = td0.justification;
  var lines = String(td0.text).split(/\r\n|\r|\n|\u0003/);
  var units = [];
  for (var j = 0; j < lines.length; j++) {
    var us = pillowSplitUnits(lines[j], mode);
    for (var k = 0; k < us.length; k++) { us[k].line = j; units.push(us[k]); }
  }
  if (!units.length) return { error: "\u201c" + layer.name + "\u201d has no text to split." };
  if (units.length > 400) return { error: "\u201c" + layer.name + "\u201d would make " + units.length + " layers \u2014 split by words or lines instead." };

  /* scratch copy for measuring: no animators, no Source Text keys */
  var tmp = layer.duplicate();
  var created = [];
  try {
    pillowStripTextLayer(tmp);
    var cache = {};
    var rectOf = function (str, jst) {
      var key = (jst === LEFT ? "L" : "J") + str;
      if (cache[key]) return cache[key];
      pillowSetLayerText(tmp, str, jst);
      var r = tmp.sourceRectAtTime(t, false);
      cache[key] = { left: r.left, top: r.top, width: r.width, height: r.height };
      return cache[key];
    };
    var right = function (str) { var r = rectOf(str, LEFT); return r.left + r.width; };

    var baseline = [], shift = [];
    var hTop = rectOf("H", LEFT).top;
    for (j = 0; j < lines.length; j++) {
      var br = "";
      for (var q = 0; q < j; q++) br += "\r";
      baseline[j] = j ? rectOf(br + "H", LEFT).top - hTop : 0;
      shift[j] = 0;
      if (just !== LEFT && /\S/.test(lines[j])) shift[j] = rectOf(lines[j], just).left - rectOf(lines[j], LEFT).left;
    }
    for (k = 0; k < units.length; k++) {
      var u = units[k], ur = rectOf(u.s, LEFT);
      u.dx = shift[u.line] + right(lines[u.line].substring(0, u.b)) - (ur.left + ur.width);
      u.dy = baseline[u.line];
      u.cx = ur.left + ur.width / 2;
      u.cy = ur.top + ur.height / 2;
    }

    var tr = layer.transform;
    var sep = false;
    try { sep = tr.position.dimensionsSeparated; } catch (eSep) {}
    var still = !sep && !pillowPropAnimated(tr.anchorPoint) && !pillowPropAnimated(tr.position) &&
      !pillowPropAnimated(tr.scale) && !pillowPropAnimated(tr.rotation);
    if (still && layer.threeDLayer) {
      still = !pillowPropAnimated(tr.orientation) && !pillowPropAnimated(tr.xRotation) && !pillowPropAnimated(tr.yRotation);
    }

    /* each duplicate lands right above the original, pushing the
       previous pieces up — so going in reading order leaves the first
       piece on top of the stack */
    for (k = 0; k < units.length; k++) {
      u = units[k];
      var L = layer.duplicate();
      created.push(L);
      L.name = u.s.length > 24 ? u.s.substr(0, 24) + "\u2026" : u.s;
      pillowStripTextLayer(L);
      pillowSetLayerText(L, u.s, LEFT);
      var ap = L.transform.anchorPoint;
      if (still) {
        var a = ap.value;
        ap.setValue(a.length > 2 ? [u.cx, u.cy, a[2]] : [u.cx, u.cy]);
        var pos = L.transform.position;
        pos.expression =
          "var o=thisComp.layer(" + layer.index + ");" +
          "var w=o.toWorld([" + (u.cx + u.dx) + "," + (u.cy + u.dy) + ",0]);" +
          "var r=hasParent?parent.fromWorld(w):w;" +
          "value.length>2?[r[0],r[1],r[2]]:[r[0],r[1]]";
        var v = pos.valueAtTime(t, false);
        pos.expression = "";
        pos.setValue(v);
      } else if (ap.numKeys > 0) {
        for (var n = 1; n <= ap.numKeys; n++) {
          var kv = ap.keyValue(n);
          ap.setValueAtKey(n, kv.length > 2 ? [kv[0] - u.dx, kv[1] - u.dy, kv[2]] : [kv[0] - u.dx, kv[1] - u.dy]);
        }
      } else {
        var av = ap.value;
        ap.setValue(av.length > 2 ? [av[0] - u.dx, av[1] - u.dy, av[2]] : [av[0] - u.dx, av[1] - u.dy]);
      }
    }
  } catch (err) {
    for (var z = 0; z < created.length; z++) { try { created[z].remove(); } catch (eRm) {} }
    try { tmp.remove(); } catch (eT) {}
    return { error: String(err).slice(0, 200) };
  }
  tmp.remove();
  layer.enabled = false;
  layer.selected = false;
  return { layers: created };
}

function pillowSplitText(mode) {
  mode = mode === "words" || mode === "lines" ? mode : "letters";
  return pillowUndo("Split to " + mode.charAt(0).toUpperCase() + mode.slice(1), function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var sel = comp.selectedLayers, texts = [];
    for (var i = 0; i < sel.length; i++) if (pillowIsTextLayer(sel[i])) texts.push(sel[i]);
    if (!texts.length) return pillowJson({ ok: false, error: "Select a text layer to split." });
    for (i = 0; i < sel.length; i++) sel[i].selected = false;
    var all = [], errors = [];
    for (i = 0; i < texts.length; i++) {
      var L = texts[i];
      var t = Math.max(L.inPoint, Math.min(comp.time, L.outPoint - comp.frameDuration));
      var r = pillowSplitOne(comp, L, mode, t);
      if (r.error) { errors.push(r.error); L.selected = true; continue; }
      for (var k = 0; k < r.layers.length; k++) { r.layers[k].selected = true; all.push(r.layers[k]); }
    }
    if (!all.length) return pillowJson({ ok: false, error: errors[0] || "Nothing to split." });
    return pillowJson({ ok: true, count: all.length, sources: texts.length - errors.length, mode: mode, warning: errors[0] || "" });
  });
}

/* ─── Animation Library ──────────────────────────────────────────
 * pillowLibCapture()  — reads the keyframes of the first selected layer
 *   (only the selected keyframes if any are selected, otherwise every
 *   animated property) from Transform and Effects: values, times relative
 *   to the first key, interpolation, temporal ease, spatial tangents and
 *   expressions. Returns a preset object for the panel to store.
 * pillowLibApply(encoded) — applies such a preset (URI-encoded JSON) to
 *   every selected layer starting at the current time. Position is
 *   applied relative to where the layer already is; missing effects are
 *   added. */

function pillowLibStr(v) {
  if (v === null || v === undefined) return "null";
  var t = typeof v;
  if (t === "number") return isFinite(v) ? String(Math.round(v * 100000) / 100000) : "0";
  if (t === "boolean") return v ? "true" : "false";
  if (t === "string") {
    return '"' + v.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t") + '"';
  }
  if (v instanceof Array) {
    var a = [];
    for (var i = 0; i < v.length; i++) a.push(pillowLibStr(v[i]));
    return "[" + a.join(",") + "]";
  }
  var o = [];
  for (var k in v) if (v.hasOwnProperty(k)) o.push(pillowLibStr(k) + ":" + pillowLibStr(v[k]));
  return "{" + o.join(",") + "}";
}

function pillowLibValueOk(p) {
  var t = p.propertyValueType;
  return t === PropertyValueType.OneD || t === PropertyValueType.TwoD || t === PropertyValueType.ThreeD ||
    t === PropertyValueType.TwoD_SPATIAL || t === PropertyValueType.ThreeD_SPATIAL || t === PropertyValueType.COLOR;
}

function pillowLibIsSpatial(p) {
  var t = p.propertyValueType;
  return t === PropertyValueType.TwoD_SPATIAL || t === PropertyValueType.ThreeD_SPATIAL;
}

function pillowLibEase(arr) {
  var out = [];
  for (var i = 0; i < arr.length; i++) out.push([arr[i].speed, arr[i].influence]);
  return out;
}

function pillowLibCapture() {
  var comp = pillowActiveComp();
  if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
  var layer = comp.selectedLayers[0];
  if (!layer) return pillowJson({ ok: false, error: "Select a layer with keyframes." });

  var found = [];
  var anySelected = false;
  function walk(group, path) {
    for (var i = 1; i <= group.numProperties; i++) {
      var p = group.property(i);
      if (!p) continue;
      var step = { m: p.matchName };
      if (group.matchName === "ADBE Effect Parade") {
        var nth = 0;
        for (var j = 1; j < i; j++) if (group.property(j).matchName === p.matchName) nth++;
        step.n = nth;
        step.name = p.name;
      }
      var here = path.concat([step]);
      if (p.propertyType === PropertyType.PROPERTY) {
        if (!p.canVaryOverTime || !pillowLibValueOk(p)) continue;
        var hasExpr = false;
        try { hasExpr = p.expressionEnabled && p.expression !== ""; } catch (e0) {}
        if (p.numKeys === 0 && !hasExpr) continue;
        var sel = [];
        try { sel = p.selectedKeys || []; } catch (e1) {}
        if (sel.length) anySelected = true;
        found.push({ p: p, path: here, sel: sel, expr: hasExpr ? p.expression : "" });
      } else {
        try { if (p.enabled === false) continue; } catch (e2) {}
        walk(p, here);
      }
    }
  }
  walk(layer.property("ADBE Transform Group"), [{ m: "ADBE Transform Group" }]);
  var fx = layer.property("ADBE Effect Parade");
  if (fx) walk(fx, [{ m: "ADBE Effect Parade" }]);

  var props = [], t0 = null, t1 = null;
  for (var f = 0; f < found.length; f++) {
    var it = found[f], p = it.p, idx = [];
    if (anySelected) idx = it.sel.slice(0);
    else for (var k = 1; k <= p.numKeys; k++) idx.push(k);
    if (anySelected && !idx.length) continue;
    var keys = [];
    for (var q = 0; q < idx.length; q++) {
      var n = idx[q], key = {
        t: p.keyTime(n),
        v: p.keyValue(n),
        ii: p.keyInInterpolationType(n),
        oi: p.keyOutInterpolationType(n)
      };
      try { key.ie = pillowLibEase(p.keyInTemporalEase(n)); key.oe = pillowLibEase(p.keyOutTemporalEase(n)); } catch (e3) {}
      try { key.tc = p.keyTemporalContinuous(n); key.ta = p.keyTemporalAutoBezier(n); } catch (e4) {}
      if (pillowLibIsSpatial(p)) {
        try {
          key.it = p.keyInSpatialTangent(n); key.ot = p.keyOutSpatialTangent(n);
          key.sc = p.keySpatialContinuous(n); key.sa = p.keySpatialAutoBezier(n);
          key.r = p.keyRoving(n);
        } catch (e5) {}
      }
      keys.push(key);
      if (t0 === null || key.t < t0) t0 = key.t;
      if (t1 === null || key.t > t1) t1 = key.t;
    }
    if (!keys.length && !it.expr) continue;
    props.push({ path: it.path, name: p.name, spatial: pillowLibIsSpatial(p), keys: keys, expr: it.expr });
  }
  if (!props.length) return pillowJson({ ok: false, error: "The selected layer has no keyframes to save." });
  if (t0 === null) { t0 = 0; t1 = 0; }
  for (var a = 0; a < props.length; a++) {
    for (var b = 0; b < props[a].keys.length; b++) props[a].keys[b].t = Math.round((props[a].keys[b].t - t0) * 10000) / 10000;
  }

  var kind = "av";
  if (pillowIsTextLayer(layer)) kind = "text";
  else { try { if (layer.matchName === "ADBE Vector Layer") kind = "shape"; } catch (e6) {} }
  var box = null;
  try { var r = layer.sourceRectAtTime(t0, false); box = [r.left, r.top, r.width, r.height]; } catch (e7) {}
  if (!box || !(box[2] > 0)) { try { box = [0, 0, layer.width, layer.height]; } catch (e8) { box = [0, 0, 100, 100]; } }
  var label = "";
  if (kind === "text") { try { label = String(layer.property("ADBE Text Properties").property("ADBE Text Document").value.text).substr(0, 24); } catch (e9) {} }

  var preset = {
    v: 1,
    duration: Math.round((t1 - t0) * 10000) / 10000,
    fps: comp.frameRate,
    comp: [comp.width, comp.height],
    layer: { kind: kind, box: box, threeD: !!layer.threeDLayer, label: label, name: layer.name },
    props: props
  };
  return '{"ok":true,"preset":' + pillowLibStr(preset) + "}";
}

function pillowLibResolve(layer, path, create) {
  var cur = layer;
  for (var i = 0; i < path.length; i++) {
    var st = path[i], next = null;
    if (st.n !== undefined) {
      var seen = 0;
      for (var j = 1; j <= cur.numProperties; j++) {
        if (cur.property(j).matchName === st.m) {
          if (seen === st.n) { next = cur.property(j); break; }
          seen++;
        }
      }
      if (!next && create) {
        if (!cur.canAddProperty(st.m)) return null;
        next = cur.addProperty(st.m);
        if (st.name) { try { next.name = st.name; } catch (eN) {} }
      }
    } else {
      next = cur.property(st.m);
    }
    if (!next) return null;
    cur = next;
  }
  return cur;
}

function pillowLibIsPosition(path) {
  var m = path[path.length - 1].m;
  return path[0].m === "ADBE Transform Group" && (m === "ADBE Position" || m === "ADBE Position_0" || m === "ADBE Position_1" || m === "ADBE Position_2");
}

function pillowLibApply(encoded) {
  var data;
  try { data = pillowParse(decodeURIComponent(encoded)); } catch (e) { return pillowJson({ ok: false, error: "Preset data is damaged." }); }
  return pillowUndo("Library \u00b7 " + (data.name || "Preset"), function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var layers = comp.selectedLayers;
    if (!layers.length) return pillowJson({ ok: false, error: "Select a layer to apply the preset to." });
    var t0 = comp.time, applied = 0, skipped = 0;
    var props = data.props || [];

    for (var L = 0; L < layers.length; L++) {
      var layer = layers[L], any = false;
      /* position split into X/Y(/Z) in the preset — match it on the layer */
      var wantSep = null;
      for (var s = 0; s < props.length; s++) {
        var last = props[s].path[props[s].path.length - 1].m;
        if (props[s].path[0].m === "ADBE Transform Group") {
          if (last === "ADBE Position") wantSep = false;
          if (last === "ADBE Position_0" || last === "ADBE Position_1") wantSep = true;
        }
      }
      if (wantSep !== null) {
        try {
          var pos = layer.property("ADBE Transform Group").property("ADBE Position");
          if (pos.dimensionsSeparated !== wantSep) pos.dimensionsSeparated = wantSep;
        } catch (eSep) {}
      }

      for (var i = 0; i < props.length; i++) {
        var P = props[i], prop = null;
        try { prop = pillowLibResolve(layer, P.path, true); } catch (eR) { prop = null; }
        if (!prop || !prop.canVaryOverTime) { skipped++; continue; }
        try {
          var keys = P.keys || [];
          var delta = null;
          if (keys.length && pillowLibIsPosition(P.path)) {
            /* the key that lands on the layer's current position: the last
               one for an entrance (the animation ends where the layer is),
               the first one otherwise */
            var ak = data.anchor === "last" ? keys[keys.length - 1] : keys[0];
            var cur = prop.valueAtTime(t0, true), first = ak.v;
            if (cur instanceof Array) { delta = []; for (var d = 0; d < cur.length; d++) delta.push(cur[d] - (first[d] || 0)); }
            else delta = cur - first;
          }
          var dim = prop.value instanceof Array ? prop.value.length : 1;
          var idxs = [];
          for (var k = 0; k < keys.length; k++) {
            var v = keys[k].v;
            if (v instanceof Array) {
              var vv = [];
              for (var c = 0; c < dim; c++) vv.push((v[c] !== undefined ? v[c] : (prop.value[c] || 0)) + (delta ? delta[c] || 0 : 0));
              v = vv;
            } else if (delta !== null) v = v + delta;
            var t = t0 + keys[k].t;
            prop.setValueAtTime(t, v);
            idxs.push(prop.nearestKeyIndex(t));
          }
          for (k = 0; k < keys.length; k++) {
            var K = keys[k], n = idxs[k];
            try { prop.setInterpolationTypeAtKey(n, K.ii, K.oi); } catch (e1) {}
            if (K.ie && K.oe) {
              try {
                /* one ease per dimension (one for spatial) — a preset from a
                   layer of another kind may carry more or fewer */
                var need = P.spatial || prop.isSpatial ? 1 : dim;
                var ie = [], oe = [];
                for (var e2 = 0; e2 < need; e2++) {
                  var a1 = K.ie[Math.min(e2, K.ie.length - 1)], a2 = K.oe[Math.min(e2, K.oe.length - 1)];
                  ie.push(new KeyframeEase(a1[0], Math.max(0.1, Math.min(100, a1[1]))));
                  oe.push(new KeyframeEase(a2[0], Math.max(0.1, Math.min(100, a2[1]))));
                }
                prop.setTemporalEaseAtKey(n, ie, oe);
              } catch (e3) {}
            }
            try { if (K.tc !== undefined) prop.setTemporalContinuousAtKey(n, K.tc); } catch (e4) {}
            try { if (K.ta !== undefined) prop.setTemporalAutoBezierAtKey(n, K.ta); } catch (e5) {}
            if (P.spatial && K.it && K.ot) {
              try { prop.setSpatialTangentsAtKey(n, K.it, K.ot); } catch (e6) {}
              try { if (K.sc !== undefined) prop.setSpatialContinuousAtKey(n, K.sc); } catch (e7) {}
              try { if (K.sa !== undefined) prop.setSpatialAutoBezierAtKey(n, K.sa); } catch (e8) {}
            }
          }
          if (P.spatial) {
            for (k = 1; k < keys.length - 1; k++) { try { if (keys[k].r) prop.setRovingAtKey(idxs[k], true); } catch (e9) {} }
          }
          if (P.expr) { try { prop.expression = P.expr; } catch (e10) {} }
          any = true;
        } catch (eP) { skipped++; }
      }
      if (any) applied++;
    }
    if (!applied) return pillowJson({ ok: false, error: "Nothing could be applied to the selected layer." });
    return pillowJson({ ok: true, count: applied, skipped: skipped });
  });
}

/* share: write a preset file / read one or more */
function pillowLibExport(encoded, fileName) {
  var f = File.saveDialog("Export Pillow preset", "Pillow preset:*.pillowanim");
  if (!f) return pillowJson({ ok: false, cancelled: true });
  if (!/\.pillowanim$/i.test(f.name)) f = new File(f.fsName + ".pillowanim");
  f.encoding = "UTF-8";
  if (!f.open("w")) return pillowJson({ ok: false, error: "Could not write the file." });
  f.write(decodeURIComponent(encoded));
  f.close();
  return pillowJson({ ok: true, path: f.fsName });
}

function pillowLibImport() {
  var files = File.openDialog("Import Pillow presets", "Pillow preset:*.pillowanim;*.json", true);
  if (!files) return pillowJson({ ok: false, cancelled: true });
  if (!(files instanceof Array)) files = [files];
  var out = [];
  for (var i = 0; i < files.length; i++) {
    var f = files[i];
    f.encoding = "UTF-8";
    if (!f.open("r")) continue;
    var s = f.read();
    f.close();
    out.push(encodeURIComponent(s));
  }
  return '{"ok":true,"files":' + pillowLibStr(out) + "}";
}

/* ─── Beat Sync ───────────────────────────────────────────────────
 * Beats come from markers: the layer carrying Pillow's "Beat N" markers
 * (Music tab), else any audio layer with markers, else the comp's own
 * markers. Marker keyTime() is comp time, and so is `time` in a layer
 * expression, so the beat list is written straight into expressions.
 *   cut   — selected layers one after another, each from a beat to the
 *           next (every N beats), starting at the playhead
 *   pulse — Scale bumps on each beat and decays   (sliders: Pulse Amount %, Pulse Decay)
 *   shake — Position shakes on each beat and decays (Shake Amount px, Shake Decay)
 *   flash — a white "Beat Flash" solid in Add mode flashes on each beat
 *           (Flash Amount %, Flash Decay)
 * Expressions start with "// Pillow Beat" so pillowBeatRemove can find them;
 * existing keyframes stay and are what the expression bumps around. */

function pillowBeatSource(comp) {
  var best = null, bestN = 0, fallback = null;
  for (var i = 1; i <= comp.numLayers; i++) {
    var L = comp.layer(i), mk = null;
    try { mk = L.property("Marker"); } catch (e0) {}
    if (!mk || !mk.numKeys) continue;
    var n = 0;
    for (var k = 1; k <= mk.numKeys; k++) {
      try { if (/^Beat \d+/.test(mk.keyValue(k).comment)) n++; } catch (e1) {}
    }
    if (n > bestN) { best = L; bestN = n; }
    var audio = false;
    try { audio = !!L.hasAudio; } catch (e2) {}
    if (!fallback && audio) fallback = L;
  }
  var src = best || fallback, prop = null, name = "";
  if (src) { prop = src.property("Marker"); name = src.name; }
  else if (comp.markerProperty && comp.markerProperty.numKeys) { prop = comp.markerProperty; name = "Composition markers"; }
  if (!prop) return null;
  /* on the layer Pillow marked, only its "Beat N" markers count: the
     user's own markers on that layer are not beats */
  var times = [];
  for (var m = 1; m <= prop.numKeys; m++) {
    if (best) { var c = ""; try { c = prop.keyValue(m).comment; } catch (eC) {} if (!/^Beat \d+/.test(c)) continue; }
    times.push(prop.keyTime(m));
  }
  times.sort(function (a, b) { return a - b; });
  return { layer: src, name: name, times: times };
}

function pillowBeatInfo() {
  var comp = pillowActiveComp();
  if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
  var s = pillowBeatSource(comp);
  if (!s || !s.times.length) return pillowJson({ ok: false, error: "No beat markers yet" });
  return pillowJson({ ok: true, count: s.times.length, source: s.name });
}

function pillowBeatSlider(layer, name, value) {
  var fx = layer.property("ADBE Effect Parade"), e = null;
  for (var i = 1; i <= fx.numProperties; i++) if (fx.property(i).name === name) e = fx.property(i);
  if (!e) { e = fx.addProperty("ADBE Slider Control"); e.name = name; }
  e.property(1).setValue(value);
  return e;
}

/* the shared head of every beat expression: e = 0…1 envelope of the last beat */
function pillowBeatEnvelope(times, tag, decayName) {
  var list = [];
  for (var i = 0; i < times.length; i++) list.push(Math.round(times[i] * 1000) / 1000);
  return "// Pillow Beat " + tag + " (re-apply in Pillow to refresh the beats)\n" +
    "var b = [" + list.join(",") + "];\n" +
    "var dec = effect(\"" + decayName + "\")(\"Slider\");\n" +
    "var t = time, lo = 0, hi = b.length - 1, k = -1;\n" +
    "while (lo <= hi) { var mid = Math.floor((lo + hi) / 2); if (b[mid] <= t) { k = mid; lo = mid + 1; } else { hi = mid - 1; } }\n" +
    "var e = 0;\n" +
    "if (k >= 0) { var d = t - b[k], a = 0.03; e = d < a ? d / a : Math.exp(-(d - a) * dec); }\n";
}

function pillowBeatSync(mode, every, strength) {
  every = Math.max(1, Math.round(every || 1));
  strength = Math.max(0, Math.min(100, strength == null ? 50 : strength));
  return pillowUndo("Beat Sync \u00b7 " + mode, function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var src = pillowBeatSource(comp);
    if (!src || src.times.length < 2) return pillowJson({ ok: false, error: "No beat markers \u2014 detect beats first (above)." });
    var beats = [];
    for (var i = 0; i < src.times.length; i += every) beats.push(src.times[i]);

    var sel = comp.selectedLayers, layers = [];
    for (i = 0; i < sel.length; i++) if (sel[i] !== src.layer) layers.push(sel[i]);

    if (mode === "flash") {
      var flash = null;
      for (i = 1; i <= comp.numLayers; i++) if (/^Beat Flash( \(Pillow\))?$/.test(comp.layer(i).name)) flash = comp.layer(i);
      if (!flash) {
        flash = comp.layers.addSolid([1, 1, 1], "Beat Flash (Pillow)", comp.width, comp.height, comp.pixelAspect, comp.duration);
        try { flash.label = PILLOW_LABELS.flash; } catch (eFl) {}
        try { flash.blendingMode = BlendingMode.ADD; } catch (eB) {}
        flash.moveToBeginning();
      }
      pillowBeatSlider(flash, "Flash Amount", strength);
      pillowBeatSlider(flash, "Flash Decay", 9);
      flash.property("ADBE Transform Group").property("ADBE Opacity").expression =
        pillowBeatEnvelope(beats, "Flash", "Flash Decay") +
        "effect(\"Flash Amount\")(\"Slider\") * e";
      return pillowJson({ ok: true, mode: mode, count: 1, beats: beats.length, source: src.name });
    }

    if (!layers.length) return pillowJson({ ok: false, error: "Select the layers to sync (not the audio layer)." });

    if (mode === "cut") {
      layers.sort(function (a, b) { return a.index - b.index; });
      var s0 = 0;
      while (s0 < beats.length && beats[s0] < comp.time - 0.0005) s0++;
      var placed = 0;
      for (i = 0; i < layers.length && s0 + i < beats.length; i++) {
        var L = layers[i], tin = beats[s0 + i];
        var tout = s0 + i + 1 < beats.length ? beats[s0 + i + 1] : tin + (beats[s0 + i] - beats[Math.max(0, s0 + i - 1)] || 1);
        try {
          L.startTime += tin - L.inPoint;
          if (tout > tin) L.outPoint = tout;
          placed++;
        } catch (eC) {}
      }
      if (!placed) return pillowJson({ ok: false, error: "No beats after the playhead." });
      return pillowJson({ ok: true, mode: mode, count: placed, beats: beats.length, source: src.name, partial: layers.length > placed });
    }

    var done = 0;
    for (i = 0; i < layers.length; i++) {
      var ly = layers[i], tr = ly.property("ADBE Transform Group");
      try {
        if (mode === "pulse") {
          pillowBeatSlider(ly, "Pulse Amount", Math.round(strength * 0.3 * 10) / 10);
          pillowBeatSlider(ly, "Pulse Decay", 9);
          tr.property("ADBE Scale").expression = pillowBeatEnvelope(beats, "Pulse", "Pulse Decay") +
            "var s = 1 + effect(\"Pulse Amount\")(\"Slider\") / 100 * e;\n" +
            "value.length > 2 ? [value[0] * s, value[1] * s, value[2]] : [value[0] * s, value[1] * s]";
        } else if (mode === "shake") {
          pillowBeatSlider(ly, "Shake Amount", Math.round(strength * 0.5));
          pillowBeatSlider(ly, "Shake Decay", 10);
          var head = pillowBeatEnvelope(beats, "Shake", "Shake Decay") +
            "var amp = effect(\"Shake Amount\")(\"Slider\") * e, f = time * 70;\n";
          var pos = tr.property("ADBE Position");
          if (pos.dimensionsSeparated) {
            tr.property("ADBE Position_0").expression = head + "value + Math.sin(f) * amp";
            tr.property("ADBE Position_1").expression = head + "value + Math.cos(f * 1.3) * amp * 0.8";
          } else {
            pos.expression = head + "var o = [Math.sin(f) * amp, Math.cos(f * 1.3) * amp * 0.8];\n" +
              "value.length > 2 ? [value[0] + o[0], value[1] + o[1], value[2]] : [value[0] + o[0], value[1] + o[1]]";
          }
        } else {
          return pillowJson({ ok: false, error: "Unknown mode" });
        }
        done++;
      } catch (eL) {}
    }
    if (!done) return pillowJson({ ok: false, error: "Could not apply to the selected layers." });
    return pillowJson({ ok: true, mode: mode, count: done, beats: beats.length, source: src.name });
  });
}

function pillowBeatRemove() {
  return pillowUndo("Remove Beat Sync", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var sel = comp.selectedLayers, n = 0, i;
    var toRemove = [];
    for (i = 0; i < sel.length; i++) {
      var L = sel[i];
      if (/^Beat Flash( \(Pillow\))?$/.test(L.name)) { toRemove.push(L); n++; continue; }
      var tr = L.property("ADBE Transform Group");
      var names = ["ADBE Scale", "ADBE Position", "ADBE Position_0", "ADBE Position_1", "ADBE Opacity"];
      for (var j = 0; j < names.length; j++) {
        try {
          var p = tr.property(names[j]);
          if (p && p.expression && p.expression.indexOf("// Pillow Beat") === 0) { p.expression = ""; n++; }
        } catch (eP) {}
      }
      var fx = L.property("ADBE Effect Parade");
      for (var k = fx.numProperties; k >= 1; k--) {
        if (/^(Pulse|Shake|Flash) (Amount|Decay)$/.test(fx.property(k).name)) fx.property(k).remove();
      }
    }
    for (i = 0; i < toRemove.length; i++) toRemove[i].remove();
    if (!n) return pillowJson({ ok: false, error: "No Beat Sync on the selected layers." });
    return pillowJson({ ok: true, count: n });
  });
}

/* ─── Library · whole layers ─────────────────────────────────────
 * pillowLibCaptureLayers() saves every selected layer with its whole
 * structure — type (solid, adjustment, null, text, shape, camera,
 * light; footage and precomps by reference), layer switches, timing,
 * parents and track mattes inside the set — and its property tree:
 * effects with all their changed settings, masks, shape contents, text
 * animators, keyframes (with ease and spatial tangents) and expressions.
 * Only what differs from the defaults is stored (isModified), so a
 * transition or a colour-correction adjustment layer stays small.
 * pillowLibApplyLayers() rebuilds them at the playhead, above the
 * selected layer. Full-frame solids follow the target comp's size. */

var PL_SKIP_GROUPS = { "ADBE Marker": 1, "ADBE Layer Styles": 1, "ADBE Audio Group": 1, "ADBE Layer Overrides": 1 };

function pillowLibLayerKind(L) {
  try { if (L instanceof TextLayer) return "text"; } catch (e0) {}
  try { if (L instanceof ShapeLayer) return "shape"; } catch (e1) {}
  try { if (L instanceof CameraLayer) return "camera"; } catch (e2) {}
  try { if (L instanceof LightLayer) return "light"; } catch (e3) {}
  try { if (L.nullLayer) return "null"; } catch (e4) {}
  var src = null;
  try { src = L.source; } catch (e5) {}
  if (src) {
    try { if (src instanceof CompItem) return "precomp"; } catch (e6) {}
    try { if (src.mainSource instanceof SolidSource) return L.adjustmentLayer ? "adjustment" : "solid"; } catch (e7) {}
    try { if (src.mainSource instanceof FileSource) return "footage"; } catch (e8) {}
  }
  return "null";
}

function pillowLibSerValue(p, v, ctx) {
  var t = p.propertyValueType;
  if (t === PropertyValueType.SHAPE) {
    return { sh: 1, vx: v.vertices, ti: v.inTangents, tq: v.outTangents, cl: v.closed };
  }
  if (t === PropertyValueType.TEXT_DOCUMENT) {
    var d = { td: 1, text: String(v.text) }, keys = ["font", "fontSize", "applyFill", "fillColor", "applyStroke", "strokeColor", "strokeWidth",
      "strokeOverFill", "justification", "tracking", "leading", "autoLeading", "fauxBold", "fauxItalic", "allCaps", "smallCaps", "baselineShift"];
    for (var i = 0; i < keys.length; i++) { try { if (v[keys[i]] !== undefined) d[keys[i]] = v[keys[i]]; } catch (e) {} }
    try { d.boxText = !!v.boxText; if (v.boxText) d.boxTextSize = v.boxTextSize; } catch (eB) {}
    return d;
  }
  if (t === PropertyValueType.LAYER_INDEX) {
    if (!v) return { li: -1 };
    for (var j = 0; j < ctx.layers.length; j++) if (ctx.layers[j].index === v) return { li: j };
    return { li: -1 };
  }
  return v;
}

function pillowLibSerProp(p, ctx) {
  var t = p.propertyValueType;
  if (t === PropertyValueType.NO_VALUE || t === PropertyValueType.CUSTOM_VALUE || t === PropertyValueType.MARKER) return null;
  var keyed = false, expr = "", mod = true;
  try { keyed = p.numKeys > 0; } catch (e0) {}
  try { if (p.canSetExpression) expr = p.expression || ""; } catch (e1) {}
  try { mod = p.isModified; } catch (e2) {}
  if (!keyed && !expr && !mod) return null;
  var o = { m: p.matchName };
  try { if (p.matchName === "ADBE Position" && p.dimensionsSeparated) o.sep = true; } catch (eS) {}
  if (expr) { o.x = expr; try { o.xe = p.expressionEnabled; } catch (e3) {} }
  if (keyed) {
    var spatial = t === PropertyValueType.TwoD_SPATIAL || t === PropertyValueType.ThreeD_SPATIAL;
    o.k = [];
    for (var n = 1; n <= p.numKeys; n++) {
      var k = { t: Math.round((p.keyTime(n) - ctx.t0) * 10000) / 10000, v: pillowLibSerValue(p, p.keyValue(n), ctx) };
      try { k.ii = p.keyInInterpolationType(n); k.oi = p.keyOutInterpolationType(n); } catch (e4) {}
      try { k.ie = pillowLibEase(p.keyInTemporalEase(n)); k.oe = pillowLibEase(p.keyOutTemporalEase(n)); } catch (e5) {}
      if (spatial) {
        try { k.it = p.keyInSpatialTangent(n); k.ot = p.keyOutSpatialTangent(n); k.r = p.keyRoving(n); } catch (e6) {}
      }
      o.k.push(k);
    }
    if (spatial) o.sp = 1;
  } else {
    var val;
    try { val = expr ? p.valueAtTime(ctx.time, true) : p.value; } catch (e7) { return null; }
    o.v = pillowLibSerValue(p, val, ctx);
  }
  return o;
}

/* a group: named groups only when something inside changed; the items
   of an indexed group (effects, masks, shape groups, animators) always,
   because they have to be re-added */
function pillowLibSerGroup(g, ctx, isItem) {
  var o = { m: g.matchName, kids: [] };
  if (isItem) {
    o.it = 1;
    try { o.n = g.name; } catch (e0) {}
    try { if (g.enabled === false) o.off = 1; } catch (e1) {}
    try { if (g.maskMode !== undefined) { o.mm = g.maskMode; o.inv = g.inverted; } } catch (e2) {}
  }
  var indexed = g.propertyType === PropertyType.INDEXED_GROUP;
  for (var i = 1; i <= g.numProperties; i++) {
    var c = g.property(i), r = null;
    if (!c || PL_SKIP_GROUPS[c.matchName]) continue;
    try {
      if (c.propertyType === PropertyType.PROPERTY) r = pillowLibSerProp(c, ctx);
      else r = pillowLibSerGroup(c, ctx, indexed);
    } catch (eC) { r = null; }
    if (r) o.kids.push(r);
  }
  if (!isItem && !o.kids.length) return null;
  return o;
}

/* Layers presets carry their precomps whole: every precomp a saved layer
   uses (and the precomps inside it, to any depth) is written into
   preset.comps, once each, with its size, frame rate, duration,
   background and all its layers - the same records as the saved layers
   themselves. Applying the preset in another project rebuilds those
   comps there, so the precomps come back with their content instead of
   as "[missing]" nulls. Footage inside is found by its file path. */
var PL_LIB_MAX_DEPTH = 8;

function pillowLibSerLayers(layers, comp, t0, time, st) {
  var ctx = { t0: t0, time: time, layers: layers };
  var out = [], i;
  for (i = 0; i < layers.length; i++) {
    var L = layers[i], kind = pillowLibLayerKind(L), rec = { kind: kind, name: L.name };
    st.kinds[kind] = (st.kinds[kind] || 0) + 1;
    try { rec.st = Math.round((L.startTime - t0) * 10000) / 10000; rec.ti = Math.round((L.inPoint - t0) * 10000) / 10000; rec.to = Math.round((L.outPoint - t0) * 10000) / 10000; } catch (eT) {}
    try { rec.str = L.stretch; } catch (eSt) {}
    var sw = ["enabled", "shy", "motionBlur", "threeDLayer", "collapseTransformation", "guideLayer", "preserveTransparency", "blendingMode", "label", "quality", "frameBlendingType", "effectsActive", "timeRemapEnabled"];
    rec.sw = {};
    for (var s = 0; s < sw.length; s++) { try { if (L[sw[s]] !== undefined) rec.sw[sw[s]] = L[sw[s]]; } catch (eW) {} }
    try { rec.tm = L.trackMatteType; } catch (eM) {}
    try { if (L.trackMatteLayer) for (var q = 0; q < layers.length; q++) if (layers[q] === L.trackMatteLayer) rec.tml = q; } catch (eML) {}
    try { if (L.parent) for (var pq = 0; pq < layers.length; pq++) if (layers[pq] === L.parent) rec.par = pq; } catch (eP) {}
    if (kind === "solid" || kind === "adjustment") {
      try { rec.color = L.source.mainSource.color; rec.w = L.source.width; rec.h = L.source.height; rec.pa = L.source.pixelAspect; } catch (eSo) {}
      rec.full = rec.w === comp.width && rec.h === comp.height;
    } else if (kind === "footage") {
      try { rec.file = L.source.mainSource.file.fsName; rec.srcName = L.source.name; } catch (eF) {}
      try { if (/\[\d+-\d+\]/.test(L.source.name) && !L.source.mainSource.isStill) { rec.seq = 1; rec.fps = L.source.mainSource.conformFrameRate || L.source.frameRate; } } catch (eSq) {}
    } else if (kind === "precomp") {
      try { rec.srcName = L.source.name; } catch (ePc) {}
      try { rec.pc = pillowLibSerComp(L.source, st); } catch (ePc2) {}
    } else if (kind === "light") {
      try { rec.lightType = L.lightType; } catch (eL) {}
    } else if (kind === "text") {
      try { var tdv = L.property("ADBE Text Properties").property("ADBE Text Document").value; if (tdv.boxText) rec.box = tdv.boxTextSize; } catch (eTx) {}
    }
    var props = [];
    for (var g = 1; g <= L.numProperties; g++) {
      var P = L.property(g), r = null;
      if (!P || PL_SKIP_GROUPS[P.matchName]) continue;
      try {
        if (P.propertyType === PropertyType.PROPERTY) r = pillowLibSerProp(P, ctx);
        else r = pillowLibSerGroup(P, ctx, false);
      } catch (eG) { r = null; }
      if (r) props.push(r);
    }
    rec.props = props;
    if (st.depth === 0) {
      try {
        var par = L.property("ADBE Effect Parade");
        for (var f = 1; f <= par.numProperties; f++) st.fx.push(par.property(f).name);
      } catch (eFx) {}
    }
    out.push(rec);
  }
  return out;
}

/* a precomp, written once into st.comps; returns its key there */
function pillowLibSerComp(C, st) {
  var key = "c" + C.id;
  if (st.comps[key] || st.busy[key]) return key;
  if (st.depth >= PL_LIB_MAX_DEPTH) return null;
  st.busy[key] = true;
  var rec = { name: C.name, w: C.width, h: C.height, pa: C.pixelAspect, fps: C.frameRate, dur: C.duration };
  try { rec.bg = C.bgColor; } catch (eBg) {}
  try { rec.ds = C.displayStartTime; } catch (eDs) {}
  try { rec.mb = { shutterAngle: C.shutterAngle, shutterPhase: C.shutterPhase }; } catch (eMb) {}
  var ls = [];
  for (var i = 1; i <= C.numLayers; i++) ls.push(C.layer(i));
  st.depth++;
  try { rec.layers = pillowLibSerLayers(ls, C, 0, 0, st); } finally { st.depth--; }
  st.comps[key] = rec;
  st.busy[key] = false;
  return key;
}

function pillowLibCaptureLayers() {
  var comp = pillowActiveComp();
  if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
  var sel = comp.selectedLayers, layers = [], i;
  for (i = 0; i < sel.length; i++) layers.push(sel[i]);
  if (!layers.length) return pillowJson({ ok: false, error: "Select the layers to save." });
  layers.sort(function (a, b) { return a.index - b.index; });
  var t0 = null, t1 = null;
  for (i = 0; i < layers.length; i++) {
    if (t0 === null || layers[i].inPoint < t0) t0 = layers[i].inPoint;
    if (t1 === null || layers[i].outPoint > t1) t1 = layers[i].outPoint;
  }
  var st = { kinds: {}, fx: [], comps: {}, busy: {}, depth: 0 };
  var out = pillowLibSerLayers(layers, comp, t0, comp.time, st);
  var preset = {
    v: 3, kind: "layers",
    duration: Math.round((t1 - t0) * 1000) / 1000,
    fps: comp.frameRate,
    comp: [comp.width, comp.height],
    layers: out,
    summary: { kinds: st.kinds, effects: st.fx.slice(0, 12) },
    layer: { name: layers[0].name }
  };
  var hasComps = false;
  for (var ck in st.comps) if (st.comps.hasOwnProperty(ck)) { hasComps = true; break; }
  if (hasComps) preset.comps = st.comps;
  return '{"ok":true,"preset":' + pillowLibStr(preset) + "}";
}

/* ---- apply ---- */

function pillowLibMakeValue(p, sv, ctx) {
  if (sv && typeof sv === "object" && !(sv instanceof Array)) {
    if (sv.sh) {
      var s = new Shape();
      s.vertices = sv.vx; s.inTangents = sv.ti; s.outTangents = sv.tq; s.closed = sv.cl;
      return s;
    }
    if (sv.td) {
      var d = p.value;
      d.text = sv.text;
      var keys = ["font", "fontSize", "applyFill", "fillColor", "applyStroke", "strokeColor", "strokeWidth", "strokeOverFill",
        "justification", "tracking", "leading", "autoLeading", "fauxBold", "fauxItalic", "allCaps", "smallCaps", "baselineShift"];
      for (var i = 0; i < keys.length; i++) { if (sv[keys[i]] !== undefined) { try { d[keys[i]] = sv[keys[i]]; } catch (e) {} } }
      return d;
    }
    if (sv.li !== undefined) {
      ctx.deferred.push({ prop: p, li: sv.li });
      return null;
    }
  }
  return sv;
}

function pillowLibShift(p, v, ctx) {
  /* full-frame layers follow a comp of another size */
  if (!ctx.shift || !(v instanceof Array)) return v;
  var m = p.matchName, d = null;
  if (m === "ADBE Position" && ctx.topLevel) d = ctx.dc;
  else if (m === "ADBE Anchor Point" && ctx.resized) d = ctx.ds;
  if (!d) return v;
  var r = v.slice(0);
  r[0] += d[0]; r[1] += d[1];
  return r;
}

function pillowLibApplyProp(p, rec, ctx) {
  /* separated position: the X / Y / Z properties carry the values */
  if (rec.sep) { try { p.dimensionsSeparated = true; } catch (eS) {} return; }
  if (rec.k && rec.k.length) {
    var idxs = [], k, n;
    for (k = 0; k < rec.k.length; k++) {
      var val = pillowLibMakeValue(p, rec.k[k].v, ctx);
      if (val === null) continue;
      val = pillowLibShift(p, val, ctx);
      var tt = ctx.T + rec.k[k].t;
      p.setValueAtTime(tt, val);
      idxs.push([p.nearestKeyIndex(tt), rec.k[k]]);
    }
    for (k = 0; k < idxs.length; k++) {
      n = idxs[k][0]; var K = idxs[k][1];
      try { if (K.ii) p.setInterpolationTypeAtKey(n, K.ii, K.oi); } catch (e1) {}
      if (K.ie && K.oe) {
        try {
          var need = rec.sp || p.isSpatial ? 1 : (p.value instanceof Array ? p.value.length : 1), ie = [], oe = [];
          for (var e2 = 0; e2 < need; e2++) {
            var a1 = K.ie[Math.min(e2, K.ie.length - 1)], a2 = K.oe[Math.min(e2, K.oe.length - 1)];
            ie.push(new KeyframeEase(a1[0], Math.max(0.1, Math.min(100, a1[1]))));
            oe.push(new KeyframeEase(a2[0], Math.max(0.1, Math.min(100, a2[1]))));
          }
          p.setTemporalEaseAtKey(n, ie, oe);
        } catch (e3) {}
      }
      if (rec.sp && K.it && K.ot) { try { p.setSpatialTangentsAtKey(n, K.it, K.ot); } catch (e4) {} }
    }
    if (rec.sp) for (k = 1; k < idxs.length - 1; k++) { try { if (idxs[k][1].r) p.setRovingAtKey(idxs[k][0], true); } catch (e5) {} }
  } else if (rec.v !== undefined) {
    var sv = pillowLibMakeValue(p, rec.v, ctx);
    if (sv !== null) p.setValue(pillowLibShift(p, sv, ctx));
  }
  if (rec.x) { try { p.expression = rec.x; if (rec.xe === false) p.expressionEnabled = false; } catch (e6) {} }
}

function pillowLibResolvePath(layer, path) {
  var g = layer;
  for (var i = 0; i < path.length; i++) g = g.property(path[i]);
  return g;
}

function pillowLibApplyGroup(layer, path, rec, ctx) {
  for (var i = 0; i < rec.kids.length; i++) {
    var kid = rec.kids[i], g = pillowLibResolvePath(layer, path);
    try {
      if (kid.it) {
        if (!g.canAddProperty(kid.m)) { ctx.missing.push(kid.n || kid.m); continue; }
        var c = g.addProperty(kid.m);
        try { if (kid.n) c.name = kid.n; } catch (eN) {}
        try { if (kid.mm !== undefined) { c.maskMode = kid.mm; c.inverted = !!kid.inv; } } catch (eM) {}
        var cpath = path.concat([c.propertyIndex]);
        pillowLibApplyGroup(layer, cpath, kid, ctx);
        if (kid.off) { try { pillowLibResolvePath(layer, cpath).enabled = false; } catch (eOff) {} }
      } else if (kid.kids) {
        var ng = g.property(kid.m);
        if (ng) pillowLibApplyGroup(layer, path.concat([ng.propertyIndex]), kid, ctx);
      } else {
        var p = g.property(kid.m);
        if (p) pillowLibApplyProp(p, kid, ctx);
      }
    } catch (eK) { ctx.errors++; }
  }
}

function pillowLibFindItem(test) {
  for (var i = 1; i <= app.project.numItems; i++) { var it = app.project.item(i); try { if (test(it)) return it; } catch (e) {} }
  return null;
}

/* the comp a saved precomp layer stands for: built once per apply from
   the preset's own copy (preset.comps), or - for presets saved before
   comps were kept - found in this project by name */
function pillowLibCompFor(rec, comp, B) {
  var key = rec.pc, C = null;
  if (key && B.comps && B.comps[key]) {
    if (B.built[key]) return B.built[key];
    var cr = B.comps[key];
    /* the same comp is already in this project (saved and applied here) */
    C = pillowLibFindItem(function (it) {
      return it instanceof CompItem && it !== comp && it.name === cr.name && it.width === cr.w && it.height === cr.h &&
        Math.abs(it.duration - cr.dur) < 0.001 && it.numLayers === (cr.layers || []).length;
    });
    if (!C) C = pillowLibBuildComp(cr, B);
    B.built[key] = C;
    return C;
  }
  return pillowLibFindItem(function (it) { return it instanceof CompItem && it.name === rec.srcName && it !== comp; });
}

function pillowLibBuildComp(cr, B) {
  var C = app.project.items.addComp(cr.name || "Comp", Math.max(4, Math.round(cr.w || 1920)), Math.max(4, Math.round(cr.h || 1080)),
    cr.pa || 1, Math.max(0.04, cr.dur || 10), cr.fps || 30);
  try { if (cr.bg) C.bgColor = cr.bg; } catch (eBg) {}
  try { if (cr.ds) C.displayStartTime = cr.ds; } catch (eDs) {}
  try { if (cr.mb) { C.shutterAngle = cr.mb.shutterAngle; C.shutterPhase = cr.mb.shutterPhase; } } catch (eMb) {}
  try {
    if (!B.folder) B.folder = app.project.items.addFolder("Pillow Library");
    C.parentFolder = B.folder;
  } catch (eF) {}
  B.depth++;
  try { pillowLibBuildLayers(C, cr.layers || [], 0, null, B, false); } finally { B.depth--; }
  B.compsMade++;
  return C;
}

/* builds recs into comp at time T; returns the new layers (index = rec) */
function pillowLibBuildLayers(comp, recs, T, anchor, B, top) {
  var sw0 = top && B.size ? B.size[0] : comp.width, sh0 = top && B.size ? B.size[1] : comp.height;
  var shift = sw0 !== comp.width || sh0 !== comp.height;
  var made = [], resized = [], i, L, rec;

  /* 1 - the bare layers, bottom first so the order ends up as saved */
  for (i = recs.length - 1; i >= 0; i--) {
    rec = recs[i]; L = null;
    try {
      if (rec.kind === "solid" || rec.kind === "adjustment") {
        var full = rec.full && shift, w = full || !rec.w ? comp.width : rec.w, h = full || !rec.h ? comp.height : rec.h;
        L = comp.layers.addSolid(rec.color || [1, 1, 1], rec.name, w, h, rec.pa || comp.pixelAspect, comp.duration);
        if (rec.kind === "adjustment") L.adjustmentLayer = true;
        resized[i] = full;
      } else if (rec.kind === "text") {
        L = rec.box ? comp.layers.addBoxText(rec.box) : comp.layers.addText("");
      } else if (rec.kind === "shape") {
        L = comp.layers.addShape();
      } else if (rec.kind === "camera") {
        L = comp.layers.addCamera(rec.name, [comp.width / 2, comp.height / 2]);
      } else if (rec.kind === "light") {
        L = comp.layers.addLight(rec.name, [comp.width / 2, comp.height / 2]);
        try { if (rec.lightType) L.lightType = rec.lightType; } catch (eLT) {}
      } else if (rec.kind === "footage" && rec.file) {
        var item = B.footage[rec.file] || pillowLibFindItem(function (it) { return it.mainSource && it.mainSource.file && it.mainSource.file.fsName === rec.file; });
        if (!item) {
          var f = new File(rec.file);
          if (f.exists) {
            var io = new ImportOptions(f);
            if (rec.seq) { try { io.sequence = true; } catch (eSq) {} }
            item = app.project.importFile(io);
            try { if (rec.seq && rec.fps) item.mainSource.conformFrameRate = rec.fps; } catch (eFr) {}
          }
        }
        if (item) { B.footage[rec.file] = item; L = comp.layers.add(item); } else B.notes.push("missing file: " + rec.name);
      } else if (rec.kind === "precomp") {
        var pc = pillowLibCompFor(rec, comp, B);
        if (pc) L = comp.layers.add(pc); else B.notes.push("missing comp: " + rec.srcName);
      }
      if (!L) { L = comp.layers.addNull(comp.duration); if (rec.kind !== "null") L.name = "[missing] " + rec.name; }
      try { if (L.name.indexOf("[missing]") !== 0) L.name = rec.name; } catch (eNm) {}
    } catch (eMk) {
      L = comp.layers.addNull(comp.duration);
      try { L.name = "[missing] " + rec.name; } catch (eNm2) {}
    }
    made[i] = L;
  }

  /* 2 - above the selected layer, keeping the saved order */
  if (anchor) {
    try {
      made[recs.length - 1].moveBefore(anchor);
      for (i = recs.length - 2; i >= 0; i--) made[i].moveBefore(made[i + 1]);
    } catch (eMv) {}
  }

  /* 3 - switches, timing and parents before any transform value, so
     parenting does not rewrite the values that follow */
  for (i = 0; i < recs.length; i++) {
    rec = recs[i]; L = made[i];
    var sw = rec.sw || {};
    if (sw.threeDLayer !== undefined) { try { L.threeDLayer = sw.threeDLayer; } catch (e3d) {} }
    if (sw.timeRemapEnabled) { try { L.timeRemapEnabled = true; } catch (eTR) {} }
    try { if (rec.str && rec.str !== 100) L.stretch = rec.str; } catch (eStr) {}
    try {
      if (rec.st !== undefined) L.startTime = T + rec.st;
      if (rec.ti !== undefined) L.inPoint = T + rec.ti;
      if (rec.to !== undefined) L.outPoint = T + rec.to;
    } catch (eTm) {}
  }
  for (i = 0; i < recs.length; i++) {
    if (recs[i].par !== undefined && made[recs[i].par]) { try { made[i].parent = made[recs[i].par]; } catch (ePa) {} }
  }

  /* 4 - the property trees */
  var ctx = { T: T, deferred: [], missing: B.missing, errors: 0, shift: shift,
    dc: [(comp.width - sw0) / 2, (comp.height - sh0) / 2] };
  for (i = 0; i < recs.length; i++) {
    rec = recs[i]; L = made[i];
    ctx.topLevel = recs[i].par === undefined;
    ctx.resized = !!resized[i];
    ctx.ds = [(comp.width - (rec.w || comp.width)) / 2, (comp.height - (rec.h || comp.height)) / 2];
    var props = rec.props || [];
    for (var g = 0; g < props.length; g++) {
      var pr = props[g];
      try {
        if (pr.kids) {
          var grp = L.property(pr.m);
          if (grp) pillowLibApplyGroup(L, [grp.propertyIndex], pr, ctx);
        } else {
          var pp = L.property(pr.m);
          if (pp) pillowLibApplyProp(pp, pr, ctx);
        }
      } catch (eG) { ctx.errors++; }
    }
  }
  /* layer references (Displacement Map, Set Matte...) point inside the set */
  for (i = 0; i < ctx.deferred.length; i++) {
    var dv = ctx.deferred[i];
    try { dv.prop.setValue(dv.li >= 0 && made[dv.li] ? made[dv.li].index : 0); } catch (eD) {}
  }

  /* 5 - switches last (enabled / matte after everything exists) */
  for (i = 0; i < recs.length; i++) {
    rec = recs[i]; L = made[i];
    var s2 = rec.sw || {}, names = ["shy", "motionBlur", "collapseTransformation", "guideLayer", "preserveTransparency", "blendingMode", "label", "quality", "frameBlendingType", "effectsActive", "enabled"];
    for (var n = 0; n < names.length; n++) { if (s2[names[n]] !== undefined) { try { L[names[n]] = s2[names[n]]; } catch (eSw) {} } }
    if (rec.tm !== undefined && rec.tm !== TrackMatteType.NO_TRACK_MATTE) {
      try {
        if (typeof L.setTrackMatte === "function" && rec.tml !== undefined && made[rec.tml]) L.setTrackMatte(made[rec.tml], rec.tm);
        else L.trackMatteType = rec.tm;
      } catch (eTm2) {}
    }
  }
  B.errors += ctx.errors;
  return made;
}

function pillowLibApplyLayers(encoded) {
  var data;
  try { data = pillowParse(decodeURIComponent(encoded)); } catch (e) { return pillowJson({ ok: false, error: "Preset data is damaged." }); }
  return pillowUndo("Library \u00b7 " + (data.name || "Layers"), function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var recs = data.layers || [];
    if (!recs.length) return pillowJson({ ok: false, error: "This preset has no layers." });
    var anchor = comp.selectedLayers.length ? comp.selectedLayers[0] : null;
    var B = { comps: data.comps || null, built: {}, footage: {}, folder: null, notes: [], missing: [], errors: 0,
      depth: 0, compsMade: 0, size: data.comp || null };
    var made = pillowLibBuildLayers(comp, recs, comp.time, anchor, B, true), i;
    for (i = 0; i < comp.numLayers; i++) { try { comp.layer(i + 1).selected = false; } catch (eSel) {} }
    for (i = 0; i < made.length; i++) { try { made[i].selected = true; } catch (eSel2) {} }
    /* a preset saved before precomps were kept, applied where its comps
       still exist: their copies go back to the panel, which writes them
       into the preset, so from now on it works in any project */
    var up = null;
    for (i = 0; i < recs.length; i++) {
      if (recs[i].kind !== "precomp" || recs[i].pc) continue;
      var src = null;
      try { src = made[i].source; } catch (eSrc) {}
      if (!src || !(src instanceof CompItem)) continue;
      if (!up) up = { pcs: {}, st: { kinds: {}, fx: [], comps: {}, busy: {}, depth: 1 } };
      try { var key = pillowLibSerComp(src, up.st); if (key) up.pcs[i] = key; } catch (eUp) {}
    }
    var res = '{"ok":true,"count":' + made.length + ',"comps":' + B.compsMade + ',"missing":' + pillowLibStr(B.missing.slice(0, 6)) +
      ',"notes":' + pillowLibStr(B.notes.slice(0, 6)) + ',"errors":' + B.errors;
    if (up) res += ',"upgrade":' + pillowLibStr({ pcs: up.pcs, comps: up.st.comps });
    return res + "}";
  });
}

/* ─── Liquid Glass for layers ─────────────────────────────────────
 * pillowGlassMake(json) turns each selected layer (shape, text, any
 * layer with alpha) into Apple-style liquid glass, built only from
 * effects that ship with AE:
 *   the layer is precomposed (all its attributes move inside, so its
 *   animation and edits keep driving the form) and switched off; inside
 *   it gets a white Fill so its colour does not matter any more. Above
 *   it, every glass layer takes the form from that precomp — comp-sized
 *   and untransformed, so effect layer references line up exactly:
 *     Glass Shadow  — soft shadow outside the form (Drop Shadow, cut out)
 *     Glass Lens    — adjustment layer, track-matted to the form: Fast
 *                     Box Blur (frost) + Displacement Map driven by the
 *                     "Glass Map" comp (the slope of the rim)
 *     Glass Tint    — light / dark tint inside
 *     Glass Rim     — bright rim: two Bevel Alpha passes, Add
 *     ◆ Glass       — null with the controls (sliders, tint colour),
 *                     every value is linked by expression
 * All pieces carry the comment "PILLOW-GLASS <id>"; pillowGlassRemove
 * takes it apart again and puts the original layer back. */

function pillowFxByName(fx, names) {
  for (var i = 1; i <= fx.numProperties; i++) {
    var p = fx.property(i), n = String(p.name).toLowerCase();
    for (var j = 0; j < names.length; j++) if (n === names[j].toLowerCase()) return p;
  }
  return null;
}

function pillowGlassAddFx(layer, matchName, name) {
  var fx = layer.property("ADBE Effect Parade").addProperty(matchName);
  if (name) { try { fx.name = name; } catch (e) {} }
  return fx;
}

function pillowGlassSetMatte(layer, formLayer, invert) {
  var sm = pillowGlassAddFx(layer, "ADBE Set Matte3", invert ? "Glass Cut" : "Glass Form");
  sm.property(1).setValue(formLayer.index);
  if (invert) { try { sm.property(3).setValue(1); } catch (e) {} }
  return sm;
}

/* The last step the glass maker reached (the panel reads it from the
   file below when After Effects stops the script without an error);
   PILLOW_HOST_BUILD is reported in the panel's error messages. */
var PILLOW_GLASS_STEP = "";
var PILLOW_HOST_BUILD = "1.0.0";
/* the step is also written to a file in the temp folder: it survives
   even when After Effects resets the script engine */
function pillowGlassStep(label) {
  PILLOW_GLASS_STEP = label;
  try {
    var f = new File(Folder.temp.fsName + "/pillow-glass-step.txt");
    f.encoding = "UTF-8";
    if (f.open("w")) { f.write(label); f.close(); }
  } catch (e) {}
}

/* A name no comp in the project has yet: the glass comps are found by
   name from their expressions. */
function pillowGlassUniqueName(base) {
  var used = {}, i;
  for (i = 1; i <= app.project.numItems; i++) {
    try { used[app.project.item(i).name] = true; } catch (e) {}
  }
  if (!used[base]) return base;
  for (i = 2; i < 1000; i++) if (!used[base + " " + i]) return base + " " + i;
  return base + " " + new Date().getTime();
}

/* The panel's shape as a new layer in the middle of the form comp. Its
   size and roundness follow the sliders on the glass controls. */
function pillowGlassNewShape(F, shape, ctlRef) {
  var W = F.width, H = F.height, m = Math.min(W, H), L;
  if (shape === "text") {
    L = F.layers.addText("Glass");
    var tp = L.property("ADBE Text Properties").property("ADBE Text Document");
    var td = tp.value;
    td.fontSize = Math.round(m * 0.26);
    var face = "Arial-BoldMT";
    try {
      var names = ["SFProDisplay-Heavy", "SFProDisplay-Bold", "SFPro-Bold", "Inter-Black", "Inter-Bold", "Montserrat-Black", "Arial-Black"];
      for (var n = 0; n < names.length; n++) {
        if (app.fonts && app.fonts.getFontsByPostScriptName && app.fonts.getFontsByPostScriptName(names[n]).length) { face = names[n]; break; }
      }
    } catch (eF) {}
    try { td.font = face; } catch (eFt) {}
    try { td.applyFill = true; td.fillColor = [1, 1, 1]; td.applyStroke = false; } catch (eC) {}
    try { td.justification = ParagraphJustification.CENTER_JUSTIFY; } catch (eJ) {}
    try { td.tracking = -20; } catch (eTr) {}
    tp.setValue(td);
    L.name = "Glass Text";
    try {
      var r = L.sourceRectAtTime(F.time, false);
      L.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([r.left + r.width / 2, r.top + r.height / 2]);
    } catch (eA) {}
  } else {
    L = F.layers.addShape();
    var grp = L.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
    grp.name = "Glass";
    var vec = grp.property("ADBE Vectors Group");
    if (shape === "circle") {
      var el = vec.addProperty("ADBE Vector Shape - Ellipse");
      el.property("ADBE Vector Ellipse Size").expression = "var s = " + ctlRef + '.effect("Size")(1);\n[s, s];';
      L.name = "Glass Circle";
    } else {
      /* a superellipse-cornered rect (Apple's continuous corners): each
         corner is a quarter of |x|^n + |y|^n = 1, n from Smoothness */
      var sp = vec.addProperty("ADBE Vector Shape - Group");
      sp.property("ADBE Vector Shape").expression =
        "var c = " + ctlRef + ";\n" +
        'var w = c.effect("Width")(1), h = c.effect("Height")(1);\n' +
        'var r = Math.max(0.5, c.effect("Roundness")(1) / 100 * Math.min(w, h) / 2);\n' +
        'var n = 3; try { n = c.effect("Smoothness")(1); } catch (e) {}\n' +
        "n = Math.max(1.5, n);\n" +
        "var pts = [], N = 28, cs = [[1, 1], [-1, 1], [-1, -1], [1, -1]];\n" +
        "for (var k = 0; k < 4; k++) {\n" +
        "  var sx = cs[k][0], sy = cs[k][1], cx = sx * (w / 2 - r), cy = sy * (h / 2 - r);\n" +
        "  for (var i = 0; i <= N; i++) {\n" +
        "    var a = (k + i / N) * Math.PI / 2, co = Math.cos(a), si = Math.sin(a);\n" +
        "    var px = (co < 0 ? -1 : 1) * Math.pow(Math.abs(co), 2 / n), py = (si < 0 ? -1 : 1) * Math.pow(Math.abs(si), 2 / n);\n" +
        "    pts.push([cx + r * px, cy + r * py]);\n" +
        "  }\n" +
        "}\n" +
        "createPath(pts, [], [], true);";
      L.name = shape === "squircle" ? "Glass Squircle" : "Glass Pill";
    }
    var fl = vec.addProperty("ADBE Vector Graphic - Fill");
    fl.property("ADBE Vector Fill Color").setValue([1, 1, 1]);
  }
  L.property("ADBE Transform Group").property("ADBE Position").setValue([W / 2, H / 2]);
  return L;
}

/* The refraction map has to sit where the glass layer is now. Displacement
   Map reads its map comp untransformed, in the active comp's space, so
   moving, scaling or turning the "Pillow Liquid Glass" layer left the
   refraction behind. Each slope layer of the map follows the glass
   layer's anchor, position, scale and rotation (through toComp, so a
   parent counts too). prefix: the expression lines that define band. */
var PILLOW_FOLLOW_MARK = "// follows the glass layer\n";
function pillowGlassFollow(fl, prefix, mainName, glName) {
  var q = function (s) { return String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"'); };
  var L = 'var L = comp("' + q(mainName) + '").layer("' + q(glName) + '");\n';
  var n = String(fl.name), dx = 0, dy = 0;
  if (/^(Slope|Body) X/.test(n)) dx = /\+$/.test(n) ? -1 : 1;
  else dy = /\+$/.test(n) ? -1 : 1;
  var tg = fl.property("ADBE Transform Group");
  var frame = L + "var a = L.transform.anchorPoint;\n" +
    "var o = L.toComp(a), x = L.toComp([a[0] + 100, a[1]]), y = L.toComp([a[0], a[1] + 100]);\n";
  tg.property("ADBE Anchor Point").expression = L + "var a = L.transform.anchorPoint;\n[a[0], a[1]];";
  tg.property("ADBE Position").expression = prefix + PILLOW_FOLLOW_MARK + L +
    "var o = L.toComp(L.transform.anchorPoint);\n" +
    "[o[0] + " + dx + " * band * 0.2, o[1] + " + dy + " * band * 0.2];";
  tg.property("ADBE Scale").expression = frame +
    "[Math.sqrt(Math.pow(x[0] - o[0], 2) + Math.pow(x[1] - o[1], 2)), Math.sqrt(Math.pow(y[0] - o[0], 2) + Math.pow(y[1] - o[1], 2))];";
  tg.property("ADBE Rotate Z").expression = frame + "radiansToDegrees(Math.atan2(x[1] - o[1], x[0] - o[0]));";
}

/* the band-defining head of a slope layer's position expression, from any
   version of it */
function pillowGlassBandPrefix(expr) {
  expr = String(expr || "");
  var i = expr.indexOf(PILLOW_FOLLOW_MARK);
  if (i >= 0) return expr.slice(0, i);
  i = expr.indexOf("value + [");
  return i >= 0 ? expr.slice(0, i) : null;
}

/* The shape sliders a new glass gets, and their starting values. */
function pillowGlassShapeSliders(shape, o) {
  var d = o.dims || {};
  if (shape === "circle") return [["Size", d.w != null ? d.w : 360]];
  if (shape === "text") return [];
  var sq = shape === "squircle";
  return [["Width", d.w != null ? d.w : (sq ? 360 : 600)], ["Height", d.h != null ? d.h : (sq ? 360 : 180)],
    ["Roundness", d.r != null ? d.r : (sq ? 52 : 100)], ["Smoothness", d.n != null ? d.n : (sq ? 3 : 2)]];
}

/*
 * Liquid Glass. Everything lives in one comp, "Pillow Liquid Glass",
 * placed in the active comp with Collapse Transformations on: that way
 * its adjustment layer still bends and blurs whatever is below it in the
 * active comp, and the whole glass moves, scales and rotates as one layer.
 *   ◆ Glass Controls — null with every slider (and the shape's size)
 *   Glass Rim         — bright rim: two Bevel Alpha passes, Add
 *   Glass Tint        — light / dark tint inside
 *   Glass Lens        — adjustment layer, track-matted to the form: Fast
 *                       Box Blur (frost) + Displacement Map driven by the
 *                       "Glass Map" comp (the slope of the rim)
 *   Glass Shadow      — soft shadow outside the form
 *   Glass Form        — the shape (a new one, or the selected layer moved
 *                       in with all its animation), white, switched off
 */
function pillowGlassMake(json) {
  var o = {};
  pillowGlassStep("start");
  try { o = pillowParse(json); } catch (e0) {}
  return pillowUndo("Liquid Glass", function () {
    pillowGlassStep("selection");
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });

    var jobs = [], i;
    if (o.create) {
      jobs.push({ create: String(o.create) });
    } else {
      var sel = comp.selectedLayers;
      for (i = 0; i < sel.length; i++) {
        var c = sel[i], isGlass = false, kind = "";
        try { isGlass = String(c.comment).indexOf("PILLOW-GLASS") === 0; } catch (eC) {}
        try { kind = pillowLibLayerKind(c); } catch (eK) {}
        if (!isGlass && kind !== "camera" && kind !== "light" && kind !== "null" && kind !== "adjustment") jobs.push({ layer: c });
      }
      if (!jobs.length) return pillowJson({ ok: false, error: "Select a shape or text layer to turn into glass." });
    }

    var v = {
      refraction: o.refraction != null ? o.refraction : 45, edge: o.edge != null ? o.edge : 22,
      frost: o.frost != null ? o.frost : 5, highlight: o.highlight != null ? o.highlight : 70,
      tint: o.tint != null ? o.tint : 8, shadow: o.shadow != null ? o.shadow : 22,
      dispersion: o.dispersion != null ? o.dispersion : 35, fresnel: o.fresnel != null ? o.fresnel : 60,
      tintColor: o.tintColor || [1, 1, 1]
    };
    var made = 0, notes = [], last = null;

    /* every part is built on its own: a part that fails is reported and
       the rest of the glass is still made */
    var part = function (label, fn) {
      pillowGlassStep(label);
      try {
        return fn();
      } catch (e) {
        var msg = label + ": " + String(e && e.message ? e.message : e);
        try { if (e.line) msg += " (line " + e.line + ")"; } catch (eL) {}
        notes.push(msg);
      }
      return null;
    };
    var opacityFrom = function (layer, expr) {
      try { layer.property("ADBE Transform Group").property("ADBE Opacity").expression = expr; } catch (eO) {}
    };
    var quote = function (s) { return String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"'); };

    /* jobs run from the bottom up so the indexes of the ones still to do
       stay put */
    jobs.sort(function (a, b) { return (b.layer ? b.layer.index : 0) - (a.layer ? a.layer.index : 0); });

    for (i = 0; i < jobs.length; i++) {
      var job = jobs[i], gid = "g" + (new Date().getTime()) + "_" + i;
      var W = comp.width, H = comp.height, pa = comp.pixelAspect, dur = comp.duration, fr = comp.frameRate;
      var gName = pillowGlassUniqueName("Pillow Liquid Glass");
      var ctlName = "\u25C6 Glass Controls (Pillow)";
      var ctlRef = 'comp("' + quote(gName) + '").layer("' + quote(ctlName) + '")';
      var shape = job.create || "";
      var sliders = shape ? pillowGlassShapeSliders(shape, o) : [];

      /* how thick the form is: the rim band is measured against it, as in
         the panel preview. New shapes follow their sliders. */
      var mdExpr = "60";
      if (shape === "circle") mdExpr = ctlRef + '.effect("Size")(1) / 2';
      else if (shape && shape !== "text") mdExpr = "Math.min(" + ctlRef + '.effect("Width")(1), ' + ctlRef + '.effect("Height")(1)) / 2';
      else if (shape === "text") mdExpr = String(Math.max(4, Math.round(Math.min(W, H) * 0.26 * 0.1)));
      else {
        var maxD = 60, L0 = job.layer;
        try {
          var rc = L0.sourceRectAtTime(comp.time, false);
          var sc = L0.property("ADBE Transform Group").property("ADBE Scale").value;
          var fw = Math.abs(rc.width * sc[0] / 100), fh = Math.abs(rc.height * sc[1] / 100);
          maxD = (L0 instanceof TextLayer) ? fh * 0.14 : Math.min(fw, fh) / 2;
        } catch (eR) {}
        mdExpr = String(Math.max(4, Math.round(maxD)));
      }
      var bandOf = function () {
        return "var e = " + ctlRef + '.effect("Edge")(1);\n' +
          "var md = " + mdExpr + ";\n" +
          "var band = Math.min(Math.max(e / 100 * 2.2 * md, 2.5), md * 1.15);\n";
      };

      /* 1 — the glass comp and its controls */
      pillowGlassStep("glass comp");
      var G = app.project.items.addComp(gName, W, H, pa, dur, fr);
      try { G.comment = "PILLOW-GLASS " + gid + " glass"; } catch (eGc) {}
      var ctl = G.layers.addNull(dur);
      ctl.name = ctlName;
      pillowNameSource(ctl, ctlName);
      try { ctl.comment = "PILLOW-GLASS " + gid + " controls"; } catch (eCc) {}
      try { ctl.label = 9; } catch (eL9) {}
      var sl = [["Refraction", v.refraction], ["Edge", v.edge], ["Frost", v.frost],
        ["Highlight", v.highlight], ["Tint", v.tint], ["Shadow", v.shadow],
        ["Dispersion", v.dispersion], ["Fresnel", v.fresnel]].concat(sliders);
      for (var s = 0; s < sl.length; s++) part("slider " + sl[s][0], (function (d) { return function () { pillowBeatSlider(ctl, d[0], d[1]); }; })(sl[s]));
      part("tint colour", function () {
        var tc = pillowGlassAddFx(ctl, "ADBE Color Control", "Tint Color");
        tc.property(1).setValue(v.tintColor);
      });

      /* 2 — the form comp */
      pillowGlassStep("form");
      var F, tIn = 0, tOut = dur, place = null, name;
      if (shape) {
        F = app.project.items.addComp("Glass Form \u00b7 " + gName, W, H, pa, dur, fr);
        var NL = pillowGlassNewShape(F, shape, ctlRef);
        name = NL.name;
        try { F.comment = "PILLOW-GLASS " + gid + " new"; } catch (eFc) {}
      } else {
        var L = job.layer, idx = L.index;
        name = L.name; tIn = L.inPoint; tOut = L.outPoint;
        F = comp.layers.precompose([idx], "Glass Form \u00b7 " + name, true);
        place = comp.layer(idx);
        try { F.comment = "PILLOW-GLASS " + gid + " layer"; } catch (eFc2) {}
        part("form fill", function () {
          for (var q = 1; q <= F.numLayers; q++) {
            var fill = pillowGlassAddFx(F.layer(q), "ADBE Fill", "Pillow Glass Form");
            (pillowFxByName(fill, ["Color"]) || fill.property(3)).setValue([1, 1, 1]);
          }
        });
      }
      var P = G.layers.add(F);
      P.moveToEnd();
      P.comment = "PILLOW-GLASS " + gid + " form";
      try { P.enabled = false; } catch (eEn) {}
      try { P.label = 0; } catch (eLb) {}

      var ref = 'thisComp.layer("' + quote(ctlName) + '")';
      var makeSolid = function (nm, col, adjust) {
        var so = G.layers.addSolid(col, nm, W, H, pa, dur);
        try { so.comment = "PILLOW-GLASS " + gid; } catch (eCm) {}
        if (adjust) { try { so.adjustmentLayer = true; } catch (eAd) {} }
        so.moveBefore(P);
        return so;
      };

      /* 3 — rim highlight */
      part("rim", function () {
        var r = makeSolid("Glass Rim", [0, 0, 0], false);
        pillowGlassSetMatte(r, P, false);
        var b1 = pillowGlassAddFx(r, "ADBE Bevel Alpha", "Rim Light");
        try { b1.property(1).setValue(2.5); b1.property(2).setValue(-45); b1.property(3).setValue([1, 1, 1]); b1.property(4).setValue(1); } catch (eB1) {}
        var b2 = pillowGlassAddFx(r, "ADBE Bevel Alpha", "Rim Back");
        try { b2.property(1).setValue(1.5); b2.property(2).setValue(135); b2.property(3).setValue([1, 1, 1]); b2.property(4).setValue(0.45); } catch (eB2) {}
        try { r.blendingMode = BlendingMode.ADD; } catch (eBm) {}
        opacityFrom(r, ref + '.effect("Highlight")(1)');
      });

      /* 4 — tint */
      part("tint", function () {
        var t = makeSolid("Glass Tint", [1, 1, 1], false);
        var tf = pillowGlassAddFx(t, "ADBE Fill", "Tint");
        try { (pillowFxByName(tf, ["Color"]) || tf.property(3)).expression = ref + '.effect("Tint Color")(1)'; } catch (eTf) {}
        pillowGlassSetMatte(t, P, false);
        opacityFrom(t, ref + '.effect("Tint")(1)');
      });

      /* 5 — the refraction map: the white form, blurred, laid in twice
         shifted left/right (red) and up/down (green) on a 50% grey, one
         copy added and one subtracted. That leaves the slope of the form
         in each channel, grey where the glass is flat, and Displacement
         Map bends what is behind the glass along it. Two sets of slopes,
         like a thick lens: a wide one that magnifies the whole inside
         ("Body") and a narrow one that squeezes the rim ("Slope", its
         width from Edge). */
      var mdHead = "var md = " + mdExpr + ";\n";
      var setsOf = function () {
        return [
          { tag: "Slope", op: 25,
            head: "var e = " + ctlRef + '.effect("Edge")(1);\n' + mdHead + "var band = Math.max(1.5, e / 100 * md) * 0.75 / 0.2;\n",
            blur: "band * 0.2 / 0.75;" },
          { tag: "Body", op: 20, head: mdHead + "var band = md * 0.5 / 0.2;\n", blur: "md;" }
        ];
      };
      var mapC = part("refraction map", function () {
        var mc = app.project.items.addComp("Glass Map \u00b7 " + gName, W, H, pa, dur, fr);
        try { mc.comment = "PILLOW-GLASS " + gid + " map"; } catch (eMc) {}
        mc.layers.addSolid([0.5, 0.5, 0], "Flat", W, H, pa, dur);
        /* added bottom-up: all ADD copies first, then the SUBTRACT ones,
           so nothing clips on the way (at most 0.5 + 0.25 + 0.2) */
        var sets = setsOf(), order = [BlendingMode.ADD, BlendingMode.SUBTRACT];
        for (var oi = 0; oi < 2; oi++) {
          for (var si = 0; si < sets.length; si++) {
            var st = sets[si], add = order[oi] === BlendingMode.ADD;
            var copies = [[add ? -1 : 1, 0, [1, 0, 0]], [0, add ? -1 : 1, [0, 1, 0]]];
            for (var q = 0; q < copies.length; q++) {
              var cp = copies[q], fl = mc.layers.add(F);
              fl.name = st.tag + (cp[0] ? " X " : " Y ") + (add ? "+" : "-");
              var cf = pillowGlassAddFx(fl, "ADBE Fill", "Channel");
              (pillowFxByName(cf, ["Color"]) || cf.property(3)).setValue(cp[2]);
              var bb = pillowGlassAddFx(fl, "ADBE Box Blur2", "Rim Band");
              try { bb.property(2).setValue(3); } catch (eBi) {}
              bb.property(1).expression = st.head + st.blur;
              pillowGlassFollow(fl, st.head, comp.name, gName);
              fl.property("ADBE Transform Group").property("ADBE Opacity").setValue(st.op);
              fl.blendingMode = order[oi];
            }
          }
        }
        return mc;
      });

      /* 6 — fresnel: a thin even line just inside the edge (the form
         minus the form choked by a couple of pixels), added on top */
      part("fresnel", function () {
        var cut = G.layers.add(F);
        cut.name = "Fresnel Cut";
        try { cut.comment = "PILLOW-GLASS " + gid; } catch (eCc1) {}
        var cfl = pillowGlassAddFx(cut, "ADBE Fill", "White");
        (pillowFxByName(cfl, ["Color"]) || cfl.property(3)).setValue([1, 1, 1]);
        var ch = pillowGlassAddFx(cut, "ADBE Simple Choker", "Ring");
        ch.property(2).expression = "var md = " + mdExpr + ";\nMath.min(4, Math.max(1.2, md * 0.018));";
        var fr2 = G.layers.add(F);
        fr2.name = "Glass Fresnel";
        try { fr2.comment = "PILLOW-GLASS " + gid; } catch (eCc2) {}
        var ffl = pillowGlassAddFx(fr2, "ADBE Fill", "White");
        (pillowFxByName(ffl, ["Color"]) || ffl.property(3)).setValue([1, 1, 1]);
        var soft = pillowGlassAddFx(fr2, "ADBE Box Blur2", "Soft");
        try { soft.property(1).setValue(0.6); soft.property(2).setValue(1); } catch (eSo) {}
        fr2.moveToBeginning();
        cut.moveBefore(fr2);
        if (typeof fr2.setTrackMatte === "function") {
          fr2.setTrackMatte(cut, TrackMatteType.ALPHA_INVERTED);
          try { cut.enabled = false; } catch (eEn2) {}
        } else {
          fr2.trackMatteType = TrackMatteType.ALPHA_INVERTED;
        }
        try { fr2.blendingMode = BlendingMode.ADD; } catch (eBm2) {}
        opacityFrom(fr2, ref + '.effect("Fresnel")(1) * 0.3');
      });

      /* 7 — shadow, outside the form only */
      part("shadow", function () {
        var d = makeSolid("Glass Shadow", [0, 0, 0], false);
        pillowGlassSetMatte(d, P, false);
        var ds = pillowGlassAddFx(d, "ADBE Drop Shadow", "Shadow");
        try { ds.property(2).setValue(255); } catch (eDo) { try { ds.property(2).setValue(100); } catch (eDo2) {} }
        try { ds.property(3).setValue(180); ds.property(4).setValue(10); ds.property(5).setValue(40); ds.property(6).setValue(1); } catch (eDs) {}
        pillowGlassSetMatte(d, P, true);
        opacityFrom(d, ref + '.effect("Shadow")(1)');
      });
      ctl.moveToBeginning();

      /* 8 — into the active comp, collapsed, where the layer was */
      pillowGlassStep("place");
      var GL = comp.layers.add(G);
      GL.name = gName;
      try { GL.comment = "PILLOW-GLASS " + gid + " glass"; } catch (eGl) {}
      try { GL.collapseTransformation = true; } catch (eCt) { notes.push("turn on Collapse Transformations for " + gName); }
      try { GL.label = 9; } catch (eL9b) {}
      if (place) {
        GL.moveBefore(place);
        try { GL.inPoint = tIn; GL.outPoint = tOut; } catch (eIO) {}
        place.remove();
      }
      part("lens", function () {
        pillowGlassMount(comp, GL, gid, F, mapC, ctlRef, bandOf(), {
          amount: "var md = Math.min(" + mdExpr + ", 110);\n" + ctlRef + '.effect("Refraction")(1) / 100 * md * 2;',
          dispersion: true
        });
      });
      made++;
      last = GL;
    }
    pillowGlassStep("finish");
    for (var k = 1; k <= comp.numLayers; k++) { try { comp.layer(k).selected = false; } catch (eS) {} }
    try { if (last) last.selected = true; } catch (eS2) {}
    pillowGlassStep("done");
    return pillowJson({ ok: true, count: made, notes: notes });
  });
}

/*
 * The lens lives in the active comp, right under the glass layer, not in
 * the glass comp: inside a collapsed precomp After Effects runs an
 * adjustment layer where the precomp sits untransformed, so moving the
 * glass left its blur and refraction behind. Three helper layers, all
 * following the glass layer:
 *   Glass Shape — the form, parented to the glass layer: the lens's
 *                 track matte, so the lens goes wherever the glass goes
 *   Glass Lens  — adjustment layer: Frost + Displacement Map
 *   Glass Map   — the refraction map (its comp already follows the glass)
 * bandPrefix: the expression lines that define band.
 */
function pillowGlassMount(comp, GL, gid, F, M, ctlRef, bandPrefix, opts) {
  opts = opts || {};
  var W = comp.width, H = comp.height, pa = comp.pixelAspect, dur = comp.duration;
  var tag = "PILLOW-GLASS " + gid + " ";
  var keep = function (L, nm, kind) {
    L.name = nm;
    try { L.comment = tag + kind; } catch (e) {}
    try { L.inPoint = GL.inPoint; L.outPoint = GL.outPoint; } catch (eIO) {}
    try { L.shy = true; } catch (eSh) {}
    try { L.label = 9; } catch (eLb) {}
    return L;
  };
  var mapL = null;
  if (M) {
    mapL = keep(comp.layers.add(M), "Glass Map \u00b7 " + GL.name, "map");
    mapL.moveAfter(GL);
    mapL.enabled = false;
  }
  var ln = keep(comp.layers.addSolid([1, 1, 1], "Glass Lens \u00b7 " + GL.name, W, H, pa, dur), "Glass Lens \u00b7 " + GL.name, "lens");
  ln.adjustmentLayer = true;
  ln.moveAfter(GL);
  var ml = keep(comp.layers.add(F), "Glass Shape \u00b7 " + GL.name, "matte");
  ml.moveAfter(GL);
  /* both sit untransformed in the middle of the comp, so the parent keeps
     the shape exactly under the glass and carries it along */
  ml.parent = GL;

  var fb = pillowGlassAddFx(ln, "ADBE Box Blur2", "Frost");
  try { fb.property(2).setValue(3); } catch (eIt) {}
  try { fb.property(4).setValue(1); } catch (eRe) {}
  fb.property(1).expression = ctlRef + '.effect("Frost")(1) * thisComp.width / 700;';
  if (mapL) {
    var dm = pillowGlassAddFx(ln, "ADBE Displacement Map", "Refraction");
    dm.property(1).setValue(mapL.index);
    var amount = opts.amount || (bandPrefix + ctlRef + '.effect("Refraction")(1) / 100 * band * 1.4;');
    try { dm.property(2).setValue(1); } catch (eH) {}   /* red   -> horizontal */
    dm.property(3).expression = amount;
    try { dm.property(4).setValue(2); } catch (eV) {}   /* green -> vertical */
    dm.property(5).expression = amount;
    try { dm.property(6).setValue(1); } catch (eBh) {}  /* centre the map */
  }
  /* the lens works only inside the shape */
  if (typeof ln.setTrackMatte === "function") {
    ln.setTrackMatte(ml, TrackMatteType.ALPHA);
    try { ml.enabled = false; } catch (eEn) {}
  } else {
    ln.trackMatteType = TrackMatteType.ALPHA;   /* the shape is right above */
  }
  /* dispersion: red bends a little more than green, blue a little less.
     Two more adjustment layers over the lens, each bending its result by
     the difference and keeping one channel (Shift Channels), laid on in
     Lighten so the other channels stay as they are. Needs a shared track
     matte (After Effects 2023 and later). */
  if (opts.dispersion && mapL && typeof ln.setTrackMatte === "function") {
    var OFF = 11;   /* Shift Channels: "Full Off" */
    var chans = [["R", 1, [2, OFF, OFF]], ["B", -1, [OFF, OFF, 4]]];
    for (var c = 0; c < chans.length; c++) {
      try {
        var cn = "Glass Dispersion " + chans[c][0] + " \u00b7 " + GL.name;
        var dl = keep(comp.layers.addSolid([1, 1, 1], cn, W, H, pa, dur), cn, "lens");
        dl.adjustmentLayer = true;
        dl.moveBefore(ln);
        var dd = pillowGlassAddFx(dl, "ADBE Displacement Map", "Spread");
        dd.property(1).setValue(mapL.index);
        var cut = amount.lastIndexOf("\n") + 1;
        var spread = amount.slice(0, cut) + "(" + amount.slice(cut).replace(/;\s*$/, "") + ") * " + chans[c][1] +
          " * " + ctlRef + '.effect("Dispersion")(1) / 100 * 0.25;';
        try { dd.property(2).setValue(1); } catch (eH2) {}
        dd.property(3).expression = spread;
        try { dd.property(4).setValue(2); } catch (eV2) {}
        dd.property(5).expression = spread;
        try { dd.property(6).setValue(1); } catch (eBh2) {}
        var sc = pillowGlassAddFx(dl, "ADBE Shift Channels", "Keep " + chans[c][0]);
        sc.property(2).setValue(chans[c][2][0]);
        sc.property(3).setValue(chans[c][2][1]);
        sc.property(4).setValue(chans[c][2][2]);
        dl.blendingMode = BlendingMode.LIGHTEN;
        dl.setTrackMatte(ml, TrackMatteType.ALPHA);
        dl.property("ADBE Transform Group").property("ADBE Opacity").expression =
          ctlRef + '.effect("Dispersion")(1) > 0 ? 100 : 0;';
      } catch (eDs) {}
    }
  }
  return ln;
}

/* the helper layers of a glass in the active comp */
function pillowGlassHelpers(comp, gid) {
  var out = [], tag = "PILLOW-GLASS " + gid + " ";
  for (var i = 1; i <= comp.numLayers; i++) {
    var c = String(comp.layer(i).comment || "");
    if (c.indexOf(tag) === 0 && !/ glass$/.test(c)) out.push(comp.layer(i));
  }
  return out;
}

/* the glass comps of the selected "Pillow Liquid Glass" layers (a selected
   helper layer counts as its glass) */
function pillowGlassSelected(comp) {
  var sel = comp.selectedLayers, gids = {}, out = [];
  for (var s = 0; s < sel.length; s++) {
    var m0 = /^PILLOW-GLASS (\S+) (glass|matte|lens|map)$/.exec(String(sel[s].comment || ""));
    if (m0) gids[m0[1]] = true;
  }
  for (var i = 1; i <= comp.numLayers; i++) {
    var L = comp.layer(i), m = /^PILLOW-GLASS (\S+) glass$/.exec(String(L.comment || ""));
    if (m && gids[m[1]] && L.source instanceof CompItem) out.push({ layer: L, comp: L.source, gid: m[1] });
  }
  return out;
}

function pillowGlassPart(G, tail) {
  for (var i = 1; i <= G.numLayers; i++) {
    if (String(G.layer(i).comment || "").match(new RegExp(" " + tail + "$"))) return G.layer(i);
  }
  return null;
}

/* the refraction map comp of a glass: a helper layer in the active comp,
   or (glass made before v87) a layer inside the glass comp */
function pillowGlassMapComp(comp, g) {
  var hs = pillowGlassHelpers(comp, g.gid);
  for (var i = 0; i < hs.length; i++) {
    if (/ map$/.test(String(hs[i].comment)) && hs[i].source instanceof CompItem) return hs[i].source;
  }
  var old = pillowGlassPart(g.comp, "map");
  return old && old.source instanceof CompItem ? old.source : null;
}

function pillowGlassMigrate(comp, g) {
  if (pillowGlassHelpers(comp, g.gid).length) return false;
  var G = g.comp, P = pillowGlassPart(G, "form"), M = pillowGlassMapComp(comp, g);
  if (!P || !(P.source instanceof CompItem)) return false;
  /* the old lens and map layer inside the glass comp go */
  for (var i = G.numLayers; i >= 1; i--) {
    var L = G.layer(i), c = String(L.comment || "");
    if (c === "PILLOW-GLASS " + g.gid + " map" || (c === "PILLOW-GLASS " + g.gid && L.adjustmentLayer)) L.remove();
  }
  var ctlRef = 'comp("' + String(G.name).replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '").layer("\u25c6 Glass Controls")';
  var prefix = null;
  if (M) {
    for (var j = 1; j <= M.numLayers && prefix == null; j++) {
      if (/^Slope [XY] [+-]$/.test(M.layer(j).name)) {
        prefix = pillowGlassBandPrefix(M.layer(j).property("ADBE Transform Group").property("ADBE Position").expression);
      }
    }
  }
  pillowGlassMount(comp, g.layer, g.gid, P.source, M, ctlRef, prefix || "var band = 20;\n");
  return true;
}

/* the panel's sliders onto the selected glass */
function pillowGlassUpdate(json) {
  var o = {};
  try { o = pillowParse(json); } catch (e0) {}
  return pillowUndo("Update Liquid Glass", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var gl = pillowGlassSelected(comp), n = 0;
    if (!gl.length) return pillowJson({ ok: false, error: "Select a Pillow Liquid Glass layer." });
    var keys = [["Refraction", "refraction"], ["Edge", "edge"], ["Frost", "frost"], ["Highlight", "highlight"], ["Tint", "tint"], ["Shadow", "shadow"],
      ["Dispersion", "dispersion"], ["Fresnel", "fresnel"]];
    var d = o.dims || {};
    for (var i = 0; i < gl.length; i++) {
      var ctl = pillowGlassPart(gl[i].comp, "controls");
      if (!ctl) continue;
      var fx = ctl.property("ADBE Effect Parade");
      var put = function (nm, val) {
        if (val == null) return;
        var e = pillowFxByName(fx, [nm]);
        if (e) { try { e.property(1).setValue(val); } catch (eP) {} }
      };
      for (var k = 0; k < keys.length; k++) put(keys[k][0], o[keys[k][1]]);
      put("Tint Color", o.tintColor);
      put("Width", d.w); put("Height", d.h); put("Roundness", d.r); put("Size", d.w); put("Smoothness", d.n);
      /* glass made before v87 keeps its lens inside the glass comp, where
         it stays behind when the glass moves: move it out */
      try { pillowGlassMigrate(comp, gl[i]); } catch (eMg) {}
      /* the refraction map follows this layer, under its current name */
      var M = pillowGlassMapComp(comp, gl[i]);
      if (M) {
        for (var j = 1; j <= M.numLayers; j++) {
          var fl = M.layer(j);
          if (!/^(Slope|Body) [XY] [+-]$/.test(fl.name)) continue;
          try {
            var pre = pillowGlassBandPrefix(fl.property("ADBE Transform Group").property("ADBE Position").expression);
            if (pre != null) pillowGlassFollow(fl, pre, comp.name, gl[i].layer.name);
          } catch (eF) {}
        }
      }
      n++;
    }
    return pillowJson({ ok: true, count: n });
  });
}

/* take the selected glass apart and put the original layer back */
function pillowGlassRemove() {
  var comp0 = pillowActiveComp();
  if (comp0 && !pillowGlassSelected(comp0).length) return pillowGlassRemoveLegacy();
  return pillowUndo("Remove Liquid Glass", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var gl = pillowGlassSelected(comp), n = 0;
    for (var i = 0; i < gl.length; i++) {
      var GL = gl[i].layer, G = gl[i].comp;
      var P = pillowGlassPart(G, "form");
      var F = P ? P.source : null, M = pillowGlassMapComp(comp, gl[i]);
      var hs = pillowGlassHelpers(comp, gl[i].gid);
      for (var h = 0; h < hs.length; h++) { try { hs[h].locked = false; hs[h].remove(); } catch (eH) {} }
      /* a glass made from a layer gives the layer back */
      if (F && /layer$/.test(String(F.comment || ""))) {
        try {
          var back = [];
          for (var j = F.numLayers; j >= 1; j--) {
            var inner = F.layer(j), fx = inner.property("ADBE Effect Parade");
            for (var f = fx.numProperties; f >= 1; f--) if (fx.property(f).name === "Pillow Glass Form") fx.property(f).remove();
            inner.copyToComp(comp);
            back.push(comp.layer(1));
          }
          for (var b = back.length - 1; b >= 0; b--) back[b].moveBefore(GL);
        } catch (eBack) {}
      }
      GL.remove();
      try { if (G.usedIn.length === 0) G.remove(); } catch (eG) {}
      try { if (M && M.usedIn.length === 0) M.remove(); } catch (eM) {}
      try { if (F && F.usedIn.length === 0) F.remove(); } catch (eF) {}
      n++;
    }
    return pillowJson({ ok: true, count: n });
  });
}

/* glass made before v83: its pieces sit loose in the comp */
function pillowGlassRemoveLegacy() {
  return pillowUndo("Remove Liquid Glass", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var sel = comp.selectedLayers, gids = {}, i, n = 0;
    for (i = 0; i < sel.length; i++) {
      var m = /^PILLOW-GLASS (\S+)/.exec(String(sel[i].comment || ""));
      if (m) gids[m[1]] = true;
    }
    for (var gid in gids) {
      if (!gids.hasOwnProperty(gid)) continue;
      var form = null, parts = [];
      for (i = 1; i <= comp.numLayers; i++) {
        var L = comp.layer(i), c = String(L.comment || "");
        if (c.indexOf("PILLOW-GLASS " + gid) !== 0) continue;
        if (/ form$/.test(c)) form = L; else parts.push(L);
      }
      var maps = [];
      for (i = 0; i < parts.length; i++) {
        try { if (parts[i].source instanceof CompItem) maps.push(parts[i].source); } catch (eSrc) {}
        parts[i].remove();
      }
      for (i = 0; i < maps.length; i++) {
        try { if (maps[i].usedIn.length === 0) maps[i].remove(); } catch (eMap) {}
      }
      if (form) {
        var pc = form.source, back = [];
        try {
          for (var j = pc.numLayers; j >= 1; j--) {
            var inner = pc.layer(j);
            var fx = inner.property("ADBE Effect Parade");
            for (var f = fx.numProperties; f >= 1; f--) if (fx.property(f).name === "Pillow Glass Form") fx.property(f).remove();
            inner.copyToComp(comp);
            back.push(comp.layer(1));
          }
          /* back[] runs bottom → top; moving the top one first keeps the order */
          for (var b = back.length - 1; b >= 0; b--) back[b].moveBefore(form);
          form.remove();
          if (pc.usedIn.length === 0) pc.remove();
        } catch (eBack) {
          form.enabled = true;
          form.comment = "";
        }
      }
      n++;
    }
    if (!n) return pillowJson({ ok: false, error: "Select a glass layer (its controls or any part)." });
    return pillowJson({ ok: true, count: n });
  });
}

/* For the notch's "Today": which project is open, and a fingerprint of
   what the user is doing in it. The panel counts time only while the
   fingerprint keeps changing (the comp, the playhead, the selection, the
   number of layers or items), so a project left open overnight is not
   counted. Cheap: no layer is walked. */
function pillowActivity() {
  try {
    if (!app || !app.project) return pillowJson({ ok: true, open: false });
    var P = app.project, f = P.file, name = "Untitled Project", path = "";
    if (f) {
      path = String(f.fsName || f.absoluteURI || "");
      try { name = decodeURIComponent(String(f.name)).replace(/\.aepx?$/i, ""); } catch (eN) { name = String(f.name); }
    }
    var sig = [P.numItems];
    var it = P.activeItem;
    if (it) {
      sig.push(it.id);
      if (it instanceof CompItem) {
        sig.push(Math.round(it.time * 100), it.numLayers, it.selectedLayers.length);
        try { sig.push(it.selectedProperties.length); } catch (eP) {}
      }
    }
    /* every edit bumps the project's revision (AE 2022+), so tweaking
       effect values counts as work even with the selection unchanged */
    try { if (P.revision !== undefined) sig.push(P.revision); } catch (eV) {}
    try { if (P.dirty !== undefined) sig.push(P.dirty ? 1 : 0); } catch (eD) {}
    /* the render queue is not touched here: this runs every 45 s even
       while AE renders, and reading it then is asking for trouble */
    return pillowJson({ ok: true, open: true, name: name, path: path, sig: sig.join(",") });
  } catch (e) {
    return pillowJson({ ok: false, error: String(e) });
  }
}

/* ── Library previews ────────────────────────────────────────────────
 * A saved preset gets a preview made of the layers themselves. The panel
 * calls pillowThumbBegin: the selected layers are soloed (so nothing else
 * in the comp is drawn), and depending on what they are:
 *   layers — plain layers: only them, on transparency;
 *   demo   — adjustment layers / blending modes / mattes, which show
 *            nothing on their own: Pillow's demo scene goes under them
 *            (a dark "A" half, a light "B" half, a grid and a circle);
 *   grade  — a static colour grade: one frame of a colourful demo picture
 *            with the grade, and (second phase) one without;
 *   frame  — the comp as it is, the user's own footage under the layers.
 * Frames are saved as PNGs to a temp folder (saveFrameToPng may finish in
 * the background, so the panel waits for the files), then
 * pillowThumbEnd puts the comp back exactly as it was. */
var PILLOW_THUMB = {};

function pillowThumbKeysRange(layers) {
  var lo = 1e9, hi = -1e9, wig = false, scaleKeys = false;
  var walk = function (g, depth) {
    if (depth > 6) return;
    for (var i = 1; i <= g.numProperties; i++) {
      var p = g.property(i);
      if (!p) continue;
      if (p.propertyType === PropertyType.PROPERTY) {
        try {
          if (p.numKeys > 0) {
            lo = Math.min(lo, p.keyTime(1)); hi = Math.max(hi, p.keyTime(p.numKeys));
            if (/Scale/i.test(p.matchName) || /Scale/i.test(p.name)) scaleKeys = true;
          }
          if (p.expressionEnabled && /wiggle|random|noise/i.test(p.expression)) wig = true;
        } catch (e) {}
      } else walk(p, depth + 1);
    }
  };
  for (var i = 0; i < layers.length; i++) walk(layers[i], 0);
  return { lo: lo, hi: hi, wig: wig, scaleKeys: scaleKeys };
}

function pillowThumbDemo(w, h, fps, dur, grade) {
  var C = app.project.items.addComp("Pillow Preview Backdrop", w, h, 1, Math.max(dur, 0.2), fps);
  var m = Math.min(w, h);
  var text = function (s, col, size) {
    var L = C.layers.addText(s);
    var tp = L.property("ADBE Text Properties").property("ADBE Text Document"), td = tp.value;
    td.fontSize = size;
    try { td.font = "Arial-BoldMT"; } catch (eF) {}
    try { td.applyFill = true; td.fillColor = col; td.applyStroke = false; } catch (eC) {}
    try { td.justification = ParagraphJustification.CENTER_JUSTIFY; } catch (eJ) {}
    tp.setValue(td);
    try {
      var r = L.sourceRectAtTime(0, false);
      L.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([r.left + r.width / 2, r.top + r.height / 2]);
    } catch (eA) {}
    L.property("ADBE Transform Group").property("ADBE Position").setValue([w / 2, h / 2]);
    return L;
  };
  var circle = function (col, x, y, d) {
    var L = C.layers.addShape();
    var grp = L.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
    var vec = grp.property("ADBE Vectors Group");
    vec.addProperty("ADBE Vector Shape - Ellipse").property("ADBE Vector Ellipse Size").setValue([d, d]);
    vec.addProperty("ADBE Vector Graphic - Fill").property("ADBE Vector Fill Color").setValue(col);
    L.property("ADBE Transform Group").property("ADBE Position").setValue([x, y]);
    return L;
  };
  var grid = function (L, col, op) {
    try {
      var g = L.property("ADBE Effect Parade").addProperty("ADBE Grid");
      var from = pillowFxByName(g, ["Size From"]); if (from) { try { from.setValue(3); } catch (eSF) {} }
      var sz = pillowFxByName(g, ["Width"]); if (sz) sz.setValue(m / 9);
      var hh = pillowFxByName(g, ["Height"]); if (hh) hh.setValue(m / 9);
      var bd = pillowFxByName(g, ["Border"]); if (bd) bd.setValue(Math.max(1.5, m / 540));
      var c = pillowFxByName(g, ["Color"]); if (c) c.setValue(col);
      var o = pillowFxByName(g, ["Opacity"]); if (o) o.setValue(op);
    } catch (e) {}
  };
  if (grade) {
    var bg = C.layers.addSolid([0.5, 0.5, 0.5], "Photo", w, h, 1, C.duration);
    try {
      var g4 = bg.property("ADBE Effect Parade").addProperty("ADBE 4ColorGradient");
      var cols = [[0.35, 0.62, 0.95], [0.98, 0.62, 0.3], [0.2, 0.78, 0.68], [0.93, 0.74, 0.62]];
      var n = 0;
      for (var i = 1; i <= g4.numProperties && n < 4; i++) {
        var pp = g4.property(i);
        if (/^Color \d/.test(pp.name)) { pp.setValue(cols[n]); n++; }
      }
    } catch (eG) {}
    circle([1, 0.96, 0.86], w * 0.72, h * 0.38, m * 0.32);
    circle([0.12, 0.13, 0.16], w * 0.28, h * 0.66, m * 0.22);
    text("Pillow", [1, 1, 1], m * 0.16);
  } else {
    var half = C.duration / 2;
    var B = C.layers.addSolid([0.9, 0.9, 0.92], "B", w, h, 1, C.duration);
    grid(B, [0, 0, 0], 18);
    var tb = text("B", [0.1, 0.1, 0.12], m * 0.5);
    var cb = circle([0.98, 0.45, 0.25], w * 0.78, h * 0.3, m * 0.16);
    var A = C.layers.addSolid([0.11, 0.12, 0.14], "A", w, h, 1, C.duration);
    grid(A, [1, 1, 1], 14);
    var ta = text("A", [1, 1, 1], m * 0.5);
    var ca = circle([0.35, 0.62, 0.95], w * 0.22, h * 0.7, m * 0.16);
    var aLayers = [A, ta, ca], bLayers = [B, tb, cb];
    for (var a = 0; a < aLayers.length; a++) aLayers[a].outPoint = half;
    for (var b = 0; b < bLayers.length; b++) { bLayers[b].inPoint = half; }
    /* A on top while it is shown */
    for (var z = aLayers.length - 1; z >= 0; z--) aLayers[z].moveToBeginning();
  }
  return C;
}

function pillowThumbBegin(json) {
  var o = {};
  try { o = pillowParse(decodeURIComponent(json)); } catch (e0) {}
  var comp = pillowActiveComp();
  if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
  if (typeof comp.saveFrameToPng !== "function") return pillowJson({ ok: false, error: "This After Effects can't save preview frames." });
  var sel = comp.selectedLayers;
  if (!sel.length) return pillowJson({ ok: false, error: "Select the layers for the preview." });
  return pillowUndo("Pillow preview", function () {
    var i, layers = [];
    for (i = 0; i < sel.length; i++) layers.push(sel[i]);
    var info = pillowThumbKeysRange(layers);
    /* the span: the keyframes, else the layers (from the playhead), at most 4 s */
    var t0, t1;
    if (info.hi > info.lo + 0.05) { t0 = info.lo; t1 = info.hi; }
    else {
      var lin = 1e9, lout = -1e9;
      for (i = 0; i < layers.length; i++) { lin = Math.min(lin, layers[i].inPoint); lout = Math.max(lout, layers[i].outPoint); }
      t0 = Math.max(lin, Math.min(comp.time, lout - 0.5)); t1 = Math.min(lout, t0 + 2.5);
    }
    if (t1 - t0 > 4) t1 = t0 + 4;
    if (t1 - t0 < 0.4) t1 = t0 + 0.4;

    /* what the layers are */
    var adjust = false, blend = false, matte = false, effects = [], colourOnly = true;
    var COLOUR = /lumetri|curves|levels|hue|saturation|tint|color balance|colour|exposure|vibrance|photo filter|tritone|brightness|contrast|lut|channel mixer|selective color|black & white|gamma|grade/i;
    for (i = 0; i < layers.length; i++) {
      var L = layers[i];
      try { if (L.adjustmentLayer) adjust = true; } catch (eA) {}
      try { if (L.blendingMode !== BlendingMode.NORMAL) blend = true; } catch (eB) {}
      try { if (L.hasTrackMatte || (L.trackMatteType && L.trackMatteType !== TrackMatteType.NO_TRACK_MATTE)) matte = true; } catch (eM) {}
      var fx = L.property("ADBE Effect Parade");
      if (fx) for (var f = 1; f <= fx.numProperties; f++) {
        var nm = fx.property(f).name + " | " + fx.property(f).matchName;
        effects.push(nm);
        if (!COLOUR.test(nm)) colourOnly = false;
      }
      try { if (!L.adjustmentLayer) colourOnly = false; } catch (eC) {}
    }
    var hasKeys = info.hi > info.lo + 0.05;
    var kind = String(o.mode || "auto");
    if (kind === "auto") kind = adjust && colourOnly && effects.length && !hasKeys && !info.wig ? "grade" : (adjust || blend || matte) ? "demo" : "layers";

    var tok = "t" + new Date().getTime();
    var dir = new Folder(Folder.temp.fsName + "/pillow-thumb-" + tok);
    dir.create();
    var st = { comp: comp, solo: [], demo: null, demoComp: null, layers: layers, dir: dir, kind: kind, t0: t0, enabled: [] };
    PILLOW_THUMB[tok] = st;

    if (kind !== "frame") {
      for (i = 1; i <= comp.numLayers; i++) { try { st.solo.push([comp.layer(i), comp.layer(i).solo]); } catch (eS) {} }
      for (i = 1; i <= comp.numLayers; i++) { try { comp.layer(i).solo = false; } catch (eS2) {} }
      for (i = 0; i < layers.length; i++) { try { layers[i].solo = true; } catch (eS3) {} }
    }
    if (kind === "demo" || kind === "grade") {
      var lowest = layers[0];
      for (i = 1; i < layers.length; i++) if (layers[i].index > lowest.index) lowest = layers[i];
      var D = pillowThumbDemo(comp.width, comp.height, comp.frameRate, t1 - t0 + 0.2, kind === "grade");
      var DL = comp.layers.add(D);
      DL.startTime = t0;
      DL.moveAfter(lowest);
      try { DL.solo = true; } catch (eD) {}
      st.demo = DL; st.demoComp = D;
    }

    /* frames: by the time (o.fps a second, at most o.max), so the preview
       plays as smoothly as it moves; else a fixed count */
    var n = kind === "grade" ? 1 : o.fps
      ? Math.max(8, Math.min(o.max || 48, Math.round((t1 - t0) * o.fps) + 1))
      : Math.max(2, Math.min(24, Math.round(o.frames || 16)));
    var files = [];
    for (i = 0; i < n; i++) {
      var t = kind === "grade" ? t0 : t0 + (t1 - t0) * i / (n - 1);
      var file = new File(dir.fsName + "/f" + (i < 10 ? "0" : "") + i + ".png");
      comp.saveFrameToPng(t, file);
      files.push(file.fsName.replace(/\\/g, "/"));
    }
    var bg = [0, 0, 0];
    try { bg = comp.bgColor; } catch (eBg) {}
    return pillowJson({ ok: true, token: tok, kind: kind, files: files, dur: t1 - t0, w: comp.width, h: comp.height, bg: bg,
      effects: effects, wiggle: info.wig, scaleKeys: info.scaleKeys, adjust: adjust, blend: blend });
  });
}

/* grade: the same frame without the grade */
function pillowThumbBefore(tok) {
  var st = PILLOW_THUMB[tok];
  if (!st) return pillowJson({ ok: false, error: "No preview in progress." });
  return pillowUndo("Pillow preview", function () {
    for (var i = 0; i < st.layers.length; i++) {
      try { st.enabled.push([st.layers[i], st.layers[i].enabled]); st.layers[i].enabled = false; } catch (e) {}
    }
    var file = new File(st.dir.fsName + "/before.png");
    st.comp.saveFrameToPng(st.t0, file);
    return pillowJson({ ok: true, file: file.fsName.replace(/\\/g, "/") });
  });
}

function pillowThumbEnd(tok) {
  var st = PILLOW_THUMB[tok];
  if (!st) return pillowJson({ ok: true });
  delete PILLOW_THUMB[tok];
  return pillowUndo("Pillow preview", function () {
    var i;
    for (i = 0; i < st.enabled.length; i++) { try { st.enabled[i][0].enabled = st.enabled[i][1]; } catch (e) {} }
    if (st.demo) { try { st.demo.remove(); } catch (e2) {} }
    if (st.demoComp) { try { st.demoComp.remove(); } catch (e3) {} }
    for (i = 0; i < st.solo.length; i++) { try { st.solo[i][0].solo = st.solo[i][1]; } catch (e4) {} }
    /* the panel has read the frames: the temp files go */
    try {
      var fl = st.dir.getFiles();
      for (i = 0; i < fl.length; i++) { try { fl[i].remove(); } catch (e5) {} }
      st.dir.remove();
    } catch (e6) {}
    return pillowJson({ ok: true });
  });
}

/* ── Notch watch: renders and missing files ───────────────────────────
 * Cheap enough to ask every few seconds: the render queue's items (status,
 * comp, output file, time taken) and how many footage files are missing.
 * While AE renders, scripts wait, so a finished render shows up on the
 * first call after it. */
function pillowWatchStatus(st) {
  try {
    if (st === RQItemStatus.DONE) return "done";
    if (st === RQItemStatus.RENDERING) return "rendering";
    if (st === RQItemStatus.QUEUED) return "queued";
    if (st === RQItemStatus.ERR_STOPPED) return "error";
    if (st === RQItemStatus.USER_STOPPED) return "stopped";
    if (st === RQItemStatus.WILL_CONTINUE) return "continue";
  } catch (e) {}
  return "other";
}
function pillowWatch() {
  try {
    if (!app || !app.project) return pillowJson({ ok: true, open: false });
    var P = app.project, rq = [], i, missing = 0;
    try {
      var Q = P.renderQueue;
      for (i = 1; i <= Q.numItems; i++) {
        var it = Q.item(i), file = "", secs = 0, comp = "";
        try { comp = it.comp.name; } catch (eC) {}
        try { file = it.outputModule(1).file.fsName; } catch (eF) {}
        try { secs = it.elapsedSeconds || 0; } catch (eS) {}
        rq.push({ i: i, status: pillowWatchStatus(it.status), comp: comp, file: file, secs: secs });
      }
    } catch (eQ) {}
    /* which files are missing, not only how many: the panel remembers the
       ones the user dismissed and speaks up only for new ones */
    var miss = [];
    for (i = 1; i <= P.numItems; i++) {
      var item = P.item(i);
      if (!(item instanceof FootageItem)) continue;
      var gone = false;
      try { gone = item.footageMissing; } catch (eM) {}
      if (!gone) continue;
      missing++;
      if (miss.length < 300) {
        var key = "";
        try { key = item.mainSource.file.fsName; } catch (eK) {}
        miss.push(key || ("#" + item.id + " " + item.name));
      }
    }
    var proj = "";
    try { if (P.file) proj = P.file.fsName; } catch (eP) {}
    return pillowJson({ ok: true, open: true, rq: rq, missing: missing, miss: miss, project: proj });
  } catch (e) {
    return pillowJson({ ok: false, error: String(e) });
  }
}

/* the finished render: its folder in Explorer / Finder, or the file itself */
function pillowRenderReveal(index, what) {
  try {
    var f = app.project.renderQueue.item(index).outputModule(1).file;
    if (!f) return pillowJson({ ok: false, error: "No output file." });
    var target = what === "play" ? new File(f.fsName) : f.parent;
    if (!target.exists) return pillowJson({ ok: false, error: "The file is not there any more." });
    target.execute();
    return pillowJson({ ok: true });
  } catch (e) {
    return pillowJson({ ok: false, error: String(e) });
  }
}

/* Missing files. The panel searches the disk itself (js/relink-find.js,
   Node, asynchronous); the host only lists what is missing and links the
   files it was given. pillowAutoRelink is the fallback when the panel
   has no Node: the same search, slower and shallower, here.

   A missing item's old path is in mainSource.missingFootagePath (its
   .file is null while it is missing); the file name is taken from it,
   the item's name is the last resort. An image sequence is relinked from
   any of its frames with replaceWithSequence. */
function pillowSafeDecode(s) {
  try { return decodeURIComponent(s); } catch (e) { return String(s); }
}
function pillowIsSeqItem(item) {
  try { return /\[\d+-\d+\]/.test(item.name) && item.mainSource && !item.mainSource.isStill; } catch (e) { return false; }
}
function pillowMissingList() {
  var out = [];
  for (var i = 1; i <= app.project.numItems; i++) {
    var item = app.project.item(i);
    if (!(item instanceof FootageItem)) continue;
    var miss = false;
    try { miss = item.footageMissing; } catch (e) {}
    if (!miss) continue;
    var oldPath = "";
    try { if (item.mainSource && item.mainSource.missingFootagePath) oldPath = String(item.mainSource.missingFootagePath); } catch (e1) {}
    if (!oldPath) { try { if (item.file) oldPath = item.file.fsName; } catch (e2) {} }
    if (!oldPath) { try { if (item.mainSource && item.mainSource.file) oldPath = item.mainSource.file.fsName; } catch (e3) {} }
    var fname = "";
    if (oldPath) fname = oldPath.replace(/^.*[\\\/]/, "");
    if (!fname) {
      fname = item.name;
      /* "shot_[0001-0120].png" -> its first frame, "shot_0001.png" */
      var m = /\[(\d+)-\d+\]/.exec(fname);
      if (m) fname = fname.replace(m[0], m[1]);
    }
    out.push({ item: item, id: item.id, name: item.name, fname: fname, oldPath: oldPath, seq: pillowIsSeqItem(item) });
  }
  return out;
}
function pillowMissingInfo() {
  try {
    if (!app || !app.project) return pillowJson({ ok: false, error: "No project open." });
    var list = pillowMissingList(), items = [];
    for (var i = 0; i < list.length; i++) {
      items.push({ id: list[i].id, name: list[i].name, fname: list[i].fname, old: list[i].oldPath, seq: list[i].seq });
    }
    var proj = "";
    try { if (app.project.file) proj = app.project.file.fsName; } catch (eP) {}
    return pillowJson({ ok: true, items: items, project: proj });
  } catch (e) {
    return pillowJson({ ok: false, error: String(e) });
  }
}
function pillowLinkOne(item, file, seq) {
  if (seq) {
    var fps = 0;
    try { fps = item.mainSource.conformFrameRate; } catch (eF) {}
    item.replaceWithSequence(file, false);
    try { if (fps) item.mainSource.conformFrameRate = fps; } catch (eF2) {}
  } else {
    item.replace(file);
  }
}
/* [{ id, path }] -> each still-missing item with that id is linked to it */
function pillowRelinkApply(json) {
  try {
    if (!app || !app.project) return pillowJson({ ok: false, error: "No project open." });
    var pairs = pillowParse(json) || [], byId = {}, i;
    for (i = 0; i < pairs.length; i++) byId[pairs[i].id] = pairs[i].path;
    var list = pillowMissingList(), linked = 0, failed = [];
    app.beginUndoGroup("Pillow \u00b7 Relink missing files");
    try {
      for (i = 0; i < list.length; i++) {
        var p = byId[list[i].id];
        if (!p) continue;
        var f = new File(p);
        if (!f.exists) { failed.push(list[i].fname); continue; }
        try { pillowLinkOne(list[i].item, f, list[i].seq); linked++; } catch (eR) { failed.push(list[i].fname); }
      }
    } finally {
      app.endUndoGroup();
    }
    var left = [], now = pillowMissingList();
    for (i = 0; i < now.length; i++) left.push(now[i].fname);
    return pillowJson({ ok: true, linked: linked, failed: failed, left: left });
  } catch (e) {
    return pillowJson({ ok: false, error: String(e) });
  }
}
function pillowRelinkSearch(roots, wanted, maxDepth) {
  if (!maxDepth) maxDepth = 4;
  var found = {}, left = 0, visited = 0, seenDir = {};
  for (var k in wanted) if (wanted.hasOwnProperty(k)) left++;
  var walk = function (folder, depth) {
    if (!left || visited > 60000 || depth > maxDepth) return;
    var key = folder.fsName.toLowerCase();
    if (seenDir[key]) return;
    seenDir[key] = true;
    var files;
    try { files = folder.getFiles(); } catch (e) { return; }
    var subs = [];
    for (var i = 0; i < files.length && left; i++) {
      visited++;
      var f = files[i];
      try {
        if (f instanceof Folder) {
          if (!/^\./.test(f.name) && !/node_modules|\$recycle|appdata|^library$/i.test(f.name)) subs.push(f);
        } else {
          /* one odd name ("100%.png") must not end the whole search */
          var n = pillowSafeDecode(f.name).toLowerCase();
          if (wanted[n] && !found[n]) { found[n] = f; left--; }
        }
      } catch (eF) {}
    }
    for (var j = 0; j < subs.length && left; j++) { try { walk(subs[j], depth + 1); } catch (eW) {} }
  };
  for (var r = 0; r < roots.length && left; r++) { try { if (roots[r] && roots[r].exists) walk(roots[r], 0); } catch (eR) {} }
  return found;
}
function pillowAutoRelink(pickedPath) {
  try {
    if (!app || !app.project) return pillowJson({ ok: false, error: "No project open." });
    var list = pillowMissingList();
    if (!list.length) return pillowJson({ ok: true, linked: 0, left: [] });
    var wanted = {}, roots = [], i;
    for (i = 0; i < list.length; i++) wanted[list[i].fname.toLowerCase()] = true;
    if (pickedPath) roots.push(new Folder(pickedPath));
    else {
      for (i = 0; i < list.length; i++) {
        if (!list[i].oldPath) continue;
        var d = new File(list[i].oldPath).parent;
        for (var up = 0; up < 4 && d; up++) { roots.push(d); d = d.parent; }
      }
      try { if (app.project.file) { roots.push(app.project.file.parent); roots.push(app.project.file.parent.parent); } } catch (eP) {}
      try { roots.push(new Folder(Folder.desktop.parent.fsName + "/Downloads")); } catch (eD) {}
      try { roots.push(Folder.desktop); } catch (eDk) {}
      try { roots.push(Folder.myDocuments); } catch (eMd) {}
      try { roots.push(Folder.desktop.parent); } catch (eH) {}
    }
    /* a folder the user picked is searched deeper than the guesses */
    var found = pillowRelinkSearch(roots, wanted, pickedPath ? 10 : 5);
    var linked = 0, left = [];
    app.beginUndoGroup("Pillow \u00b7 Relink missing files");
    try {
      for (i = 0; i < list.length; i++) {
        var f = found[list[i].fname.toLowerCase()];
        if (!f) { left.push(list[i].fname); continue; }
        try { pillowLinkOne(list[i].item, f, list[i].seq); linked++; } catch (eRp) { left.push(list[i].fname); }
      }
    } finally {
      app.endUndoGroup();
    }
    return pillowJson({ ok: true, linked: linked, left: left });
  } catch (e) {
    return pillowJson({ ok: false, error: String(e) });
  }
}

/* ── Carousel: the selected layers go round ───────────────────────────
 * Four styles, one controller "Carousel (Pillow)": a 3D guide solid at 0%
 * opacity (a solid, so it can carry the Curved Line's mask) with every
 * setting as an effect. Each layer's Position and Orientation (Scale and
 * Opacity on the line) are expressions over it, so everything stays live
 * in After Effects and can be keyframed:
 *   Radial       a ring       Radius, Spread (an arc below 360), Tilt
 *   Spherical    a ball       Radius, Tilt
 *   Rectangular  a loop round a rectangle   Radius, Aspect, Tilt
 *   Curved Line  along the controller's mask "Carousel Path" (3 points)
 *                Gap, Middle Size (the pictures swell at the middle point)
 *   Speed  degrees a second (one loop takes 360/Speed s; keys on it ease
 *   the turning up, down or to a stop without a jump), Turn  where the
 *   loop stands, Face  which way the pictures look.
 * Positions are in the controller's own space (toWorld), so moving,
 * turning or scaling the controller carries the whole carousel.
 * Rings made by the old 3D Ring (two nulls, parented) are taken apart and
 * rebuilt as a carousel when their layers are applied again. */
var PILLOW_RING_TAG = "PILLOW-RING";
var PILLOW_CAR_TAG = "PILLOW-RING carousel";
var PILLOW_CAR_EXPR = "// Pillow Carousel";
var PILLOW_CAR_FACES = { radial: ["Forward", "Screen", "Center"], rect: ["Forward", "Screen", "Center"], sphere: ["Inward", "Outward", "Screen"] };
var PILLOW_CAR_SLIDERS = { radial: ["Radius", "Spread", "Tilt"], sphere: ["Radius", "Tilt"], rect: ["Radius", "Aspect", "Tilt"], curve: ["Gap", "Middle Size"] };
var PILLOW_CAR_ALL = ["Radius", "Spread", "Tilt", "Aspect", "Gap", "Middle Size"];

function pillowCarSlider(L, name, v) {
  var fx = L.property("ADBE Effect Parade"), e = pillowFxByName(fx, [name]);
  if (!e) { e = fx.addProperty("ADBE Slider Control"); e.name = name; }
  var p = e.property(1);
  if (p.numKeys > 0) p.setValueAtTime(L.containingComp.time, v); else p.setValue(v);
}
/* Face: a dropdown with the style's own words (a slider 1-3 before AE 17) */
function pillowCarFace(L, items, v) {
  var fx = L.property("ADBE Effect Parade"), e = pillowFxByName(fx, ["Face"]);
  if (e) { try { e.remove(); } catch (eR) {} }
  if (!items) return;
  e = null;
  try {
    e = fx.addProperty("ADBE Dropdown Control");
    var p = e.property(1).setPropertyParameters(items);
    p.propertyGroup(1).name = "Face";
    p.setValue(v);
    return;
  } catch (eD) {}
  try { if (e) e.remove(); } catch (eR2) {}
  e = fx.addProperty("ADBE Slider Control");
  e.name = "Face";
  e.property(1).setValue(v);
}
function pillowCarQuote(s) { return String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"'); }

/* the expression for one property of layer k of n */
function pillowCarExpr(style, prop, ctlName, n, k, cell) {
  var s = PILLOW_CAR_EXPR + " (" + style + ") - every setting is on the layer \"" + pillowCarQuote(ctlName) + "\"\n" +
    'var c = thisComp.layer("' + pillowCarQuote(ctlName) + '"), n = ' + n + ", k = " + k + ";\n" +
    "function fx(m) { return c.effect(m)(1); }\n" +
    /* how far it has gone: Speed summed over time, so keys on Speed
       speed it up, slow it down or stop it without a jump */
    'function run(T) {\n' +
    '  var p = c.effect("Speed")(1), nk = p.numKeys, acc = 0, i, j;\n' +
    '  if (!(nk > 0)) return p.valueAtTime(0) * T;\n' +
    '  var mk = [0];\n' +
    '  for (i = 1; i <= nk; i++) { var kt = p.key(i).time; if (kt > 0 && kt < T) mk.push(kt); }\n' +
    '  mk.push(T);\n' +
    '  for (i = 0; i < mk.length - 1; i++) {\n' +
    '    var a = mk[i], h = (mk[i + 1] - a) / 8;\n' +
    '    for (j = 0; j < 8; j++) acc += (p.valueAtTime(a + j * h) + 4 * p.valueAtTime(a + (j + 0.5) * h) + p.valueAtTime(a + (j + 1) * h)) * h / 6;\n' +
    '  }\n' +
    '  return acc;\n' +
    '}\n' +
    'var v = run(Math.max(0, time)) + fx("Turn");\n' +
    /* Mix: 0 = the layer's own animation, 100 = the carousel; Stagger
       starts each picture's change a little after the one before */
    'var mx = Math.max(0, Math.min(1, c.effect("Mix")(1).valueAtTime(time - k * fx("Stagger")) / 100));\n';
  if (prop === "rot") return s + "value * (1 - mx);";
  if (style === "curve") {
    s += 'var m = c.mask("Carousel Path").maskPath, sp = Math.max(1, ' + cell + ' * (1 + fx("Gap") / 100));\n' +
      "var L = 0, q0 = m.pointOnPath(0), q, i;\n" +
      "for (i = 1; i <= 32; i++) { q = m.pointOnPath(i / 32); L += length(q, q0); q0 = q; }\n" +
      "L = Math.max(1, L);\n" +
      "var per = Math.max(L, n * sp), d = L / 2 + (k - (n - 1) / 2) * sp + v / 360 * L;\n" +
      "d = ((d % per) + per) % per;\n" +
      "var pt = m.pointOnPath(Math.min(1, d / L)), pts = m.points(), mid = pts.length > 2 ? pts[1] : m.pointOnPath(0.5);\n" +
      "var w = Math.max(0, 1 - length(pt, mid) / (L / 2)); w = w * w * (3 - 2 * w);\n";
    if (prop === "pos") return s + "var W = c.toWorld([pt[0], pt[1], 0]);\nadd(mul(value, 1 - mx), mul([W[0], W[1], W[2] - w * 4], mx));";
    if (prop === "scale") return s + 'mul(value, 1 + (fx("Middle Size") / 100 - 1) * w * mx);';
    return s + "var fo = d > L ? 0 : clamp(Math.min(d, L - d) / (sp * 0.5), 0, 1);\nvalue * (1 - mx + mx * fo);";
  }
  s += 'var R = fx("Radius"), t = degreesToRadians(fx("Tilt")), F = Math.round(fx("Face"));\n' +
    "function tl(p) { return [p[0], p[1] * Math.cos(t) + p[2] * Math.sin(t), -p[1] * Math.sin(t) + p[2] * Math.cos(t)]; }\n";
  var screen = 2;
  if (style === "radial") {
    s += 'var sa = fx("Spread"), full = sa >= 359.9, st = full ? 360 / n : (n > 1 ? sa / (n - 1) : 0);\n' +
      "var a = degreesToRadians(v + (full ? k * st : (k - (n - 1) / 2) * st));\n" +
      "var P = tl([R * Math.sin(a), -R * Math.cos(a), 0]);\n" +
      "var D = F == 1 ? tl([0, 0, -1]) : tl([-Math.sin(a), Math.cos(a), 0]);\n";
  } else if (style === "sphere") {
    screen = 3;
    s += "var y = n > 1 ? 1 - 2 * (k + 0.5) / n : 0, r = Math.sqrt(Math.max(0, 1 - y * y));\n" +
      "var ph = k * 2.39996323 + degreesToRadians(v);\n" +
      "var u = tl([r * Math.sin(ph), y, -r * Math.cos(ph)]), P = mul(u, R);\n" +
      "var D = F == 1 ? mul(u, -1) : u;\n";
  } else {
    s += 'var as = Math.max(0.05, fx("Aspect") / 100), A = R * Math.sqrt(as), B = R / Math.sqrt(as);\n' +
      "var s = (((k / n + v / 360) % 1) + 1) % 1 * 4 * (A + B), x, y, nx = 0, ny = 0;\n" +
      "if (s < 2 * A) { x = -A + s; y = -B; ny = -1; }\n" +
      "else if (s < 2 * A + 2 * B) { x = A; y = -B + s - 2 * A; nx = 1; }\n" +
      "else if (s < 4 * A + 2 * B) { x = A - (s - 2 * A - 2 * B); y = B; ny = 1; }\n" +
      "else { x = -A; y = B - (s - 4 * A - 2 * B); nx = -1; }\n" +
      "var P = tl([x, y, 0]), D = F == 1 ? tl([0, 0, -1]) : tl([-nx, -ny, 0]);\n";
  }
  s += "var o = c.transform.anchorPoint, W = c.toWorld(add(o, P));\n";
  if (prop === "pos") return s + "add(mul(value, 1 - mx), mul(W, mx));";
  /* the pictures' fronts look along D (through the controller's own turn);
     facing the screen means facing the active camera, if there is one */
  return s + "var Dw = sub(c.toWorld(add(add(o, P), D)), W);\n" +
    "if (F == " + screen + ") { Dw = [0, 0, -1]; try { Dw = sub(thisComp.activeCamera.toWorld([0, 0, 0]), W); } catch (e) {} }\n" +
    "var O = lookAt(W, sub(W, Dw));\n" +
    "function am(a, b) { return a + ((((b - a) % 360) + 540) % 360 - 180) * mx; }\n" +
    "[am(value[0], O[0]), am(value[1], O[1]), am(value[2], O[2])];";
}

/* the carousel a layer already belongs to (its controller), if any */
function pillowCarOf(comp, L) {
  var ex = "";
  try { ex = String(L.property("ADBE Transform Group").property("ADBE Position").expression || ""); } catch (e) {}
  if (ex.indexOf(PILLOW_CAR_EXPR) !== 0) return null;
  var m = /thisComp\.layer\("((?:[^"\\]|\\.)*)"\)/.exec(ex);
  if (!m) return null;
  var nm = m[1].replace(/\\(.)/g, "$1");
  for (var i = 1; i <= comp.numLayers; i++) {
    try { if (comp.layer(i).name === nm && String(comp.layer(i).comment) === PILLOW_CAR_TAG) return comp.layer(i); } catch (e2) {}
  }
  return null;
}
/* a Pillow expression (this carousel's or the old ring's) is cleared */
function pillowCarClear(p) {
  try {
    var ex = String(p.expression || "");
    if (ex.indexOf(PILLOW_CAR_EXPR) === 0 || ex.indexOf("Pillow Ring") >= 0 || ex.indexOf('c.effect("Wrap")') >= 0) p.expression = "";
  } catch (e) {}
}

function pillowRing(json) {
  var o = {};
  try { o = pillowParse(json); } catch (e0) {}
  var style = PILLOW_CAR_SLIDERS[o.style] ? o.style : "radial";
  return pillowUndo("Carousel", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var sel = comp.selectedLayers, layers = [], i, ctl = null;
    var tagOf = function (L) { try { return String(L.comment || ""); } catch (e) { return ""; } };
    for (i = 0; i < sel.length; i++) {
      var L = sel[i], tg = tagOf(L), kind = "";
      if (tg === PILLOW_CAR_TAG) { ctl = L; continue; }
      if (tg === PILLOW_RING_TAG || tg === PILLOW_RING_TAG + "-LEAN") continue;
      try { kind = pillowLibLayerKind(L); } catch (eK) {}
      if (kind === "camera" || kind === "light" || kind === "audio") continue;
      layers.push(L);
    }
    for (i = 0; i < layers.length && !ctl; i++) ctl = pillowCarOf(comp, layers[i]);
    /* the controller selected on its own: its layers */
    if (ctl && !layers.length) {
      for (i = 1; i <= comp.numLayers; i++) { if (comp.layer(i) !== ctl && pillowCarOf(comp, comp.layer(i)) === ctl) layers.push(comp.layer(i)); }
    }
    if (layers.length < 2) return pillowJson({ ok: false, error: "Select two or more layers." });
    layers.sort(function (a, b) { return a.index - b.index; });
    var n = layers.length;

    /* the size of one picture: the median of the layers' sizes */
    var sizes = [];
    for (i = 0; i < n; i++) {
      try {
        var rc = layers[i].sourceRectAtTime(comp.time, false), sc = layers[i].property("ADBE Transform Group").property("ADBE Scale").value;
        sizes.push(Math.max(Math.abs(rc.width * sc[0] / 100), Math.abs(rc.height * sc[1] / 100)));
      } catch (eS) {}
    }
    sizes.sort(function (a, b) { return a - b; });
    var cell = sizes.length ? sizes[Math.floor(sizes.length / 2)] : 200;
    var radius = pillowCarRadius(style, n, cell) * ((o.size != null ? o.size : 100) / 100);

    if (!ctl) {
      var nm = "Carousel (Pillow)", nk = 1, taken = true;
      while (taken) {
        taken = false;
        for (i = 1; i <= comp.numLayers; i++) if (comp.layer(i).name === nm) { taken = true; break; }
        if (taken) nm = "Carousel (Pillow) " + (++nk);
      }
      ctl = comp.layers.addSolid([0.5, 0.5, 0.5], nm, comp.width, comp.height, comp.pixelAspect, comp.duration);
      ctl.comment = PILLOW_CAR_TAG;
      ctl.threeDLayer = true;
      try { ctl.guideLayer = true; } catch (eG) {}
      try { ctl.label = 10; } catch (eL) {}
      ctl.property("ADBE Transform Group").property("ADBE Opacity").setValue(0);
      ctl.moveBefore(layers[0]);
    }

    /* the settings this style has; the others' go */
    var keep = PILLOW_CAR_SLIDERS[style], fxp = ctl.property("ADBE Effect Parade"), j, used;
    for (i = 0; i < PILLOW_CAR_ALL.length; i++) {
      used = false;
      for (j = 0; j < keep.length; j++) if (keep[j] === PILLOW_CAR_ALL[i]) used = true;
      if (!used) { var old = pillowFxByName(fxp, [PILLOW_CAR_ALL[i]]); if (old) { try { old.remove(); } catch (eRm) {} } }
    }
    if (style !== "curve") pillowCarSlider(ctl, "Radius", Math.round(radius));
    if (style === "radial") pillowCarSlider(ctl, "Spread", o.spread != null ? o.spread : 360);
    if (style === "rect") pillowCarSlider(ctl, "Aspect", o.aspect != null ? o.aspect : 160);
    if (style !== "curve") pillowCarSlider(ctl, "Tilt", o.tilt != null ? o.tilt : 25);
    if (style === "curve") {
      pillowCarSlider(ctl, "Gap", o.gap != null ? o.gap : 18);
      pillowCarSlider(ctl, "Middle Size", o.mid != null ? o.mid : 190);
    }
    pillowCarSlider(ctl, "Speed", o.speed != null ? o.speed : 20);
    pillowCarSlider(ctl, "Turn", o.turn || 0);
    pillowCarFace(ctl, PILLOW_CAR_FACES[style] || null, o.face || 1);
    pillowCarMix(ctl, comp, o);

    /* Curved Line: the three points become the mask "Carousel Path" */
    if (style === "curve") pillowCarPath(ctl, comp, o.pts);

    var oldLeans = [];
    for (i = 0; i < n; i++) {
      var L2 = layers[i];
      try { if (L2.locked) continue; } catch (eLk) {}
      try {
        var pa = L2.parent;
        if (pa) { if (tagOf(pa) === PILLOW_RING_TAG + "-LEAN") oldLeans.push(pa); L2.parent = null; }
      } catch (eP) {}
      L2.threeDLayer = true;
      if (o.blur !== false) { try { L2.motionBlur = true; } catch (eMb) {} }
      var t2 = L2.property("ADBE Transform Group"), pos = t2.property("ADBE Position");
      try { if (pos.dimensionsSeparated) pos.dimensionsSeparated = false; } catch (eD) {}
      pos.expression = pillowCarExpr(style, "pos", ctl.name, n, i, Math.round(cell));
      /* the layer's own rotation fades out as the carousel takes over */
      t2.property("ADBE Rotate X").expression = pillowCarExpr(style, "rot", ctl.name, n, i, Math.round(cell));
      t2.property("ADBE Rotate Y").expression = pillowCarExpr(style, "rot", ctl.name, n, i, Math.round(cell));
      t2.property("ADBE Rotate Z").expression = pillowCarExpr(style, "rot", ctl.name, n, i, Math.round(cell));
      var ori = t2.property("ADBE Orientation"), scl = t2.property("ADBE Scale"), opa = t2.property("ADBE Opacity");
      if (style === "curve") {
        pillowCarClear(ori);
        scl.expression = pillowCarExpr(style, "scale", ctl.name, n, i, Math.round(cell));
        opa.expression = pillowCarExpr(style, "opacity", ctl.name, n, i, Math.round(cell));
      } else {
        ori.expression = pillowCarExpr(style, "ori", ctl.name, n, i, Math.round(cell));
        pillowCarClear(scl);
        pillowCarClear(opa);
      }
    }
    pillowCarDropOld(comp, oldLeans);
    if (o.blur !== false) { try { comp.motionBlur = true; } catch (eMB) {} }

    try { for (i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false; ctl.selected = true; } catch (eSel) {}
    return pillowJson({ ok: true, count: n, controller: ctl.name, style: style });
  });
}

/* Mix (0 your animation -> 100 the carousel) and Stagger. "From my
   animation": Mix keyed 0 -> 100 from the playhead over Blend time on a
   smooth ease-in-out; otherwise the carousel straight away (100). */
function pillowCarMix(ctl, comp, o) {
  var fx = ctl.property("ADBE Effect Parade"), e = pillowFxByName(fx, ["Mix"]);
  if (!e) { e = fx.addProperty("ADBE Slider Control"); e.name = "Mix"; }
  var p = e.property(1), i;
  for (i = p.numKeys; i >= 1; i--) { try { p.removeKey(i); } catch (eK) {} }
  if (o.blend) {
    var t0 = comp.time, d = Math.max(0.1, o.blendDur || 1.2);
    p.setValueAtTime(t0, 0);
    p.setValueAtTime(t0 + d, 100);
    pillowEaseBezier(p, t0, t0 + d, [0.65, 0, 0.35, 1], "in");
  } else p.setValue(100);
  pillowCarSlider(ctl, "Stagger", o.blend ? (o.blendStagger != null ? o.blendStagger : 0.06) : 0);
}

/* the radius that fits the pictures round the shape side by side */
function pillowCarRadius(style, n, cell) {
  if (style === "sphere") return Math.max(cell * 0.9, cell * Math.sqrt(n * 2.2 / (4 * Math.PI)));
  if (style === "rect") return Math.max(cell * 0.9, n * cell * 0.1625);
  return Math.max(n * cell * 1.15 / (2 * Math.PI), cell * 0.9);
}

/* P0, P1, P2 (0..1 of the comp) as a smooth open mask through all three */
function pillowCarPath(ctl, comp, pts) {
  if (!(pts instanceof Array) || pts.length !== 3) pts = [[0.12, 0.7], [0.5, 0.6], [0.88, 0.3]];
  var P = [], i;
  for (i = 0; i < 3; i++) P.push([Number(pts[i][0]) * comp.width, Number(pts[i][1]) * comp.height]);
  var m1 = [(P[2][0] - P[0][0]) / 6, (P[2][1] - P[0][1]) / 6];
  var sh = new Shape();
  sh.vertices = P;
  sh.inTangents = [[0, 0], [-m1[0], -m1[1]], [(P[1][0] - P[2][0]) / 3, (P[1][1] - P[2][1]) / 3]];
  sh.outTangents = [[(P[1][0] - P[0][0]) / 3, (P[1][1] - P[0][1]) / 3], [m1[0], m1[1]], [0, 0]];
  sh.closed = false;
  var mp = ctl.property("ADBE Mask Parade"), mk = null;
  for (i = 1; i <= mp.numProperties; i++) if (mp.property(i).name === "Carousel Path") mk = mp.property(i);
  if (!mk) {
    mk = mp.addProperty("ADBE Mask Atom");
    mk.name = "Carousel Path";
    try { mk.maskMode = MaskMode.NONE; } catch (eM) {}
  }
  var sp = mk.property("ADBE Mask Shape");
  if (sp.numKeys > 0) sp.setValueAtTime(comp.time, sh); else sp.setValue(sh);
}

/* the old 3D Ring's two nulls, once no layer hangs on them */
function pillowCarDropOld(comp, leans) {
  for (var i = 0; i < leans.length; i++) {
    try {
      var lean = leans[i], top = lean.parent, busy = false, j;
      for (j = 1; j <= comp.numLayers; j++) { if (comp.layer(j).parent === lean) { busy = true; break; } }
      if (busy) continue;
      lean.remove();
      if (!top) continue;
      for (j = 1; j <= comp.numLayers; j++) { if (comp.layer(j).parent === top) { busy = true; break; } }
      if (!busy) top.remove();
    } catch (e) {}
  }
}

/* ── Text Morph: the letters swell where the null is ──────────────────
 * After the reference: a null "Morph (Pillow)" is dragged over a text
 * layer and the letters under it inflate — fat, round, a little bigger —
 * their neighbours a little, the rest stay thin. Works with any font,
 * with two text animators:
 *   "Pillow Morph"         Stroke Width (a round stroke in the fill's own
 *                          colour, so each glyph puffs up) and Scale,
 *                          under a selector giving each letter its swell k
 *   "Pillow Morph Spacing" Position [U, 0] under a selector giving each
 *                          letter its exact sideways shift: the swollen
 *                          letters take the room they need, the word grows
 *                          evenly from its middle, nothing flies apart.
 *                          (Tracking was not used: in an animator it piles
 *                          up from letter to letter.)
 * Every number is in the text layer's own units, so a scaled text layer
 * behaves like the preview. The letter centres and widths are measured
 * when applied (re-apply after editing the text). */
var PILLOW_MORPH_TAG = "PILLOW-MORPH";
var PILLOW_MORPH_BUILD = "morph-4";
var PILLOW_MORPH_U = 10000;
function pillowMorphMeasure(L) {
  /* the centre and width of each character, in the layer's own space,
     from the width of every leading part of the text on a scratch copy */
  var comp = L.containingComp, doc = L.property("ADBE Text Properties").property("ADBE Text Document").value;
  var txt = String(doc.text), tmp = null, out = [], i;
  try {
    tmp = L.duplicate();
    try {
      var an = tmp.property("ADBE Text Properties").property("ADBE Text Animators");
      for (i = an.numProperties; i >= 1; i--) an.property(i).remove();
    } catch (eA) {}
    var src = tmp.property("ADBE Text Properties").property("ADBE Text Document");
    var full = tmp.sourceRectAtTime(comp.time, false);
    var y = full.top + full.height / 2, prev = full.left;
    var line = txt.split(/[\r\n]/)[0];
    for (i = 1; i <= line.length; i++) {
      var d = src.value; d.text = line.substr(0, i); src.setValue(d);
      var r = tmp.sourceRectAtTime(comp.time, false), right = r.left + r.width;
      /* a trailing space has no ink: give it the average advance */
      if (line.charAt(i - 1) === " " || right <= prev) right = prev + full.width / Math.max(1, line.length);
      out.push([(prev + right) / 2, y, right - prev]);
      prev = right;
    }
    for (i = line.length; i < txt.length; i++) out.push(out.length ? out[i % Math.max(1, line.length)] : [0, y, 10]);
  } catch (e) {
    for (i = 0; i < txt.length; i++) out.push([i * 20, 0, 20]);
  }
  try { if (tmp) tmp.remove(); } catch (eR) {}
  return out;
}
function pillowMorphRound(v) { return Math.round(v * 10) / 10; }
function pillowTextMorph(json) {
  var o = {};
  try { o = pillowParse(json); } catch (e0) {}
  return pillowUndo("Text Morph", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var sel = comp.selectedLayers, texts = [], i, ctl = null;
    for (i = 0; i < sel.length; i++) {
      if (String(sel[i].comment || "") === PILLOW_MORPH_TAG) { ctl = sel[i]; continue; }
      if (sel[i] instanceof TextLayer) texts.push(sel[i]);
    }
    if (!texts.length) return pillowJson({ ok: false, error: "Select a text layer." });
    var mode = "null";
    var made = 0, notes = [];
    for (var t = 0; t < texts.length; t++) {
      var L = texts[t], tp = L.property("ADBE Text Properties");
      var size = 100;
      try { size = tp.property("ADBE Text Document").value.fontSize; } catch (eF) {}
      /* the stroke the animator swells: the fill's own colour, round */
      try {
        var sd = tp.property("ADBE Text Document"), doc = sd.value;
        doc.applyStroke = true;
        try { doc.strokeColor = doc.fillColor; } catch (eC) {}
        doc.strokeWidth = 0;
        doc.strokeOverFill = false;
        try { doc.lineJoinType = LineJoinType.LINE_JOIN_ROUND; } catch (eJ) {}
        sd.setValue(doc);
      } catch (eDoc) { notes.push("stroke: " + eDoc); }
      /* each letter grows round its own centre */
      try { tp.property("ADBE Text More Options").property("ADBE Text Anchor Point Option").setValue(1); } catch (eAo) {}
      try { tp.property("ADBE Text More Options").property("ADBE Text Anchor Point Align").setValue([0, -50]); } catch (eAa) {}
      /* the old morph goes */
      var anims = tp.property("ADBE Text Animators");
      for (i = anims.numProperties; i >= 1; i--) if (/^Pillow Morph/.test(anims.property(i).name)) anims.property(i).remove();
      var M = pillowMorphMeasure(L);
      var cs = [], ws = [];
      for (i = 0; i < M.length; i++) { cs.push("[" + pillowMorphRound(M[i][0]) + "," + pillowMorphRound(M[i][1]) + "]"); ws.push(pillowMorphRound(M[i][2])); }

      /* the controls: on the null */
      var C, ref;
      if (!ctl) {
        ctl = comp.layers.addNull(comp.duration);
        ctl.name = "Morph (Pillow)";
        pillowNameSource(ctl, "Morph (Pillow)");
        ctl.comment = PILLOW_MORPH_TAG;
        try { ctl.label = 10; } catch (eL) {}
        /* on the first letter, in the comp */
        try {
          var c0 = M.length ? M[0] : [0, 0];
          var pt = L.property("ADBE Transform Group"), pos = pt.property("ADBE Position").value, anc = pt.property("ADBE Anchor Point").value, sc = pt.property("ADBE Scale").value;
          ctl.property("ADBE Transform Group").property("ADBE Position").setValue([pos[0] + (c0[0] - anc[0]) * sc[0] / 100, pos[1] + (c0[1] - anc[1]) * sc[1] / 100]);
        } catch (eP) {}
        ctl.moveBefore(L);
      }
      C = ctl;
      ref = 'thisComp.layer("' + String(ctl.name).replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '")';
      pillowRingSlider(C, "Inflate", pillowMorphRound((o.inflate != null ? o.inflate : 60) / 100 * size * 0.2));
      pillowRingSlider(C, "Grow", o.grow != null ? o.grow : 12);
      pillowRingSlider(C, "Radius", Math.round((o.radius != null ? o.radius : 70) / 100 * size * 2.2));
      pillowRingSlider(C, "Softness", o.soft != null ? o.soft : 60);

      /* the swell of letter j (0-based), shared by both selectors */
      var kHead = "// Pillow Morph (" + PILLOW_MORPH_BUILD + ") - re-apply after editing the text\n" +
        "var C = [" + cs.join(",") + "];\nvar W = [" + ws.join(",") + "];\n" +
        "var N = " + ref + ";\n";
      kHead += "var P = fromComp(N.toComp(N.transform.anchorPoint));\n" +
        'var R = Math.max(1, N.effect("Radius")(1)), S = Math.max(0.01, N.effect("Softness")(1) / 100);\n' +
        "function kOf(j) { var dx = P[0] - C[j][0], dy = P[1] - C[j][1]; var k = linear(Math.sqrt(dx * dx + dy * dy), R * (1 - S), R, 1, 0); return k * k * (3 - 2 * k); }\n";
      kHead += "var i = Math.min(textIndex, C.length) - 1;\n";

      /* 1 — swell: stroke + scale */
      var an = anims.addProperty("ADBE Text Animator");
      an.name = "Pillow Morph";
      var props = an.property("ADBE Text Animator Properties");
      var sw = props.addProperty("ADBE Text Stroke Width");
      var scp = props.addProperty("ADBE Text Scale 3D");
      sw.expression = "// Pillow Morph\n" + ref + '.effect("Inflate")(1);';
      scp.expression = "// Pillow Morph\nvar g = " + ref + '.effect("Grow")(1);\n[100 + g, 100 + g, 100];';
      var ex = an.property("ADBE Text Selectors").addProperty("ADBE Text Expressible Selector");
      ex.name = "Pillow Morph Swell";
      ex.property("ADBE Text Expressible Amount").expression = kHead + "var k = kOf(i) * 100;\n[k, k, k];";

      /* 2 — spacing: each letter moves aside by exactly the room the
         swollen letters before it took, the word growing from its middle */
      var an2 = anims.addProperty("ADBE Text Animator");
      an2.name = "Pillow Morph Spacing";
      var ps = an2.property("ADBE Text Animator Properties").addProperty("ADBE Text Position 3D");
      ps.setValue([PILLOW_MORPH_U, 0, 0]);
      var ex2 = an2.property("ADBE Text Selectors").addProperty("ADBE Text Expressible Selector");
      ex2.name = "Pillow Morph Room";
      ex2.property("ADBE Text Expressible Amount").expression = kHead +
        'var inf = N.effect("Inflate")(1), gr = N.effect("Grow")(1) / 100;\n' +
        "var before = 0, mine = 0, tot = 0;\n" +
        "for (var j = 0; j < C.length; j++) {\n" +
        "  var kj = kOf(j), e = (W[j] + inf * kj) * (1 + gr * kj) - W[j];\n" +
        "  if (j < i) before += e; else if (j == i) mine = e;\n" +
        "  tot += e;\n" +
        "}\n" +
        "var sh = before + mine / 2 - tot / 2;\n" +
        "[sh / " + PILLOW_MORPH_U + " * 100, 0, 0];";
      made++;
    }
    try { for (i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false; (ctl || texts[0]).selected = true; } catch (eS) {}
    return pillowJson({ ok: true, count: made, mode: mode, controller: ctl ? ctl.name : texts[0].name, notes: notes, build: PILLOW_MORPH_BUILD });
  });
}
function pillowTextMorphRemove() {
  return pillowUndo("Remove Morph", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var sel = comp.selectedLayers, n = 0, i, j, nulls = [], lnulls = [];
    for (i = 0; i < sel.length; i++) {
      var tg = String(sel[i].comment || "");
      if (tg === PILLOW_MORPH_TAG) { nulls.push(sel[i]); continue; }
      if (tg === PILLOW_LMORPH_TAG) { lnulls.push(sel[i]); continue; }
      if (pillowLayerMorphClear(sel[i])) n++;
      if (!(sel[i] instanceof TextLayer)) continue;
      var anims = sel[i].property("ADBE Text Properties").property("ADBE Text Animators");
      for (j = anims.numProperties; j >= 1; j--) if (/^Pillow Morph/.test(anims.property(j).name)) { anims.property(j).remove(); n++; }
      var fx = sel[i].property("ADBE Effect Parade");
      for (j = fx.numProperties; j >= 1; j--) if (/^(Inflate|Grow|Progress|Wave)$/.test(fx.property(j).name)) fx.property(j).remove();
    }
    /* a Layer Morph null takes its layers' expressions with it */
    for (i = 0; i < lnulls.length; i++) {
      var key = "thisComp.layer(\"" + String(lnulls[i].name).replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\")";
      for (j = 1; j <= comp.numLayers; j++) {
        var L = comp.layer(j), T = L.property("ADBE Transform Group");
        try {
          var e1 = T.property("ADBE Scale").expression, e2 = T.property("ADBE Anchor Point").expression;
          if ((e1 && e1.indexOf(key) >= 0) || (e2 && e2.indexOf(key) >= 0)) { if (pillowLayerMorphClear(L)) n++; }
        } catch (eL) {}
      }
      nulls.push(lnulls[i]);
    }
    for (i = 0; i < nulls.length; i++) { try { nulls[i].remove(); } catch (eN) {} }
    return pillowJson({ ok: true, count: n, nulls: nulls.length });
  });
}

/* ─── Layer Morph ─────────────────────────────────────────────
 * The Text Morph idea for any layers (cards, cars, icons, a scrolling
 * list): a null "Layer Morph (Pillow)" sits in the middle, and the layers
 * that pass over it grow, then shrink back evenly as they leave. The
 * others make room, so a column of layers never overlaps:
 *   Scale        value x (1 + Grow x k), k the smoothstep of the distance
 *                from the layer's centre to the null (Radius, Softness)
 *   Anchor Point moves the layer along the column by the room the grown
 *                layers before / after it take (Push), and keeps each
 *                layer growing round its own centre.
 * Only Position is read across layers (never touched by Pillow), so the
 * expressions cannot loop. The column runs along the axis the layers are
 * spread over when applied. */
var PILLOW_LMORPH_TAG = "PILLOW-LMORPH";
var PILLOW_LMORPH_BUILD = "lmorph-1";
var PILLOW_LMORPH_MARK = "// Pillow Layer Morph";
function pillowLayerMorphHead(D, axis, ref, me) {
  var rows = [];
  for (var i = 0; i < D.length; i++) {
    rows.push("[\"" + D[i].name.replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\"," +
      pillowMorphRound(D[i].ox) + "," + pillowMorphRound(D[i].oy) + "," + pillowMorphRound(D[i].ext) + "]");
  }
  return PILLOW_LMORPH_MARK + " (" + PILLOW_LMORPH_BUILD + ") - re-apply after adding layers\n" +
    "var D = [" + rows.join(",") + "];\n" +
    "var AX = " + axis + ", me = " + me + ";\n" +
    "var N = " + ref + ";\n" +
    "var P = N.toComp(N.transform.anchorPoint);\n" +
    "var R = Math.max(1, N.effect(\"Radius\")(1)), S = clamp(N.effect(\"Softness\")(1) / 100, 0.01, 1);\n" +
    "var G = N.effect(\"Grow\")(1) / 100, PU = N.effect(\"Push\")(1) / 100;\n" +
    "function ctr(j) { var L = thisComp.layer(D[j][0]); var b = L.hasParent ? L.parent.toComp(L.transform.position) : L.transform.position; return [b[0] + D[j][1], b[1] + D[j][2]]; }\n" +
    "function kOf(c) { var dx = P[0] - c[0], dy = P[1] - c[1]; var k = linear(Math.sqrt(dx * dx + dy * dy), R * (1 - S), R, 1, 0); return k * k * (3 - 2 * k); }\n";
}
function pillowLayerMorphEligible(L) {
  try {
    if (L instanceof CameraLayer || L instanceof LightLayer) return false;
    if (L.nullLayer || L.guideLayer) return false;
    if (L.hasVideo === false) return false;
    var tg = String(L.comment || "");
    if (tg === PILLOW_LMORPH_TAG || tg === PILLOW_MORPH_TAG) return false;
    return true;
  } catch (e) { return false; }
}
function pillowLayerMorph(json) {
  var o = {};
  try { o = pillowParse(json); } catch (e0) {}
  return pillowUndo("Layer Morph", function () {
    var comp = pillowActiveComp();
    if (!comp) return pillowJson({ ok: false, error: "Open a composition first." });
    var sel = comp.selectedLayers, layers = [], ctl = null, i, j, notes = [];
    for (i = 0; i < sel.length; i++) {
      if (String(sel[i].comment || "") === PILLOW_LMORPH_TAG) { ctl = sel[i]; continue; }
      if (pillowLayerMorphEligible(sel[i])) layers.push(sel[i]);
    }
    /* a layer whose parent is in the set would read its own expressions */
    var kept = [];
    for (i = 0; i < layers.length; i++) {
      var inSet = false;
      try { for (j = 0; j < layers.length; j++) if (layers[i].parent === layers[j]) inSet = true; } catch (eP) {}
      if (inSet) notes.push(layers[i].name + ": its parent is morphed too, skipped"); else kept.push(layers[i]);
    }
    layers = kept;
    if (layers.length < 1) return pillowJson({ ok: false, error: "Select the layers to morph (not nulls or cameras)." });
    /* names are how the expressions find each other: make them unique */
    var seen = {};
    for (i = 1; i <= comp.numLayers; i++) {
      var isSel = false;
      for (j = 0; j < layers.length; j++) if (layers[j] === comp.layer(i)) isSel = true;
      if (!isSel) seen[comp.layer(i).name] = true;
    }
    for (i = 0; i < layers.length; i++) {
      var nm = layers[i].name, base = nm, n = 2;
      while (seen[nm]) { nm = base + " " + n; n++; }
      if (nm !== layers[i].name) { layers[i].name = nm; notes.push("renamed to " + nm); }
      seen[nm] = true;
    }
    /* measure: the centre of each layer as an offset from its position
       (comp px, with its scale and rotation), and its size */
    var D = [], minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9, t = comp.time, sizeSum = 0;
    for (i = 0; i < layers.length; i++) {
      var L = layers[i], tg = L.property("ADBE Transform Group");
      var r = L.sourceRectAtTime(t, false);
      var A = tg.property("ADBE Anchor Point").value, s = tg.property("ADBE Scale").value;
      var rot = 0;
      try { rot = tg.property("ADBE Rotate Z").value; } catch (eR) {}
      var vx = (r.left + r.width / 2 - A[0]) * s[0] / 100, vy = (r.top + r.height / 2 - A[1]) * s[1] / 100;
      var a = rot * Math.PI / 180, ox = vx * Math.cos(a) - vy * Math.sin(a), oy = vx * Math.sin(a) + vy * Math.cos(a);
      var w = Math.abs(r.width * s[0] / 100), h = Math.abs(r.height * s[1] / 100);
      var pos = tg.property("ADBE Position").value;
      var cx = pos[0] + ox, cy = pos[1] + oy;
      try { if (L.parent) { cx = pos[0]; cy = pos[1]; } } catch (eP2) {}
      D.push({ name: L.name, ox: ox, oy: oy, w: w, h: h, cx: cx, cy: cy });
      minX = Math.min(minX, cx); maxX = Math.max(maxX, cx); minY = Math.min(minY, cy); maxY = Math.max(maxY, cy);
    }
    var axis = (o.axis === "x") ? 0 : (o.axis === "y") ? 1 : ((maxX - minX) > (maxY - minY) ? 0 : 1);
    for (i = 0; i < D.length; i++) { D[i].ext = axis ? D[i].h : D[i].w; sizeSum += D[i].ext; }
    var avg = sizeSum / D.length || 100;

    if (!ctl) {
      var cname = "Layer Morph (Pillow)", c = 2, taken = true;
      while (taken) {
        taken = false;
        for (i = 1; i <= comp.numLayers; i++) if (comp.layer(i).name === cname) taken = true;
        if (taken) { cname = "Layer Morph " + c + " (Pillow)"; c++; }
      }
      ctl = comp.layers.addNull(comp.duration);
      ctl.name = cname;
      pillowNameSource(ctl, cname);
      ctl.comment = PILLOW_LMORPH_TAG;
      try { ctl.label = 10; } catch (eL) {}
      /* in the middle of the comp along the column (where a scrolling list
         is read), over the layers across it */
      try { ctl.property("ADBE Transform Group").property("ADBE Position").setValue(axis ? [(minX + maxX) / 2, comp.height / 2] : [comp.width / 2, (minY + maxY) / 2]); } catch (eCp) {}
      var top = layers[0];
      for (i = 1; i < layers.length; i++) if (layers[i].index < top.index) top = layers[i];
      ctl.moveBefore(top);
    }
    pillowRingSlider(ctl, "Grow", o.grow != null ? o.grow : 60);
    pillowRingSlider(ctl, "Radius", Math.round((o.radius != null ? o.radius : 120) / 100 * avg));
    pillowRingSlider(ctl, "Softness", o.soft != null ? o.soft : 100);
    pillowRingSlider(ctl, "Push", o.push != null ? o.push : 100);

    var ref = "thisComp.layer(\"" + String(ctl.name).replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\")";
    for (i = 0; i < layers.length; i++) {
      var T = layers[i].property("ADBE Transform Group");
      var head = pillowLayerMorphHead(D, axis, ref, i);
      T.property("ADBE Scale").expression = head +
        "var k = kOf(ctr(me));\n" +
        "value * (1 + G * k);";
      T.property("ADBE Anchor Point").expression = head +
        "var cs = [], ks = [], i;\n" +
        "for (i = 0; i < D.length; i++) { cs.push(ctr(i)); ks.push(kOf(cs[i])); }\n" +
        "/* the room the grown layers before / after this one take */\n" +
        "var sh = 0, pm = cs[me][AX];\n" +
        "for (i = 0; i < D.length; i++) { if (i == me) continue; var e = D[i][3] * G * ks[i] * PU / 2; if (cs[i][AX] < pm) sh += e; else if (cs[i][AX] > pm) sh -= e; }\n" +
        "var sv = AX ? [0, sh] : [sh, 0];\n" +
        "if (hasParent) { var b = parent.toComp(transform.position); var q0 = parent.fromComp(b), q1 = parent.fromComp([b[0] + sv[0], b[1] + sv[1]].concat(b.length > 2 ? [b[2]] : [])); sv = [q1[0] - q0[0], q1[1] - q0[1]]; }\n" +
        "/* into the layer's own space: undo rotation and scale */\n" +
        "var a = -degreesToRadians(transform.rotation), sc = transform.scale;\n" +
        "var lx = sv[0] * Math.cos(a) - sv[1] * Math.sin(a), ly = sv[0] * Math.sin(a) + sv[1] * Math.cos(a);\n" +
        "lx /= Math.abs(sc[0]) > 0.01 ? sc[0] / 100 : 1; ly /= Math.abs(sc[1]) > 0.01 ? sc[1] / 100 : 1;\n" +
        "/* grow round the layer's centre, not its anchor */\n" +
        "var r = sourceRectAtTime(time, false), c = [r.left + r.width / 2, r.top + r.height / 2], f = 1 + G * ks[me];\n" +
        "var ax = c[0] - (c[0] - value[0]) / f - lx, ay = c[1] - (c[1] - value[1]) / f - ly;\n" +
        "value.length > 2 ? [ax, ay, value[2]] : [ax, ay];";
    }
    try { for (i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false; ctl.selected = true; } catch (eS) {}
    return pillowJson({ ok: true, count: layers.length, axis: axis ? "y" : "x", controller: ctl.name, notes: notes, build: PILLOW_LMORPH_BUILD });
  });
}
/* clears the Layer Morph expressions on L; true when there were any */
function pillowLayerMorphClear(L) {
  var hit = false;
  try {
    var T = L.property("ADBE Transform Group"), ps = ["ADBE Scale", "ADBE Anchor Point"];
    for (var i = 0; i < ps.length; i++) {
      var p = T.property(ps[i]);
      if (p.expression && p.expression.indexOf(PILLOW_LMORPH_MARK) === 0) { p.expression = ""; hit = true; }
    }
  } catch (e) {}
  return hit;
}

/* ─── Pillow Hub bridge (generated by scripts/build-panel.mjs from public/modules/ae-bridge.mjs) ─── */
/* >>> Pillow Hub bridge runtime 92.0.0 */
function pillowHubComp() {
  try {
    var c = app.project ? app.project.activeItem : null;
    if (c && c instanceof CompItem) return c;
  } catch (e) {}
  return null;
}

function pillowHubIsOwn(mv) {
  try { var p = mv.getParameters(); return !!(p && p.pillow); } catch (e) { return false; }
}

function pillowHubParse(text) {
  if (typeof pillowParse === "function") return pillowParse(text);
  if (typeof JSON !== "undefined" && JSON.parse) return JSON.parse(text);
  return eval("(" + text + ")");
}

function pillowHubOut(o) {
  if (typeof pillowJson === "function") return pillowJson(o);
  return o.ok ? "ok" : String(o.error);
}

function pillowHubPlural(n, word) { return n + " " + word + (n === 1 ? "" : "s"); }

/* Marker times in the payload are seconds of the source audio. On a selected layer they follow the
   layer's start and stretch; on the composition they start at 0. Old Pillow markers are replaced. */
function pillowHubApplyBeats(data, opt) {
  var comp = pillowHubComp();
  if (!comp) return { ok: false, error: "Open a composition first." };
  opt = opt || {};
  var types = opt.types || { hit: true, cut: true, section: true };
  var sel = comp.selectedLayers, layer = null;
  if (opt.target !== "comp" && sel && sel.length) layer = sel[0];
  if (opt.target === "layer" && !layer) return { ok: false, error: "Select a layer first." };
  var prop = layer ? layer.property("ADBE Marker") : comp.markerProperty;
  if (!prop) return { ok: false, error: "This layer can't hold markers." };
  var offset = 0, scale = 1;
  if (layer) {
    offset = layer.startTime;
    try { scale = layer.stretch / 100; } catch (eS) {}
    if (!(scale > 0)) scale = 1;
  }
  if (opt.replace !== false) {
    for (var k = prop.numKeys; k >= 1; k--) {
      try { if (pillowHubIsOwn(prop.keyValue(k))) prop.removeKey(k); } catch (eR) {}
    }
  }
  var list = data.markers || [], count = 0, keys = { cut: [], section: [] }, numbers = { hit: 0, cut: 0 };
  for (var i = 0; i < list.length; i++) {
    var m = list[i];
    if (!m || !types[m.type]) continue;
    var t = offset + Number(m.time) * scale;
    if (!(t >= 0) || t > comp.duration) continue;
    var label = m.label ? String(m.label) : "";
    if (!label) { numbers[m.type] = (numbers[m.type] || 0) + 1; label = (m.type === "cut" ? "Cut " : "Beat ") + numbers[m.type]; }
    var mv = new MarkerValue(label);
    var span = m.type === "section" && Number(m.duration) > 0 ? Number(m.duration) * scale : 0;
    if (span > 0) { try { mv.duration = Math.min(span, comp.duration - t); } catch (eD) {} }
    try { var params = {}; params.pillow = String(m.type); mv.setParameters(params); } catch (eP) {}
    try { prop.setValueAtTime(t, mv); count++; } catch (eM) { continue; }
    if (keys[m.type]) keys[m.type].push({ t: t, d: span, label: label });
  }
  var made = 0, mode = opt.layers;
  if (mode === "nulls" || mode === "solids") {
    var points = mode === "solids" ? (keys.section.length ? keys.section : keys.cut) : (keys.cut.length ? keys.cut : keys.section);
    var fd = comp.frameDuration || (1 / 30);
    for (var j = 0; j < points.length; j++) {
      var start = points[j].t;
      var end = j + 1 < points.length ? points[j + 1].t : (points[j].d > 0 ? start + points[j].d : comp.duration);
      if (end > comp.duration) end = comp.duration;
      if (end - start < fd) end = Math.min(comp.duration, start + fd);
      if (end <= start) continue;
      var L;
      if (mode === "nulls") {
        L = comp.layers.addNull(end - start);
      } else {
        var g = j % 2 ? 0.32 : 0.18;
        L = comp.layers.addSolid([g, g, g], points[j].label + " (Pillow)", comp.width, comp.height, comp.pixelAspect, end - start);
        try { L.guideLayer = true; } catch (eG) {}
        try { L.property("ADBE Transform Group").property("ADBE Opacity").setValue(40); } catch (eO) {}
      }
      L.name = points[j].label + " (Pillow)";
      L.startTime = start;
      try { L.inPoint = start; L.outPoint = end; } catch (eIO) {}
      if (layer) { try { L.moveBefore(layer); } catch (eMv) {} }
      made++;
    }
  }
  var where = layer ? "\u201c" + layer.name + "\u201d" : "the composition";
  var msg = pillowHubPlural(count, "marker") + " on " + where;
  if (made) msg += " \u00b7 " + pillowHubPlural(made, mode === "nulls" ? "null" : "guide solid");
  return { ok: true, count: count, layers: made, target: layer ? layer.name : "", message: msg };
}

function pillowHubRun(data, opt) {
  if (!data || typeof data !== "object") return { ok: false, error: "This file isn't a Pillow Hub export." };
  var schema = String(data.schema || "");
  if (schema.indexOf("pillow.beats.") !== 0) return { ok: false, error: "This file isn't a Pillow Hub beats export." };
  if (schema !== "pillow.beats.v1") return { ok: false, error: "This export needs a newer Pillow panel." };
  var result = null, failure = null;
  app.beginUndoGroup("Pillow \u00b7 Auto Beats");
  try {
    result = pillowHubApplyBeats(data, opt || data.options);
  } catch (e) {
    failure = String(e && e.message ? e.message : e);
    try { if (e.line) failure += " (line " + e.line + ")"; } catch (eL) {}
  }
  try { app.endUndoGroup(); } catch (eEnd) {}
  if (failure) return { ok: false, error: failure };
  return result || { ok: false, error: "Nothing happened." };
}

/* Pillow panel entry point: pillowHubImport(encodeURIComponent(jsonText)) */
function pillowHubImport(encoded) {
  var data;
  try { data = pillowHubParse(decodeURIComponent(encoded)); } catch (e) { return pillowHubOut({ ok: false, error: "This file isn't a Pillow Hub export." }); }
  return pillowHubOut(pillowHubRun(data, data && data.options));
}
/* <<< Pillow Hub bridge runtime */
