/* Pillow — colour picker (Create · Solid colour).
 *
 * One button shows the colour and its hex; pressing it opens a small
 * sheet: a saturation / brightness field, a hue strip, the hex, a row of
 * chosen colours and the last ones used. Everything follows the pointer
 * live; the sheet closes on a click outside or Escape.
 *
 * API: PillowColorPicker.mount(el, hex, onChange) -> { set(hex) }
 */
(function () {
  "use strict";
  if (window.PillowColorPicker) return;

  var PRESETS = ["#ffffff", "#e8e8e8", "#8e8e93", "#3a3a3c", "#000000",
    "#ff3b30", "#ff9500", "#ffcc00", "#34c759", "#00c7be", "#0a84ff", "#5e5ce6", "#bf5af2", "#ff2d55"];
  var RECENT_KEY = "pillow.recentColors";

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function hexOk(h) { return /^#?[0-9a-f]{6}$/i.test(h) || /^#?[0-9a-f]{3}$/i.test(h); }
  function normHex(h) {
    h = String(h || "").replace(/^#/, "").toLowerCase();
    if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
    return "#" + h;
  }
  function hexToRgb(h) { h = normHex(h); return [parseInt(h.substr(1, 2), 16), parseInt(h.substr(3, 2), 16), parseInt(h.substr(5, 2), 16)]; }
  function rgbToHex(r, g, b) {
    function p(v) { var s = Math.round(clamp(v, 0, 255)).toString(16); return s.length < 2 ? "0" + s : s; }
    return "#" + p(r) + p(g) + p(b);
  }
  function rgbToHsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
    if (d) {
      if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
      h *= 60; if (h < 0) h += 360;
    }
    return [h, mx ? d / mx : 0, mx];
  }
  function hsvToRgb(h, s, v) {
    var c = v * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c, r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
    return [(r + m) * 255, (g + m) * 255, (b + m) * 255];
  }
  function recent() { try { var a = JSON.parse(localStorage.getItem(RECENT_KEY) || "[]"); return a instanceof Array ? a.slice(0, 7) : []; } catch (e) { return []; } }
  function remember(hex) {
    var a = recent().filter(function (x) { return x !== hex; });
    a.unshift(hex);
    try { localStorage.setItem(RECENT_KEY, JSON.stringify(a.slice(0, 7))); } catch (e) {}
  }
  function light(hex) { var c = hexToRgb(hex); return (c[0] * 0.299 + c[1] * 0.587 + c[2] * 0.114) > 160; }

  var sheet = null, cur = null;   /* one sheet for the panel */

  function build() {
    sheet = document.createElement("div");
    sheet.className = "pl-cp";
    sheet.setAttribute("role", "dialog");
    sheet.innerHTML =
      '<div class="pl-cp-sv"><div class="pl-cp-sv-thumb"></div></div>' +
      '<div class="pl-cp-hue"><div class="pl-cp-hue-thumb"></div></div>' +
      '<div class="pl-cp-row">' +
        '<span class="pl-cp-now"></span>' +
        '<label class="pl-cp-hex"><span>#</span><input type="text" maxlength="7" spellcheck="false" aria-label="Hex"></label>' +
      '</div>' +
      '<div class="pl-cp-sw pl-cp-presets"></div>' +
      '<div class="pl-cp-label">Recent</div>' +
      '<div class="pl-cp-sw pl-cp-recent"></div>';
    document.body.appendChild(sheet);

    var sv = sheet.querySelector(".pl-cp-sv"), hue = sheet.querySelector(".pl-cp-hue");
    drag(sv, function (x, y) { cur.s = x; cur.v = 1 - y; commit(); });
    drag(hue, function (x) { cur.h = clamp(x * 360, 0, 359.9); commit(); });

    var inp = sheet.querySelector(".pl-cp-hex input");
    inp.addEventListener("input", function () {
      var v = inp.value.replace(/[^0-9a-f]/gi, "");
      if (v.length === 6 || v.length === 3) setHex("#" + v, true);
    });
    inp.addEventListener("keydown", function (e) { if (e.key === "Enter") close(); });

    sheet.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-hex]") : null;
      if (b) setHex(b.getAttribute("data-hex"));
    });
    document.addEventListener("pointerdown", function (e) {
      if (!cur || sheet.contains(e.target) || cur.btn.contains(e.target)) return;
      close();
    }, true);
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && cur) close(); });
    window.addEventListener("resize", function () { if (cur) place(); });
    /* the panel scrolls under a fixed sheet: it closes rather than float off its button */
    document.addEventListener("scroll", function (e) { if (cur && !sheet.contains(e.target)) close(); }, true);
  }

  function drag(el, fn) {
    function at(e) {
      var r = el.getBoundingClientRect();
      fn(clamp((e.clientX - r.left) / r.width, 0, 1), clamp((e.clientY - r.top) / r.height, 0, 1));
    }
    el.addEventListener("pointerdown", function (e) {
      if (!cur) return;
      e.preventDefault();
      try { el.setPointerCapture(e.pointerId); } catch (x) {}
      el.classList.add("is-drag");
      at(e);
      var mv = function (ev) { at(ev); };
      var up = function () { el.classList.remove("is-drag"); el.removeEventListener("pointermove", mv); el.removeEventListener("pointerup", up); el.removeEventListener("pointercancel", up); };
      el.addEventListener("pointermove", mv);
      el.addEventListener("pointerup", up);
      el.addEventListener("pointercancel", up);
    });
  }

  function swatches(list, active) {
    var h = "";
    for (var i = 0; i < list.length; i++) {
      h += '<button type="button" class="pl-cp-dot' + (list[i] === active ? " on" : "") + (light(list[i]) ? " is-light" : "") +
        '" data-hex="' + list[i] + '" style="background:' + list[i] + '" aria-label="' + list[i] + '"></button>';
    }
    return h;
  }

  function paint(fromInput) {
    var rgb = hsvToRgb(cur.h, cur.s, cur.v), hex = rgbToHex(rgb[0], rgb[1], rgb[2]);
    var pure = hsvToRgb(cur.h, 1, 1);
    var sv = sheet.querySelector(".pl-cp-sv");
    sv.style.backgroundColor = rgbToHex(pure[0], pure[1], pure[2]);
    var t = sheet.querySelector(".pl-cp-sv-thumb");
    t.style.left = (cur.s * 100) + "%"; t.style.top = ((1 - cur.v) * 100) + "%"; t.style.backgroundColor = hex;
    var ht = sheet.querySelector(".pl-cp-hue-thumb");
    ht.style.left = (cur.h / 360 * 100) + "%"; ht.style.backgroundColor = rgbToHex(pure[0], pure[1], pure[2]);
    sheet.querySelector(".pl-cp-now").style.backgroundColor = hex;
    if (!fromInput) sheet.querySelector(".pl-cp-hex input").value = hex.slice(1).toUpperCase();
    sheet.querySelector(".pl-cp-presets").innerHTML = swatches(PRESETS, hex);
    var rc = recent();
    sheet.querySelector(".pl-cp-recent").innerHTML = swatches(rc, hex);
    sheet.querySelector(".pl-cp-label").style.display = rc.length ? "" : "none";
    sheet.querySelector(".pl-cp-recent").style.display = rc.length ? "" : "none";
    return hex;
  }
  function commit(fromInput) {
    var hex = paint(fromInput);
    cur.hex = hex;
    cur.view(hex);
    cur.onChange(hex);
  }
  function setHex(hex, fromInput) {
    if (!hexOk(hex)) return;
    var c = hexToRgb(hex), hsv = rgbToHsv(c[0], c[1], c[2]);
    if (hsv[1] > 0.001 && hsv[2] > 0.001) cur.h = hsv[0];   /* greys keep the hue they had */
    cur.s = hsv[1]; cur.v = hsv[2];
    commit(fromInput);
  }

  function place() {
    var r = cur.btn.getBoundingClientRect(), vw = document.documentElement.clientWidth, vh = window.innerHeight;
    var w = Math.min(268, vw - 24);
    sheet.style.width = w + "px";
    var h = sheet.offsetHeight || 330;
    var left = clamp(r.left + r.width / 2 - w / 2, 12, vw - w - 12);
    var below = r.bottom + 8, above = r.top - 8 - h;
    var top = below + h <= vh - 8 || above < 8 ? below : above;
    sheet.style.left = left + "px";
    sheet.style.top = Math.max(8, top) + "px";
    sheet.style.transformOrigin = (r.left + r.width / 2 - left) + "px " + (top === below ? "0" : "100%");
  }

  function open(ctl) {
    if (!sheet) build();
    if (cur && cur !== ctl) close(true);
    cur = ctl;
    var c = hexToRgb(ctl.hex), hsv = rgbToHsv(c[0], c[1], c[2]);
    cur.h = hsv[0]; cur.s = hsv[1]; cur.v = hsv[2];
    paint();
    sheet.classList.add("is-open");
    place();
    ctl.btn.setAttribute("aria-expanded", "true");
  }
  function close(silent) {
    if (!cur) return;
    sheet.classList.remove("is-open");
    cur.btn.setAttribute("aria-expanded", "false");
    if (!silent) remember(cur.hex);
    cur = null;
  }

  function mount(el, hex, onChange) {
    el.innerHTML = '<button type="button" class="pl-color-btn" aria-haspopup="dialog" aria-expanded="false">' +
      '<span class="pl-color-dot"></span><span class="pl-color-hex"></span>' +
      '<svg class="pl-color-chev" viewBox="0 0 12 12" width="10" height="10" aria-hidden="true"><path d="M3 4.5 6 7.5 9 4.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button>';
    var btn = el.firstChild;
    var ctl = {
      btn: btn, hex: normHex(hex || "#e8e8e8"), onChange: onChange || function () {},
      view: function (h) {
        btn.querySelector(".pl-color-dot").style.backgroundColor = h;
        btn.querySelector(".pl-color-hex").textContent = h.slice(1).toUpperCase();
      }
    };
    ctl.view(ctl.hex);
    btn.addEventListener("click", function () { if (cur === ctl) close(); else open(ctl); });
    return { set: function (h) { if (hexOk(h)) { ctl.hex = normHex(h); ctl.view(ctl.hex); } } };
  }

  window.PillowColorPicker = { mount: mount };
})();
