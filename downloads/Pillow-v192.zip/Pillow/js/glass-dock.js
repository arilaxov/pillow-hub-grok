/* Pillow — GlassDock (порт websiteglass.com/r/glass-dock.json).
 *
 * Стеклянная панель с пунктами и «пилюлей» выбора, которую можно
 * нажать или перетащить: при захвате пилюля поднимается в стеклянную
 * линзу с «гелем» от скорости и после отпускания пружиной садится на
 * ближайший пункт. Структура и числа — из исходника компонента:
 *
 *   bar      Glass radius 20 · strength 0.28 · frost 0.3 →
 *            tint min(.5, frost·.5) = .15 · blur 2 + frost·8 = 4.4 · dome .03
 *   pill     inset 6 · radius = radius − 7
 *            solid: rgba(255,255,255,.1) (светлая тема .5), inset 0 1px 0 rgba(255,255,255,.25)
 *            glass: strength .5 · blur 1 · tint .05 · dome .16, opacity = lift
 *            transform: translateX(x − w/2) scale(1 + .5q, 1 − .28q)
 *   row      flex, gap 2px (gap-0.5), padding 6px (p-1.5)
 *   item     min-width 62 · padding 6×12 · иконка 22px · подпись 11px medium
 *            white/55 → hover /80, «горячий» пункт — accent
 *   motion   spring cx/w 340/28 (на отпускании 340/26) · lift glide
 *            easeGel .22s / easeSoft .4s · deform spring 210/12 от
 *            0.0022·|v|^0.7 (≥ .1 пока тянут, ≤ .32) · overdrag 22px
 *
 * Мотор (Track / spring / glide / easeGel / easeSoft / overdrag) — тот
 * же порт glass-motion, что в js/glass-switch.js; стекло — движок
 * glass.json в js/glass.js (PillowGlass.attachLens).
 *
 * API: PillowGlassDock.create(host, {
 *        items: [{ value, label, icon (html), title, attrs }],
 *        value, onValueChange(value), radius, strength, frost, accent })
 *      → { setValue(value | null), bar, row }
 *   setValue(null) — ни один пункт не выбран (пилюля гаснет).
 */
(function () {
  "use strict";
  if (window.PillowGlassDock) return;

  var PILL_INSET = 6;

  function create(host, opts) {
    var C = window.PillowGlassSwitch && window.PillowGlassSwitch.core;
    if (!host || !C) return null;
    var items = opts.items || [];
    var radius = opts.radius != null ? opts.radius : 20;
    var pillRadius = opts.pillRadius != null ? opts.pillRadius : Math.max(4, radius - 7);
    var strength = opts.strength != null ? opts.strength : 0.28;
    var frost = opts.frost != null ? opts.frost : 0.3;
    var barTint = opts.tint != null ? opts.tint : Math.min(0.5, frost * 0.5);
    var barBlur = opts.blur != null ? opts.blur : 2 + frost * 8;
    var accent = opts.accent || "";
    var active = opts.value != null ? opts.value : (items[0] && items[0].value);

    /* ── разметка ─────────────────────────────────────────────────── */
    var bar = document.createElement("div");
    bar.className = "pl-dock";
    bar.style.borderRadius = radius + "px";
    bar.style.setProperty("--dock-tint", String(barTint));
    var bg = document.createElement("span");
    bg.className = "pl-dock-bg";
    bg.style.borderRadius = radius + "px";
    var pill = document.createElement("span");
    pill.className = "pl-dock-pill";
    pill.style.top = PILL_INSET + "px";
    pill.style.bottom = PILL_INSET + "px";
    var solid = document.createElement("span");
    solid.className = "pl-dock-pill-solid";
    solid.style.borderRadius = pillRadius + "px";
    var glassPill = document.createElement("span");
    glassPill.className = "pl-dock-pill-glass";
    glassPill.style.borderRadius = pillRadius + "px";
    pill.appendChild(solid);
    pill.appendChild(glassPill);
    var row = document.createElement("div");
    row.className = "pl-dock-row";

    var itemEls = [];
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var b = document.createElement("button");
      b.type = "button";
      b.className = "pl-dock-item";
      b.style.borderRadius = pillRadius + "px";
      b.setAttribute("data-value", it.value);
      if (it.title) b.title = it.title;
      if (it.attrs) for (var k in it.attrs) if (it.attrs.hasOwnProperty(k)) b.setAttribute(k, it.attrs[k]);
      b.innerHTML = '<span class="pl-dock-icon">' + (it.icon || "") + "</span>" +
        '<span class="pl-dock-label">' + it.label + "</span>";
      row.appendChild(b);
      itemEls.push(b);
    }
    bar.appendChild(bg);
    bar.appendChild(pill);
    bar.appendChild(row);
    host.innerHTML = "";
    host.appendChild(bar);

    if (window.PillowGlass && window.PillowGlass.attachLens) {
      /* Glass: backdrop url(линза) blur(b) saturate(1.6), полоса кромки по glass.json */
      window.PillowGlass.attachLens(bg, { strength: strength, blur: barBlur, dome: 0.03, saturate: 1.6, glassBand: true });
      window.PillowGlass.attachLens(glassPill, { strength: 0.5, blur: 1, dome: 0.16, saturate: 1.6, glassBand: true });
    }

    /* ── геометрия ────────────────────────────────────────────────── */
    function geom(i) {
      var el = itemEls[i];
      if (!el) return null;
      return { left: el.offsetLeft, width: el.offsetWidth, center: el.offsetLeft + el.offsetWidth / 2 };
    }
    function indexOf(v) {
      for (var i = 0; i < items.length; i++) if (items[i].value === v) return i;
      return -1;
    }
    function nearestIndex(x) {
      var best = 0, bestD = Infinity;
      for (var i = 0; i < items.length; i++) {
        var g = geom(i);
        if (!g) continue;
        var d = Math.abs(x - g.center);
        if (d < bestD) { bestD = d; best = i; }
      }
      return best;
    }

    /* ── motion ───────────────────────────────────────────────────── */
    var cx = new C.Track(0), wv = new C.Track(0), lift = new C.Track(0), deform = new C.Track(0);
    var dragging = false, grab = null, ready = false, hot = active;

    function paint() {
      var x = cx.get(), w = wv.get(), l = C.clamp(lift.get(), 0, 1), q = deform.get();
      pill.style.width = w + "px";
      pill.style.transform = "translateX(" + (x - w / 2) + "px) scale(" + (1 + 0.5 * q) + "," + (1 - 0.28 * q) + ")";
      solid.style.opacity = String(1 - l);
      glassPill.style.opacity = String(l);
      /* «горячий» пункт — ближайший к пилюле, пока её тянут */
      var v = (indexOf(active) < 0 && !dragging) || !items.length ? null : items[nearestIndex(x)].value;
      if (v !== hot) {
        hot = v;
        for (var i = 0; i < itemEls.length; i++) {
          var on = items[i].value === hot;
          itemEls[i].classList.toggle("is-hot", on);
          itemEls[i].style.color = on && accent ? accent : "";
        }
      }
    }
    cx.watch(paint); wv.watch(paint); lift.watch(paint); deform.watch(paint);

    function placeToActive() {
      var idx = indexOf(active);
      bar.classList.toggle("is-empty", idx < 0);
      if (idx < 0) { paint(); return; }
      var g = geom(idx);
      if (!g || !g.width) return;
      if (!ready || C.reduceMotion()) {
        cx.snap(g.center); wv.snap(g.width); ready = true; return;
      }
      C.spring(cx, function () { return g.center; }, { tension: 340, friction: 28 });
      C.spring(wv, function () { return g.width; }, { tension: 340, friction: 28 });
    }

    function runDeform() {
      if (C.reduceMotion()) return;
      C.spring(deform, function () {
        return C.clamp(Math.max(0.0022 * Math.pow(Math.abs(cx.velocity()), 0.7), dragging ? 0.1 : 0), 0, 0.32);
      }, {
        tension: 210, friction: 12,
        canRest: function () { return !dragging && Math.abs(cx.velocity()) < 0.02; }
      });
    }

    function bounds() {
      var first = geom(0), last = geom(items.length - 1);
      return { lo: first ? first.center : 0, hi: last ? last.center : 0 };
    }

    function select(idx) {
      var target = items[idx];
      if (!target) return;
      var changed = target.value !== active;
      active = target.value;
      bar.classList.remove("is-empty");
      if (changed && opts.onValueChange) opts.onValueChange(active);
    }

    row.addEventListener("pointerdown", function (e) {
      if (e.button !== undefined && e.button !== 0) return;
      try { row.setPointerCapture(e.pointerId); } catch (err) { /* нет активного указателя */ }
      /* из «ничего не выбрано» пилюля стартует с пункта под пальцем */
      if (indexOf(active) < 0) {
        var r0 = row.getBoundingClientRect();
        var g0 = geom(nearestIndex(e.clientX - r0.left));
        if (g0) { cx.snap(g0.center); wv.snap(g0.width); }
        bar.classList.remove("is-empty");
      }
      dragging = true;
      grab = { startX: e.clientX, from: cx.get(), moved: false };
      cx.halt();
      C.glide(lift, 1, 0.22, C.easeGel);
      runDeform();
    });
    row.addEventListener("pointermove", function (e) {
      if (!dragging || !grab) return;
      var dx = e.clientX - grab.startX;
      if (Math.abs(dx) > 3) grab.moved = true;
      var bd = bounds();
      var raw = grab.from + dx;
      var c = C.clamp(raw, bd.lo, bd.hi);
      cx.push(c + C.overdrag(raw - c, 22));
    });
    function onUp(e) {
      if (!dragging) return;
      dragging = false;
      var moved = grab && grab.moved;
      grab = null;
      var idx;
      if (moved) idx = nearestIndex(cx.get());
      else {
        var r = row.getBoundingClientRect();
        idx = nearestIndex(e.clientX - r.left);
      }
      C.glide(lift, 0, 0.4, C.easeSoft);
      select(idx);
      var g = geom(idx);
      if (g) {
        C.spring(cx, function () { return g.center; }, { tension: 340, friction: 26 });
        C.spring(wv, function () { return g.width; }, { tension: 340, friction: 26 });
      }
      runDeform();
    }
    row.addEventListener("pointerup", onUp);
    row.addEventListener("pointercancel", onUp);
    /* клавиатура: Enter / Space на пункте (click без указателя) */
    row.addEventListener("click", function (e) {
      if (e.detail !== 0) return;
      var b = e.target.closest ? e.target.closest(".pl-dock-item") : null;
      if (!b) return;
      select(itemEls.indexOf(b));
      placeToActive();
    });

    if (window.ResizeObserver) {
      new ResizeObserver(function () { ready = false; placeToActive(); }).observe(row);
    }
    placeToActive();

    return {
      bar: bar,
      row: row,
      setValue: function (v) {
        if (v === active) return;
        active = v;
        placeToActive();
        paint();
      }
    };
  }

  window.PillowGlassDock = { create: create };
})();
