/* Pillow — theme button icon: sun ⇄ moon with stars, morphed on a spring.
 *
 * One outlined shape does both: the body is a circle that grows, and a
 * second circle slides in from the top right and bites a crescent out of
 * it. The crescent outline is solved in closed form from where the two
 * circles meet (no masks or ids, so the icon survives being cloned into
 * the theme-switch snapshots). The rays shrink and turn away, two stars
 * pop into the bite, and a bouncy spring drives it all.
 *
 * API: PillowThemeIcon.set(isMoon, animate)
 *      PillowThemeIcon.adopt(root) — also drive the icons inside root
 *      (the theme switch's snapshots), so the morph shows there too.
 */
(function () {
  "use strict";
  if (window.PillowThemeIcon) return;

  var NS = "http://www.w3.org/2000/svg";
  var C = 12;                                  /* centre of the 24×24 grid */
  var SUN_R = 4.2, MOON_R = 8.6;               /* body radius */
  var CUT_R = 7.2;                             /* the biting circle */
  var CUT_DIR = [0.7071, -0.7071];             /* it comes from the top right */
  var CUT_FAR = 12.8, CUT_NEAR = 6.6;         /* its distance from the centre */
  var STARS = [
    { x: 17.4, y: 5.2, d: "M17.4 3.2a2 2 0 0 0 2 2a2 2 0 0 0 -2 2a2 2 0 0 0 -2 -2a2 2 0 0 0 2 -2", at: 0.45, size: 1.25 },
    { x: 20.2, y: 10.6, d: "M19.2 10.6h2m-1 -1v2", at: 0.6, size: 1 }
  ];

  var targets = [];
  var spring = { x: 0, v: 0, to: 0, raf: 0, last: 0 };
  /* bouncy: settles in ~0.5s with one soft overshoot */
  var K = 220, D = 14.5;

  function lerp(a, b, t) { return a + (b - a) * t; }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function f(n) { return (Math.round(n * 100) / 100).toString(); }

  /* the arc of circle (cx, cy, r) from P to Q that passes through M */
  function arc(r, cx, cy, P, Q, M) {
    var TAU = Math.PI * 2;
    var a1 = Math.atan2(P[1] - cy, P[0] - cx);
    var a2 = Math.atan2(Q[1] - cy, Q[0] - cx);
    var am = Math.atan2(M[1] - cy, M[0] - cx);
    var dq = ((a2 - a1) % TAU + TAU) % TAU;
    var dm = ((am - a1) % TAU + TAU) % TAU;
    var sweep = dm < dq ? 1 : 0;
    var span = sweep ? dq : TAU - dq;
    return "A" + f(r) + " " + f(r) + " 0 " + (span > Math.PI ? 1 : 0) + " " + sweep + " " + f(Q[0]) + " " + f(Q[1]);
  }

  function bodyPath(R, d) {
    var ux = CUT_DIR[0], uy = CUT_DIR[1], r = CUT_R;
    if (d >= R + r - 0.01 || d <= Math.abs(R - r) + 0.01) {
      return "M" + f(C - R) + " " + f(C) + "a" + f(R) + " " + f(R) + " 0 1 0 " + f(2 * R) + " 0" +
        "a" + f(R) + " " + f(R) + " 0 1 0 " + f(-2 * R) + " 0Z";
    }
    var a = (d * d + R * R - r * r) / (2 * d);
    var h = Math.sqrt(Math.max(0, R * R - a * a));
    var bx = C + a * ux, by = C + a * uy;
    var P1 = [bx - h * uy, by + h * ux], P2 = [bx + h * uy, by - h * ux];
    var kx = C + d * ux, ky = C + d * uy;             /* the cut's centre */
    var far = [C - R * ux, C - R * uy];                /* body's far side */
    var inner = [kx - r * ux, ky - r * uy];            /* bite's deepest point */
    return "M" + f(P1[0]) + " " + f(P1[1]) + arc(R, C, C, P1, P2, far) + arc(r, kx, ky, P2, P1, inner) + "Z";
  }

  function raysPath(s, rot) {
    if (s <= 0.01) return "";
    var out = "", rin = 6.6 + (1 - s) * 1.4, rout = rin + 2.4 * s;
    for (var i = 0; i < 8; i++) {
      var t = rot + i * Math.PI / 4, c = Math.cos(t), sn = Math.sin(t);
      out += "M" + f(C + c * rin) + " " + f(C + sn * rin) + "L" + f(C + c * rout) + " " + f(C + sn * rout);
    }
    return out;
  }

  function build(svg) {
    if (svg.__plIcon) return svg.__plIcon;
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    var g = document.createElementNS(NS, "g");
    var body = document.createElementNS(NS, "path");
    var rays = document.createElementNS(NS, "path");
    g.appendChild(body); g.appendChild(rays);
    var stars = [];
    for (var i = 0; i < STARS.length; i++) {
      var sp = document.createElementNS(NS, "path");
      sp.setAttribute("d", STARS[i].d);
      g.appendChild(sp);
      stars.push(sp);
    }
    svg.appendChild(g);
    svg.__plIcon = { g: g, body: body, rays: rays, stars: stars };
    return svg.__plIcon;
  }

  /* bind a clone made by cloneNode (its paths are there, the handle not) */
  function bindClone(svg) {
    var ps = svg.querySelectorAll("path"), g = svg.querySelector("g");
    if (!g || ps.length < 2 + STARS.length) return null;
    svg.__plIcon = { g: g, body: ps[0], rays: ps[1], stars: Array.prototype.slice.call(ps, 2) };
    return svg.__plIcon;
  }

  function draw(p) {
    var R = Math.max(3, lerp(SUN_R, MOON_R, p));
    var d = lerp(CUT_FAR, CUT_NEAR, p);
    var raysS = clamp(1 - p / 0.55, 0, 1);
    var rot = p * Math.PI / 3;
    var swing = Math.sin(Math.PI * clamp(p, 0, 1)) * -28 + (p - clamp(p, 0, 1)) * -60;
    var bodyD = bodyPath(R, d), raysD = raysPath(raysS, rot);
    var starS = [];
    for (var k = 0; k < STARS.length; k++) starS.push(Math.max(0, (p - STARS[k].at) / (1 - STARS[k].at)));
    for (var i = targets.length - 1; i >= 0; i--) {
      var svg = targets[i];
      if (!svg.isConnected) { targets.splice(i, 1); continue; }
      var ic = svg.__plIcon || bindClone(svg);
      if (!ic) continue;
      ic.body.setAttribute("d", bodyD);
      ic.rays.setAttribute("d", raysD);
      ic.g.setAttribute("transform", "rotate(" + f(swing) + " 12 12)");
      for (var j = 0; j < ic.stars.length; j++) {
        var s = starS[j];
        ic.stars[j].setAttribute("transform", "translate(" + STARS[j].x + " " + STARS[j].y + ") scale(" + f(s * STARS[j].size) + ") translate(" + -STARS[j].x + " " + -STARS[j].y + ")");
        ic.stars[j].style.opacity = s > 0.02 ? "1" : "0";
      }
    }
  }

  function tick(now) {
    var dt = spring.last ? Math.min(0.05, (now - spring.last) / 1000) : 1 / 60;
    spring.last = now;
    var steps = Math.ceil(dt / 0.004), h = dt / steps;
    for (var i = 0; i < steps; i++) {
      var a = -K * (spring.x - spring.to) - D * spring.v;
      spring.v += a * h;
      spring.x += spring.v * h;
    }
    if (Math.abs(spring.x - spring.to) < 0.0015 && Math.abs(spring.v) < 0.01) {
      spring.x = spring.to; spring.v = 0; spring.raf = 0; spring.last = 0;
      draw(spring.x);
      return;
    }
    draw(spring.x);
    spring.raf = requestAnimationFrame(tick);
  }

  function reduced() {
    try { return window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) { return false; }
  }

  function collect() {
    var list = document.querySelectorAll("svg.theme-morph");
    for (var i = 0; i < list.length; i++) {
      build(list[i]);
      if (targets.indexOf(list[i]) < 0) targets.push(list[i]);
    }
  }

  window.PillowThemeIcon = {
    set: function (moon, animate) {
      collect();
      spring.to = moon ? 1 : 0;
      if (!animate || reduced()) {
        if (spring.raf) cancelAnimationFrame(spring.raf);
        spring.raf = 0; spring.last = 0;
        spring.x = spring.to; spring.v = 0;
        draw(spring.x);
        return;
      }
      if (!spring.raf) spring.raf = requestAnimationFrame(tick);
    },
    adopt: function (root) {
      if (!root || !root.querySelectorAll) return;
      var list = root.querySelectorAll("svg.theme-morph");
      for (var i = 0; i < list.length; i++) {
        list[i].__plIcon = null;
        if (bindClone(list[i]) && targets.indexOf(list[i]) < 0) targets.push(list[i]);
      }
      draw(spring.x);
    },
    _state: spring,
    _draw: draw
  };
})();
