/* Pillow — Animation Library
 *
 * Save the keyframes of any layer as a preset (host: pillowLibCapture),
 * browse presets as cards with a mini player, apply one to the selected
 * layers (pillowLibApply), share presets as .pillowanim files.
 *
 * Storage: one .pillowanim (JSON) file per preset in
 * <user data>/Pillow/Library when CEP's file API is available, otherwise
 * localStorage. Built-in starter presets live in this file.
 *
 * Mini player: the preset's own keyframes are evaluated the way AE does
 * it — hold / linear / bezier with temporal ease (speed + influence),
 * spatial tangents for Position — and drive a stand-in object: the text
 * of a text layer, otherwise a rounded tile. Transform (position, scale,
 * rotation, X/Y rotation, opacity) and blur effects are shown; wiggle()
 * expressions are imitated.
 */
(function () {
  "use strict";
  if (window.PillowLibrary) return;

  var HOLD = 6614, LINEAR = 6612;
  var LS_KEY = "pillow.library";
  var AUTHOR_KEY = "pillow.libraryAuthor";

  var state = { presets: [], folders: [], view: null, filter: "", active: null, playing: {}, resumed: false, editing: null };

  /* ── built-in starter presets ──────────────────────────────────── */
  function K(t, v, oe, ie, extra) {
    var k = { t: t, v: v, ii: 6613, oi: 6613, ie: ie || [[0, 33.33]], oe: oe || [[0, 33.33]] };
    if (extra) for (var x in extra) k[x] = extra[x];
    return k;
  }
  function E3(speed, infl) { return [[speed, infl], [speed, infl], [speed, infl]]; }
  var TR = { m: "ADBE Transform Group" };
  function tp(m) { return [TR, { m: m }]; }
  var POS = tp("ADBE Position"), SCALE = tp("ADBE Scale"), ROT = tp("ADBE Rotate Z"), OPA = tp("ADBE Opacity");
  var BLUR = [{ m: "ADBE Effect Parade" }, { m: "ADBE Gaussian Blur 2", n: 0, name: "Gaussian Blur" }, { m: "ADBE Gaussian Blur 2-0001" }];
  var SP = { it: [0, 0, 0], ot: [0, 0, 0] };

  var BUILTIN = [
    { id: "pl-pop-in", name: "Pop In", anchor: "last", duration: 0.5, props: [
      { path: SCALE, keys: [K(0, [0, 0, 100], E3(0, 20)), K(0.3, [112, 112, 100], E3(0, 40), E3(0, 60)), K(0.5, [100, 100, 100], null, E3(0, 70))] },
      { path: OPA, keys: [K(0, 0, [[0, 20]]), K(0.2, 100, null, [[0, 60]])] }] },
    { id: "pl-slide-up", name: "Slide Up Fade", anchor: "last", duration: 0.6, props: [
      { path: POS, spatial: true, keys: [K(0, [960, 620, 0], [[0, 12]], null, SP), K(0.6, [960, 540, 0], null, [[0, 88]], SP)] },
      { path: OPA, keys: [K(0, 0, [[0, 20]]), K(0.35, 100, null, [[0, 70]])] }] },
    { id: "pl-drop-bounce", name: "Drop Bounce", anchor: "last", duration: 0.9, props: [
      { path: POS, spatial: true, keys: [
        K(0, [960, 340, 0], [[0, 60]], null, SP),
        K(0.35, [960, 540, 0], [[900, 30]], [[1100, 30]], SP),
        K(0.55, [960, 490, 0], [[0, 45]], [[0, 45]], SP),
        K(0.72, [960, 540, 0], [[400, 30]], [[500, 30]], SP),
        K(0.82, [960, 526, 0], [[0, 45]], [[0, 45]], SP),
        K(0.9, [960, 540, 0], null, [[250, 30]], SP)] },
      { path: OPA, keys: [K(0, 0, [[0, 10]]), K(0.12, 100, null, [[0, 50]])] }] },
    { id: "pl-spin-in", name: "Spin In", anchor: "last", duration: 0.7, props: [
      { path: ROT, keys: [K(0, -180, [[0, 10]]), K(0.7, 0, null, [[0, 85]])] },
      { path: SCALE, keys: [K(0, [0, 0, 100], E3(0, 10)), K(0.7, [100, 100, 100], null, E3(0, 85))] }] },
    { id: "pl-blur-in", name: "Blur In", anchor: "last", duration: 0.6, props: [
      { path: BLUR, keys: [K(0, 40, [[0, 10]]), K(0.6, 0, null, [[0, 80]])] },
      { path: OPA, keys: [K(0, 0, [[0, 15]]), K(0.4, 100, null, [[0, 70]])] },
      { path: SCALE, keys: [K(0, [115, 115, 100], E3(0, 10)), K(0.6, [100, 100, 100], null, E3(0, 80))] }] },
    { id: "pl-fade-out-down", name: "Fade Out Down", anchor: "first", duration: 0.5, props: [
      { path: POS, spatial: true, keys: [K(0, [960, 540, 0], [[0, 70]], null, SP), K(0.5, [960, 600, 0], null, [[0, 15]], SP)] },
      { path: OPA, keys: [K(0, 100, [[0, 60]]), K(0.5, 0, null, [[0, 20]])] }] },
    { id: "pl-pulse", name: "Pulse Loop", anchor: "first", duration: 0.8, props: [
      { path: SCALE, keys: [K(0, [100, 100, 100], E3(0, 50)), K(0.4, [110, 110, 100], E3(0, 50), E3(0, 50)), K(0.8, [100, 100, 100], null, E3(0, 50))],
        expr: 'loopOut("cycle")' }] },
    { id: "pl-wiggle", name: "Wiggle", anchor: "first", duration: 0, props: [
      { path: POS, spatial: true, keys: [], expr: "wiggle(3, 25)" },
      { path: ROT, keys: [], expr: "wiggle(2, 4)" }] }
  ];
  for (var b = 0; b < BUILTIN.length; b++) {
    BUILTIN[b].builtin = true;
    BUILTIN[b].author = "Pillow";
    BUILTIN[b].v = 1;
    BUILTIN[b].comp = [1920, 1080];
    BUILTIN[b].fps = 30;
    BUILTIN[b].layer = { kind: "av", box: [0, 0, 200, 200] };
  }

  /* ── storage ───────────────────────────────────────────────────── */
  var FOLDERS_KEY = "pillow.libraryFolders";
  var BUILTIN_FOLDER = "pillow";
  var COLORS = ["blue", "white", "gray", "yellow"];
  /* Where presets live — never inside the extension's own folder, so
     installing a new Pillow over the old one keeps them:
       main   <user data>/Pillow/Library       (AppData / Application Support)
       backup <Documents>/Pillow/Library       (a second copy of every preset
                                                and of folders.json)
     On start the two are merged (a preset missing from one is copied back
     from the other), and presets an older Pillow kept in localStorage
     (when it had no file access) are moved into the files once. Without
     file access everything stays in localStorage, as before. */
  var dir = null, bdir = null;
  function fs() { return window.cep && window.cep.fs ? window.cep.fs : null; }
  function sysDir(kind, sub) {
    try {
      if (fs() && window.csInterface && window.SystemPath) {
        var base = window.csInterface.getSystemPath(kind);
        if (base) {
          var d = base.replace(/\\/g, "/").replace(/\/$/, "") + sub;
          fs().makedir(d.replace(/\/Library$/, ""));
          fs().makedir(d);
          var chk = fs().readdir(d);
          if (chk && !chk.err) return d;
        }
      }
    } catch (e) {}
    return "";
  }
  function libDir() {
    if (dir === null) dir = sysDir(window.SystemPath ? SystemPath.USER_DATA : "userData", "/Pillow/Library");
    return dir;
  }
  function backupDir() {
    if (bdir === null) {
      bdir = sysDir(window.SystemPath ? SystemPath.MY_DOCUMENTS : "myDocuments", "/Pillow/Library");
      if (bdir && bdir === libDir()) bdir = "";
    }
    return bdir;
  }
  function readDirPresets(d) {
    var out = [];
    if (!d) return out;
    var ls = fs().readdir(d);
    var names = ls && !ls.err ? ls.data || [] : [];
    for (var i = 0; i < names.length; i++) {
      if (!/\.pillowanim$/i.test(names[i])) continue;
      var f = fs().readFile(d + "/" + names[i]);
      if (!f || f.err) continue;
      var p = parse(f.data);
      if (p) { p._file = names[i]; out.push(p); }
    }
    return out;
  }
  function writePreset(d, p) {
    if (!d) return;
    try { fs().writeFile(d + "/" + p._file, JSON.stringify(clean(p), null, 1)); } catch (e) {}
  }
  function loadUser() {
    var out = [], d = libDir(), b = backupDir(), seen = {}, i;
    if (d) {
      var main = readDirPresets(d), back = readDirPresets(b);
      for (i = 0; i < main.length; i++) { seen[main[i].id] = true; out.push(main[i]); }
      /* only in the backup (the main folder was cleared): bring it back */
      for (i = 0; i < back.length; i++) if (!seen[back[i].id]) { seen[back[i].id] = true; out.push(back[i]); writePreset(d, back[i]); }
      /* only in the main folder: give it its backup copy */
      if (b) {
        var inBack = {};
        for (i = 0; i < back.length; i++) inBack[back[i].id] = true;
        for (i = 0; i < out.length; i++) if (!inBack[out[i].id]) writePreset(b, out[i]);
      }
      /* an older Pillow without file access kept presets in localStorage */
      try {
        var old = JSON.parse(window.localStorage.getItem(LS_KEY) || "[]");
        for (i = 0; i < old.length; i++) {
          if (!valid(old[i]) || seen[old[i].id]) continue;
          old[i]._file = old[i].id + ".pillowanim";
          writePreset(d, old[i]); writePreset(b, old[i]);
          seen[old[i].id] = true; out.push(old[i]);
        }
        if (old.length) window.localStorage.removeItem(LS_KEY);
      } catch (eOld) {}
      return out;
    }
    try {
      var raw = JSON.parse(window.localStorage.getItem(LS_KEY) || "[]");
      for (var j = 0; j < raw.length; j++) if (valid(raw[j])) out.push(raw[j]);
    } catch (e2) {}
    return out;
  }
  function saveUserAll() {
    if (libDir()) return;
    var mine = [];
    for (var i = 0; i < state.presets.length; i++) if (!state.presets[i].builtin) mine.push(clean(state.presets[i]));
    try { window.localStorage.setItem(LS_KEY, JSON.stringify(mine)); } catch (e) {}
  }
  function store(p) {
    var d = libDir();
    if (d) {
      p._file = p._file || (p.id + ".pillowanim");
      writePreset(d, p);
      writePreset(backupDir(), p);
    }
    saveUserAll();
  }
  function unstore(p) {
    var d = libDir(), b = backupDir();
    if (d && p._file) { try { fs().deleteFile(d + "/" + p._file); } catch (e) {} }
    if (b && p._file) { try { fs().deleteFile(b + "/" + p._file); } catch (e2) {} }
    saveUserAll();
  }
  /* folders: [{ id, name, color, created }] — folders.json next to the
     presets (and in the backup), or localStorage */
  function readFoldersFile(d) {
    if (!d) return null;
    try { var f = fs().readFile(d + "/folders.json"); if (f && !f.err) return f.data; } catch (e) {}
    return null;
  }
  function loadFolders() {
    var raw = null, d = libDir();
    try {
      if (d) {
        raw = readFoldersFile(d);
        if (!raw) {
          raw = readFoldersFile(backupDir()) || window.localStorage.getItem(FOLDERS_KEY);
          if (raw) fs().writeFile(d + "/folders.json", raw);
        }
      } else raw = window.localStorage.getItem(FOLDERS_KEY);
    } catch (e) {}
    var list = [];
    try { list = JSON.parse(raw || "[]"); } catch (e2) { list = []; }
    var out = [];
    for (var i = 0; i < list.length; i++) {
      var F = list[i];
      if (F && F.id && F.id !== BUILTIN_FOLDER) out.push({ id: String(F.id), name: String(F.name || "Folder"), color: COLORS.indexOf(F.color) >= 0 ? F.color : "blue", created: F.created || 0 });
    }
    return out;
  }
  function storeFolders() {
    var mine = state.folders.filter(function (F) { return !F.builtin; })
      .map(function (F) { return { id: F.id, name: F.name, color: F.color, created: F.created }; });
    var json = JSON.stringify(mine, null, 1), d = libDir(), b = backupDir();
    try {
      if (d) { fs().writeFile(d + "/folders.json", json); if (b) fs().writeFile(b + "/folders.json", json); }
      else window.localStorage.setItem(FOLDERS_KEY, json);
    } catch (e) {}
  }
  function clean(p) {
    var o = {};
    for (var k in p) if (p.hasOwnProperty(k) && k.charAt(0) !== "_" && k !== "builtin") o[k] = p[k];
    return o;
  }
  function valid(p) {
    if (!p || typeof p !== "object") return false;
    if (p.kind === "layers") return !!(p.layers && p.layers.length);
    return !!(p.props && p.props.length);
  }
  function parse(s) {
    try { var p = JSON.parse(s); return valid(p) ? p : null; } catch (e) { return null; }
  }
  function newId() { return "u" + Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36); }

  /* ── keyframe evaluation (AE semantics) ────────────────────────── */
  function bez(p0, p1, p2, p3, u) {
    var m = 1 - u;
    return m * m * m * p0 + 3 * m * m * u * p1 + 3 * m * u * u * p2 + u * u * u * p3;
  }
  /* y of the cubic (0,y0)(x1,y1)(x2,y2)(dt,y3) at x */
  function curveAt(x, dt, y0, x1, y1, x2, y2, y3) {
    var lo = 0, hi = 1, u = x / dt;
    for (var i = 0; i < 24; i++) {
      var xu = bez(0, x1, x2, dt, u);
      if (Math.abs(xu - x) < 1e-5) break;
      if (xu < x) lo = u; else hi = u;
      u = (lo + hi) / 2;
    }
    return bez(y0, y1, y2, y3, u);
  }
  function easeOf(arr, d) {
    if (!arr || !arr.length) return [0, 33.33];
    return arr[Math.min(d, arr.length - 1)];
  }
  /* one scalar channel between two keys: value from y0 to y3 over dt */
  function channel(x, dt, y0, y3, k0, k1, d) {
    var linOut = k0.oi === LINEAR, linIn = k1.ii === LINEAR;
    if (linOut && linIn) return y0 + (y3 - y0) * (x / dt);
    var slope = (y3 - y0) / dt;
    var oe = easeOf(k0.oe, d), ie = easeOf(k1.ie, d);
    var io = linOut ? 1 / 3 : Math.max(0.001, oe[1] / 100), ii = linIn ? 1 / 3 : Math.max(0.001, ie[1] / 100);
    var so = linOut ? slope : oe[0], si = linIn ? slope : ie[0];
    return curveAt(x, dt, y0, io * dt, y0 + so * io * dt, dt - ii * dt, y3 - si * ii * dt, y3);
  }
  function spatialPoint(a, b, ot, it, s) {
    var out = [];
    for (var d = 0; d < 2; d++) out.push(bez(a[d], a[d] + (ot ? ot[d] || 0 : 0), b[d] + (it ? it[d] || 0 : 0), b[d], s));
    return out;
  }
  function valueAt(P, t) {
    var ks = P.keys;
    if (!ks || !ks.length) return null;
    if (t <= ks[0].t) return ks[0].v;
    var last = ks[ks.length - 1];
    if (t >= last.t) return last.v;
    var i = 0;
    while (i < ks.length - 2 && t >= ks[i + 1].t) i++;
    var k0 = ks[i], k1 = ks[i + 1], dt = Math.max(1e-4, k1.t - k0.t), x = t - k0.t;
    if (k0.oi === HOLD) return k0.v;
    if (P.spatial && k0.v instanceof Array) {
      /* distance along the path, eased, then the point at that distance */
      var L = 0, prev = k0.v, N = 24, lens = [0];
      for (var n = 1; n <= N; n++) {
        var pt = spatialPoint(k0.v, k1.v, k0.ot, k1.it, n / N);
        L += Math.sqrt(Math.pow(pt[0] - prev[0], 2) + Math.pow(pt[1] - prev[1], 2));
        lens.push(L); prev = pt;
      }
      if (L < 1e-6) return k0.v;
      var dist = channel(x, dt, 0, L, k0, k1, 0);
      var j = 1;
      while (j < N && lens[j] < dist) j++;
      var seg = lens[j] - lens[j - 1], f = seg > 0 ? (dist - lens[j - 1]) / seg : 0;
      return spatialPoint(k0.v, k1.v, k0.ot, k1.it, (j - 1 + f) / N);
    }
    if (k0.v instanceof Array) {
      var out = [];
      for (var d = 0; d < k0.v.length; d++) out.push(channel(x, dt, k0.v[d], k1.v[d], k0, k1, d));
      return out;
    }
    return channel(x, dt, k0.v, k1.v, k0, k1, 0);
  }

  /* smooth pseudo-noise for wiggle() look-alike */
  function noise(t, seed) {
    return Math.sin(t * 1.7 + seed) * 0.55 + Math.sin(t * 3.1 + seed * 2.3) * 0.3 + Math.sin(t * 5.3 + seed * 0.7) * 0.15;
  }
  function wiggleOf(expr) {
    var m = /wiggle\(\s*([\d.]+)\s*,\s*([\d.]+)/.exec(expr || "");
    return m ? { f: parseFloat(m[1]), a: parseFloat(m[2]) } : null;
  }

  function lastM(P) { return P.path[P.path.length - 1].m; }
  function durationOf(p) {
    if (p.thumb && p.thumb.data) return Math.max(0.5, p.thumb.dur || 1);
    var d = p.duration || 0;
    return d > 0.05 ? d : 2;
  }

  /* the look of the stand-in at time t */
  function frame(p, t, stageW, stageH) {
    var sc = (p.comp && p.comp[1]) ? stageH / p.comp[1] * 1.9 : 0.12;
    var anchorLast = p.anchor === "last";
    var tx = 0, ty = 0, sx = 1, sy = 1, rot = 0, rx = 0, ry = 0, op = 1, blur = 0;
    for (var i = 0; i < p.props.length; i++) {
      var P = p.props[i], m = lastM(P), v = valueAt(P, t), w = wiggleOf(P.expr);
      var loop = /loopOut/.test(P.expr || "");
      if (loop && P.keys && P.keys.length > 1) {
        var span = P.keys[P.keys.length - 1].t - P.keys[0].t;
        if (span > 0 && t > P.keys[P.keys.length - 1].t) v = valueAt(P, P.keys[0].t + ((t - P.keys[0].t) % span));
      }
      var ref = P.keys && P.keys.length ? (anchorLast ? P.keys[P.keys.length - 1].v : P.keys[0].v) : null;
      if (m === "ADBE Position" && v) {
        tx += (v[0] - ref[0]) * sc; ty += (v[1] - ref[1]) * sc;
      } else if (m === "ADBE Position_0" && v !== null) tx += (v - ref) * sc;
      else if (m === "ADBE Position_1" && v !== null) ty += (v - ref) * sc;
      else if (m === "ADBE Scale" && v) { sx = v[0] / 100; sy = v[1] / 100; }
      else if (m === "ADBE Rotate Z" && v !== null) rot = v;
      else if (m === "ADBE Rotate X" && v !== null) rx = v;
      else if (m === "ADBE Rotate Y" && v !== null) ry = v;
      else if (m === "ADBE Opacity" && v !== null) op = v / 100;
      else if ((m === "ADBE Gaussian Blur 2-0001" || m === "ADBE Box Blur2-0001") && v !== null) blur = v * sc * 0.6;
      if (w) {
        var amp = w.a, ph = t * w.f;
        if (m === "ADBE Position") { tx += noise(ph, 1) * amp * sc; ty += noise(ph, 7) * amp * sc; }
        else if (m === "ADBE Rotate Z") rot += noise(ph, 3) * amp;
        else if (m === "ADBE Scale") { var ds = noise(ph, 5) * amp / 100; sx += ds; sy += ds; }
        else if (m === "ADBE Opacity") op = Math.max(0, Math.min(1, op + noise(ph, 9) * amp / 100));
      }
    }
    var lim = stageW * 0.9;
    tx = Math.max(-lim, Math.min(lim, tx)); ty = Math.max(-stageH, Math.min(stageH, ty));
    return {
      transform: "translate(" + tx.toFixed(2) + "px," + ty.toFixed(2) + "px) perspective(300px) rotateX(" + rx.toFixed(2) + "deg) rotateY(" + ry.toFixed(2) +
        "deg) rotate(" + rot.toFixed(2) + "deg) scale(" + sx.toFixed(4) + "," + sy.toFixed(4) + ")",
      opacity: Math.max(0, Math.min(1, op)).toFixed(3),
      filter: blur > 0.05 ? "blur(" + blur.toFixed(2) + "px)" : "none"
    };
  }
  function paint(obj, p, t) {
    if (obj && p.thumb && p.thumb.data) { paintThumb(obj, p, t); return; }
    if (!obj || p.kind === "layers") return;
    var st = obj.parentNode;
    var f = frame(p, t, st.clientWidth || 180, st.clientHeight || 64);
    obj.style.transform = f.transform;
    obj.style.opacity = f.opacity;
    obj.style.filter = f.filter;
  }
  /* resting frame: the end of an entrance, the start of anything else */
  function restTime(p) {
    if (p.thumb && p.thumb.data) return p.thumb.n > 1 ? (p.thumb.rest || 0) / (p.thumb.n - 1) * durationOf(p) : 0;
    return p.anchor === "last" ? durationOf(p) : 0;
  }

  /* ── players ───────────────────────────────────────────────────── */
  var raf = 0;
  function tick(now) {
    raf = 0;
    var any = false;
    for (var id in state.playing) {
      var pl = state.playing[id];
      if (!pl.obj.isConnected) { delete state.playing[id]; continue; }
      var D = durationOf(pl.p), cycle = D + 0.9;
      var t = ((now - pl.start) / 1000) % cycle;
      /* 0.25 s before, then the animation, then a hold */
      t = Math.max(0, Math.min(D, t - 0.25));
      paint(pl.obj, pl.p, t);
      any = true;
    }
    if (any && state.resumed) raf = requestAnimationFrame(tick);
  }
  function play(card, on) {
    var id = card.getAttribute("data-lib-id"), p = byId(id), obj = card.querySelector(".lib-obj");
    if (!p || !obj) return;
    if (on) {
      if (!state.playing[id]) state.playing[id] = { p: p, obj: obj, start: performance.now() };
      if (!raf && state.resumed) raf = requestAnimationFrame(tick);
    } else if (state.playing[id] && id !== state.active) {
      delete state.playing[id];
      paint(obj, p, restTime(p));
    }
  }

  /* ── rendering ─────────────────────────────────────────────────── */
  function byId(id) {
    for (var i = 0; i < state.presets.length; i++) if (state.presets[i].id === id) return state.presets[i];
    return null;
  }
  function folderById(id) {
    for (var i = 0; i < state.folders.length; i++) if (state.folders[i].id === id) return state.folders[i];
    return null;
  }
  function presetsIn(fid) {
    return state.presets.filter(function (p) { return (p.builtin ? BUILTIN_FOLDER : p.folder) === fid; });
  }
  function esc(s) { return window.escapeHtml ? window.escapeHtml(s) : String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function fmtDur(p) { return p.duration > 0.05 ? p.duration.toFixed(p.duration < 10 ? 2 : 1).replace(/0$/, "") + "s" : "loop"; }
  function plural(n, w) { return n + " " + w + (n === 1 ? "" : "s"); }

  /* macOS-style folder: darker back with the tab, lighter front body,
     a highlight along its top edge and the two faint lines at the bottom */
  function folderSvg(color) {
    return '<svg class="lib-fsvg lib-f-' + color + '" viewBox="0 0 64 50" aria-hidden="true">' +
      '<path class="f-back" d="M3 9.5A4.5 4.5 0 0 1 7.5 5h13.2c1.5 0 2.6.5 3.7 1.6l2.3 2.3c1 1 2 1.4 3.4 1.4H56.5A4.5 4.5 0 0 1 61 14.8V40H3z"/>' +
      '<rect class="f-front" x="2" y="14.5" width="60" height="33.5" rx="4.6"/>' +
      '<rect x="2" y="14.5" width="60" height="33.5" rx="4.6" fill="url(#lib-f-sheen)"/>' +
      '<rect class="f-shine" x="3.2" y="15.2" width="57.6" height="1.2" rx=".6"/>' +
      "</svg>";
  }

  /* a saved set of layers: a little stack of its layers, top first */
  var KIND_ICON = { adjustment: "A", solid: "S", null: "N", text: "T", shape: "\u25C6", camera: "C", light: "L", footage: "F", precomp: "P" };
  function stackMarkup(p) {
    var ls = p.layers || [], html = '<span class="lib-stack">', n = Math.min(ls.length, 3);
    for (var i = 0; i < n; i++) {
      html += '<span class="lib-stack-row" style="--i:' + i + '"><span class="lib-stack-k">' + (KIND_ICON[ls[i].kind] || "\u2022") + "</span>" +
        '<span class="lib-stack-n">' + esc(ls[i].name) + "</span></span>";
    }
    if (ls.length > n) html += '<span class="lib-stack-more">+' + (ls.length - n) + " more</span>";
    return html + "</span>";
  }
  function objMarkup(p) {
    if (p.thumb && p.thumb.data) return thumbMarkup(p);
    if (p.kind === "layers") return stackMarkup(p);
    var L = p.layer || {};
    if (L.kind === "text" && L.label) return '<span class="lib-obj lib-obj-text">' + esc(L.label) + "</span>";
    return '<span class="lib-obj lib-obj-tile"></span>';
  }

  function cardMarkup(p) {
    return '<div class="card lib-card' + (p.id === state.active ? " active" : "") + '" data-lib-id="' + esc(p.id) + '" tabindex="0">' +
        '<div class="lib-stage">' + objMarkup(p) + "</div>" +
        '<div class="lib-name">' + esc(p.name) + "</div>" +
        '<div class="lib-meta">' + (p.author ? "by " + esc(p.author) + " · " : "") + (p.kind === "layers" ? plural(p.layers.length, "layer") + " · " : "") + fmtDur(p) + "</div>" +
        '<div class="lib-actions">' +
          '<button type="button" class="btn-ghost btn-sm lib-apply" data-act="apply">Apply</button>' +
          (p.builtin ? "" :
          '<button type="button" class="tool-btn lib-icon" data-act="move" title="Move to folder" aria-label="Move to folder">' +
            '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><path d="M2 4.5c0-.8.7-1.5 1.5-1.5h3l1.5 1.5h4.5c.8 0 1.5.7 1.5 1.5v5.5c0 .8-.7 1.5-1.5 1.5h-9c-.8 0-1.5-.7-1.5-1.5z" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg></button>') +
          (p.builtin ? "" :
          '<button type="button" class="tool-btn lib-icon" data-act="thumb" title="Make the preview from the selected layers" aria-label="Make preview">' +
            '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><rect x="2" y="4" width="12" height="9" rx="2" fill="none" stroke="currentColor" stroke-width="1.4"/><circle cx="8" cy="8.5" r="2.2" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M5.5 4l1-1.6h3L10.5 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg></button>') +
          '<button type="button" class="tool-btn lib-icon" data-act="code" title="Copy preset code (send it in any chat)" aria-label="Copy preset code">' +
            '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><path d="M5.5 4.5 2 8l3.5 3.5M10.5 4.5 14 8l-3.5 3.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' +
          '<button type="button" class="tool-btn lib-icon" data-act="export" title="Export preset" aria-label="Export preset">' +
            '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><path d="M8 2v8M4.5 6.5 8 10l3.5-3.5M3 13h10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' +
          (p.builtin ? "" :
          '<button type="button" class="tool-btn lib-icon" data-act="delete" title="Delete preset" aria-label="Delete preset">' +
            '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button>') +
        "</div>" +
      "</div>";
  }

  /* ── folder editor (new folder / rename, colour, delete) ───────────── */
  function editorMarkup(F) {
    var sw = "";
    for (var i = 0; i < COLORS.length; i++) {
      var c = COLORS[i];
      sw += '<button type="button" class="lib-swatch lib-sw-' + c + (F.color === c ? " on" : "") + '" data-color="' + c + '" title="' + c.charAt(0).toUpperCase() + c.slice(1) + '" aria-label="' + c + '"></button>';
    }
    return '<div class="glass-panel lib-editor">' +
      '<div class="lib-editor-row">' +
        '<div class="lib-editor-icon">' + folderSvg(F.color) + "</div>" +
        '<div class="field lib-editor-field"><label class="field-label" for="lib-folder-name">Folder name</label>' +
        '<input class="field-input" id="lib-folder-name" type="text" maxlength="28" value="' + esc(F.name) + '" placeholder="Folder name" /></div>' +
      "</div>" +
      '<div class="lib-swatches">' + sw + "</div>" +
      '<div class="lib-editor-btns">' +
        (F.id ? '<button type="button" class="btn-ghost lib-ed-delete" data-ed="delete">Delete</button>' : "") +
        '<button type="button" class="btn-ghost" data-ed="cancel">Cancel</button>' +
        '<button type="button" class="btn-ghost lib-ed-ok" data-ed="ok">' + (F.id ? "Save" : "Create") + "</button>" +
      "</div>" +
    "</div>";
  }

  function openEditor(F) {
    state.editing = { id: F ? F.id : null, name: F ? F.name : "", color: F ? F.color : "blue", confirm: false };
    var box = $(state.view ? "lib-folder-editor" : "lib-root-editor");
    if (!box) return;
    box.innerHTML = editorMarkup(state.editing);
    box.hidden = false;
    var inp = $("lib-folder-name");
    if (inp) { inp.focus(); inp.select(); }
    if (window.pillowRescanTactile) window.pillowRescanTactile(box);
  }
  function closeEditor() {
    state.editing = null;
    var ids = ["lib-root-editor", "lib-folder-editor"];
    for (var i = 0; i < ids.length; i++) { var h = $(ids[i]); if (h) { h.hidden = true; h.innerHTML = ""; } }
  }
  function editorClick(ev) {
    var E = state.editing;
    if (!E) return;
    var sw = ev.target.closest ? ev.target.closest("[data-color]") : null;
    if (sw) {
      E.color = sw.getAttribute("data-color");
      var all = ev.currentTarget.querySelectorAll(".lib-swatch");
      for (var i = 0; i < all.length; i++) all[i].classList.toggle("on", all[i] === sw);
      var ic = ev.currentTarget.querySelector(".lib-editor-icon");
      if (ic) ic.innerHTML = folderSvg(E.color);
      return;
    }
    var btn = ev.target.closest ? ev.target.closest("[data-ed]") : null;
    if (!btn) return;
    var what = btn.getAttribute("data-ed");
    var name = (($("lib-folder-name") || {}).value || "").trim();
    if (what === "cancel") { closeEditor(); return; }
    if (what === "ok") {
      if (!name) { toast("Name the folder", true); return; }
      if (E.id) {
        var F = folderById(E.id);
        if (F) { F.name = name; F.color = E.color; }
      } else {
        state.folders.push({ id: "f" + newId(), name: name, color: E.color, created: Date.now() });
      }
      storeFolders();
      closeEditor();
      renderView();
      return;
    }
    if (what === "delete" && E.id) {
      var inside = presetsIn(E.id);
      if (inside.length && !E.confirm) {
        E.confirm = true;
        btn.textContent = "Delete " + plural(inside.length, "preset") + "?";
        btn.classList.add("is-armed");
        return;
      }
      for (var k = 0; k < inside.length; k++) unstore(inside[k]);
      state.presets = state.presets.filter(function (p) { return inside.indexOf(p) < 0; });
      saveUserAll();
      state.folders = state.folders.filter(function (F2) { return F2.id !== E.id; });
      storeFolders();
      closeEditor();
      state.view = null;
      renderView();
      toast("Folder deleted");
    }
  }
  function editorKey(ev) {
    /* Enter anywhere in the editor (name field, a colour swatch) confirms */
    if (ev.key === "Enter" && !(ev.target.closest && ev.target.closest("[data-ed]"))) {
      ev.preventDefault();
      var ok = ev.currentTarget.querySelector('[data-ed="ok"]');
      if (ok) ok.click();
    } else if (ev.key === "Escape") closeEditor();
  }

  /* ── views ─────────────────────────────────────────────────────── */
  function renderFolders() {
    var box = $("lib-folders");
    if (!box) return;
    var html = "";
    for (var i = 0; i < state.folders.length; i++) {
      var F = state.folders[i], n = presetsIn(F.id).length;
      html += '<button type="button" class="lib-folder" data-folder="' + esc(F.id) + '">' +
        folderSvg(F.color) +
        '<span class="lib-folder-name">' + esc(F.name) + "</span>" +
        '<span class="lib-folder-count">' + plural(n, "preset") + "</span>" +
      "</button>";
    }
    html += '<button type="button" class="lib-folder lib-folder-new" data-folder-new="1">' +
      '<span class="lib-new-icon"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></span>' +
      '<span class="lib-folder-name">New Folder</span><span class="lib-folder-count">&nbsp;</span></button>';
    box.innerHTML = html;
  }

  function renderView() {
    var root = $("lib-root"), inFolder = $("lib-in-folder");
    if (!root || !inFolder) return;
    var F = state.view ? folderById(state.view) : null;
    if (state.view && !F) state.view = null;
    root.hidden = !!F;
    inFolder.hidden = !F;
    unstage();
    state.staged = null;
    state.playing = {};
    if (!F) {
      renderFolders();
      var g = $("lib-grid"); if (g) g.innerHTML = "";
      return;
    }
    fillFolderView(F);
  }

  function fillFolderView(F) {
    var head = $("lib-folder-head");
    if (head) {
      head.innerHTML =
        '<button type="button" class="btn-ghost lib-back" data-nav="back" title="All folders">' +
          '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><path d="M10 3 5 8l5 5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Folders</span></button>' +
        '<span class="lib-head-icon">' + folderSvg(F.color) + "</span>" +
        '<span class="lib-head-name">' + esc(F.name) + "</span>" +
        (F.builtin ? "" : '<button type="button" class="btn-ghost lib-edit" data-nav="edit">Edit</button>');
    }
    var save = $("lib-save-panel"), imp = $("btn-lib-import");
    if (save) save.hidden = !!F.builtin;
    var g3d = $("g3d");
    if (g3d) g3d.hidden = !F.builtin;
    if (window.PillowGrid3D) window.PillowGrid3D[F.builtin ? "show" : "hide"]();
    if (imp) imp.hidden = !!F.builtin;
    renderGrid();
  }

  /* the presets of the open folder — rebuild the cards */
  function renderGrid() {
    var grid = $("lib-grid");
    if (!grid || !state.view) return;
    var list = presetsIn(state.view), html = "";
    for (var i = 0; i < list.length; i++) html += cardMarkup(list[i]);
    html += '<div class="lib-empty" style="display:none"></div>';
    state.playing = {};
    /* previews already on screen move into the new grid as they are
       (same picture), so a rebuild does not redraw them */
    var keep = {}, olds = grid.querySelectorAll(".lib-thumb[data-thumb]"), k;
    for (k = 0; k < olds.length; k++) {
      var op = byId(olds[k].getAttribute("data-thumb"));
      if (op && op.thumb) { olds[k].__thumbData = olds[k].__thumbData || op.thumb.data; keep[op.id] = olds[k]; }
    }
    grid.innerHTML = html;
    dressThumbs(grid);
    var news = grid.querySelectorAll(".lib-thumb[data-thumb]");
    for (k = 0; k < news.length; k++) {
      var id = news[k].getAttribute("data-thumb"), old = keep[id], np = byId(id);
      if (old && np && np.thumb && old.__thumbData === np.thumb.data && news[k].parentNode) {
        old.style.backgroundImage = news[k].style.backgroundImage;
        old.style.backgroundSize = news[k].style.backgroundSize;
        news[k].parentNode.replaceChild(old, news[k]);
      }
    }
    var cards = grid.querySelectorAll(".lib-card");
    for (var c = 0; c < cards.length; c++) {
      var pp = byId(cards[c].getAttribute("data-lib-id"));
      paint(cards[c].querySelector(".lib-obj"), pp, restTime(pp));
      if (pp.id === state.active) play(cards[c], true);
    }
    var cnt = $("lib-count");
    if (cnt) cnt.textContent = plural(list.length, "preset");
    filter(false);
    if (window.pillowRescanTactile) window.pillowRescanTactile(grid);
  }

  /* the filter changed — show / hide the existing cards */
  function filter(animate) {
    var grid = $("lib-grid");
    if (!grid) return;
    var q = state.filter.toLowerCase(), cards = grid.querySelectorAll(".lib-card"), show = [], n = 0;
    for (var i = 0; i < cards.length; i++) {
      var p = byId(cards[i].getAttribute("data-lib-id"));
      show[i] = !q || (p.name + " " + (p.author || "")).toLowerCase().indexOf(q) >= 0;
      if (show[i]) n++;
    }
    var empty = grid.querySelector(".lib-empty");
    if (empty) {
      empty.textContent = q ? "No presets match." : "Empty folder. Select a layer in AE and save its animation here, or import presets.";
      empty.style.display = n ? "none" : "";
    }
    if (window.PillowListFx && cards.length) window.PillowListFx.apply(grid, cards, show, { animate: animate !== false });
    else for (i = 0; i < cards.length; i++) cards[i].style.display = show[i] ? "" : "none";
  }

  /* switch between the folder grid and a folder, no animation */
  function showView(id) {
    closeEditor();
    closeMoveMenu();
    state.view = id;
    state.filter = "";
    if ($("lib-filter")) $("lib-filter").value = "";
    renderView();
    var sc = scroller();
    if (sc) sc.scrollTop = 0;
  }
  function scroller() { var pane = $("pane-library"); return pane && pane.closest ? pane.closest(".content") : null; }
  function reduceMotion() { return !!window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches; }

  /* ── folder morph ─────────────────────────────────────────────────
     Like the logo → settings morph: the folder's front body lifts off
     its tile, grows into the folder view and turns from the folder's
     colour into the theme surface (its tab melts away on the way); then
     the contents come in. Back runs it in reverse, landing on the tile. */
  var FRONT = { blue: "#5fc4fb", white: "#f7f8fa", gray: "#a8abb1", yellow: "#fdd34f" };
  var BACK = { blue: "#1f8ee0", white: "#c3c8d0", gray: "#72767c", yellow: "#e3a60a" };
  var M_OPEN = 280, M_CLOSE = 260, M_EASE = "cubic-bezier(0.25, 0.9, 0.3, 1)";
  var morphing = false, pending = null;
  /* a click that lands while a morph runs is not lost — it runs next */
  function morphDone() {
    morphing = false;
    var next = pending; pending = null;
    if (next) next();
  }

  function surface() {
    var root = document.documentElement;
    var light = root.getAttribute("data-theme") === "light";
    if (root.getAttribute("data-pl-glass") === "on") return light ? "rgba(252, 252, 253, 0.82)" : "rgba(58, 60, 66, 0.82)";
    return light ? "rgb(246, 246, 248)" : "rgb(24, 25, 28)";
  }
  /* where the folder view lives: under the section hint, down to the
     bottom of the scrolling area */
  function viewRect() {
    var pane = $("pane-library"), sc = scroller();
    var hint = pane.querySelector(".section-hint");
    var pr = pane.getBoundingClientRect(), cr = sc ? sc.getBoundingClientRect() : pr;
    var top = Math.max(cr.top + 6, hint.getBoundingClientRect().bottom + 8);
    return { left: pr.left, top: top, width: pr.width, height: Math.max(80, cr.bottom - 8 - top), r: 18 };
  }
  /* the front body of a folder icon, in viewport px */
  function bodyRect(svg) {
    var a = svg.getBoundingClientRect(), k = a.width / 64;
    return { left: a.left + 2 * k, top: a.top + 14.5 * (a.height / 50), width: 60 * k, height: 33.5 * (a.height / 50), r: 4.6 * k };
  }
  function geoOf(R) { return { left: R.left + "px", top: R.top + "px", width: R.width + "px", height: R.height + "px" }; }
  function lookOf(R, color) { return { borderRadius: R.r + "px", backgroundColor: color }; }
  var BACK_PATH = "M3 9.5A4.5 4.5 0 0 1 7.5 5h13.2c1.5 0 2.6.5 3.7 1.6l2.3 2.3c1 1 2 1.4 3.4 1.4H56.5A4.5 4.5 0 0 1 61 14.8V22H3z";
  /* the whole folder: its back (with the tab) behind, the front body on
     top. The back is the icon's own outline, pinned above the body in
     px and stretched with its width, so at the start the overlay is the
     icon exactly, and the back melts away as the body grows. */
  function makeOverlay(F, R, color) {
    var ov = document.createElement("div");
    ov.className = "lib-morph";
    var g = geoOf(R);
    for (var k in g) ov.style[k] = g[k];
    var kv = R.height / 33.5;
    ov.innerHTML =
      '<svg class="lib-morph-back" viewBox="0 0 64 22" preserveAspectRatio="none" aria-hidden="true" style="top:' + (-14.5 * kv).toFixed(2) + "px;height:" + (22 * kv).toFixed(2) + 'px">' +
        '<path d="' + BACK_PATH + '" fill="' + (BACK[F.color] || BACK.blue) + '"/></svg>' +
      '<div class="lib-morph-body"><span class="lib-morph-sheen"></span></div>';
    var body = ov.querySelector(".lib-morph-body"), l = lookOf(R, color);
    for (var j in l) body.style[j] = l[j];
    document.body.appendChild(ov);
    return ov;
  }
  function contentIn(sec) {
    var kids = sec.children, n = 0;
    for (var i = 0; i < kids.length; i++) {
      if (kids[i].hidden || !kids[i].animate) continue;
      kids[i].animate([{ opacity: 0, transform: "translateY(8px) scale(0.985)" }, { opacity: 1, transform: "none" }],
        { duration: 180, delay: Math.min(n++, 4) * 14, easing: "cubic-bezier(0.23, 1, 0.32, 1)", fill: "backwards" });
    }
  }

  /* ── staging: a folder's view is built ahead, invisibly ──────────────
     Building its cards (plates, glass, players) is the expensive part of
     opening a folder; done in the middle of the morph it cost frames.
     Hovering a folder builds its view in place, hidden, so the click only
     has to reveal it. */
  function stage(id) {
    var inFolder = $("lib-in-folder"), root = $("lib-root");
    if (!inFolder || !root || state.view) return;
    if (state.staged === id && !inFolder.hidden) return;
    var keep = state.active;
    state.view = id;
    fillFolderView(folderById(id));
    state.view = null;
    state.active = keep;
    inFolder.classList.add("lib-staging");
    inFolder.style.top = root.offsetTop + "px";
    inFolder.hidden = false;
    state.staged = id;
  }
  function unstage() {
    var inFolder = $("lib-in-folder");
    if (inFolder) { inFolder.classList.remove("lib-staging"); inFolder.style.top = ""; }
  }
  /* the staged view becomes the real one */
  function reveal(id) {
    closeEditor();
    closeMoveMenu();
    state.view = id;
    state.filter = "";
    if ($("lib-filter")) $("lib-filter").value = "";
    $("lib-root").hidden = true;
    unstage();
    $("lib-in-folder").hidden = false;
    state.staged = null;
    var sc = scroller();
    if (sc) sc.scrollTop = 0;
  }

  function openFolder(id, tile) {
    if (morphing) { pending = function () { var t = $("lib-folders").querySelector('[data-folder="' + id + '"]'); if (!state.view) openFolder(id, t); }; return; }
    var F = folderById(id), svg = tile && tile.querySelector(".lib-fsvg");
    if (!F) return;
    stage(id);
    if (!svg || reduceMotion() || !document.body.animate) { reveal(id); contentIn($("lib-in-folder")); return; }
    morphing = true;
    var sc = scroller();
    if (sc && sc.scrollTop) { sc.scrollTop = 0; }
    var from = bodyRect(svg), to = viewRect();
    var front = FRONT[F.color] || FRONT.blue;
    var ov = makeOverlay(F, from, front);
    var body = ov.querySelector(".lib-morph-body");
    svg.style.visibility = "hidden";
    /* the other tiles step back while the folder grows */
    var root = $("lib-root");
    root.animate([{ opacity: 1, transform: "none" }, { opacity: 0, transform: "scale(0.97)" }], { duration: 140, easing: "ease-out", fill: "forwards" });
    ov.querySelector(".lib-morph-back").animate([{ opacity: 1 }, { opacity: 0 }], { duration: M_OPEN * 0.55, easing: "ease-out", fill: "forwards" });
    ov.querySelector(".lib-morph-sheen").animate([{ opacity: 1 }, { opacity: 0 }], { duration: M_OPEN * 0.7, easing: "ease-out", fill: "forwards" });
    var grow = ov.animate([geoOf(from), geoOf(to)], { duration: M_OPEN, easing: M_EASE, fill: "forwards" });
    body.animate([lookOf(from, front), lookOf(to, surface())], { duration: M_OPEN, easing: M_EASE, fill: "forwards" });
    /* the contents start coming in while the folder is still settling —
       the last stretch of the ease barely moves */
    var landed = false;
    function land() {
      if (landed) return;
      landed = true;
      root.getAnimations().forEach(function (an) { an.cancel(); });
      svg.style.visibility = "";
      reveal(id);
      contentIn($("lib-in-folder"));
      var fade = ov.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 150, easing: "ease-out", fill: "forwards" });
      fade.onfinish = function () { ov.remove(); morphDone(); };
    }
    setTimeout(land, M_OPEN * 0.62);
    grow.onfinish = land;
  }

  function closeFolder() {
    if (morphing) { pending = function () { if (state.view) closeFolder(); }; return; }
    var id = state.view, F = folderById(id);
    if (!F || reduceMotion() || !document.body.animate) { showView(null); contentIn($("lib-root")); return; }
    morphing = true;
    closeEditor();
    closeMoveMenu();
    var from = viewRect(), front = FRONT[F.color] || FRONT.blue;
    var ov = makeOverlay(F, from, surface());
    var body = ov.querySelector(".lib-morph-body"), back = ov.querySelector(".lib-morph-back"), sheen = ov.querySelector(".lib-morph-sheen");
    ov.style.opacity = "0";
    /* back and sheen belong to the folder — they come back only as it lands */
    back.style.opacity = "0";
    sheen.style.opacity = "0";
    var sec = $("lib-in-folder");
    sec.animate([{ opacity: 1, transform: "none" }, { opacity: 0, transform: "scale(0.985)" }], { duration: 90, easing: "ease-in", fill: "forwards" });
    var cover = ov.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 90, easing: "ease-out", fill: "forwards" });
    cover.onfinish = function () {
      sec.getAnimations().forEach(function (an) { an.cancel(); });
      /* back to the grid; the folder's view stays built (staged), so
         opening it again is instant */
      state.view = null;
      state.playing = {};
      renderFolders();
      var root = $("lib-root");
      root.hidden = false;
      sec.classList.add("lib-staging");
      sec.style.top = root.offsetTop + "px";
      state.staged = id;
      var sc = scroller();
      if (sc) sc.scrollTop = 0;
      var tile = $("lib-folders").querySelector('[data-folder="' + id + '"]');
      var svg = tile && tile.querySelector(".lib-fsvg");
      if (!svg) { ov.remove(); contentIn(root); morphDone(); return; }
      svg.style.visibility = "hidden";
      var to = bodyRect(svg);
      /* the back is pinned in px from the body's height — re-pin it for
         the size it lands at */
      var kv = to.height / 33.5;
      back.style.top = (-14.5 * kv).toFixed(2) + "px";
      back.style.height = (22 * kv).toFixed(2) + "px";
      ov.style.opacity = "1";
      cover.cancel();
      root.animate([{ opacity: 0, transform: "scale(0.97)" }, { opacity: 1, transform: "none" }], { duration: 200, delay: 40, easing: "cubic-bezier(0.23, 1, 0.32, 1)", fill: "backwards" });
      back.animate([{ opacity: 0 }, { opacity: 0, offset: 0.4 }, { opacity: 1 }], { duration: M_CLOSE, easing: "ease-in", fill: "forwards" });
      sheen.animate([{ opacity: 0 }, { opacity: 1 }], { duration: M_CLOSE, easing: "ease-in", fill: "forwards" });
      body.animate([lookOf(from, surface()), lookOf(to, front)], { duration: M_CLOSE, easing: M_EASE, fill: "forwards" });
      var shrink = ov.animate([geoOf(from), geoOf(to)], { duration: M_CLOSE, easing: M_EASE, fill: "forwards" });
      shrink.onfinish = function () {
        svg.style.visibility = "";
        ov.remove();
        morphDone();
      };
    };
  }

  function select(id) {
    var prev = state.active;
    state.active = id;
    var grid = $("lib-grid");
    if (!grid) return;
    var cards = grid.querySelectorAll(".lib-card");
    for (var i = 0; i < cards.length; i++) {
      var cid = cards[i].getAttribute("data-lib-id");
      cards[i].classList.toggle("active", cid === id);
      if (cid === prev && prev !== id) { state.active = null; play(cards[i], false); state.active = id; }
      if (cid === id) play(cards[i], true);
    }
  }

  /* ── move a preset to another folder ───────────────────────────── */
  var moveMenu = null;
  function closeMoveMenu() { if (moveMenu) { moveMenu.remove(); moveMenu = null; } }
  function openMoveMenu(p, btn) {
    closeMoveMenu();
    var targets = state.folders.filter(function (F) { return !F.builtin && F.id !== p.folder; });
    if (!targets.length) { toast("Create another folder first", true); return; }
    moveMenu = document.createElement("div");
    moveMenu.className = "lib-move-menu";
    var html = '<div class="lib-move-title">Move to</div>';
    for (var i = 0; i < targets.length; i++) {
      html += '<button type="button" class="lib-move-item" data-move="' + esc(targets[i].id) + '">' +
        '<span class="lib-move-icon">' + folderSvg(targets[i].color) + "</span><span>" + esc(targets[i].name) + "</span></button>";
    }
    moveMenu.innerHTML = html;
    var card = btn.closest(".lib-card");
    card.appendChild(moveMenu);
    moveMenu.addEventListener("click", function (ev) {
      ev.stopPropagation();
      var it = ev.target.closest ? ev.target.closest("[data-move]") : null;
      if (!it) return;
      var F = folderById(it.getAttribute("data-move"));
      p.folder = F.id;
      store(p);
      closeMoveMenu();
      renderGrid();
      toast("Moved to “" + F.name + "”");
    });
  }

  /* ── actions ───────────────────────────────────────────────────── */
  function detectAnchor(p) {
    /* entrance (fades / grows in) — the animation should end where the
       layer is; anything else starts there */
    for (var i = 0; i < p.props.length; i++) {
      var P = p.props[i], m = lastM(P), ks = P.keys;
      if (!ks || ks.length < 2) continue;
      var a = ks[0].v, z = ks[ks.length - 1].v;
      if (m === "ADBE Opacity") return a < z ? "last" : "first";
      if (m === "ADBE Scale") return a[0] < z[0] ? "last" : "first";
    }
    return "first";
  }

  var saveMode = "anim";
  var SAVE_TEXT = {
    anim: { btn: "Save Animation", hint: "Keyframes of the selected layer (only the selected keys, if any) \u2014 apply them to any layer." },
    layers: { btn: "Save Layers", hint: "All selected layers with everything on them: effects and their settings, masks, shapes, text, keyframes, blending, mattes. Apply rebuilds them at the playhead \u2014 transitions, color grades." }
  };
  function paintSaveMode() {
    var bs = document.querySelectorAll("#lib-save-mode [data-save]");
    for (var i = 0; i < bs.length; i++) bs[i].classList.toggle("active", bs[i].getAttribute("data-save") === saveMode);
    var lb = $("btn-lib-save-label"), h = $("lib-save-hint");
    if (lb) lb.textContent = SAVE_TEXT[saveMode].btn;
    if (h) h.textContent = SAVE_TEXT[saveMode].hint;
  }

  function saveFromSelection() {
    var F = folderById(state.view);
    if (!F || F.builtin) return;
    var layersMode = saveMode === "layers";
    host(layersMode ? "pillowLibCaptureLayers()" : "pillowLibCapture()", function (r) {
      if (!r || !r.ok || !r.preset) { toast((r && r.error) || "Could not read the layer", true); return; }
      var p = r.preset;
      var nameEl = $("lib-name"), authorEl = $("lib-author");
      p.id = newId();
      p.folder = F.id;
      p.name = (nameEl && nameEl.value.trim()) || (p.layer && p.layer.name) || "My animation";
      p.author = (authorEl && authorEl.value.trim()) || "";
      p.created = Date.now();
      if (!layersMode) p.anchor = detectAnchor(p);
      try { window.localStorage.setItem(AUTHOR_KEY, p.author); } catch (e) {}
      state.presets.unshift(p);
      store(p);
      if (nameEl) nameEl.value = "";
      state.filter = ""; if ($("lib-filter")) $("lib-filter").value = "";
      state.active = p.id;
      renderGrid();
      var pm = $("lib-prev-mode") ? $("lib-prev-mode").value : "auto";
      if (pm === "none") { toast("Saved “" + p.name + "” to " + F.name); return; }
      toast("Saved “" + p.name + "” · making the preview…");
      makeThumb(p, pm, function (ok, err) {
        toast(ok ? "Saved “" + p.name + "” with a preview" : "Saved “" + p.name + "” · no preview: " + err, !ok);
      });
    });
  }

  /* ── previews made of the layers themselves ───────────────────────
   * The host solos the selected layers (plus Pillow's demo scene under
   * adjustment layers / blending modes, or a demo picture for a colour
   * grade) and saves frames; here they become one small sprite strip:
   * cropped to what is actually drawn (plain layers), scaled into a
   * 320×200 cell, encoded as WebP and kept with the preset.
   * "As in the project" (frame, the default) is the comp exactly as it
   * looks in After Effects: nothing soloed or cropped, the comp's own
   * background under it, ~15 frames a second of the animation. The
   * frames sit in a grid (8 a row), not one long strip, so a long
   * preview stays within the image size limits. */
  var THUMB_W = 320, THUMB_H = 200, THUMB_FPS = 15, THUMB_MAX = 48, THUMB_COLS = 8;
  function fileUrl(path) {
    var u = String(path).replace(/\\/g, "/");
    if (!/^\//.test(u)) u = "/" + u;
    return "file://" + encodeURI(u) + "?v=" + Date.now();
  }
  /* saveFrameToPng may still be writing: retry until the PNG decodes */
  function loadFrame(path, timeout) {
    var until = Date.now() + (timeout || 25000);
    return new Promise(function (res, rej) {
      (function attempt() {
        var img = new Image();
        img.onload = function () { if (img.naturalWidth) res(img); else retry(); };
        img.onerror = retry;
        img.src = fileUrl(path);
        function retry() { if (Date.now() > until) rej(new Error("AE didn't render the frames")); else setTimeout(attempt, 180); }
      })();
    });
  }
  function badgeFor(r) {
    var all = (r.effects || []).join(" ");
    if (r.kind === "grade") return "Grade";
    if (/glitch|rgb|chromatic|split|displacement|channel shift|block|scan ?line|digital|vhs|datamosh/i.test(all)) return "Glitch";
    if (r.wiggle || /shake|wiggle|jitter/i.test(all)) return "Shake";
    if (/zoom|bulge|spherize|lens|optics/i.test(all) || (r.adjust && r.scaleKeys)) return "Zoom";
    if (/blur|defocus|bokeh/i.test(all)) return "Blur";
    if (/flash|exposure|glow|light ?leak|brightness/i.test(all)) return "Flash";
    if (r.kind === "demo") return "FX";
    return "";
  }
  function bboxOf(imgs) {
    var cw = Math.min(320, imgs[0].naturalWidth), ch = Math.round(cw * imgs[0].naturalHeight / imgs[0].naturalWidth);
    var c = document.createElement("canvas"); c.width = cw; c.height = ch;
    var x = c.getContext("2d"), L = cw, T = ch, R = -1, B = -1, best = 0, bestI = 0;
    for (var i = 0; i < imgs.length; i++) {
      x.clearRect(0, 0, cw, ch);
      x.drawImage(imgs[i], 0, 0, cw, ch);
      var d = x.getImageData(0, 0, cw, ch).data, cover = 0;
      for (var yy = 0; yy < ch; yy++) for (var xx = 0; xx < cw; xx++) {
        if (d[(yy * cw + xx) * 4 + 3] > 10) {
          cover++;
          if (xx < L) L = xx; if (xx > R) R = xx; if (yy < T) T = yy; if (yy > B) B = yy;
        }
      }
      if (cover > best) { best = cover; bestI = i; }
    }
    if (R < 0) return { x: 0, y: 0, w: 1, h: 1, rest: 0 };
    var k = imgs[0].naturalWidth / cw;
    var bw = (R - L + 1) * k, bh = (B - T + 1) * k, pad = Math.max(bw, bh) * 0.1 + 4 * k;
    var X = Math.max(0, L * k - pad), Y = Math.max(0, T * k - pad);
    var W = Math.min(imgs[0].naturalWidth - X, bw + pad * 2), H = Math.min(imgs[0].naturalHeight - Y, bh + pad * 2);
    return { x: X / imgs[0].naturalWidth, y: Y / imgs[0].naturalHeight, w: W / imgs[0].naturalWidth, h: H / imgs[0].naturalHeight, rest: bestI };
  }
  function strip(imgs, crop, bg) {
    var iw = imgs[0].naturalWidth, ih = imgs[0].naturalHeight;
    var sw = crop.w * iw, sh = crop.h * ih, sc = Math.min(THUMB_W / sw, THUMB_H / sh, 1);
    var cw = Math.max(8, Math.round(sw * sc)), ch = Math.max(8, Math.round(sh * sc));
    var cols = Math.min(imgs.length, THUMB_COLS), rows = Math.ceil(imgs.length / cols);
    var c = document.createElement("canvas"); c.width = cw * cols; c.height = ch * rows;
    var x = c.getContext("2d");
    x.imageSmoothingQuality = "high";
    if (bg) {
      x.fillStyle = "rgb(" + Math.round(bg[0] * 255) + "," + Math.round(bg[1] * 255) + "," + Math.round(bg[2] * 255) + ")";
      x.fillRect(0, 0, c.width, c.height);
    }
    for (var i = 0; i < imgs.length; i++) x.drawImage(imgs[i], crop.x * iw, crop.y * ih, sw, sh, (i % cols) * cw, Math.floor(i / cols) * ch, cw, ch);
    var data = c.toDataURL("image/webp", 0.86);
    if (data.indexOf("data:image/webp") !== 0) data = c.toDataURL("image/png");
    return { data: data, cw: cw, ch: ch, cols: cols, rows: rows };
  }
  var thumbBusy = false;
  function makeThumb(p, mode, done) {
    if (thumbBusy) { done(false, "another preview is being made"); return; }
    thumbBusy = true;
    markBusy(p, true);
    var finish = function (ok, err) {
      thumbBusy = false;
      markBusy(p, false);
      if (ok) { store(p); renderGrid(); }
      done(ok, err);
    };
    host('pillowThumbBegin("' + encodeURIComponent(JSON.stringify({ mode: mode || "frame", fps: THUMB_FPS, max: THUMB_MAX })).replace(/'/g, "%27") + '")', function (r) {
      if (!r || !r.ok) { finish(false, (r && r.error) || "AE didn't answer"); return; }
      var tok = r.token;
      var end = function () { host('pillowThumbEnd("' + tok + '")', function () {}); };
      Promise.all(r.files.map(function (f) { return loadFrame(f); })).then(function (imgs) {
        if (r.kind === "grade") {
          return new Promise(function (res, rej) {
            host('pillowThumbBefore("' + tok + '")', function (b) {
              if (!b || !b.ok) { rej(new Error((b && b.error) || "no before frame")); return; }
              loadFrame(b.file).then(function (before) {
                var full = { x: 0, y: 0, w: 1, h: 1 };
                var after = strip(imgs, full), pre = strip([before], full);
                p.thumb = { kind: "grade", n: 1, cw: after.cw, ch: after.ch, dur: 2.4, data: after.data, before: pre.data, badge: "Grade", rest: 0 };
                res();
              }, rej);
            });
          });
        }
        var crop = r.kind === "layers" ? bboxOf(imgs) : { x: 0, y: 0, w: 1, h: 1, rest: Math.floor(imgs.length / 2) };
        /* the comp's own background under the frame, as in the viewer */
        var st = strip(imgs, crop, r.kind === "frame" ? r.bg : null);
        p.thumb = { kind: r.kind, n: imgs.length, cw: st.cw, ch: st.ch, cols: st.cols, rows: st.rows, dur: r.dur, data: st.data, badge: r.kind === "frame" ? "" : badgeFor(r), rest: crop.rest || 0 };
      }).then(function () { end(); finish(true); }, function (e) { end(); finish(false, e && e.message ? e.message : "failed"); });
    });
  }
  function remakeThumb(p) {
    if (p.builtin) return;
    var pm = $("lib-prev-mode") ? $("lib-prev-mode").value : "auto";
    toast("Making the preview of “" + p.name + "” from the selected layers…");
    makeThumb(p, pm === "none" ? "frame" : pm, function (ok, err) {
      toast(ok ? "Preview of “" + p.name + "” updated" : "No preview: " + err, !ok);
    });
  }
  function markBusy(p, on) {
    var card = $("lib-grid") && $("lib-grid").querySelector('.lib-card[data-lib-id="' + p.id + '"]');
    if (card) card.classList.toggle("lib-busy", on);
  }
  function thumbMarkup(p) {
    var T = p.thumb;
    return '<span class="lib-obj lib-thumb lib-thumb-' + esc(T.kind) + '" data-thumb="' + esc(p.id) + '" style="aspect-ratio:' + T.cw + " / " + T.ch + '">' +
      (T.kind === "grade" ? '<i class="lib-thumb-before"></i><i class="lib-thumb-line"></i>' : "") + "</span>" +
      (T.badge ? '<span class="lib-badge">' + esc(T.badge) + "</span>" : "");
  }
  /* A preview's picture as a blob: URL, made once per picture. The same
     URL on a rebuilt card hits the image cache already decoded; a data:
     URL of a big sprite was decoded again on every rebuild of the grid,
     and the cards blinked empty meanwhile (adding a preset, filtering). */
  var thumbUrls = {};
  function thumbUrl(data) {
    if (!data || data.indexOf("data:") !== 0 || !window.Blob || !window.URL || !URL.createObjectURL) return data;
    var key = data.length + ":" + data.slice(-48);
    if (thumbUrls[key]) return thumbUrls[key];
    try {
      var comma = data.indexOf(","), meta = data.slice(5, comma), bin = atob(data.slice(comma + 1));
      var arr = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      return (thumbUrls[key] = URL.createObjectURL(new Blob([arr], { type: meta.split(";")[0] })));
    } catch (e) { return data; }
  }
  function dressThumbs(root) {
    var els = root.querySelectorAll(".lib-thumb[data-thumb]");
    for (var i = 0; i < els.length; i++) {
      var p = byId(els[i].getAttribute("data-thumb"));
      if (!p || !p.thumb) continue;
      els[i].style.backgroundImage = "url(" + thumbUrl(p.thumb.data) + ")";
      var tc = p.thumb.cols || p.thumb.n, tr = p.thumb.rows || 1;
      els[i].style.backgroundSize = (tc * 100) + "% " + (tr * 100) + "%";
      var b = els[i].querySelector(".lib-thumb-before");
      if (b && p.thumb.before) b.style.backgroundImage = "url(" + thumbUrl(p.thumb.before) + ")";
    }
  }
  function paintThumb(obj, p, t) {
    var T = p.thumb, D = durationOf(p);
    if (T.kind === "grade") {
      /* the "before" side sweeps across and back */
      var u = 0.5 - 0.42 * Math.cos(Math.min(1, t / D) * Math.PI * 2);
      var b = obj.querySelector(".lib-thumb-before"), ln = obj.querySelector(".lib-thumb-line");
      if (b) b.style.clipPath = "inset(0 " + ((1 - u) * 100).toFixed(2) + "% 0 0)";
      if (ln) ln.style.left = (u * 100).toFixed(2) + "%";
      return;
    }
    var n = T.n, i = n > 1 ? Math.max(0, Math.min(n - 1, Math.round(t / D * (n - 1)))) : 0;
    /* a grid of frames (newer previews) or one strip (older ones) */
    var cols = T.cols || n, rows = T.rows || 1, col = i % cols, row = Math.floor(i / cols);
    obj.style.backgroundPosition = (cols > 1 ? col / (cols - 1) * 100 : 0).toFixed(3) + "% " + (rows > 1 ? row / (rows - 1) * 100 : 0).toFixed(3) + "%";
  }

  function apply(p) {
    /* the preview strip stays here: AE does not need it */
    var send = clean(p);
    delete send.thumb;
    var payload = encodeURIComponent(JSON.stringify(send));
    if (p.kind === "layers") {
      host('pillowLibApplyLayers("' + payload + '")', function (r) {
        if (!r || !r.ok) { toast((r && r.error) || "Failed", true); return; }
        /* an older preset learned its precomps: keep them in it */
        if (r.upgrade && r.upgrade.comps && !p.builtin) {
          p.comps = p.comps || {};
          for (var ck in r.upgrade.comps) if (r.upgrade.comps.hasOwnProperty(ck)) p.comps[ck] = r.upgrade.comps[ck];
          for (var li in r.upgrade.pcs) if (r.upgrade.pcs.hasOwnProperty(li) && p.layers[li]) p.layers[li].pc = r.upgrade.pcs[li];
          store(p);
        }
        var warn = (r.missing && r.missing.length) ? " \u00b7 not installed: " + r.missing.join(", ") :
          (r.notes && r.notes.length) ? " \u00b7 " + r.notes.join(", ") : "";
        toast(p.name + " \u00b7 " + plural(r.count, "layer") + " added" + (r.comps ? " \u00b7 " + plural(r.comps, "precomp") + " rebuilt" : "") + warn, !!warn);
      });
      return;
    }
    host('pillowLibApply("' + payload + '")', function (r) {
      if (r && r.ok) toast(p.name + " applied" + (r.count > 1 ? " to " + r.count + " layers" : "") + (r.skipped ? " · " + r.skipped + " skipped" : ""));
      else toast((r && r.error) || "Failed", true);
    });
  }

  function exportPreset(p) {
    var out = clean(p);
    delete out.folder;
    host('pillowLibExport("' + encodeURIComponent(JSON.stringify(out, null, 1)) + '")', function (r) {
      if (r && r.ok) toast("Exported “" + p.name + "”");
      else if (r && !r.cancelled) toast(r.error || "Export failed", true);
    });
  }

  function importPresets() {
    var F = folderById(state.view);
    if (!F || F.builtin) return;
    host("pillowLibImport()", function (r) {
      if (!r || !r.ok) { if (r && !r.cancelled) toast(r.error || "Import failed", true); return; }
      var added = 0, first = null;
      for (var i = 0; i < (r.files || []).length; i++) {
        var p = null;
        try { p = parse(decodeURIComponent(r.files[i])); } catch (e) {}
        if (!p) continue;
        p.id = newId();
        delete p._file;
        p.folder = F.id;
        p.name = p.name || "Imported";
        p.created = Date.now() + added;
        state.presets.unshift(p);
        store(p);
        added++; first = first || p.id;
      }
      if (!added) { toast("No Pillow presets in the selected files", true); return; }
      state.active = first;
      renderGrid();
      toast("Imported " + plural(added, "preset") + " to " + F.name);
    });
  }

  function removePreset(p) {
    if (p.builtin) return;
    state.presets = state.presets.filter(function (x) { return x !== p; });
    unstore(p);
    if (state.active === p.id) state.active = null;
    renderGrid();
    toast("Deleted “" + p.name + "”");
  }

  /* ── wiring ────────────────────────────────────────────────────── */
  function init() {
    var grid = $("lib-grid");
    if (!grid) return;
    /* one shared vertical sheen for every folder front */
    if (!document.getElementById("lib-f-defs")) {
      var defs = document.createElement("div");
      defs.id = "lib-f-defs";
      defs.style.cssText = "position:absolute;width:0;height:0;overflow:hidden";
      defs.innerHTML = '<svg width="0" height="0" aria-hidden="true"><defs><linearGradient id="lib-f-sheen" x1="0" y1="0" x2="0" y2="1">' +
        '<stop offset="0" stop-color="#fff" stop-opacity="0.30"/><stop offset="0.55" stop-color="#fff" stop-opacity="0.04"/>' +
        '<stop offset="1" stop-color="#000" stop-opacity="0.06"/></linearGradient></defs></svg>';
      document.body.appendChild(defs);
    }
    state.folders = [{ id: BUILTIN_FOLDER, name: "Pillow Presets", color: "blue", builtin: true }].concat(loadFolders());
    var user = loadUser().sort(function (a, b) { return (b.created || 0) - (a.created || 0); });
    /* presets without a (known) folder — e.g. saved before folders
       existed — go to "My Animations" */
    var orphan = user.filter(function (p) { return !p.folder || !folderById(p.folder); });
    if (orphan.length || state.folders.length === 1) {
      var mine = null;
      for (var i = 0; i < state.folders.length; i++) if (state.folders[i].name === "My Animations" && !state.folders[i].builtin) mine = state.folders[i];
      if (!mine) { mine = { id: "fmine", name: "My Animations", color: "yellow", created: 1 }; if (folderById("fmine")) mine.id = "f" + newId(); state.folders.push(mine); storeFolders(); }
      for (var o = 0; o < orphan.length; o++) { orphan[o].folder = mine.id; store(orphan[o]); }
    }
    state.presets = user.concat(BUILTIN);
    try { var au = window.localStorage.getItem(AUTHOR_KEY); if (au && $("lib-author")) $("lib-author").value = au; } catch (e) {}

    $("lib-folders").addEventListener("click", function (ev) {
      var t = ev.target.closest ? ev.target.closest("[data-folder],[data-folder-new]") : null;
      if (!t) return;
      if (t.hasAttribute("data-folder-new")) openEditor(null);
      else openFolder(t.getAttribute("data-folder"), t);
    });
    /* hovering a folder builds its view ahead (see stage) */
    $("lib-folders").addEventListener("mouseover", function (ev) {
      var t = ev.target.closest ? ev.target.closest("[data-folder]") : null;
      if (t && !morphing && !state.view) stage(t.getAttribute("data-folder"));
    });
    $("lib-folders").addEventListener("contextmenu", function (ev) {
      var t = ev.target.closest ? ev.target.closest("[data-folder]") : null;
      var F = t && folderById(t.getAttribute("data-folder"));
      if (!F || F.builtin) return;
      ev.preventDefault();
      openEditor(F);
    });
    $("lib-folder-head").addEventListener("click", function (ev) {
      var t = ev.target.closest ? ev.target.closest("[data-nav]") : null;
      if (!t) return;
      if (t.getAttribute("data-nav") === "back") closeFolder();
      else if (state.editing) closeEditor();
      else openEditor(folderById(state.view));
    });
    var eds = ["lib-root-editor", "lib-folder-editor"];
    for (var e = 0; e < eds.length; e++) {
      $(eds[e]).addEventListener("click", editorClick);
      $(eds[e]).addEventListener("keydown", editorKey);
    }

    grid.addEventListener("click", function (ev) {
      var card = ev.target.closest ? ev.target.closest(".lib-card") : null;
      if (!card) return;
      if (ev.target.closest(".lib-move-menu")) return;
      var p = byId(card.getAttribute("data-lib-id"));
      if (!p) return;
      var btn = ev.target.closest("[data-act]");
      var act = btn ? btn.getAttribute("data-act") : "";
      if (act !== "move") closeMoveMenu();
      if (act === "apply") apply(p);
      else if (act === "export") exportPreset(p);
      else if (act === "code") { if (window.PillowNotch) window.PillowNotch.share(p); }
      else if (act === "thumb") { remakeThumb(p); return; }
      else if (act === "delete") { removePreset(p); return; }
      else if (act === "move") { if (moveMenu && moveMenu.parentNode === card) closeMoveMenu(); else openMoveMenu(p, btn); }
      select(p.id);
    });
    grid.addEventListener("dblclick", function (ev) {
      if (ev.target.closest && ev.target.closest("[data-act], .lib-move-menu")) return;
      var card = ev.target.closest ? ev.target.closest(".lib-card") : null;
      var p = card && byId(card.getAttribute("data-lib-id"));
      if (p) apply(p);
    });
    grid.addEventListener("mouseover", function (ev) {
      var card = ev.target.closest ? ev.target.closest(".lib-card") : null;
      if (card && !card.contains(ev.relatedTarget)) play(card, true);
    });
    grid.addEventListener("mouseout", function (ev) {
      var card = ev.target.closest ? ev.target.closest(".lib-card") : null;
      if (card && !card.contains(ev.relatedTarget)) play(card, false);
    });
    document.addEventListener("click", function (ev) {
      if (moveMenu && !(ev.target.closest && ev.target.closest(".lib-move-menu, [data-act='move']"))) closeMoveMenu();
    });
    if ($("btn-lib-save")) $("btn-lib-save").onclick = saveFromSelection;
    if ($("lib-save-mode")) $("lib-save-mode").addEventListener("click", function (ev) {
      var b = ev.target.closest ? ev.target.closest("[data-save]") : null;
      if (!b) return;
      saveMode = b.getAttribute("data-save");
      paintSaveMode();
    });
    paintSaveMode();
    if ($("btn-lib-import")) $("btn-lib-import").onclick = importPresets;
    if ($("lib-filter")) $("lib-filter").addEventListener("input", function () { state.filter = this.value.trim(); filter(true); });
    renderView();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();

  window.PillowLibrary = {
    resume: function () { state.resumed = true; if (!raf) raf = requestAnimationFrame(tick); },
    pause: function () { state.resumed = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
    list: function () { return state.presets.slice(0); },
    folders: function () { return state.folders.slice(0); },
    open: function (id) { showView(id); },
    /* a preset that came as a code: into folder fid (or My Animations) */
    add: function (p, fid) {
      var F = folderById(fid);
      if (!F || F.builtin) {
        F = null;
        for (var i = 0; i < state.folders.length; i++) if (!state.folders[i].builtin) { F = state.folders[i]; break; }
        if (!F) { F = { id: "f" + newId(), name: "My Animations", color: "yellow", created: Date.now() }; state.folders.push(F); storeFolders(); }
      }
      p.id = newId();
      delete p._file;
      p.folder = F.id;
      p.name = p.name || "Shared preset";
      p.created = Date.now();
      state.presets.unshift(p);
      store(p);
      state.active = p.id;
      if (state.view === F.id) renderGrid();
      else if (!state.view) renderView();
      return p;
    },
    _eval: valueAt,
    _frame: frame
  };
})();
