/* Pillow — Morph (the first tab of the notch)
 *
 * Text: a word on a canvas whose letters swell where the pointer is (in
 * After Effects the pointer is the "Morph (Pillow)" null). Each letter is
 * drawn with a round stroke in its own colour, as the host's text animator
 * does (Stroke Width + Scale under an Expression Selector).
 * Apply → host pillowTextMorph(json).
 *
 * Layers: a column of cards scrolls past the null; the ones over it grow
 * and shrink back evenly as they leave, the rest making room — the very
 * formulas of the host's Scale / Anchor Point expressions.
 * Apply → host pillowLayerMorph(json).
 */
(function () {
  "use strict";
  if (window.PillowMorph) return;

  var o = { kind: "text", inflate: 60, grow: 12, radius: 70, word: "Morph", lgrow: 60, lradius: 120, push: 100 };
  var raf = 0, on = false, ptr = null, cur = null, t0 = 0, bound = false;
  /* the pointer left the stage at leftAt (s); lastT — the previous frame */
  var leftAt = -1e9, lastT = 0, nowT = 0;
  function $(id) { return document.getElementById(id); }
  function load() { try { var d = JSON.parse(localStorage.getItem("pillow.morph") || "null"); if (d) for (var k in o) if (typeof d[k] === typeof o[k]) o[k] = d[k]; } catch (e) {} if (o.word === "Inflate") o.word = "Morph"; if (o.kind !== "layers") o.kind = "text"; }
  function save() { try { localStorage.setItem("pillow.morph", JSON.stringify(o)); } catch (e) {} }

  function smooth(k) { k = Math.max(0, Math.min(1, k)); return k * k * (3 - 2 * k); }

  /* the null: the pointer (quick), or — when the pointer is away — the
     given idle spot, slowly. Once the pointer leaves, the null drifts back
     to the middle first and its idle sweep grows in from nothing (idleAmp),
     instead of snapping back into the sweep. */
  function idleAmp() {
    var since = nowT - leftAt - 0.7;
    return since <= 0 ? 0 : smooth(since / 2.2);
  }
  function idlePhase() { return Math.max(0, nowT - leftAt - 0.7); }
  function follow(nx, ny) {
    var dt = lastT ? Math.min(0.05, nowT - lastT) : 1 / 60;
    var rate = ptr ? 15 : 2.4;
    if (ptr) { nx = ptr[0]; ny = ptr[1]; }
    if (!cur) cur = [nx, ny];
    var a = 1 - Math.exp(-rate * dt);
    cur[0] += (nx - cur[0]) * a; cur[1] += (ny - cur[1]) * a;
  }
  function drawNull(ctx) {
    ctx.strokeStyle = "rgba(255,80,90,0.9)";
    ctx.lineWidth = 1;
    ctx.strokeRect(cur[0] - 6, cur[1] - 6, 12, 12);
  }

  function drawText(ctx, W, H, t, ink) {
    var word = o.word || "Morph", size = Math.min(H * 0.5, W / Math.max(3, word.length) * 1.5);
    var font = "300 " + size + "px system-ui, -apple-system, 'Segoe UI', sans-serif";
    ctx.font = font;
    var widths = [], total = 0, i;
    for (i = 0; i < word.length; i++) { widths.push(ctx.measureText(word[i]).width); total += widths[i]; }
    var x = (W - total) / 2, y = H / 2 + size * 0.34;
    /* the idle sweep along the word, from the middle, growing in */
    var s = 0.5 + 0.5 * Math.sin(idlePhase() * 0.9) * idleAmp();
    follow((W - total) / 2 + s * total, H / 2);
    /* the very numbers the host puts on the null, in the text's own units
       (S = font size), and the very formulas of its expressions */
    var S = size, INF = o.inflate / 100 * S * 0.2, GROW = o.grow, RAD = o.radius / 100 * S * 2.2, SOFT = 0.6;
    var lefts = [], acc = x, n = word.length;
    for (i = 0; i < n; i++) { lefts.push(acc); acc += widths[i]; }
    var ks = [], ex = [], tot = 0;
    for (i = 0; i < n; i++) {
      var cx = lefts[i] + widths[i] / 2;
      var d = Math.sqrt((cx - cur[0]) * (cx - cur[0]) + (H / 2 - cur[1]) * (H / 2 - cur[1]));
      var k = smooth((RAD - d) / (RAD * SOFT));
      ks.push(k);
      /* the room this letter takes when swollen — the host's
         "Pillow Morph Spacing" selector, same formula */
      var e = (widths[i] + INF * k) * (1 + GROW / 100 * k) - widths[i];
      ex.push(e); tot += e;
    }
    var before = 0;
    for (i = 0; i < n; i++) {
      var k2 = ks[i], g = 1 + GROW / 100 * k2;
      var cx2 = lefts[i] + widths[i] / 2 + before + ex[i] / 2 - tot / 2;
      before += ex[i];
      ctx.save();
      ctx.translate(cx2, y - size * 0.34);
      ctx.scale(g, g);
      ctx.font = font;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.lineJoin = "round";
      ctx.lineCap = "round";
      ctx.fillStyle = ink;
      ctx.strokeStyle = ink;
      if (k2 > 0.01) { ctx.lineWidth = INF * k2; ctx.strokeText(word[i], 0, 0); }
      ctx.fillText(word[i], 0, 0);
      ctx.restore();
    }
    drawNull(ctx);
  }

  function rr(ctx, x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  /* a column of cards scrolling up through the stage, as in a list */
  function drawLayers(ctx, W, H, t, ink, light) {
    var ch = Math.round(H * 0.17), cw = Math.round(ch * 2.6), gap = Math.round(ch * 0.55), pitch = ch + gap;
    var n = Math.ceil(H / pitch) + 4, scroll = ((t - t0) * ch * 0.9) % pitch, first = Math.floor((t - t0) * ch * 0.9 / pitch);
    follow(W / 2, H / 2);
    var G = o.lgrow / 100, R = o.lradius / 100 * ch, PU = o.push / 100;
    var cs = [], ks = [], i;
    for (i = 0; i < n; i++) {
      var cy = H / 2 + (i - n / 2) * pitch - scroll + pitch / 2;
      cs.push(cy);
      var dx = cur[0] - W / 2, dy = cur[1] - cy;
      /* Softness 100: the falloff runs from the null's centre out to Radius */
      ks.push(smooth(1 - Math.sqrt(dx * dx + dy * dy) / R));
    }
    var tones = light ? ["#16151a", "#6e6b75", "#b9b6bf"] : ["#f4f2f6", "#9d99a6", "#5d5a64"];
    for (i = 0; i < n; i++) {
      var sh = 0;
      for (var j = 0; j < n; j++) { if (j === i) continue; var e = ch * G * ks[j] * PU / 2; if (cs[j] < cs[i]) sh += e; else if (cs[j] > cs[i]) sh -= e; }
      var f = 1 + G * ks[i], w = cw * f, h = ch * f, x = W / 2 - w / 2, y = cs[i] + sh - h / 2;
      var id = ((first + i) % 3 + 3) % 3;
      ctx.fillStyle = tones[id];
      rr(ctx, x, y, w, h, h * 0.32);
      ctx.fill();
      /* a little row content, so it reads as a list item */
      ctx.fillStyle = light ? "rgba(255,255,255,0.75)" : "rgba(0,0,0,0.35)";
      ctx.beginPath(); ctx.arc(x + h * 0.5, y + h / 2, h * 0.2, 0, Math.PI * 2); ctx.fill();
      rr(ctx, x + h * 0.9, y + h * 0.36, w * 0.42, h * 0.12, h * 0.06); ctx.fill();
      rr(ctx, x + h * 0.9, y + h * 0.56, w * 0.26, h * 0.1, h * 0.05); ctx.fill();
    }
    drawNull(ctx);
  }

  function wakeFrame() { if (on && !raf) raf = requestAnimationFrame(frame); }
  function frame(now) {
    var cv = $("nt-morph-stage");
    if (!on || !cv || !cv.offsetParent) { raf = 0; return; }
    /* asleep while nobody looks at the panel (js/presence.js) */
    if (window.PillowPresence && !window.PillowPresence.awake()) { raf = 0; window.PillowPresence.onWake(wakeFrame); return; }
    var dpr = Math.min(2, window.devicePixelRatio || 1), W = cv.clientWidth, H = cv.clientHeight;
    if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
    var ctx = cv.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    var t = now / 1000;
    if (!t0) t0 = t;
    nowT = t;
    var light = document.documentElement.getAttribute("data-theme") === "light";
    var ink = light ? "#16151a" : "#f4f2f6";
    if (o.kind === "layers") drawLayers(ctx, W, H, t, ink, light); else drawText(ctx, W, H, t, ink);
    lastT = t;
    raf = requestAnimationFrame(frame);
  }

  function paint() {
    var ks = document.querySelectorAll("#nt-morph-kind [data-morph-kind]"), i;
    for (i = 0; i < ks.length; i++) ks[i].classList.toggle("active", ks[i].getAttribute("data-morph-kind") === o.kind);
    var sets = document.querySelectorAll("[data-morph-for]");
    for (i = 0; i < sets.length; i++) sets[i].hidden = sets[i].getAttribute("data-morph-for") !== o.kind;
    $("nt-morph-word").hidden = o.kind !== "text";
    $("nt-morph-stage").classList.toggle("is-layers", o.kind === "layers");
    $("nt-morph-stage").setAttribute("aria-label", o.kind === "layers" ? "Morph preview — the layers over the null grow" : "Morph preview — move the pointer over the word");
    $("nt-morph-apply-l").textContent = o.kind === "layers" ? "Morph Layers" : "Morph Text";
    ["inflate", "grow", "radius", "lgrow", "lradius", "push"].forEach(function (k) { var el = $("nt-morph-" + k); if (el && document.activeElement !== el) el.value = o[k]; });
    var w = $("nt-morph-word"); if (w && document.activeElement !== w) w.value = o.word;
  }
  function plural(n, s) { return n + " " + s + (n > 1 ? "s" : ""); }
  function bind() {
    if (bound || !$("nt-morph-stage")) return;
    bound = true;
    load();
    var cv = $("nt-morph-stage");
    cv.addEventListener("pointermove", function (e) { var r = cv.getBoundingClientRect(); ptr = [e.clientX - r.left, e.clientY - r.top]; });
    cv.addEventListener("pointerleave", function () { ptr = null; leftAt = nowT; });
    $("nt-morph-kind").addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-morph-kind]") : null;
      if (!b || b.getAttribute("data-morph-kind") === o.kind) return;
      o.kind = b.getAttribute("data-morph-kind"); cur = null; t0 = 0; paint(); save();
      if (window.PillowNotch && window.PillowNotch._refit) window.PillowNotch._refit();
    });
    ["inflate", "grow", "radius", "lgrow", "lradius", "push"].forEach(function (k) {
      $("nt-morph-" + k).addEventListener("input", function () { o[k] = parseFloat(this.value); save(); });
    });
    $("nt-morph-word").addEventListener("input", function () { o.word = this.value; save(); });
    $("nt-morph-apply").addEventListener("click", function () {
      if (typeof window.host !== "function") return;
      var layers = o.kind === "layers";
      var pl = JSON.stringify(layers ? { grow: o.lgrow, radius: o.lradius, push: o.push } : { inflate: o.inflate, grow: o.grow, radius: o.radius });
      var fn = layers ? "pillowLayerMorph" : "pillowTextMorph";
      window.host(fn + '("' + pl.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '")', function (r) {
        if (!r || !r.ok) { if (window.toast) window.toast((r && r.error) || (layers ? "Couldn't morph the layers" : "Couldn't morph the text"), true); return; }
        if (window.toast) window.toast((r.build ? "[" + r.build + "] " : "") + "Morph on " + plural(r.count, layers ? "layer" : "text layer") + " · drag “" + r.controller + "” over " + (r.count > 1 ? "them" : "it"));
      });
    });
    $("nt-morph-remove").addEventListener("click", function () {
      if (typeof window.host !== "function") return;
      window.host("pillowTextMorphRemove()", function (r) {
        if (window.toast) window.toast(r && r.ok ? (r.count || r.nulls ? "Morph removed" : "No Pillow morph on the selection") : ((r && r.error) || "Couldn't remove"), !(r && r.ok));
      });
    });
    paint();
  }

  window.PillowMorph = {
    start: function () { bind(); on = true; if (!raf) raf = requestAnimationFrame(frame); },
    stop: function () { on = false; },
    _cur: function () { return cur && cur.slice(); },
    _o: o
  };
})();
