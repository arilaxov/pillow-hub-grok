/* Pillow — Anchor Point
 *
 * The tool tile (#btn-anchor-tool) opens/closes the 3x3 field below the
 * Quick Create grid; each tile sets the selected layer's Anchor Point via
 * host/pillow.jsx:pillowSetAnchor(pos), reusing the same host()/toast()
 * calling convention every other Create tool already uses.
 *
 * The hover morph: each of the 9 tiles is absolutely positioned and owns
 * an independent target width/height, not a shared CSS Grid track. A
 * hovered tile's own row/column gets the full boost; the rest of the
 * field responds through a distance-based falloff (axisWeight) so the
 * effect stays local — direct neighbours shift a little, everything two
 * steps away stays put — instead of the whole row/column moving as one
 * block. For any fixed row the per-tile width deltas still sum to zero
 * (same for every column's height deltas), so the 290x290 field itself
 * never resizes — only the internal tile boundaries shift.
 *
 * All of that geometry is driven by one requestAnimationFrame loop of
 * hand-rolled springs (Euler integration, same shape as the Track/spring
 * motor in js/glass-switch.js and js/glass-tabs.js, just stepping many
 * scalars together instead of one Track each) writing a single
 * `transform: translate() scale()` per tile every frame — never width,
 * height, or grid-template-*, so the browser only has to composite, not
 * lay out, each frame. Base left/top/width/height are set once at init;
 * transform-origin is the tile's own top-left, and the per-frame
 * translate compensates for that so tiles still appear to scale from
 * their own center.
 *
 * Springs (not a CSS transition) because a CSS transition is a
 * fire-and-forget request the browser is free to not honor for a value
 * it doesn't know how to interpolate — and the CEP panel's bundled
 * Chromium in fact didn't, for the grid-track version this replaced.
 * Springs also keep their current position and velocity when the target
 * changes mid-flight, so sweeping across several tiles stays one
 * continuous motion instead of restarting.
 *
 * The click bounce is a per-tile "press" scalar composed into the same
 * loop and the same transform, rather than a separate Web Animations API
 * animation: snap it down on click, let it spring back past 1 and settle
 * (the overshoot is just underdamped spring motion, not a second
 * animation), so pressing a tile can never fight or reset the hover
 * morph that's already in flight on top of it.
 *
 * The active/selected look is a single floating surface (#anchor-active-fill,
 * behind the tiles — see css/panel.css) rather than a class toggled on two
 * different buttons: each tile's own "active" background/ring is gone in
 * this file's skin, so there's only ever one thing on screen that can look
 * selected. Its left/top/width/height spring toward whichever tile is
 * currently active, read straight off that tile's own live w/h/position —
 * the same numbers the morph loop below already computes for painting the
 * tile itself — so the indicator glides smoothly from the old position to
 * the new one on click, and keeps following if the hover morph reshapes
 * the active tile in the meantime, instead of jumping in one frame.
 */
(function () {
  "use strict";

  var LABELS = {
    tl: "Top Left", tc: "Top Center", tr: "Top Right",
    ml: "Middle Left", mc: "Center", mr: "Middle Right",
    bl: "Bottom Left", bc: "Bottom Center", br: "Bottom Right"
  };

  /* a quarter smaller than before (92px), hover morph and corners in step */
  var BASE = 68, GAP = 6, STEP = BASE + GAP, FULL = 15, PARTIAL = 9;
  var W_ADJ = 0.28; // how much a one-step-away row/column still participates

  var MORPH_TENSION = 170, MORPH_FRICTION = 26; // soft, barely-there settle
  var ACTIVE_TENSION = 130, ACTIVE_FRICTION = 25; // slower glide, no overshoot — it should read as sliding into place, not bouncing there
  var PRESS_TENSION = 90, PRESS_FRICTION = 13; // slower than the morph; damping ratio ~0.68 gives a small (~5-7%), clearly-visible-but-controlled settle-overshoot
  var PRESS_DOWN = 0.94;

  /* Раскрытие «жидкой каплей»: кубики выходят из центра поля и
     расплываются по местам. Каждый — своя пружина em 0…1 (0 — в
     центре, сжат до EM_K0; 1 — на месте). Поверх летит SVG-слой с теми
     же формами под фильтром «размытие + порог альфы» — веб-аналог
     Gaussian Blur + Simple Choker из AE: пока формы рядом, они слиты в
     одну каплю, расходясь — рвутся перемычками. Размытие гаснет к концу,
     формы становятся точными кубиками, и настоящие кубики проявляются
     на их месте. Закрытие — то же в обратную сторону. */
  var EM_K0 = 0.12;
  var EM_OPEN_TENSION = 170, EM_OPEN_FRICTION = 18;   /* ζ≈0.69 — лёгкий перелёт */
  var EM_CLOSE_TENSION = 260, EM_CLOSE_FRICTION = 32; /* ζ≈1 — без перелёта */
  /* кольца от центра: центр → стороны → углы */
  var EM_RING = [2, 1, 2, 1, 0, 1, 2, 1, 2];
  var EM_RING_OPEN = 38, EM_RING_CLOSE = 26;
  var GOO_BLUR = 11, GOO_BLUR_MIN = 1.5;
  /* Капля отрывается от кнопки Anchor Point: жидкий слой лежит под
     кнопкой, у её нижнего края — «корень» жидкости; капля вытягивается
     из-под края, перемычка тянется и рвётся (порог альфы делает это сам),
     капля падает к центру поля, чуть пружинит — и уже из неё
     расходятся кубики. Своя пружина dd 0…1. */
  var DROP_OPEN_TENSION = 120, DROP_OPEN_FRICTION = 13;  /* ζ≈0.6 — отскок внизу */
  var DROP_CLOSE_TENSION = 170, DROP_CLOSE_FRICTION = 24;
  var DROP_LEAD = 250;   /* кубики начинают расходиться, когда капля почти внизу */
  var DROP_RETURN = 190; /* при закрытии капля поднимается, когда кубики уже стеклись */
  var PANEL_OPEN_MS = 460, PANEL_CLOSE_MS = 300;
  var PANEL_EASE = "cubic-bezier(0.22, 1, 0.36, 1)";


  function reduceMotion() {
    return !!window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }

  function axisWeight(dist) { return dist === 0 ? 1 : dist === 1 ? W_ADJ : 0; }

  function axisBoost(hr, hc) {
    var midRow = hr === 1, midCol = hc === 1;
    if (midRow && midCol) return { rowBoost: FULL, colBoost: FULL };
    if (midRow) return { rowBoost: FULL, colBoost: 0 };
    if (midCol) return { rowBoost: 0, colBoost: FULL };
    return { rowBoost: PARTIAL, colBoost: PARTIAL };
  }

  /* Per-tile target width/height for hovering (hr, hc), or the neutral
     field when hr is null. Zero-sum per row (width) and per column
     (height) by construction — see file header. */
  function computeTargets(hr, hc) {
    var w = [BASE, BASE, BASE, BASE, BASE, BASE, BASE, BASE, BASE];
    var h = w.slice();
    if (hr === null || hr === undefined) return { w: w, h: h };

    var boost = axisBoost(hr, hc);
    var rowDelta = [0, 0, 0], colDelta = [0, 0, 0];
    var r, c;
    for (r = 0; r < 3; r++) rowDelta[r] = r === hr ? boost.rowBoost : -boost.rowBoost / 2;
    for (c = 0; c < 3; c++) colDelta[c] = c === hc ? boost.colBoost : -boost.colBoost / 2;

    for (r = 0; r < 3; r++) {
      for (c = 0; c < 3; c++) {
        var idx = r * 3 + c;
        var colWeight = axisWeight(Math.abs(c - hc));
        var rowWeight = axisWeight(Math.abs(r - hr));
        h[idx] = BASE + colWeight * rowDelta[r];
        w[idx] = BASE + rowWeight * colDelta[c];
      }
    }
    return { w: w, h: h };
  }

  function init() {
    var toolBtn = document.getElementById("btn-anchor-tool");
    var panel = document.getElementById("anchor-panel");
    var field = document.getElementById("anchor-field");
    var statusEl = document.getElementById("anchor-status-value");
    var fill = document.getElementById("anchor-active-fill");
    if (!toolBtn || !panel || !field) return;

    var tiles = field.querySelectorAll(".anchor-tile");
    var n = tiles.length;

    var baseLeft = new Array(n), baseTop = new Array(n);
    var curW = new Array(n), curH = new Array(n);
    var velW = new Array(n), velH = new Array(n);
    var targetW = new Array(n), targetH = new Array(n);
    var curPress = new Array(n), velPress = new Array(n);
    var left = new Array(n), top = new Array(n);
    var em = new Array(n), emV = new Array(n), emTgt = new Array(n), emAt = new Array(n);
    var emGoal = 0, emTension = EM_OPEN_TENSION, emFriction = EM_OPEN_FRICTION;
    var dd = 0, ddV = 0, ddTgt = 0, ddAt = 0, ddGoal = 0;
    var ddTension = DROP_OPEN_TENSION, ddFriction = DROP_OPEN_FRICTION;
    var plateGeo = null; /* низ и центр кнопки в координатах поля */

    var i, r, c;
    var activeIdx = 4; // "mc" — matches the .anchor-tile.active already in the markup
    for (i = 0; i < n; i++) {
      r = Math.floor(i / 3); c = i % 3;
      baseLeft[i] = c * STEP; baseTop[i] = r * STEP;
      tiles[i].style.left = baseLeft[i] + "px";
      tiles[i].style.top = baseTop[i] + "px";
      tiles[i].style.width = BASE + "px";
      tiles[i].style.height = BASE + "px";
      /* верхний ряд над средним, средний над нижним: при раскрытии ряд
         выезжает из-под того, что над ним */
      tiles[i].style.zIndex = String(3 - r);
      curW[i] = targetW[i] = BASE; curH[i] = targetH[i] = BASE;
      velW[i] = velH[i] = velPress[i] = 0;
      curPress[i] = 1;
      em[i] = emTgt[i] = 0; emV[i] = 0; emAt[i] = 0;
      if (tiles[i].classList.contains("active")) activeIdx = i;
    }

    /* The indicator's own base rect is fixed and arbitrary (transform is
       relative to it, same as every tile) — using the initially-active
       tile's neutral rect just means it starts at translate(0,0) scale(1,1)
       with no set-up jump. */
    var fillBaseLeft = baseLeft[activeIdx], fillBaseTop = baseTop[activeIdx];
    var curFillLeft = fillBaseLeft, curFillTop = fillBaseTop;
    var curFillW = BASE, curFillH = BASE;
    var velFillLeft = 0, velFillTop = 0, velFillW = 0, velFillH = 0;
    if (fill) {
      fill.style.left = fillBaseLeft + "px";
      fill.style.top = fillBaseTop + "px";
      fill.style.width = BASE + "px";
      fill.style.height = BASE + "px";
    }

    function layout() {
      for (r = 0; r < 3; r++) {
        var x = 0;
        for (c = 0; c < 3; c++) { var idx = r * 3 + c; left[idx] = x; x += curW[idx] + GAP; }
      }
      for (c = 0; c < 3; c++) {
        var y = 0;
        for (r = 0; r < 3; r++) { var idx2 = r * 3 + c; top[idx2] = y; y += curH[idx2] + GAP; }
      }
    }

    function smooth(a, b, x) { var t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); }

    /* прямоугольник на месте → с учётом раскрытия e: центр едет из центра
       поля, размер растёт от EM_K0 */
    function emergeRect(x, y, w, h, e) {
      if (e >= 0.9999 && e <= 1.0001) return { x: x, y: y, w: w, h: h };
      var fc = (3 * BASE + 2 * GAP) / 2;
      var k = EM_K0 + (1 - EM_K0) * Math.max(0, e);
      var ww = w * k, hh = h * k;
      var cx = fc + (x + w / 2 - fc) * e, cy = fc + (y + h / 2 - fc) * e;
      return { x: cx - ww / 2, y: cy - hh / 2, w: ww, h: hh };
    }
    function tf(r, bx, by) {
      return "translate(" + (r.x - bx).toFixed(2) + "px," + (r.y - by).toFixed(2) + "px) scale(" +
        (r.w / BASE).toFixed(4) + "," + (r.h / BASE).toFixed(4) + ")";
    }

    /* ── жидкий слой (SVG: blur → порог альфы, как Simple Choker) ── */
    var SVGNS = "http://www.w3.org/2000/svg";
    var goo = document.createElementNS(SVGNS, "svg");
    goo.setAttribute("class", "anchor-goo");
    goo.setAttribute("aria-hidden", "true");
    goo.innerHTML =
      '<defs><filter id="pl-anchor-goo" x="-50%" y="-50%" width="200%" height="200%" color-interpolation-filters="sRGB">' +
      '<feGaussianBlur in="SourceGraphic" stdDeviation="' + GOO_BLUR + '" result="b"/>' +
      /* «чокер»: крутой порог альфы превращает размытую массу в каплю */
      '<feColorMatrix in="b" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 22 -10" result="goo"/>' +
      /* тонкая кромка по контуру капли — как рамка у кубиков */
      '<feMorphology in="goo" operator="erode" radius="1.2" result="er"/>' +
      '<feComposite in="goo" in2="er" operator="out" result="edge"/>' +
      '<feColorMatrix in="edge" mode="matrix" class="goo-rim" values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.16 0" result="rim"/>' +
      '<feMerge><feMergeNode in="goo"/><feMergeNode in="rim"/></feMerge>' +
      '</filter><clipPath id="pl-anchor-goo-clip" clipPathUnits="userSpaceOnUse">' +
      '<rect class="goo-clip" x="-2000" y="0" width="4000" height="4000"/></clipPath></defs>' +
      /* всё выше нижнего края кнопки срезано: капля выходит из её кромки */
      '<g clip-path="url(#pl-anchor-goo-clip)"><g filter="url(#pl-anchor-goo)"></g></g>';
    /* жидкость считается в половинном разрешении: SVG вдвое меньше поля и
       растянут transform'ом — размытие и порог стоят вчетверо дешевле, а
       размытая капля на глаз не теряет чёткости */
    var FIELD = 3 * BASE + 2 * GAP;
    goo.setAttribute("viewBox", "0 0 " + FIELD + " " + FIELD);
    goo.style.width = FIELD / 2 + "px";
    goo.style.height = FIELD / 2 + "px";
    goo.style.transform = "scale(2)";
    goo.style.transformOrigin = "0 0";
    field.appendChild(goo);
    var gooBlur = goo.querySelector("feGaussianBlur");
    var gooG = goo.querySelector("g[filter]");
    var gooClip = goo.querySelector(".goo-clip");
    var gooRects = [];
    var gooStub = document.createElementNS(SVGNS, "rect");
    var gooDrop = document.createElementNS(SVGNS, "ellipse");
    gooG.appendChild(gooStub);
    gooG.appendChild(gooDrop);
    for (i = 0; i < n; i++) {
      var rr = document.createElementNS(SVGNS, "rect");
      gooG.appendChild(rr);
      gooRects.push(rr);
    }
    var gooRim = goo.querySelector(".goo-rim");
    function gooColor() {
      var light = document.documentElement.getAttribute("data-theme") === "light";
      gooRim.setAttribute("values", light
        ? "0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.14 0"
        : "0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.16 0");
      /* the liquid is the squares' own grey (css/minimal.css) */
      return light ? "#e5e5ea" : "#2c2c2e";
    }

    function paint() {
      var eMin = 1, eMax = 0, eSum = 0;
      for (i = 0; i < n; i++) {
        var press = curPress[i];
        var compX = curW[i] * (1 - press) / 2;
        var compY = curH[i] * (1 - press) / 2;
        var e = em[i];
        var r = emergeRect(left[i] + compX, top[i] + compY, curW[i] * press, curH[i] * press, e);
        tiles[i].style.transform = tf(r, baseLeft[i], baseTop[i]);
        /* настоящий кубик проявляется, когда жидкая форма уже стала им */
        tiles[i].style.opacity = String(smooth(0.72, 0.98, e));
        var g = gooRects[i];
        g.setAttribute("x", r.x.toFixed(2)); g.setAttribute("y", r.y.toFixed(2));
        g.setAttribute("width", Math.max(0, r.w).toFixed(2)); g.setAttribute("height", Math.max(0, r.h).toFixed(2));
        g.setAttribute("rx", (16 * r.w / BASE).toFixed(2));
        if (e < eMin) eMin = e;
        if (e > eMax) eMax = e;
        eSum += e;
      }
      /* капля: из-под нижнего края кнопки к центру поля */
      var fc = (3 * BASE + 2 * GAP) / 2;
      if (plateGeo) {
        var t = dd, tc = Math.max(0, Math.min(1, t));
        /* сначала набухает у края и тянет шейку, потом «тяжелеет» и
           срывается вниз — перемычка вытягивается и рвётся */
        var travel = t >= 1 ? t : Math.pow(tc, 1.8);
        var dy0 = plateGeo.bottom - 6;
        var dcx = plateGeo.cx + (fc - plateGeo.cx) * travel;
        var dcy = dy0 + (fc - dy0) * travel;
        var dr = 12 + 20 * smooth(0, 0.55, tc);
        var fall = Math.sin(Math.PI * tc);
        gooDrop.setAttribute("cx", dcx.toFixed(2));
        gooDrop.setAttribute("cy", dcy.toFixed(2));
        /* в падении вытягивается, внизу пружинит (перелёт t>1 — сплющивание) */
        var squash = t > 1 ? (t - 1) * 1.6 : 0;
        gooDrop.setAttribute("rx", (dr * (1 - 0.18 * fall + squash)).toFixed(2));
        gooDrop.setAttribute("ry", (dr * (1 + 0.4 * fall - squash)).toFixed(2));
        /* «корень» под краем кнопки: держит перемычку, после отрыва уходит */
        var sw = plateGeo.w * 0.34 * (1 - smooth(0.55, 0.95, tc));
        gooStub.setAttribute("x", (plateGeo.cx - sw / 2).toFixed(2));
        gooStub.setAttribute("y", (plateGeo.bottom - 22).toFixed(2));
        gooStub.setAttribute("width", Math.max(0, sw).toFixed(2));
        gooStub.setAttribute("height", "20");
        gooStub.setAttribute("rx", "10");
        gooClip.setAttribute("y", (plateGeo.bottom - 0.5).toFixed(2));
      }
      /* жидкий слой: виден, пока капля в пути или кубики не на местах;
         размытие гаснет к концу */
      var gOp = (1 - smooth(0.86, 1, Math.min(eMin, dd))) * smooth(0, 0.06, Math.max(eMax, dd));
      goo.style.opacity = gOp.toFixed(3);
      goo.style.display = gOp > 0.001 ? "" : "none";
      if (gOp > 0.001) {
        var avg = Math.max(0, Math.min(1, eSum / n));
        gooBlur.setAttribute("stdDeviation", (GOO_BLUR_MIN + (GOO_BLUR - GOO_BLUR_MIN) * Math.pow(1 - avg, 1.3)).toFixed(2));
        gooG.setAttribute("fill", gooColor());
      }
      if (fill) {
        var fr = emergeRect(curFillLeft, curFillTop, curFillW, curFillH, em[activeIdx]);
        fill.style.transform = tf(fr, fillBaseLeft, fillBaseTop);
        /* in Liquid Glass the tiles are frosted glass: under them the
           indicator was blurred into a ghost on its way and lost its
           ring, so there it rides on top of the tiles (it is see-through) */
        fill.style.zIndex = document.documentElement.getAttribute("data-pl-glass") === "on"
          ? "6" : String(3 - Math.floor(activeIdx / 3));
        fill.style.opacity = String(smooth(0.72, 0.98, em[activeIdx]));
      }
    }

    var raf = 0, running = false, lastT = -1;

    function step(x, v, target, dt, tension, friction) {
      v += (-tension * (x - target) - friction * v) * dt;
      x += v * dt;
      return [x, v];
    }

    function tick(t) {
      if (lastT < 0) lastT = t;
      var dt = Math.min(Math.max((t - lastT) / 1000, 0), 0.032);
      lastT = t;

      var settled = true;
      var j, res;
      var nowT = window.performance ? performance.now() : Date.now();
      if (nowT >= ddAt) ddTgt = ddGoal;
      res = step(dd, ddV, ddTgt, dt, ddTension, ddFriction);
      dd = res[0]; ddV = res[1];
      if (ddTgt !== ddGoal || Math.abs(dd - ddTgt) > 0.002 || Math.abs(ddV) > 0.002) settled = false;
      if (pendingCollapse && ddGoal === 0 && ddTgt === 0 && dd < 0.3) collapseNow();
      for (j = 0; j < n; j++) {
        if (nowT >= emAt[j]) emTgt[j] = emGoal;
        res = step(em[j], emV[j], emTgt[j], dt, emTension, emFriction);
        em[j] = res[0]; emV[j] = res[1];
        if (emTgt[j] !== emGoal) settled = false;
        else if (Math.abs(em[j] - emTgt[j]) > 0.002 || Math.abs(emV[j]) > 0.002) settled = false;
        res = step(curW[j], velW[j], targetW[j], dt, MORPH_TENSION, MORPH_FRICTION);
        curW[j] = res[0]; velW[j] = res[1];
        res = step(curH[j], velH[j], targetH[j], dt, MORPH_TENSION, MORPH_FRICTION);
        curH[j] = res[0]; velH[j] = res[1];
        res = step(curPress[j], velPress[j], 1, dt, PRESS_TENSION, PRESS_FRICTION);
        curPress[j] = res[0]; velPress[j] = res[1];

        if (settled) {
          if (Math.abs(curW[j] - targetW[j]) > 0.03 || Math.abs(velW[j]) > 0.03) settled = false;
          else if (Math.abs(curH[j] - targetH[j]) > 0.03 || Math.abs(velH[j]) > 0.03) settled = false;
          else if (Math.abs(curPress[j] - 1) > 0.001 || Math.abs(velPress[j]) > 0.001) settled = false;
        }
      }

      layout();

      if (fill) {
        var fillTargetLeft = left[activeIdx], fillTargetTop = top[activeIdx];
        var fillTargetW = curW[activeIdx], fillTargetH = curH[activeIdx];
        res = step(curFillLeft, velFillLeft, fillTargetLeft, dt, ACTIVE_TENSION, ACTIVE_FRICTION);
        curFillLeft = res[0]; velFillLeft = res[1];
        res = step(curFillTop, velFillTop, fillTargetTop, dt, ACTIVE_TENSION, ACTIVE_FRICTION);
        curFillTop = res[0]; velFillTop = res[1];
        res = step(curFillW, velFillW, fillTargetW, dt, ACTIVE_TENSION, ACTIVE_FRICTION);
        curFillW = res[0]; velFillW = res[1];
        res = step(curFillH, velFillH, fillTargetH, dt, ACTIVE_TENSION, ACTIVE_FRICTION);
        curFillH = res[0]; velFillH = res[1];

        if (settled) {
          if (Math.abs(curFillLeft - fillTargetLeft) > 0.03 || Math.abs(velFillLeft) > 0.03) settled = false;
          else if (Math.abs(curFillTop - fillTargetTop) > 0.03 || Math.abs(velFillTop) > 0.03) settled = false;
          else if (Math.abs(curFillW - fillTargetW) > 0.03 || Math.abs(velFillW) > 0.03) settled = false;
          else if (Math.abs(curFillH - fillTargetH) > 0.03 || Math.abs(velFillH) > 0.03) settled = false;
        }
      }

      paint();

      if (settled) {
        for (j = 0; j < n; j++) {
          curW[j] = targetW[j]; curH[j] = targetH[j]; curPress[j] = 1;
          velW[j] = velH[j] = velPress[j] = 0;
          em[j] = emGoal; emV[j] = 0;
        }
        dd = ddGoal; ddV = 0;
        layout();
        if (fill) {
          curFillLeft = left[activeIdx]; curFillTop = top[activeIdx];
          curFillW = curW[activeIdx]; curFillH = curH[activeIdx];
          velFillLeft = velFillTop = velFillW = velFillH = 0;
        }
        paint();
        running = false; lastT = -1;
        panel.classList.remove("is-anim");
        if (pendingCollapse) collapseNow();
        maybeHide();
        return;
      }
      raf = requestAnimationFrame(tick);
    }

    function ensureLoop() {
      if (reduceMotion()) {
        for (i = 0; i < n; i++) { curW[i] = targetW[i]; curH[i] = targetH[i]; curPress[i] = 1; velW[i] = velH[i] = velPress[i] = 0; em[i] = emTgt[i] = emGoal; emV[i] = 0; }
        dd = ddTgt = ddGoal; ddV = 0;
        layout();
        if (fill) {
          curFillLeft = left[activeIdx]; curFillTop = top[activeIdx];
          curFillW = curW[activeIdx]; curFillH = curH[activeIdx];
          velFillLeft = velFillTop = velFillW = velFillH = 0;
        }
        paint();
        return;
      }
      if (running) return;
      running = true; lastT = -1;
      raf = requestAnimationFrame(tick);
    }

    function goTo(hr, hc) {
      var targets = computeTargets(hr, hc);
      targetW = targets.w; targetH = targets.h;
      ensureLoop();
    }

    function pressBounce(idx) {
      curPress[idx] = PRESS_DOWN;
      velPress[idx] = 0;
      ensureLoop();
    }

    /* ── открытие / закрытие ─────────────────────────────────────── */
    var inner = panel.querySelector(".anchor-panel-inner");
    var panelT = 0, scrollRaf = 0;

    function setPanelHeight(to, ms, done) {
      clearTimeout(panelT);
      var from = panel.getBoundingClientRect().height;
      panel.style.transition = "none";
      panel.style.height = from + "px";
      void panel.offsetHeight;
      panel.style.transition = "height " + ms + "ms " + PANEL_EASE;
      panel.style.height = to + "px";
      panelT = setTimeout(function () { panel.style.transition = "none"; if (done) done(); }, ms + 40);
    }

    /* если сетка не помещается — мягко докрутить, чтобы она была видна */
    function revealInScroll(finalBottom) {
      var sc = panel.closest ? panel.closest(".content") : null;
      if (!sc) return;
      var over = finalBottom + 12 - sc.getBoundingClientRect().bottom;
      if (over <= 0) return;
      var start = sc.scrollTop, t0 = 0;
      cancelAnimationFrame(scrollRaf);
      (function f(t) {
        if (!t0) t0 = t;
        var p = Math.min(1, (t - t0) / PANEL_OPEN_MS);
        var e = 1 - Math.pow(1 - p, 3);
        sc.scrollTop = start + over * e;
        if (p < 1) scrollRaf = requestAnimationFrame(f);
      })(0);
    }

    var plateEl = toolBtn.closest ? (toolBtn.closest(".create-tile-anchor") || toolBtn) : toolBtn;
    function measurePlate() {
      var fr = field.getBoundingClientRect(), pr = plateEl.getBoundingClientRect();
      plateGeo = { cx: pr.left + pr.width / 2 - fr.left, bottom: pr.bottom - fr.top, w: pr.width };
    }

    /* панель прячется, только когда и высота схлопнулась, и капля
       впиталась в кнопку */
    var collapsed = false, pendingCollapse = false;
    function collapseNow() {
      pendingCollapse = false;
      setPanelHeight(0, PANEL_CLOSE_MS, function () { collapsed = true; maybeHide(); });
    }
    function maybeHide() {
      if (!panel.classList.contains("open") && collapsed && !running) panel.classList.remove("is-shown");
    }

    function setOpen(open) {
      measurePlate();
      collapsed = false;
      pendingCollapse = false;
      panel.classList.toggle("open", open);
      /* пока кубики вылетают/втягиваются — без стеклянного размытия под
         ними (они ещё прозрачны), иначе оно пересчитывалось каждый кадр */
      panel.classList.add("is-anim");
      toolBtn.setAttribute("aria-expanded", open ? "true" : "false");
      var now = window.performance ? performance.now() : Date.now();
      var reduce = reduceMotion();
      if (open) {
        panel.classList.add("is-shown");
        var H = inner.scrollHeight;
        ddGoal = 1; ddAt = now; ddTension = DROP_OPEN_TENSION; ddFriction = DROP_OPEN_FRICTION;
        emGoal = 1; emTension = EM_OPEN_TENSION; emFriction = EM_OPEN_FRICTION;
        for (var k = 0; k < n; k++) emAt[k] = now + DROP_LEAD + EM_RING[k] * EM_RING_OPEN;
        if (reduce) { panel.style.height = "auto"; }
        else {
          setPanelHeight(H, PANEL_OPEN_MS, function () { if (panel.classList.contains("open")) panel.style.height = "auto"; });
          revealInScroll(panel.getBoundingClientRect().top + H);
        }
      } else {
        emGoal = 0; emTension = EM_CLOSE_TENSION; emFriction = EM_CLOSE_FRICTION;
        /* обратно: углы первыми, центр последним */
        for (var m = 0; m < n; m++) emAt[m] = now + (2 - EM_RING[m]) * EM_RING_CLOSE;
        /* капля поднимается и впитывается в кнопку, когда кубики стеклись */
        ddGoal = 0; ddAt = now + DROP_RETURN; ddTension = DROP_CLOSE_TENSION; ddFriction = DROP_CLOSE_FRICTION;
        if (reduce) { panel.style.height = "0px"; panel.classList.remove("is-shown"); }
        else {
          /* панель схлопывается, когда капля почти вернулась в кнопку
             (раньше вкладка обрезала бы её по новой высоте) — см. tick */
          clearTimeout(panelT);
          pendingCollapse = true;
        }
      }
      ensureLoop();
    }

    panel.style.height = "0px";

    /* Прогрев. Первое (и второе) открытие стоили заметно дороже следующих:
       видеокарта впервые компилировала фильтр капли, растеризовала плитки
       и собирала их стеклянное размытие (во время анимации оно выключено,
       is-anim, — поэтому его цену платило ещё и второе открытие). Прежний
       прогрев держал плитки полностью прозрачными — такие браузер вообще
       не рисует, и прогревалась только пустая панель.
       Теперь панель на несколько кадров показывается раскрытой по-
       настоящему — плитки на местах и непрозрачны, капля в полёте, фильтр
       в полную силу — но вся целиком с непрозрачностью 1% (is-warm), в
       обоих режимах: с размытием плиток и без (is-anim). Делается это
       вскоре после запуска, а если вкладка Create тогда была скрыта —
       при первом наведении на кнопку Anchor Point. */
    var warmed = false, warming = false;
    /* a click in the middle of the warm-up: back to the closed state first */
    function warmAbort() {
      if (!warming) return;
      warming = false;
      for (var j = 0; j < n; j++) em[j] = 0;
      dd = 0;
      layout();
      paint();
      panel.classList.remove("is-shown", "is-warm", "is-anim");
    }
    function warm() {
      if (warmed || running || panel.classList.contains("open")) return;
      if (!panel.offsetParent && !panel.closest(".pane:not(.hidden)")) return;
      warmed = true;
      warming = true;
      measurePlate();
      var j;
      for (j = 0; j < n; j++) em[j] = 1;
      dd = 0.6;
      layout();
      panel.classList.add("is-shown", "is-warm");
      paint();
      goo.style.display = "";
      goo.style.opacity = "1";
      gooBlur.setAttribute("stdDeviation", String(GOO_BLUR));
      gooG.setAttribute("fill", gooColor());
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          if (!warming) return;
          panel.classList.add("is-anim");
          requestAnimationFrame(function () {
            requestAnimationFrame(function () {
              if (!warming) return;
              warmAbort();
            });
          });
        });
      });
    }
    var idle = window.requestIdleCallback || function (fn) { return setTimeout(fn, 50); };
    function warmSoon(ms) { if (!warmed) setTimeout(function () { idle(warm, { timeout: 1500 }); }, ms); }
    warmSoon(1400);
    /* the panel was not on screen then: as soon as Create is shown, or
       the panel is looked at again */
    var pane = panel.closest(".pane");
    if (pane && window.MutationObserver) {
      new MutationObserver(function () { if (!pane.classList.contains("hidden")) warmSoon(250); })
        .observe(pane, { attributes: true, attributeFilter: ["class"] });
    }
    if (window.PillowPresence && window.PillowPresence.onWakeEach) window.PillowPresence.onWakeEach(function () { warmSoon(400); });
    toolBtn.addEventListener("mouseenter", warm);

    toolBtn.addEventListener("click", function () {
      warmAbort();
      setOpen(!panel.classList.contains("open"));
    });

    for (i = 0; i < n; i++) {
      (function (tile, idx) {
        var rr = Math.floor(idx / 3), cc = idx % 3;
        tile.addEventListener("mouseenter", function () { goTo(rr, cc); });
        tile.addEventListener("mouseleave", function () { goTo(null, null); });
      })(tiles[i], i);
    }

    field.addEventListener("click", function (ev) {
      var btn = ev.target.closest ? ev.target.closest(".anchor-tile") : null;
      if (!btn) return;
      var idx = Array.prototype.indexOf.call(tiles, btn);
      var pos = btn.getAttribute("data-pos");
      for (var j = 0; j < n; j++) tiles[j].classList.toggle("active", tiles[j] === btn);
      if (statusEl) statusEl.textContent = LABELS[pos] || pos;
      if (idx >= 0) {
        activeIdx = idx; // .anchor-active-fill now springs toward this tile
        pressBounce(idx);
      }

      if (typeof host !== "function") return;
      host('pillowSetAnchor("' + pos + '")', function (r) {
        if (r.ok) { if (typeof toast === "function") toast("Anchor set to " + (window.PillowI18n ? window.PillowI18n.tr(LABELS[pos] || pos) : (LABELS[pos] || pos)) + (r.count > 1 ? " · " + r.count + " layers" : "")); }
        else if (typeof toast === "function") toast(r.error || "Failed", true);
      });
    });

    layout();
    paint();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
