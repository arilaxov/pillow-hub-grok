/* Pillow — пербуквенный морф вордмарка «Pillow» (шапка) вслед за курсором
 *
 * Слово режется на отдельные буквы-спаны. Для каждой считается расстояние
 * от курсора до её центра -> плавный спад влияния -> целевая деформация.
 * Реальная деформация не прыгает к цели, а каждый кадр догоняет её пружиной
 * (жёсткость/демпфирование с лёгким перелётом), поэтому волна плавно
 * перетекает от буквы к букве и так же плавно возвращается в покой.
 * Только геометрия: scaleX/scaleY, небольшой сдвиг и наклон. Вес, гарнитура,
 * размер и трекинг не меняются. Целевой элемент — только .header .brand-title;
 * общий морф самого элемента остаётся в chip-morph.js.
 */

(function () {
  "use strict";

  var REACH = 46;        // px, радиус влияния курсора на букву
  var SX = 0.42;         // максимум растяжения вширь
  var SY = 0.22;         // максимум растяжения ввысь
  var LIFT = 1.6;        // px, подъём буквы
  var PULL = 2.4;        // px, сдвиг буквы к курсору
  var SKEW = 7;          // градусов, наклон в сторону курсора
  var K = 240, C = 17;   // пружина: лёгкий, не тяжёлый перелёт

  var reduced = false;
  try {
    reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  } catch (e) {}

  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

  /* плавный спад: 1 у центра буквы -> 0 на границе REACH, без углов */
  function falloff(d) {
    var t = clamp(1 - d / REACH, 0, 1);
    return t * t * (3 - 2 * t);
  }

  function bind(el) {
    if (!el || el.__plLetters || reduced) return;
    el.__plLetters = true;

    var text = el.textContent;
    el.setAttribute("aria-label", text);
    el.textContent = "";
    var letters = [];
    for (var i = 0; i < text.length; i++) {
      var sp = document.createElement("span");
      sp.className = "wordmark-letter";
      sp.setAttribute("aria-hidden", "true");
      sp.textContent = text.charAt(i);
      el.appendChild(sp);
      /* a — сила, d — направление к курсору по X (−1..1) */
      letters.push({ el: sp, a: 0, va: 0, d: 0, vd: 0, ta: 0, td: 0, cx: 0, cy: 0 });
    }

    var raf = null, last = 0, near = false, box = null, stale = true;

    /* центры букв берём из раскладки без их собственных трансформов.
       Вордмарк стоит на месте: замер хранится и берётся заново, только
       когда раскладка вокруг менялась — замер на каждый pointermove
       заставлял браузер пересчитывать стили всей панели после любого
       ховера */
    function measure() {
      if (!stale && box) return;
      stale = false;
      var r = el.getBoundingClientRect();
      box = { left: r.left, top: r.top, right: r.right, bottom: r.bottom };
      var k = el.offsetWidth ? r.width / el.offsetWidth : 1;
      for (var j = 0; j < letters.length; j++) {
        var L = letters[j];
        L.cx = r.left + (L.el.offsetLeft + L.el.offsetWidth / 2) * k;
        L.cy = r.top + (L.el.offsetTop + L.el.offsetHeight / 2) * k;
      }
    }

    function aim(x, y) {
      for (var j = 0; j < letters.length; j++) {
        var L = letters[j];
        var dx = x - L.cx, dy = (y - L.cy) * 0.7;
        L.ta = falloff(Math.sqrt(dx * dx + dy * dy));
        L.td = clamp(dx / (REACH * 0.6), -1, 1);
      }
    }

    function rest() {
      for (var j = 0; j < letters.length; j++) { letters[j].ta = 0; letters[j].td = 0; }
    }

    function write(L) {
      var a = L.a;
      var sx = 1 + SX * a, sy = 1 + SY * a;
      L.el.style.transform =
        "translate3d(" + (L.d * PULL * a).toFixed(2) + "px," + (-LIFT * a).toFixed(2) + "px,0) " +
        "skewX(" + (-L.d * SKEW * a).toFixed(2) + "deg) " +
        "scale(" + sx.toFixed(4) + "," + sy.toFixed(4) + ")";
    }

    function tick(now) {
      var dt = Math.min(0.032, (now - last) / 1000 || 0.016);
      last = now;
      var moving = false;
      for (var j = 0; j < letters.length; j++) {
        var L = letters[j];
        L.va += (K * (L.ta - L.a) - C * L.va) * dt;
        L.a += L.va * dt;
        L.vd += (K * (L.td - L.d) - C * L.vd) * dt;
        L.d += L.vd * dt;
        if (Math.abs(L.va) > 0.002 || Math.abs(L.ta - L.a) > 0.001 ||
            Math.abs(L.vd) > 0.01 || Math.abs(L.td - L.d) > 0.002) moving = true;
        write(L);
      }
      if (moving || near) raf = requestAnimationFrame(tick);
      else {
        raf = null;
        for (var m = 0; m < letters.length; m++) {
          var Q = letters[m];
          Q.a = Q.va = Q.d = Q.vd = 0;
          Q.el.style.transform = "";
          Q.el.style.willChange = "";
        }
      }
    }

    function wake() {
      if (raf) return;
      for (var j = 0; j < letters.length; j++) letters[j].el.style.willChange = "transform";
      last = performance.now();
      raf = requestAnimationFrame(tick);
    }

    if (window.ResizeObserver) {
      var ro = new ResizeObserver(function () { stale = true; });
      ro.observe(el); if (el.parentElement) ro.observe(el.parentElement); ro.observe(document.documentElement);
    }
    window.addEventListener("resize", function () { stale = true; });
    new MutationObserver(function () { stale = true; }).observe(document.documentElement, { attributes: true, attributeFilter: ["data-rail", "lang"] });

    document.addEventListener("pointermove", function (e) {
      if (e.pointerType === "touch") return;
      measure();
      var r = box;
      var inside =
        e.clientX > r.left - REACH && e.clientX < r.right + REACH &&
        e.clientY > r.top - REACH && e.clientY < r.bottom + REACH;
      if (inside) { near = true; aim(e.clientX, e.clientY); wake(); }
      else if (near) { near = false; rest(); wake(); }
    }, { passive: true });

    document.addEventListener("pointerleave", function () {
      if (near) { near = false; rest(); wake(); }
    });
  }

  function boot() { bind(document.querySelector(".header .brand-title")); }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
