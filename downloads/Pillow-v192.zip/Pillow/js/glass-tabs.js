/* Pillow — единые Liquid Glass segmented controls (только режим стекла).
 *
 * Три существующих группы кнопок: IN/OUT (.inout-switch), категории
 * (.text-cats — общий класс #text-cats и #sfx-cats), Direction
 * (.dir-row). Их разметка, id, data-атрибуты и обработчики кликов
 * (text.js: setDirection()/onclick, renderCats(), dir-row onclick) не
 * трогаются нигде — клик по-прежнему просто переключает класс .active
 * на нужной кнопке (категории вдобавок перерисовывают список целиком,
 * это тоже не меняется). Модуль только держит один плавающий
 * индикатор внутри каждого такого трека и двигает его пружиной к
 * активной кнопке при любой смене .active — включая полную
 * перерисовку innerHTML, которую делает renderCats(): она стирает и
 * индикатор вместе со старыми кнопками, поэтому он при необходимости
 * пересоздаётся, не теряя текущей позиции (переезд остаётся плавным).
 *
 * Материал самих треков и снятие обычной заливки кнопок в стекле —
 * css/glass.css; сами кнопки в стекле больше не одеваются js/glass.js
 * (см. комментарий там же).
 *
 * Пружина — та же минимальная реализация (Track/spring), что уже
 * возит палец .switch в js/glass-switch.js: отдельные драйверы для
 * каждой измеряемой величины (x, y, width, height), как у референсного
 * Glass Tabs.
 */
(function () {
  "use strict";
  if (window.PillowGlassTabs) return;

  var GROUP_SEL = ".inout-switch, .text-cats, .dir-row, .pl-fb-kind";

  function nowMs() { return window.performance ? performance.now() : Date.now(); }
  function reduceMotion() {
    return !!window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }
  function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }

  function Track(initial) {
    this.value = initial; this.watchers = []; this.activeStop = null;
    this.lastStamp = 0; this.speed = 0;
  }
  Track.prototype.get = function () { return this.value; };
  Track.prototype.velocity = function () { return nowMs() - this.lastStamp > 90 ? 0 : this.speed; };
  Track.prototype.push = function (next) {
    var stamp = nowMs(), dt = stamp - this.lastStamp;
    if (dt > 90) this.speed = 0;
    else if (dt > 0) this.speed = ((next - this.value) / clamp(dt, 8, 32)) * 1000;
    this.lastStamp = stamp; this.value = next;
    for (var i = 0; i < this.watchers.length; i++) this.watchers[i](next);
  };
  Track.prototype.snap = function (next) {
    this.halt(); this.speed = 0; this.lastStamp = nowMs(); this.value = next;
    for (var i = 0; i < this.watchers.length; i++) this.watchers[i](next);
  };
  Track.prototype.watch = function (fn) { this.watchers.push(fn); fn(this.value); };
  Track.prototype.claim = function (stop) { this.activeStop = stop; };
  Track.prototype.halt = function () { if (this.activeStop) this.activeStop(); this.activeStop = null; };

  function spring(track, target, cfg) {
    cfg = cfg || {};
    var tension = cfg.tension || 340, friction = cfg.friction || 28;
    var eps = cfg.epsilon || 0.01;
    if (reduceMotion()) { track.snap(target()); return; }
    track.halt();
    var vel = track.velocity() / 1000, raf = 0, last = -1, stopped = false;
    track.claim(function () { stopped = true; cancelAnimationFrame(raf); });
    function tick(t) {
      if (stopped) return;
      if (last < 0) last = t;
      var dt = Math.min(Math.max((t - last) / 1000, 0), 0.032); last = t;
      var goal = target(), x = track.get();
      vel += (-tension * (x - goal) - friction * vel) * dt;
      var next = x + vel * dt;
      track.push(next);
      if (Math.abs(next - goal) < eps && Math.abs(vel) < eps * 50) {
        track.push(goal); track.claim(null); return;
      }
      raf = requestAnimationFrame(tick);
    }
    raf = requestAnimationFrame(tick);
  }

  function activeBtn(el) {
    return el.querySelector(":scope > .active") || el.querySelector(":scope > button");
  }

  function upgrade(el) {
    if (el.__git) return;
    el.__git = true;
    /* marks a track whose selection is painted by the sliding indicator
       (css/minimal.css: outside glass too, except the category chips) */
    el.classList.add("pl-seg-live");

    var s = {
      x: new Track(0), y: new Track(0), w: new Track(0), h: new Track(0),
      ind: null, placed: false, d: 0
    };

    function makeIndicator() {
      var ind = document.createElement("span");
      ind.className = "pl-seg-indicator";
      ind.setAttribute("aria-hidden", "true");
      return ind;
    }

    /* the indicator never springs past the track's ends: at the first and
       last button it stops at the edge (it still springs between them) */
    function ends() {
      var bs = el.querySelectorAll(":scope > button"), a = bs[0], z = bs[bs.length - 1];
      if (!a || !z || !a.offsetWidth) return null;
      return { lo: a.offsetLeft, hi: z.offsetLeft + z.offsetWidth };
    }
    /* the indicator never pokes past the track's ends: an overshoot at
       the first or last button squashes it against the wall instead, so
       it still bounces. On the move it stretches with its speed and
       springs back (jelly), like the Bounce presets' dock. */
    function paint() {
      if (!s.ind) return;
      var x = s.x.get(), w = Math.max(0, s.w.get()), e = ends();
      if (e && w > 0) {
        if (x + w > e.hi) { w = Math.max(w * 0.55, w - (x + w - e.hi)); x = e.hi - w; }
        if (x < e.lo) { w = Math.max(w * 0.55, w - (e.lo - x)); x = e.lo; }
      }
      var q = s.d, sx = 1 + 0.5 * q, sy = 1 - 0.28 * q;
      if (e && w > 0) {
        /* the stretch stays inside the track too */
        var room = 2 * Math.min(x + w / 2 - e.lo, e.hi - x - w / 2) / w;
        if (sx > room) sx = Math.max(1, room);
      }
      s.ind.style.transform = "translate(" + x + "px," + s.y.get() + "px) scale(" + sx.toFixed(4) + "," + sy.toFixed(4) + ")";
      s.ind.style.width = w + "px";
      s.ind.style.height = Math.max(0, s.h.get()) + "px";
    }
    var jelly = 0;
    function runJelly() {
      if (jelly || reduceMotion()) return;
      var dv = 0, last = -1;
      function tick(t) {
        if (last < 0) last = t;
        var dt = Math.min(Math.max((t - last) / 1000, 0), 0.032); last = t;
        var goal = clamp(0.0022 * Math.pow(Math.abs(s.x.velocity()), 0.7), 0, 0.32);
        dv += (-210 * (s.d - goal) - 12 * dv) * dt;
        s.d += dv * dt;
        paint();
        if (!s.x.activeStop && Math.abs(s.d) < 0.002 && Math.abs(dv) < 0.02) {
          s.d = 0; jelly = 0; paint(); return;
        }
        jelly = requestAnimationFrame(tick);
      }
      jelly = requestAnimationFrame(tick);
    }
    s.x.watch(paint); s.y.watch(paint); s.w.watch(paint); s.h.watch(paint);

    function ensureIndicator() {
      if (s.ind && el.contains(s.ind)) return;
      /* renderCats() (js/text.js) перерисовывает категории через
         innerHTML — это стирает прежний узел индикатора вместе со
         старыми кнопками. Пересоздаём узел, но Track'и (s.x/y/w/h)
         живут вне DOM и своих значений не теряют, поэтому paint()
         сразу ставит новый узел туда же, где был старый — скачка нет. */
      s.ind = makeIndicator();
      el.insertBefore(s.ind, el.firstChild);
      paint();
    }

    function place(animate) {
      ensureIndicator();
      var b = activeBtn(el);
      if (!b) return;
      var x = b.offsetLeft, y = b.offsetTop, w = b.offsetWidth, h = b.offsetHeight;
      if (!w || !h) return;               /* спрятанная вкладка — нечего мерить */
      if (!animate || !s.placed || reduceMotion()) {
        s.x.snap(x); s.y.snap(y); s.w.snap(w); s.h.snap(h);
      } else {
        spring(s.x, function () { var c = activeBtn(el); return c ? c.offsetLeft : x; }, { tension: 340, friction: 21 });
        runJelly();
        spring(s.y, function () { var c = activeBtn(el); return c ? c.offsetTop : y; }, { tension: 340, friction: 28 });
        spring(s.w, function () { var c = activeBtn(el); return c ? c.offsetWidth : w; }, { tension: 340, friction: 32 });
        spring(s.h, function () { var c = activeBtn(el); return c ? c.offsetHeight : h; }, { tension: 340, friction: 32 });
      }
      s.placed = true;
    }
    el.__gitPlace = place;

    if (window.ResizeObserver) new ResizeObserver(function () { place(false); }).observe(el);

    new MutationObserver(function () { place(true); })
      .observe(el, { childList: true, subtree: true, attributes: true, attributeFilter: ["class"] });

    place(false);
  }

  function scan(root) {
    var scope = root && root.querySelectorAll ? root : document;
    var list = scope.querySelectorAll ? scope.querySelectorAll(GROUP_SEL) : [];
    if (scope.matches && scope.matches(GROUP_SEL)) upgrade(scope);
    for (var i = 0; i < list.length; i++) upgrade(list[i]);
  }

  /* Стекло включили/выключили, сменили вкладку или тему — индикатор мог
     всё это время мерить нулевой (скрытой) плашке; досчитываем без
     анимации, как только он снова на виду. */
  function resnapAll() {
    var list = document.querySelectorAll(GROUP_SEL);
    for (var i = 0; i < list.length; i++) if (list[i].__gitPlace) list[i].__gitPlace(false);
  }

  function boot() {
    scan(document);
    new MutationObserver(function (recs) {
      for (var i = 0; i < recs.length; i++) {
        var added = recs[i].addedNodes;
        for (var j = 0; j < added.length; j++) {
          if (added[j].nodeType === 1) scan(added[j]);
        }
      }
    }).observe(document.body, { childList: true, subtree: true });

    new MutationObserver(resnapAll)
      .observe(document.documentElement, { attributes: true, attributeFilter: ["data-pl-glass"] });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  window.PillowGlassTabs = { scan: scan, resnap: resnapAll };
})();
