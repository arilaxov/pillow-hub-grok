/* Pillow 2.0 — Text Animations
 * Fixed AE application + Liquid Glass UI hooks.
 * Relies on globals from panel.js: $, host, toast, esc, escapeHtml, PillowFav.
 */
(function () {
  "use strict";

  function P(id, name, hint, category, opts) {
    opts = opts || {};
    return {
      id: id,
      name: name,
      hint: hint,
      category: category,
      basedOn: opts.basedOn || "all",
      useDir: !!opts.useDir,
      dx: opts.dx || 0,
      dy: opts.dy || 0,
      blur: opts.blur || 0,
      scaleFrom: opts.scaleFrom != null ? opts.scaleFrom : null,
      rotate: opts.rotate != null ? opts.rotate : null,
      tracking: opts.tracking || 0,
      opacityFrom: opts.opacityFrom != null ? opts.opacityFrom : 0,
      smoothness: opts.smoothness != null ? opts.smoothness : 60,
      duration: opts.duration != null ? opts.duration : 0.6,
      stagger: opts.stagger != null ? opts.stagger : 0.045,
      distance: opts.distance != null ? opts.distance : (Math.max(Math.abs(opts.dx || 0), Math.abs(opts.dy || 0)) || 40),
      forceDir: opts.forceDir || null,
      flicker: !!opts.flicker,
      expr: opts.expr || null,         /* "drop" | "spring": a damped spring per unit (host: pillowTextSpringSelector) */
      freq: opts.freq || 0,
      amp: opts.amp != null ? opts.amp : null,
      scaleXY: opts.scaleXY || null,    /* [x%, y%] off-state scale per axis */
      refDur: opts.refDur || 0,         /* the spring's own length: freq is for this duration */
      rel: opts.rel !== false,          /* offsets and blur are for a 100 px font: AE scales them to the layer's */
      ease: opts.ease || null           /* [x1, y1, x2, y2]: the preset's own curve over its category's */
    };
  }

  /* twenty presets in five groups: the moves people actually use */
  var LIBRARY = [
    { category: "Bounce", items: [
      /* measured on the reference video frame by frame (offsets are for a
         100 px font and follow the layer's real font size - "rel"):
         Up     words rise from one text-height below, squashed to 40% tall,
                blurred and transparent, overshoot ~0.3 above, settle
                (100·e^(-6t)·cos(2π·2.5t), 0.06 s apart, 0.8 s)
         Slide  words come from 1.4 text-heights to the right, bunch up
                past their place by ~0.3 and settle (same spring)
         Spring letters swing in on an arc and snap together
                (50·cos(2π·2t)/e^(8t), 0.03 s apart)
         Rise   a gentler rise, slightly small */
      P("bounce-drop", "Bounce Up", "Words rise, overshoot and settle", "Bounce", { expr: "drop", freq: 2.5, basedOn: "word", dy: 100, scaleXY: [100, 40], blur: 12, distance: 100, duration: 0.8, refDur: 0.8, stagger: 0.06, rel: true, forceDir: "in" }),
      P("bounce-slide", "Bounce Slide", "Words slide in and bunch up", "Bounce", { expr: "drop", freq: 2.5, basedOn: "word", dx: 140, blur: 12, distance: 140, duration: 0.8, refDur: 0.8, stagger: 0.04, rel: true, forceDir: "in" }),
      P("spring-letters", "Spring Letters", "Letters swing in on an arc", "Bounce", { expr: "spring", freq: 2, amp: 0.5, basedOn: "char", dx: 70, dy: 50, rotate: 22, blur: 10, distance: 70, duration: 0.6, refDur: 0.6, stagger: 0.03, rel: true, forceDir: "in" }),
      P("bounce-rise", "Bounce Rise", "Words rise softly into place", "Bounce", { expr: "drop", freq: 2.5, basedOn: "word", dy: 45, scaleFrom: 85, blur: 14, distance: 45, duration: 0.8, refDur: 0.8, stagger: 0.06, rel: true, forceDir: "in" })
    ]},
    { category: "Basic", items: [
      P("fade-in", "Fade", "Opacity, nothing else", "Basic"),
      P("blur-in", "Blur", "Focus pulls into place", "Basic", { blur: 26, scaleFrom: 104 }),
      P("smooth-slide", "Slide", "Travel, then rest — pick the side below", "Basic", { useDir: true, distance: 50, duration: 0.8 }),
      P("pop-in", "Pop", "Quick, springy arrival", "Basic", { scaleFrom: 40, duration: 0.45, ease: [0.34, 1.56, 0.64, 1] }),
      P("soft-scale", "Scale", "Gentle, unhurried grow", "Basic", { scaleFrom: 85, duration: 0.9 })
    ]},
    { category: "Reveal", items: [
      P("char-reveal", "Character Reveal", "Letters rise one by one", "Reveal", { basedOn: "char", dy: 30, duration: 0.5, stagger: 0.035 }),
      P("word-reveal", "Word Reveal", "Phrase, then phrase", "Reveal", { basedOn: "word", dy: 40, blur: 8, duration: 0.6, stagger: 0.09 }),
      P("line-reveal", "Line Reveal", "One line settles at a time", "Reveal", { basedOn: "line", dy: 50, duration: 0.7, stagger: 0.14 }),
      P("char-blur", "Character Blur", "Focus, per letter", "Reveal", { basedOn: "char", blur: 24, scaleFrom: 115, duration: 0.55, stagger: 0.035 }),
      P("char-pop", "Character Pop", "Springy, per letter", "Reveal", { basedOn: "char", scaleFrom: 30, duration: 0.5, stagger: 0.04, ease: [0.34, 1.56, 0.64, 1] })
    ]},
    { category: "Motion", items: [
      P("cinematic", "Cinematic", "Slow focus pull from large", "Motion", { scaleFrom: 115, blur: 20, duration: 1.2 }),
      P("float-in", "Float In", "Drifts up into place", "Motion", { dy: 45, blur: 6, duration: 0.9 }),
      P("tracking-reveal", "Tracking Reveal", "Letters draw together", "Motion", { basedOn: "char", tracking: 180, duration: 0.7, stagger: 0.03 }),
      P("flicker", "Flicker", "Unstable signal, then hold", "Motion", { duration: 0.5, flicker: true })
    ]},
    { category: "Subtitles", items: [
      P("sub-fade", "Subtitle Fade", "Clean lower-third fade", "Subtitles", { dy: 8, duration: 0.35 }),
      P("sub-word", "Caption Words", "Word-by-word for readability", "Subtitles", { basedOn: "word", dy: 12, duration: 0.4, stagger: 0.08 })
    ]}
  ];

  var CATEGORY_EASE = {
    Bounce: "linear",
    Basic: "cubic-bezier(.22,1,.36,1)",
    Subtitles: "cubic-bezier(.25,.1,.25,1)",
    Fade: "cubic-bezier(.25,.1,.25,1)",
    Blur: "cubic-bezier(.4,0,.2,1)",
    Slide: "cubic-bezier(.22,1,.36,1)",
    Reveal: "cubic-bezier(.16,1,.3,1)",
    Scale: "cubic-bezier(.34,1.56,.64,1)",
    Rotation: "cubic-bezier(.34,1.56,.64,1)",
    Motion: "cubic-bezier(.25,.46,.45,.94)",
    "Glitch / Modern": "steps(5,end)",
    Character: "cubic-bezier(.22,1,.36,1)"
  };

  function findItem(id) {
    for (var c = 0; c < LIBRARY.length; c++) {
      for (var i = 0; i < LIBRARY[c].items.length; i++) {
        if (LIBRARY[c].items[i].id === id) return LIBRARY[c].items[i];
      }
    }
    return null;
  }

  var state = {
    direction: "in",
    dial: "up",
    previewText: "Pillow",
    settingsLevel: "basic",
    activeId: "bounce-drop",
    settings: {},
    filter: "",
    category: "All",
    favsOnly: false,
    updateText: false,
    active: false
  };

  var applyDebounceT = null;
  var previewInputT = null;
  var filterDebounceT = null;

  function settingsFromItem(item) {
    return {
      duration: item.duration,
      delay: 0,
      stagger: item.stagger,
      blur: item.blur,
      distance: item.distance,
      scale: item.scaleFrom != null ? item.scaleFrom : 100,
      rotation: item.rotate != null ? item.rotate : 0,
      opacity: item.opacityFrom
    };
  }

  /* a spring slowed down as a whole: over a longer duration it swings
     the same number of times, just slower (not more wobbles) */
  function springFreq(item, dur) {
    return item.refDur ? item.freq * item.refDur / Math.max(0.05, dur) : item.freq;
  }
  function computeDxDy(item, distance) {
    /* a preset with its own direction: the Distance slider scales it */
    if (!item.useDir) {
      var k = item.distance && distance != null ? distance / item.distance : 1;
      return { dx: item.dx * k, dy: item.dy * k };
    }
    var dx = 0, dy = 0;
    if (state.dial === "up") dy = distance;
    else if (state.dial === "down") dy = -distance;
    else if (state.dial === "left") dx = distance;
    else if (state.dial === "right") dx = -distance;
    return { dx: dx, dy: dy };
  }

  function buildPreviewMarkup(text, basedOn) {
    text = text && text.length ? text : "Pillow";
    var html = "";
    if (basedOn === "word") {
      var words = text.split(" ");
      for (var i = 0; i < words.length; i++) {
        html += '<span class="tp-unit">' + escapeHtml(words[i]) + (i < words.length - 1 ? "&nbsp;" : "") + "</span>";
      }
      return html;
    }
    if (basedOn === "char") {
      for (var j = 0; j < text.length; j++) {
        var ch = text.charAt(j);
        html += '<span class="tp-unit">' + (ch === " " ? "&nbsp;" : escapeHtml(ch)) + "</span>";
      }
      return html;
    }
    return '<span class="tp-unit">' + escapeHtml(text) + "</span>";
  }

  /* ── Card preview ──────────────────────────────────────────────── *
   * Drawn frame by frame from the same per-unit amount the AE side uses
   * (1 = the animator's full "off" state, 0 = at rest): a staggered eased
   * sweep for the classic presets, the damped springs for Bounce. AE
   * pixels are scaled down to the 12px preview so the motion stays in
   * the box. */
  var BEZ = {};
  function bezier(x1, y1, x2, y2) {
    function cx(t) { return 3 * x1 * t * (1 - t) * (1 - t) + 3 * x2 * t * t * (1 - t) + t * t * t; }
    function cy(t) { return 3 * y1 * t * (1 - t) * (1 - t) + 3 * y2 * t * t * (1 - t) + t * t * t; }
    return function (x) {
      var lo = 0, hi = 1, t = x;
      for (var i = 0; i < 24; i++) { t = (lo + hi) / 2; if (cx(t) < x) lo = t; else hi = t; }
      return cy(t);
    };
  }
  /* the preset's curve as [x1, y1, x2, y2] (null for steps) */
  function bezierOf(item) {
    if (item.ease) return item.ease;
    var m = /cubic-bezier\(([^)]+)\)/.exec(CATEGORY_EASE[item.category] || "");
    if (!m) return [0.25, 0.1, 0.25, 1];
    var v = m[1].split(",");
    return [+v[0], +v[1], +v[2], +v[3]];
  }
  function easeOf(item) {
    if (item.ease) {
      var key = item.ease.join(",");
      return BEZ[key] || (BEZ[key] = bezier(item.ease[0], item.ease[1], item.ease[2], item.ease[3]));
    }
    var css = CATEGORY_EASE[item.category] || "ease";
    if (BEZ[css]) return BEZ[css];
    var m = /cubic-bezier\(([^)]+)\)/.exec(css), f;
    if (m) { var v = m[1].split(","); f = bezier(+v[0], +v[1], +v[2], +v[3]); }
    else if (/^steps\((\d+)/.test(css)) { var n = +/^steps\((\d+)/.exec(css)[1]; f = function (x) { return Math.min(1, Math.floor(x * n) / n + (x >= 1 ? 1 : 0)); }; }
    else if (css === "linear") f = function (x) { return x; };
    else f = bezier(0.25, 0.1, 0.25, 1);
    return (BEZ[css] = f);
  }
  /* the amount of unit i at t seconds into the animation */
  function amountAt(item, i, t, out) {
    var st = item.stagger, dur = item.duration;
    if (item.expr) {
      var tt = out ? i * st + dur - t : t - i * st;
      if (tt < 0) return 1;
      var k = 4.6 / dur, w = (springFreq(item, dur) || 2.5) * 2 * Math.PI * tt;
      return item.expr === "spring" ? (item.amp != null ? item.amp : 0.5) * Math.cos(w) / Math.exp(k * tt)
        : Math.exp(-k * tt) * Math.cos(w);
    }
    var p = Math.max(0, Math.min(1, (t - i * st) / dur));
    if (item.flicker) { var pat = [1, 0.35, 0.85, 0.15, 0.7, 0]; var q = pat[Math.min(pat.length - 1, Math.floor(p * pat.length))]; return out ? 1 - q : q; }
    /* Out plays the curve mirrored: it leaves slowly, then quickly (the
       host does the same: pillowEaseBezier, the "ease" selector) */
    return out ? 1 - easeOf(item)(1 - p) : 1 - easeOf(item)(p);
  }
  function sweepSeconds(item, n) {
    return item.duration + item.stagger * Math.max(0, n - 1);
  }
  /* the preview in AE's proportions: a "rel" preset's offsets and blur
     are for a 100 px font (AE scales them to the layer's font), the
     others are AE pixels on Pillow's default 86 px text - both scaled
     here to the preview's own font size. Blur is a text-shadow, not a
     CSS filter: a filter per letter made the first frames stutter in
     After Effects' panel. Scale works from the baseline, like AE's. */
  function rgbaOf(col, alpha) {
    var m = /rgba?\(([^)]+)\)/.exec(col);
    if (!m) return col;
    var c = m[1].split(",");
    return "rgba(" + c[0] + "," + c[1] + "," + c[2] + "," + alpha.toFixed(3) + ")";
  }
  function paintUnits(container, item, t, out) {
    var units = container.querySelectorAll(".tp-unit");
    if (!units.length) return;
    var px = container.__fpx || (container.__fpx = parseFloat(getComputedStyle(container).fontSize) || 16);
    var col = getComputedStyle(container).color || "#fff";   /* not cached: the theme can change */
    var k = px / (item.rel ? 100 : 86);
    var dd = computeDxDy(item, item.distance);
    var off = (item.opacityFrom || 0) / 100;
    var sf = item.scaleFrom != null ? item.scaleFrom / 100 : 1;
    var sfx = item.scaleXY ? item.scaleXY[0] / 100 : sf, sfy = item.scaleXY ? item.scaleXY[1] / 100 : sf;
    /* tracking (per letter): every letter pushes the ones after it by
       its share of the tracking; the line stays centred, as in AE */
    var trX = null;
    if (item.tracking && units.length > 1) {
      trX = []; var acc = 0;
      for (var u = 0; u < units.length; u++) {
        trX.push(acc);
        acc += item.tracking / 1000 * px * Math.max(0, Math.min(1, t == null ? 0 : amountAt(item, u, t, out)));
      }
      for (u = 0; u < units.length; u++) trX[u] -= acc / 2;
    }
    for (var i = 0; i < units.length; i++) {
      var a = t == null ? 0 : amountAt(item, i, t, out);
      var ac = Math.max(0, Math.min(1, a)), st = units[i].style;
      st.transition = "none";
      st.transformOrigin = "50% 82%";
      st.opacity = (1 - (1 - off) * ac).toFixed(3);
      /* blur: the crisp letters hand over to a blurred shadow as the
         radius grows - a faint radius drawn only as shadow read as
         bold, smudged letters near the end of every bounce */
      var r = item.blur ? item.blur * k * a : 0;
      if (r > 0.6) {
        var keep = Math.max(0, 1 - (r - 0.6) / 2.4);
        st.color = keep > 0.01 ? rgbaOf(col, keep) : "transparent";
        st.textShadow = "0 0 " + r.toFixed(2) + "px " + col;
      } else if (st.textShadow) { st.color = ""; st.textShadow = ""; }
      st.filter = "";
      st.transform = "translate(" + (dd.dx * k * a + (trX ? trX[i] : 0)).toFixed(2) + "px," + (dd.dy * k * a).toFixed(2) + "px) scale(" +
        Math.max(0, 1 + (sfx - 1) * a).toFixed(4) + "," + Math.max(0, 1 + (sfy - 1) * a).toFixed(4) + ") rotate(" + ((item.rotate || 0) * a).toFixed(2) + "deg)";
    }
  }
  function applyCardVars(container, item) {
    paintUnits(container, item, null, false);
  }

  var play = { raf: 0, el: null, item: null, t0: 0 };
  function clearPreviewTimers() {
    if (play.raf) cancelAnimationFrame(play.raf);
    play.raf = 0;
  }
  /* in: animate, hold at rest, again. out: rest, animate away, hold, again */
  function startCardPreview(container, item) {
    if (!state.active) return;
    clearPreviewTimers();
    if (play.el && play.el !== container && play.item) { paintUnits(play.el, play.item, null, false); play.el.classList.remove("tp-playing"); }
    play.el = container; play.item = item; play.t0 = 0;
    container.classList.add("tp-playing");
    var n = container.querySelectorAll(".tp-unit").length;
    var out = state.direction === "out";
    var lead = out ? 0.35 : 0.12, sweep = sweepSeconds(item, n) + (item.expr ? 0.15 : 0), hold = 0.6;
    function frame(now) {
      play.raf = 0;
      if (!state.active || play.el !== container) return;
      if (!play.t0) play.t0 = now;
      var t = ((now - play.t0) / 1000) % (lead + sweep + hold);
      paintUnits(container, item, Math.max(0, t - lead) + (t < lead ? (out ? 0 : -1) : 0), out);
      play.raf = requestAnimationFrame(frame);
    }
    play.raf = requestAnimationFrame(frame);
  }
  function stopCardPreview(container) {
    clearPreviewTimers();
    var item = play.el === container ? play.item : findItem(container.getAttribute("data-preview-for"));
    if (item) paintUnits(container, item, null, false);
    container.classList.remove("tp-playing");
    if (play.el === container) play.el = null;
  }

  function passesFilter(item) {
    if (state.favsOnly && window.PillowFav && !window.PillowFav.is(window.PillowFav.TEXT, item.id)) return false;
    if (state.category !== "All" && item.category !== state.category) return false;
    if (!state.filter) return true;
    var q = state.filter.toLowerCase();
    return (item.name + " " + item.hint + " " + item.category).toLowerCase().indexOf(q) >= 0;
  }

  function renderCats() {
    var box = $("text-cats");
    if (!box) return;
    var cats = ["All"];
    for (var c = 0; c < LIBRARY.length; c++) cats.push(LIBRARY[c].category);
    var html = "";
    for (var i = 0; i < cats.length; i++) {
      html += '<button type="button" class="text-cat' + (cats[i] === state.category ? " active" : "") +
        '" data-cat="' + escapeHtml(cats[i]) + '">' + escapeHtml(cats[i]) + "</button>";
    }
    box.innerHTML = html;
    box.onclick = function (ev) {
      var b = ev.target.closest ? ev.target.closest("[data-cat]") : null;
      if (!b) return;
      var cat = b.getAttribute("data-cat");
      if (cat === state.category) return;
      state.category = cat;
      /* только переключаем .active — без пересборки кнопок */
      var btns = box.querySelectorAll("[data-cat]");
      for (var j = 0; j < btns.length; j++) btns[j].classList.toggle("active", btns[j] === b);
      renderGrid();
    };
  }

  /* ── Сетка пресетов ─────────────────────────────────────────────── *
   * Карточки строятся ОДИН раз на весь LIBRARY; категория, поиск и
   * «только избранное» только показывают/прячут их с анимацией —
   * см. js/list-fx.js (общий движок для Text, SFX и Curves). */
  function buildGrid(grid) {
    var html = "";
    for (var c = 0; c < LIBRARY.length; c++) {
      var group = LIBRARY[c];
      for (var i = 0; i < group.items.length; i++) {
        var it = group.items[i];
        var favOn = window.PillowFav && window.PillowFav.is(window.PillowFav.TEXT, it.id);
        html +=
          '<button type="button" class="text-card' + (it.id === state.activeId ? " active" : "") + '" data-text-id="' + it.id + '">' +
          '<span class="fav-star' + (favOn ? " on" : "") + '" data-fav="' + it.id + '" title="Favorite">' + (favOn ? "★" : "☆") + "</span>" +
          '<div class="text-preview tp-on" data-preview-for="' + it.id + '">' + buildPreviewMarkup(state.previewText, it.basedOn) + "</div>" +
          '<span class="name">' + escapeHtml(it.name) + "</span>" +
          '<span class="hint">' + escapeHtml(it.hint) + "</span>" +
          "</button>";
      }
    }
    html += '<div class="text-grid-empty" style="display:none;grid-column:1/-1;text-align:center;color:var(--muted);font-size:11px;padding:20px">No presets match</div>';
    grid.innerHTML = html;
    grid.style.position = "relative";
    grid._built = true;

    var previews = grid.querySelectorAll(".text-preview");
    for (var p = 0; p < previews.length; p++) {
      var el = previews[p];
      var item = findItem(el.getAttribute("data-preview-for"));
      if (item) applyCardVars(el, item);
    }
    bindGrid(grid);
  }

  function renderGrid(animate) {
    var grid = $("text-grid");
    if (!grid) return;
    var first = !grid._built;
    if (first) buildGrid(grid);
    var cards = grid.querySelectorAll(".text-card");
    var show = [], count = 0;
    for (var i = 0; i < cards.length; i++) {
      var it = findItem(cards[i].getAttribute("data-text-id"));
      show[i] = !!it && passesFilter(it);
      if (show[i]) count++;
    }
    var empty = grid.querySelector(".text-grid-empty");
    if (empty) empty.style.display = count ? "none" : "";
    if (window.PillowListFx) {
      window.PillowListFx.apply(grid, cards, show, { animate: !first && animate !== false });
    }
  }

  function bindGrid(grid) {
    grid.onclick = function (ev) {
      var fav = ev.target.closest ? ev.target.closest("[data-fav]") : null;
      if (fav && window.PillowFav) {
        ev.preventDefault();
        ev.stopPropagation();
        var id = fav.getAttribute("data-fav");
        var on = window.PillowFav.toggle(window.PillowFav.TEXT, id);
        fav.className = "fav-star" + (on ? " on" : "");
        fav.textContent = on ? "★" : "☆";
        if (state.favsOnly) renderGrid();
        return;
      }
      var card = ev.target.closest ? ev.target.closest(".text-card") : null;
      if (!card) return;
      selectPreset(card.getAttribute("data-text-id"), card);
    };

    // Avoid stacking listeners on re-render: use onmouseenter pattern via one delegated pair
    if (!grid._previewBound) {
      grid._previewBound = true;
      grid.addEventListener("pointerover", function (ev) {
        if (!state.active) return;
        var card = ev.target.closest ? ev.target.closest(".text-card") : null;
        if (!card || card === grid._hoverCard) return;
        grid._hoverCard = card;
        var preview = card.querySelector(".text-preview");
        var item = findItem(card.getAttribute("data-text-id"));
        if (preview && item) startCardPreview(preview, item);
      }, true);
      grid.addEventListener("pointerout", function (ev) {
        var card = ev.target.closest ? ev.target.closest(".text-card") : null;
        if (!card) return;
        var related = ev.relatedTarget;
        if (related && card.contains(related)) return;
        if (grid._hoverCard === card) grid._hoverCard = null;
        var preview = card.querySelector(".text-preview");
        if (preview) stopCardPreview(preview);
      }, true);
    }

    if (window.pillowRescanTactile) window.pillowRescanTactile();
  }

  function refreshAllCardVars() {
    var grid = $("text-grid");
    if (!grid) return;
    var previews = grid.querySelectorAll(".text-preview");
    for (var p = 0; p < previews.length; p++) {
      var el = previews[p];
      var item = findItem(el.getAttribute("data-preview-for"));
      if (!item) continue;
      el.innerHTML = buildPreviewMarkup(state.previewText, item.basedOn);
      applyCardVars(el, item);
    }
  }

  function clearActiveCard() {
    var rows = document.querySelectorAll(".text-card.active");
    for (var i = 0; i < rows.length; i++) rows[i].classList.remove("active");
  }

  function selectPreset(id, cardEl) {
    var item = findItem(id);
    if (!item) return;
    state.activeId = id;
    var lab = $("btn-text-apply-label");
    if (lab) lab.textContent = item.name;
    state.settings = settingsFromItem(item);
    if (item.forceDir) setDirection(item.forceDir, false);
    clearActiveCard();
    if (cardEl) cardEl.classList.add("active");
    syncSettingsInputs();
  }

  function setDirection(dir) {
    state.direction = dir === "out" ? "out" : "in";
    var box = $("inout-switch");
    var btns = box ? box.querySelectorAll(".inout-btn") : [];
    for (var i = 0; i < btns.length; i++) {
      btns[i].className = "inout-btn" + (btns[i].getAttribute("data-dir") === state.direction ? " active" : "");
    }
  }

  function syncSettingsInputs() {
    var s = state.settings;
    setSlider("sl-t-duration", s.duration, function (v) { return v.toFixed(2) + "s"; });
    setSlider("sl-t-delay", s.delay, function (v) { return Math.round(v * 1000) + "ms"; });
    setSlider("sl-t-stagger", s.stagger, function (v) { return Math.round(v * 1000) + "ms"; });
    setSlider("sl-t-blur", s.blur, function (v) { return Math.round(v) + "px"; });
    setSlider("sl-t-distance", s.distance, function (v) { return Math.round(v) + "px"; });
    setSlider("sl-t-scale", s.scale, function (v) { return Math.round(v) + "%"; });
    setSlider("sl-t-rotation", s.rotation, function (v) { return Math.round(v) + "°"; });
    setSlider("sl-t-opacity", s.opacity, function (v) { return Math.round(v) + "%"; });
  }
  function setSlider(id, value, fmt) {
    var el = $(id);
    if (!el) return;
    el.value = value;
    var lab = $(id + "-val");
    if (lab) lab.textContent = fmt(value);
  }
  function bindSlider(id, key, fmt) {
    var el = $(id);
    if (!el) return;
    el.oninput = function () {
      state.settings[key] = parseFloat(this.value);
      var lab = $(id + "-val");
      if (lab) lab.textContent = fmt(state.settings[key]);
    };
  }

  function buildPayload() {
    var item = findItem(state.activeId);
    if (!item) return null;
    var s = state.settings;
    var dd = computeDxDy(item, s.distance);
    // Always pass scale/rotate when user moved sliders away from neutral OR preset defines them
    var scaleVal = null;
    if (item.scaleFrom != null || s.scale !== 100) scaleVal = s.scale;
    var rotVal = null;
    if (item.rotate != null || s.rotation !== 0) rotVal = s.rotation;
    return {
      presetId: item.id,
      direction: state.direction,
      text: state.previewText,
      updateText: !!state.updateText,
      basedOn: item.basedOn,
      duration: s.duration,
      delay: s.delay,
      dx: dd.dx,
      dy: dd.dy,
      blur: s.blur,
      scaleFrom: scaleVal,
      rotate: rotVal,
      tracking: item.tracking || 0,
      opacityFrom: s.opacity,
      smoothness: item.smoothness,
      flicker: !!item.flicker,
      /* per-letter (word, line) presets are driven per unit on the
         preset's curve, exactly as the preview draws them */
      expr: item.expr || (item.basedOn !== "all" && !item.flicker ? "ease" : null),
      ease: bezierOf(item),
      freq: springFreq(item, s.duration),
      amp: item.amp,
      scaleXY: item.scaleXY,
      rel: item.rel,
      stagger: s.stagger
    };
  }

  function applyToAENow() {
    var payload = buildPayload();
    if (!payload) return;
    var json = JSON.stringify(payload);
    host('pillowApplyTextPreset("' + esc(json) + '")', function (r) {
      if (r.ok) {
        var nm = (findItem(payload.presetId) || {}).name || "Text";
        toast(nm + " · " + payload.direction.toUpperCase() + (r.created ? " · new layer" : " applied"));
      } else {
        toast(r.error || "Failed", true);
      }
    });
  }

  function applyToAE() {
    if (applyDebounceT) clearTimeout(applyDebounceT);
    applyDebounceT = setTimeout(function () {
      applyDebounceT = null;
      applyToAENow();
    }, 120);
  }

  function bindControls() {
    var previewInput = $("inp-preview-text");
    if (previewInput) {
      previewInput.oninput = function () {
        var v = this.value || "Pillow";
        if (previewInputT) clearTimeout(previewInputT);
        previewInputT = setTimeout(function () {
          state.previewText = v;
          if (state.active) refreshAllCardVars();
        }, 100);
      };
    }

    var upd = $("toggle-update-text");
    if (upd) {
      upd.onclick = function () {
        state.updateText = !state.updateText;
        this.className = "switch" + (state.updateText ? " on" : "");
        this.setAttribute("aria-checked", state.updateText ? "true" : "false");
      };
    }

    /* Split into letters / words / lines — one text layer per piece */
    var splitMode = "letters";
    var SPLIT_LABEL = { letters: "Split into Letters", words: "Split into Words", lines: "Split into Lines" };
    var splitBox = $("split-switch");
    if (splitBox) {
      splitBox.onclick = function (ev) {
        var b = ev.target.closest ? ev.target.closest("[data-split]") : null;
        if (!b) return;
        splitMode = b.getAttribute("data-split");
        var bs = splitBox.querySelectorAll(".inout-btn");
        for (var i = 0; i < bs.length; i++) bs[i].classList.toggle("active", bs[i] === b);
        if ($("btn-text-split-label")) $("btn-text-split-label").textContent = SPLIT_LABEL[splitMode];
      };
    }
    if ($("btn-text-split")) {
      $("btn-text-split").onclick = function () {
        host('pillowSplitText("' + splitMode + '")', function (r) {
          if (!r.ok) { toast(r.error || "Failed", true); return; }
          var what = splitMode === "letters" ? "letter" : splitMode === "words" ? "word" : "line";
          toast(r.warning ? r.warning : "Split into " + r.count + " " + what + (r.count === 1 ? "" : "s"), !!r.warning);
        });
      };
    }

    var inoutBox = $("inout-switch");
    if (inoutBox) {
      inoutBox.onclick = function (ev) {
        var b = ev.target.closest ? ev.target.closest("[data-dir]") : null;
        if (!b) return;
        setDirection(b.getAttribute("data-dir"));
      };
    }

    var dirRow = document.querySelector("#text-settings-basic .dir-row");
    if (dirRow) {
      dirRow.onclick = function (ev) {
        var b = ev.target.closest ? ev.target.closest("[data-dir]") : null;
        if (!b) return;
        state.dial = b.getAttribute("data-dir");
        var btns = dirRow.querySelectorAll(".dir-btn");
        for (var i = 0; i < btns.length; i++) {
          btns[i].className = "dir-btn" + (btns[i].getAttribute("data-dir") === state.dial ? " active" : "");
        }
        refreshAllCardVars();
      };
    }

    var tabs = $("settings-tabs");
    if (tabs) {
      tabs.onclick = function (ev) {
        var b = ev.target.closest ? ev.target.closest("[data-level]") : null;
        if (!b) return;
        state.settingsLevel = b.getAttribute("data-level");
        var btns = tabs.querySelectorAll(".settings-tab");
        for (var i = 0; i < btns.length; i++) {
          btns[i].className = "settings-tab" + (btns[i].getAttribute("data-level") === state.settingsLevel ? " active" : "");
        }
        var basic = $("text-settings-basic");
        var adv = $("text-settings-advanced");
        if (basic) basic.className = "glass-panel" + (state.settingsLevel === "basic" ? "" : " hidden");
        if (adv) adv.className = "glass-panel" + (state.settingsLevel === "advanced" ? "" : " hidden");
      };
    }

    var filter = $("inp-text-filter");
    if (filter) {
      filter.oninput = function () {
        var v = this.value || "";
        if (filterDebounceT) clearTimeout(filterDebounceT);
        filterDebounceT = setTimeout(function () {
          state.filter = v;
          renderGrid();
        }, 80);
      };
    }
    var favOnly = $("btn-text-favs-only");
    if (favOnly) {
      favOnly.onclick = function () {
        state.favsOnly = !state.favsOnly;
        this.classList.toggle("on", state.favsOnly);
        this.style.color = state.favsOnly ? "var(--accent-soft)" : "";
        renderGrid();
      };
    }

    bindSlider("sl-t-duration", "duration", function (v) { return v.toFixed(2) + "s"; });
    bindSlider("sl-t-delay", "delay", function (v) { return Math.round(v * 1000) + "ms"; });
    bindSlider("sl-t-stagger", "stagger", function (v) { return Math.round(v * 1000) + "ms"; });
    bindSlider("sl-t-blur", "blur", function (v) { return Math.round(v) + "px"; });
    bindSlider("sl-t-distance", "distance", function (v) { return Math.round(v) + "px"; });
    bindSlider("sl-t-scale", "scale", function (v) { return Math.round(v) + "%"; });
    bindSlider("sl-t-rotation", "rotation", function (v) { return Math.round(v) + "°"; });
    bindSlider("sl-t-opacity", "opacity", function (v) { return Math.round(v) + "%"; });

    var applyBtn = $("btn-text-apply");
    if (applyBtn) applyBtn.onclick = applyToAE;
  }

  function initText() {
    var def = findItem(state.activeId);
    state.settings = settingsFromItem(def);
    renderCats();
    renderGrid();
    bindControls();
    syncSettingsInputs();
    var lab = $("btn-text-apply-label");
    if (lab && def) lab.textContent = def.name;
  }

  function pauseText() {
    state.active = false;
    clearPreviewTimers();
    var grid = $("text-grid");
    if (grid) grid._hoverCard = null;
  }
  function resumeText() {
    state.active = true;
  }
  function toggleFavsOnly() {
    state.favsOnly = !state.favsOnly;
    var btn = $("btn-text-favs-only");
    if (btn) {
      btn.classList.toggle("on", state.favsOnly);
      btn.style.color = state.favsOnly ? "var(--accent-soft)" : "";
    }
    renderGrid();
  }

  window.PillowText = {
    init: initText,
    pause: pauseText,
    resume: resumeText,
    apply: applyToAE,
    toggleFavsOnly: toggleFavsOnly
  };

  document.addEventListener("DOMContentLoaded", initText);
})();
