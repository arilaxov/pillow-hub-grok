/* Pillow — iOS Liquid Glass on the main buttons (Apply, Apply Bounce,
 * Make Ring, Morph…: every #app .btn-primary).
 *
 * The button becomes a clear glass capsule: a light tint over a blurred,
 * saturated backdrop, a specular rim (bright on the edge facing the light,
 * weaker on the opposite one, from a canvas map of the capsule's bevel),
 * a soft inner shade along the rim and a drop shadow.
 *
 * Like iOS 26, the glass reacts to the finger rather than sinking: under
 * the pointer a soft light follows it, and on press the capsule swells a
 * little and lights up, then settles back on a spring. Springs run only
 * while moving. The button's own markup, ids and click handlers are kept.
 */
(function () {
  "use strict";
  if (window.PillowGlassButton) return;

  var SEL = "#app .btn-primary";
  var MAPS = {};

  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }

  /* specular rim and inner shade for a w × h capsule */
  function buildMaps(w, h, radius, bevel) {
    var key = w + ":" + h + ":" + radius + ":" + bevel;
    if (MAPS[key]) return MAPS[key];
    var res = 2, W = Math.max(8, Math.round(w * res)), H = Math.max(8, Math.round(h * res));
    var cv = document.createElement("canvas");
    cv.width = W; cv.height = H;
    var ctx = cv.getContext("2d");
    if (!ctx) return null;
    var shine = ctx.createImageData(W, H), shade = ctx.createImageData(W, H);
    var r = Math.min(radius * res, W / 2, H / 2), band = Math.max(1, bevel * res);
    var hw = W / 2, hh = H / 2, lx = -0.55, ly = -0.83;
    for (var y = 0; y < H; y++) {
      for (var x = 0; x < W; x++) {
        var px = x + 0.5 - hw, py = y + 0.5 - hh;
        var qx = Math.abs(px) - (hw - r), qy = Math.abs(py) - (hh - r);
        var ox = Math.max(qx, 0), oy = Math.max(qy, 0);
        var distance = Math.sqrt(ox * ox + oy * oy) + Math.min(Math.max(qx, qy), 0) - r;
        var nx = 0, ny = 0;
        if (qx > 0 && qy > 0) {
          var len = Math.sqrt(ox * ox + oy * oy) || 1;
          nx = (ox / len) * (px < 0 ? -1 : 1); ny = (oy / len) * (py < 0 ? -1 : 1);
        } else if (qx > qy) nx = px < 0 ? -1 : 1;
        else ny = py < 0 ? -1 : 1;
        var inside = -distance;
        var t = inside >= band ? 0 : inside <= 0 ? 1 : 1 - inside / band;
        var i = (y * W + x) * 4;
        var facing = nx * lx + ny * ly;
        var edge = inside <= 0 ? 0 : Math.min(1, inside / (0.8 * res));
        var glow = (Math.max(0, facing) * 1 + Math.max(0, -facing) * 0.45) * t * t * t * edge;
        shine.data[i] = shine.data[i + 1] = shine.data[i + 2] = 255;
        shine.data[i + 3] = Math.round(255 * Math.min(1, glow));
        var dim = (Math.max(0, -facing) * 0.6 + 0.4) * t * t * edge;
        shade.data[i + 3] = Math.round(255 * Math.min(1, dim));
      }
    }
    ctx.putImageData(shine, 0, 0);
    var shineUrl = cv.toDataURL();
    ctx.putImageData(shade, 0, 0);
    var shadeUrl = cv.toDataURL();
    return (MAPS[key] = { shine: shineUrl, shade: shadeUrl });
  }

  function drive(v, vel, target, k, c, dt) {
    var next = vel + (k * (target - v) - c * vel) * dt;
    return [v + next * dt, next];
  }

  function span(cls) { var s = document.createElement("span"); s.className = cls; s.setAttribute("aria-hidden", "true"); return s; }

  function dress(btn) {
    if (btn.__gb) return;
    var glass = span("pl-gb-glass"), shade = span("pl-gb-shade"), shine = span("pl-gb-shine"), light = span("pl-gb-light");
    glass.appendChild(shade); glass.appendChild(light); glass.appendChild(shine);
    /* loose text gets a span so it can sit above the glass */
    for (var n = btn.firstChild; n; n = n.nextSibling) {
      if (n.nodeType === 3 && n.nodeValue.trim()) {
        var lab = document.createElement("span"); lab.className = "pl-gb-label";
        btn.replaceChild(lab, n); lab.appendChild(n); n = lab;
      }
    }
    btn.insertBefore(glass, btn.firstChild);
    btn.classList.add("pl-gbtn");

    /* h: hover, p: press, x/y: light position (0..1) */
    var g = btn.__gb = { w: 0, h: 0, h0: 0, hv: 0, ht: 0, p: 0, pv: 0, pt: 0,
      x: 0.5, xv: 0, xt: 0.5, y: 0.5, yv: 0, yt: 0.5, raf: 0, last: 0 };

    function measure() {
      var w = btn.offsetWidth, h = btn.offsetHeight;
      if (!w || !h || (w === g.w && h === g.h)) return;
      g.w = w; g.h = h;
      var radius = Math.round(h / 2);
      btn.style.setProperty("--gb-radius", radius + "px");
      var m = buildMaps(w, h, radius, Math.max(2, Math.round(h * 0.16)));
      if (m) { shade.style.backgroundImage = "url(" + m.shade + ")"; shine.style.backgroundImage = "url(" + m.shine + ")"; }
      apply();
    }
    function apply() {
      var h = g.h || 42, w = g.w || 120;
      /* swell on press: a few px either way, the same on wide and narrow buttons */
      var sx = 1 + g.p * Math.min(0.06, 6 / w), sy = 1 + g.p * Math.min(0.12, 5 / h);
      glass.style.transform = "scale(" + sx.toFixed(4) + "," + sy.toFixed(4) + ")";
      light.style.opacity = (0.35 * g.h0 + 0.65 * g.p).toFixed(3);
      light.style.backgroundPosition = (g.x * 100).toFixed(1) + "% " + (g.y * 100).toFixed(1) + "%";
      btn.style.setProperty("--gb-face-s", (1 + g.p * 0.02).toFixed(4));
    }
    function tick(now) {
      g.raf = 0;
      var t = now / 1000, dt = g.last ? Math.min(1 / 30, t - g.last) : 1 / 60;
      g.last = t;
      var steps = Math.max(1, Math.ceil(dt * 240)), hs = dt / steps, k, r;
      for (k = 0; k < steps; k++) {
        r = drive(g.h0, g.hv, g.ht, 170, 24, hs); g.h0 = r[0]; g.hv = r[1];
        r = drive(g.p, g.pv, g.pt, 320, 18, hs); g.p = r[0]; g.pv = r[1];   /* a touch of bounce */
        r = drive(g.x, g.xv, g.xt, 160, 26, hs); g.x = r[0]; g.xv = r[1];
        r = drive(g.y, g.yv, g.yt, 160, 26, hs); g.y = r[0]; g.yv = r[1];
      }
      var moving = Math.abs(g.ht - g.h0) > 0.0005 || Math.abs(g.hv) > 0.001 || Math.abs(g.pt - g.p) > 0.0005 || Math.abs(g.pv) > 0.001 ||
        Math.abs(g.xt - g.x) > 0.0005 || Math.abs(g.xv) > 0.001 || Math.abs(g.yt - g.y) > 0.0005 || Math.abs(g.yv) > 0.001;
      apply();
      if (moving) g.raf = requestAnimationFrame(tick); else g.last = 0;
    }
    function wake() {
      var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (reduce) { g.h0 = g.ht; g.p = g.pt; g.x = g.xt; g.y = g.yt; apply(); return; }
      if (!g.raf) g.raf = requestAnimationFrame(tick);
    }
    function aim(e) {
      var rc = btn.getBoundingClientRect();
      g.xt = clamp((e.clientX - rc.left) / rc.width, 0, 1);
      g.yt = clamp((e.clientY - rc.top) / rc.height, 0, 1);
    }
    btn.addEventListener("pointerenter", function (e) { aim(e); if (!g.h0) { g.x = g.xt; g.y = g.yt; } if (e.pointerType !== "touch") g.ht = 1; wake(); });
    btn.addEventListener("pointerleave", function () { g.ht = 0; g.pt = 0; wake(); });
    btn.addEventListener("pointermove", function (e) { aim(e); wake(); });
    btn.addEventListener("pointerdown", function (e) { if (btn.disabled) return; aim(e); g.pt = 1; wake(); });
    btn.addEventListener("pointerup", function () { g.pt = 0; wake(); });
    btn.addEventListener("pointercancel", function () { g.pt = 0; wake(); });

    measure();
    if (window.ResizeObserver) new ResizeObserver(measure).observe(btn);
  }

  function scan(root) {
    var list = (root && root.querySelectorAll ? root : document).querySelectorAll(SEL);
    for (var i = 0; i < list.length; i++) dress(list[i]);
  }
  function boot() {
    scan(document);
    new MutationObserver(function () {
      var list = document.querySelectorAll(SEL);
      for (var i = 0; i < list.length; i++) if (!list[i].__gb) dress(list[i]);
    }).observe(document.getElementById("app") || document.body, { childList: true, subtree: true });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  window.PillowGlassButton = { scan: scan };
})();
