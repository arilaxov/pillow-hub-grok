/* Pillow — SFX library.
 *
 * The sounds are Pillow's own, synthesized by tools/sfx-gen.py into
 * sfx/*.wav, with their categories, lengths and waveforms in
 * js/sfx-data.js (window.PILLOW_SFX). A card plays its sound (the bars
 * fill as it plays); + imports it into the project (folder "Pillow SFX",
 * once) and puts it in the active comp at the playhead.
 */

(function () {
  "use strict";

  var SOUNDS = (window.PILLOW_SFX || []).map(function (s) {
    return { name: s.name, cat: s.cat, file: s.file, sec: s.dur, dur: s.dur.toFixed(1) + "s", peaks: s.peaks };
  });
  /* the categories in the order the sounds come */
  var CATS = ["All"];
  for (var c0 = 0; c0 < SOUNDS.length; c0++) if (CATS.indexOf(SOUNDS[c0].cat) < 0) CATS.push(SOUNDS[c0].cat);

  var BARS = 26;
  var state = { cat: "All", q: "", playing: null };
  var _filterTimer = null;

  function el(id) { return document.getElementById(id); }

  /** Deterministic bar heights — stable per sound, so a card always looks
   *  like the same waveform instead of reshuffling on every re-render. */
  function waveHeights(seedStr) {
    var seed = 0;
    for (var s = 0; s < seedStr.length; s++) seed = (seed * 31 + seedStr.charCodeAt(s)) % 100000;
    var out = [];
    for (var i = 0; i < BARS; i++) {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      var r = (seed / 0x7fffffff);
      // envelope: quiet at the edges, fuller through the middle
      var env = 0.45 + 0.55 * Math.sin((Math.PI * (i + 0.5)) / BARS);
      out.push(Math.max(2, Math.round(14 * env * (0.35 + 0.65 * r))));
    }
    return out;
  }

  function waveMarkup(item) {
    /* the sound's own waveform (peaks per bar, 0..1) */
    var h = item.peaks ? item.peaks.map(function (v) { return Math.max(2, Math.round(2 + 12 * v)); }) : waveHeights(item.name);
    var html = "";
    for (var i = 0; i < h.length; i++) {
      html += '<i style="height:' + h[i] + "px;animation-delay:" + (i * 34) + 'ms"></i>';
    }
    return html;
  }

  function matches(item) {
    if (state.cat !== "All" && item.cat !== state.cat) return false;
    if (!state.q) return true;
    return (item.name + " " + item.cat).toLowerCase().indexOf(state.q) !== -1;
  }

  function renderCats() {
    var host = el("sfx-cats");
    if (!host) return;
    var html = "";
    for (var i = 0; i < CATS.length; i++) {
      html +=
        '<button type="button" class="text-cat' + (CATS[i] === state.cat ? " active" : "") +
        '" data-sfx-cat="' + CATS[i] + '">' + CATS[i] + "</button>";
    }
    host.innerHTML = html;
    host.onclick = function (ev) {
      var b = ev.target.closest ? ev.target.closest("[data-sfx-cat]") : null;
      if (!b) return;
      var cat = b.getAttribute("data-sfx-cat");
      if (cat === state.cat) return;
      state.cat = cat;
      /* только переключаем .active — без пересборки кнопок */
      var btns = host.querySelectorAll("[data-sfx-cat]");
      for (var j = 0; j < btns.length; j++) btns[j].classList.toggle("active", btns[j] === b);
      renderList();
    };
    if (window.pillowRescanTactile) window.pillowRescanTactile();
  }

  /* Карточки строятся один раз; категория и поиск только показывают /
     прячут их с анимацией (js/list-fx.js) — без пересборки innerHTML. */
  function buildList(host) {
    var html = "";
    for (var j = 0; j < SOUNDS.length; j++) {
      var it = SOUNDS[j];
      html +=
        '<article class="card" data-sfx-card="' + j + '">' +
          '<div class="sfx-row" data-sfx="' + it.name + '">' +
            '<button type="button" class="sfx-play" data-sfx-play="' + it.name + '" title="Preview ' + it.name + '" aria-label="Preview ' + it.name + '">' +
              '<svg class="ico-play" viewBox="0 0 24 24" width="11" height="11" aria-hidden="true"><path fill="currentColor" d="M8 5.5l11 6.5-11 6.5z"/></svg>' +
            "</button>" +
            '<div class="sfx-info">' +
              '<div class="sfx-head"><span class="sfx-name">' + it.name + '</span><span class="sfx-dur">' + it.dur + "</span></div>" +
              '<div class="sfx-wave">' + waveMarkup(it) + "</div>" +
            "</div>" +
            '<button type="button" class="sfx-add" data-sfx-add="' + it.name + '" title="Add to project" aria-label="Add ' + it.name + ' to project">' +
              '<svg class="ico-plus" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true"><path d="M12 6v12M6 12h12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>' +
              '<svg class="ico-check" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true"><path d="M5.5 12.5l4 4 9-9" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            "</button>" +
          "</div>" +
        "</article>";
    }
    host.innerHTML = html;
    host._built = true;
    if (window.pillowRescanTactile) window.pillowRescanTactile();
  }

  function renderList(animate) {
    var host = el("sfx-list");
    if (!host) return;
    var first = !host._built;
    if (first) buildList(host);

    var cards = host.querySelectorAll("[data-sfx-card]");
    var show = [], shownCount = 0;
    for (var i = 0; i < cards.length; i++) {
      var it = SOUNDS[+cards[i].getAttribute("data-sfx-card")];
      show[i] = !!it && matches(it);
      if (show[i]) shownCount++;
      /* спрятанный звук не должен остаться «играющим» */
      else if (it && state.playing === it.name) stopPlaying();
    }

    var empty = el("sfx-empty");
    if (empty) empty.className = "sfx-empty" + (shownCount ? " hidden" : "");
    var count = el("sfx-count");
    if (count) {
      count.textContent =
        shownCount === SOUNDS.length
          ? SOUNDS.length + " Sounds"
          : shownCount + " of " + SOUNDS.length;
    }
    if (window.PillowListFx) {
      window.PillowListFx.apply(host, cards, show, { animate: !first && animate !== false });
    }
  }

  /* ── playback ─────────────────────────────────────────────────── */
  var audio = null, progRaf = 0;
  function byName(name) { for (var i = 0; i < SOUNDS.length; i++) if (SOUNDS[i].name === name) return SOUNDS[i]; return null; }
  function bars(row) { return row ? row.querySelectorAll(".sfx-wave i") : []; }
  function clearBars() { var on = document.querySelectorAll("#sfx-list .sfx-wave i.on"); for (var i = 0; i < on.length; i++) on[i].classList.remove("on"); }
  function progress(row) {
    progRaf = 0;
    if (!audio || !row) return;
    var d = audio.duration || 1, p = Math.min(1, audio.currentTime / d), b = bars(row), k = Math.round(p * b.length);
    for (var i = 0; i < b.length; i++) b[i].classList.toggle("on", i < k);
    /* play() starts a moment later: keep going until it ends or stops */
    if (!audio.ended) progRaf = requestAnimationFrame(function () { progress(row); });
  }
  function stopAudio() {
    if (progRaf) cancelAnimationFrame(progRaf);
    progRaf = 0;
    if (audio) { try { audio.pause(); } catch (e) {} audio.onended = null; audio = null; }
    clearBars();
  }

  function stopPlaying() {
    stopAudio();
    var all = document.querySelectorAll("#sfx-list .sfx-play.playing");
    for (var i = 0; i < all.length; i++) {
      all[i].className = "sfx-play";
      all[i].innerHTML = playIcon();
      if (all[i].parentNode) all[i].parentNode.className = "sfx-row";
    }
    state.playing = null;
  }

  /** One sound plays at a time; a second tap stops it. */
  function togglePlay(name, btn) {
    var row = btn.parentNode;
    var wasPlaying = state.playing === name;
    stopAudio();
    var all = document.querySelectorAll("#sfx-list .sfx-play.playing");
    for (var i = 0; i < all.length; i++) {
      all[i].className = "sfx-play";
      all[i].innerHTML = playIcon();
      if (all[i].parentNode) all[i].parentNode.className = "sfx-row";
    }
    if (wasPlaying) {
      state.playing = null;
      return;
    }
    state.playing = name;
    btn.className = "sfx-play playing";
    btn.innerHTML =
      '<svg class="ico-pause" viewBox="0 0 24 24" width="11" height="11" aria-hidden="true">' +
      '<path fill="currentColor" d="M8 6h3v12H8zM13 6h3v12h-3z"/></svg>';
    row.className = "sfx-row playing";
    var it = byName(name);
    if (!it || !it.file || !window.Audio) return;
    audio = new Audio(it.file);
    var mine = audio;
    audio.onended = function () { if (audio === mine) stopPlaying(); };
    var pr = audio.play();
    if (pr && pr.catch) pr.catch(function () { if (audio === mine) stopPlaying(); });
    progress(row);
  }

  function select(card) {
    var host = el("sfx-list");
    var was = host && host.querySelector("[data-sfx-card].active");
    if (was === card) return;
    if (was) was.classList.remove("active");
    card.classList.add("active");
  }

  function playIcon() {
    return '<svg class="ico-play" viewBox="0 0 24 24" width="11" height="11" aria-hidden="true"><path fill="currentColor" d="M8 5.5l11 6.5-11 6.5z"/></svg>';
  }

  /* the sound file's path on disk, from the panel's own address */
  function diskPath(rel) {
    var u = new URL(rel, window.location.href);
    var p = decodeURIComponent(u.pathname);
    if (/^\/[A-Za-z]:\//.test(p)) p = p.slice(1);   /* Windows: /C:/… */
    return p;
  }
  function confirmAdd(name, btn) {
    if (btn._adding) return;
    var it = byName(name);
    if (!it || typeof window.host !== "function") return;
    btn._adding = true;
    var arg = JSON.stringify({ file: diskPath(it.file), name: it.name });
    window.host('pillowAddSfx("' + encodeURIComponent(arg) + '")', function (r) {
      if (!r || !r.ok) {
        btn._adding = false;
        if (typeof window.toast === "function") window.toast((r && r.error) || "Couldn't add the sound", true);
        return;
      }
      btn.className = "sfx-add added";
      if (typeof window.toast === "function") window.toast(r.inComp ? name + " added at the playhead" : name + " added to project");
      setTimeout(function () {
        btn.className = "sfx-add";
        btn._adding = false;
      }, 1300);
    });
  }

  function bind() {
    var list = el("sfx-list");
    if (list && !list._bound) {
      list._bound = true;
      list.addEventListener("click", function (ev) {
        var t = ev.target;
        var card = t.closest ? t.closest("[data-sfx-card]") : null;
        /* the sound you last touched is the selected one: the glass pill
           (js/select-ring.js) glides to it, as in Curves */
        if (card) select(card);
        var play = t.closest ? t.closest("[data-sfx-play]") : null;
        if (play) { togglePlay(play.getAttribute("data-sfx-play"), play); return; }
        var add = t.closest ? t.closest("[data-sfx-add]") : null;
        if (add) { confirmAdd(add.getAttribute("data-sfx-add"), add); return; }
        /* a tap on the row itself previews it, like a song in a list */
        var pb = card && card.querySelector("[data-sfx-play]");
        if (pb) togglePlay(pb.getAttribute("data-sfx-play"), pb);
      });
    }
    var inp = el("inp-sfx-filter");
    if (inp && !inp._bound) {
      inp._bound = true;
      inp.oninput = function () {
        var v = inp.value || "";
        if (_filterTimer) clearTimeout(_filterTimer);
        _filterTimer = setTimeout(function () {
          state.q = v.trim().toLowerCase();
          renderList();
        }, 110);
      };
    }
  }

  var built = false;

  window.PillowSfx = {
    prebuild: function () {
      if (built) return;
      built = true;
      renderCats();
      renderList();
      bind();
    },
    /** Built lazily on first visit — the cards' markup shouldn't be parsed
     *  during startup when the pane is hidden. */
    resume: function () {
      if (!built) {
        built = true;
        renderCats();
        renderList();
        bind();
      }
    },
    pause: stopPlaying
  };
})();
