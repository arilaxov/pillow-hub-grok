/* glass-switch.js — утверждённый Liquid Glass Switch в Pillow.
 *
 * Перенос один-в-один из прототипа: плоский порт официального компонента
 * Website Glass (websiteglass.com/r/glass-switch.json + /r/glass.json +
 * glass-motion) — карта смещения на canvas → feDisplacementMap, поданный
 * в backdrop-filter, плюс motion-ядро Track / spring / glide / overdrag.
 *
 * Апгрейд делается ПОВЕРХ существующих .switch: разметка, id, классы,
 * размеры, цвета и обработчики Pillow не трогаются. Заменяется только
 * ::after-палец на двухслойный thumb (solid + стеклянная линза).
 *
 * Поведение:
 *   idle        — обычный solid-палец;
 *   press/hold  — solid гаснет, проступает линза, палец растёт (gel);
 *   drag        — палец свободно едет по треку, ON/OFF НЕ меняется;
 *   release     — только теперь решается итоговое состояние, дальше spring;
 *   tap         — обычный toggle на отпускании.
 */
(function () {
  "use strict";
  if (window.PillowGlassSwitch) return;

  var PAD = 2;                 /* совпадает с .switch::after в panel.css */
  var THUMB_BG = "#fff";
  var THUMB_SHADOW = "0 1px 3px rgba(0,0,0,0.35)";
  var RIM_LENS = "inset 0 1px 1px rgba(255,255,255,0.55), inset 0 0 0 1px rgba(255,255,255,0.16), 0 6px 14px -6px rgba(0,0,0,0.6)";
  var SHEEN = "linear-gradient(135deg, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0) 40%, rgba(255,255,255,0) 62%, rgba(255,255,255,0.08) 100%)";

  /* ── карта преломления ───────────────────────────────────────────── */
  var MAPS = {};
  function cb(v) { return v < 0 ? 0 : v > 255 ? 255 : Math.round(v); }
  function sg(v) { return v < 0 ? -1 : v > 0 ? 1 : 0; }
  function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }

  function buildLensMap(w, h, radius, band, dome, res) {
    var key = w + "x" + h + "|r" + radius + "|b" + Math.round(band) + "|d" + dome;
    if (MAPS[key]) return MAPS[key];
    if (w < 1 || h < 1) return null;
    var aspect = w / h;
    var mw = aspect >= 1 ? res : Math.round(res * aspect);
    var mh = aspect >= 1 ? Math.round(res / aspect) : res;
    if (mw < 1 || mh < 1) return null;
    var c = document.createElement("canvas");
    c.width = mw; c.height = mh;
    var ctx = c.getContext("2d");
    if (!ctx) return null;
    var img = ctx.createImageData(mw, mh), buf = img.data;
    var hw = w / 2, hh = h / 2, r = Math.min(radius, hw, hh);
    band = Math.max(1, band);
    for (var y = 0; y < mh; y++) {
      for (var x = 0; x < mw; x++) {
        var px = ((x + 0.5) / mw - 0.5) * w, py = ((y + 0.5) / mh - 0.5) * h;
        var qx = Math.abs(px) - (hw - r), qy = Math.abs(py) - (hh - r);
        var ox = Math.max(qx, 0), oy = Math.max(qy, 0);
        var sdf = Math.sqrt(ox * ox + oy * oy) + Math.min(Math.max(qx, qy), 0) - r;
        var nx = 0, ny = 0;
        if (sdf < 0) {
          var depth = -sdf;
          var dx = qx > qy ? sg(px) : 0, dy = qy >= qx ? sg(py) : 0;
          if (qx > 0 && qy > 0) {
            var len = Math.sqrt(qx * qx + qy * qy) || 1;
            dx = (sg(px) * qx) / len; dy = (sg(py) * qy) / len;
          }
          var ramp = depth < band ? 1 - depth / band : 0;
          var rim = ramp * ramp * (3 - 2 * ramp);
          nx = dx * rim; ny = dy * rim;
          if (dome) {
            var u = px / hw, v = py / hh;
            var fall = Math.max(0, 1 - (u * u + v * v));
            nx += u * fall * dome; ny += v * fall * dome;
          }
        }
        var i = (y * mw + x) * 4;
        buf[i] = cb(128 + nx * 127); buf[i + 1] = cb(128 + ny * 127);
        buf[i + 2] = 128; buf[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    MAPS[key] = c.toDataURL("image/png");
    return MAPS[key];
  }

  var canRefract = null;
  function refractionSupported() {
    if (canRefract !== null) return canRefract;
    try {
      var ua = navigator.userAgent || "";
      canRefract = /\b(Chrome|Chromium|Edg|OPR|CEF)\//.test(ua) &&
        !/^((?!chrome|android).)*safari/i.test(ua) &&
        !!window.CSS && !!CSS.supports &&
        (CSS.supports("backdrop-filter", "url(#x)") || CSS.supports("-webkit-backdrop-filter", "url(#x)"));
    } catch (e) { canRefract = false; }
    return canRefract;
  }

  var SVGNS = "http://www.w3.org/2000/svg";
  function svgEl(t, a) {
    var el = document.createElementNS(SVGNS, t);
    for (var k in a) if (a.hasOwnProperty(k)) el.setAttribute(k, a[k]);
    return el;
  }
  var LENS_SEQ = 0;
  function lensFilter(size, strength, dome) {
    if (!refractionSupported()) return null;
    var band = Math.max(4, size * (0.18 + strength * 0.2));
    var map = buildLensMap(size, size, size / 2, band, dome, 180);
    if (!map) return null;
    var id = "pl-gsw-lens-" + (++LENS_SEQ);
    var f = svgEl("filter", {
      id: id, x: "0", y: "0", width: "100%", height: "100%",
      filterUnits: "objectBoundingBox", primitiveUnits: "userSpaceOnUse",
      "color-interpolation-filters": "sRGB"
    });
    var fe = svgEl("feImage", {
      result: "map", x: "0", y: "0", width: String(size), height: String(size),
      preserveAspectRatio: "none"
    });
    fe.setAttributeNS("http://www.w3.org/1999/xlink", "href", map);
    fe.setAttribute("href", map);
    f.appendChild(fe);
    f.appendChild(svgEl("feDisplacementMap", {
      "in": "SourceGraphic", in2: "map", xChannelSelector: "R", yChannelSelector: "G",
      scale: String(6 + strength * 46)
    }));
    var host = document.getElementById("pl-gsw-defs");
    if (!host) {
      host = svgEl("svg", { id: "pl-gsw-defs", "aria-hidden": "true", width: "0", height: "0" });
      host.style.position = "absolute";
      host.appendChild(svgEl("defs", {}));
      document.body.appendChild(host);
    }
    host.firstChild.appendChild(f);
    return "url(#" + id + ")";
  }

  /* ── motion-ядро ─────────────────────────────────────────────────── */
  function nowMs() { return window.performance ? performance.now() : Date.now(); }
  function reduceMotion() {
    return !!window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }
  function overdrag(over, give) {
    if (!over) return 0;
    var d = Math.abs(over);
    return sg(over) * (1 - 1 / (d / give + 1)) * give;
  }

  function Track(initial) {
    this.value = initial; this.watchers = []; this.activeStop = null;
    this.lastStamp = 0; this.speed = 0;
  }
  Track.prototype.get = function () { return this.value; };
  Track.prototype.velocity = function () { return nowMs() - this.lastStamp > 90 ? 0 : this.speed; };
  Track.prototype.push = function (next) {
    var stamp = nowMs(), dt = stamp - this.lastStamp;
    if (dt > 90) this.speed = 0;
    else if (dt > 0) this.speed = ((next - this.value) / clamp(dt, 8, 32)) * 1000;
    this.lastStamp = stamp; this.value = next;
    for (var i = 0; i < this.watchers.length; i++) this.watchers[i](next);
  };
  Track.prototype.snap = function (next) {
    this.halt(); this.speed = 0; this.lastStamp = nowMs(); this.value = next;
    for (var i = 0; i < this.watchers.length; i++) this.watchers[i](next);
  };
  Track.prototype.watch = function (fn) { this.watchers.push(fn); fn(this.value); };
  Track.prototype.claim = function (stop) { this.activeStop = stop; };
  Track.prototype.halt = function () { if (this.activeStop) this.activeStop(); this.activeStop = null; };

  function easeOutBack(pull) {
    return function (t) {
      if (t <= 0) return 0;
      if (t >= 1) return 1;
      var u = t - 1;
      return 1 + (pull + 1) * u * u * u + pull * u * u;
    };
  }
  var easeGel = easeOutBack(1.3);
  function easeSoft(t) { return t <= 0 ? 0 : t >= 1 ? 1 : 1 - Math.pow(1 - t, 3); }

  function glide(track, to, seconds, ease) {
    track.halt();
    if (seconds <= 0 || reduceMotion()) { track.snap(to); return; }
    var from = track.get(), start = -1, raf = 0, stopped = false;
    function tick(t) {
      if (stopped) return;
      if (start < 0) start = t;
      var p = Math.min((t - start) / (seconds * 1000), 1);
      track.push(from + (to - from) * ease(p));
      if (p < 1) raf = requestAnimationFrame(tick);
      else track.claim(null);
    }
    raf = requestAnimationFrame(tick);
    track.claim(function () { stopped = true; cancelAnimationFrame(raf); });
  }

  function spring(track, target, cfg) {
    cfg = cfg || {};
    var tension = cfg.tension || 320, friction = cfg.friction || 24;
    var eps = cfg.epsilon || 0.001;
    var canRest = cfg.canRest || function () { return true; };
    if (reduceMotion()) { track.snap(target()); return; }
    track.halt();
    var vel = track.velocity() / 1000, raf = 0, last = -1, stopped = false;
    track.claim(function () { stopped = true; cancelAnimationFrame(raf); });
    function tick(t) {
      if (stopped) return;
      if (last < 0) last = t;
      var dt = Math.min(Math.max((t - last) / 1000, 0), 0.032); last = t;
      var goal = target(), x = track.get();
      vel += (-tension * (x - goal) - friction * vel) * dt;
      var next = x + vel * dt;
      track.push(next);
      if (Math.abs(next - goal) < eps && Math.abs(vel) < eps * 50 && canRest()) {
        track.push(goal); track.claim(null); return;
      }
      raf = requestAnimationFrame(tick);
    }
    raf = requestAnimationFrame(tick);
  }

  /* ── апгрейд существующего .switch ───────────────────────────────── */
  function styleSheet() {
    if (document.getElementById("pl-gsw-style")) return;
    var s = document.createElement("style");
    s.id = "pl-gsw-style";
    s.textContent =
      ".switch[data-gsw]{touch-action:none;-webkit-user-select:none;user-select:none;}" +
      ".switch[data-gsw]::after{display:none!important;}";
    document.head.appendChild(s);
  }

  function upgrade(el) {
    if (el.__gsw) return;

    var thumb = document.createElement("span");
    var solid = document.createElement("span");
    var glass = document.createElement("span");
    thumb.setAttribute("data-sw-thumb", "");
    solid.setAttribute("data-sw-solid", "");
    glass.setAttribute("data-sw-glass", "");
    thumb.style.cssText = "position:absolute;border-radius:50%;transform-origin:center;will-change:transform;pointer-events:none";
    solid.style.cssText = "position:absolute;inset:0;border-radius:50%;background:" + THUMB_BG + ";box-shadow:" + THUMB_SHADOW;
    glass.style.cssText = "position:absolute;inset:0;border-radius:50%;opacity:0";
    glass.style.boxShadow = RIM_LENS;
    glass.style.backgroundImage = SHEEN;
    thumb.appendChild(solid);
    thumb.appendChild(glass);
    el.appendChild(thumb);
    el.setAttribute("data-gsw", "");

    var s = {
      el: el, thumb: thumb, solid: solid, glass: glass,
      size: 0, travel: 0, pressed: false, drag: null, want: null,
      pos: new Track(0), lift: new Track(0), deform: new Track(0)
    };
    el.__gsw = s;

    function isOn() { return el.classList.contains("on"); }

    function paint() {
      var x = s.pos.get(), l = s.lift.get(), q = s.deform.get();
      var grow = 1 + 0.16 * l;
      var sx = grow * (1 + 0.62 * q), sy = grow * (1 - 0.42 * q);
      thumb.style.transform = "translateX(" + x + "px) scale(" + sx + "," + sy + ")";
      solid.style.opacity = String(1 - l);
      glass.style.opacity = String(l);
      /* while the thumb is lifted into glass the track goes to its off
         grey: on the light "on" track the clear lens could not be seen */
      var up = l > 0.04;
      if (up !== s.lifted) { s.lifted = up; el.classList.toggle("gsw-lifted", up); }
    }
    s.pos.watch(paint); s.lift.watch(paint); s.deform.watch(paint);

    function measure() {
      var w = el.offsetWidth, h = el.offsetHeight;
      if (w < 8 || h < 8) return false;
      var size = Math.max(6, h - PAD * 2);
      if (size === s.size && w === s.w) return true;
      s.w = w; s.size = size;
      s.travel = Math.max(0, w - size - PAD * 2);
      thumb.style.top = PAD + "px";
      thumb.style.left = PAD + "px";
      thumb.style.width = size + "px";
      thumb.style.height = size + "px";
      var lf = lensFilter(size, 0.7, 0.35);
      var lb = (lf ? lf + " " : "") + "blur(1px) saturate(1.5) brightness(1.06)";
      glass.style.backdropFilter = lb;
      glass.style.setProperty("-webkit-backdrop-filter", lb);
      if (!s.pressed) { s.want = isOn() ? s.travel : 0; s.pos.snap(s.want); }
      return true;
    }
    s.measure = measure;
    /* первый замер делает ResizeObserver (до ближайшего кадра, пачкой) —
       немедленный замер на каждом переключателе форсировал раскладку */
    if (window.ResizeObserver) new ResizeObserver(measure).observe(el);
    else measure();

    function goTo(v) {
      if (s.want === v) return;
      s.want = v;
      spring(s.pos, function () { return v; }, { tension: 320, friction: 22 });
    }

    function runDeform() {
      if (reduceMotion()) return;
      spring(s.deform, function () {
        var vel = Math.abs(s.pos.velocity());
        var fromVel = 0.0026 * Math.pow(vel, 0.7);
        return clamp(Math.max(fromVel, s.pressed ? 0.14 : 0), 0, 0.34);
      }, {
        tension: 210, friction: 12,
        canRest: function () { return !s.pressed && Math.abs(s.pos.velocity()) < 0.01; }
      });
    }

    /* Внешние изменения состояния (settings, другие модули) догоняются
       пружиной — но только когда палец не удерживают. */
    new MutationObserver(function () {
      if (s.pressed) return;
      goTo(isOn() ? s.travel : 0);
    }).observe(el, { attributes: true, attributeFilter: ["class"] });

    el.addEventListener("pointerdown", function (e) {
      if (e.button !== undefined && e.button !== 0) return;
      measure();
      try { el.setPointerCapture(e.pointerId); } catch (err) { /* нет активного указателя */ }
      s.pressed = true;
      s.drag = { startX: e.clientX, from: s.pos.get(), moved: false };
      s.pos.halt();
      s.want = null;
      glide(s.lift, 1, 0.26, easeGel);
      runDeform();
    });

    el.addEventListener("pointermove", function (e) {
      if (!s.pressed || !s.drag) return;
      var dx = e.clientX - s.drag.startX;
      if (Math.abs(dx) > 3) s.drag.moved = true;
      var raw = s.drag.from + dx;
      var c = clamp(raw, 0, s.travel);
      s.pos.push(c + overdrag(raw - c, 26));   /* rubber-band за краями */
    });

    function release(cancelled) {
      if (!s.pressed) return;
      s.pressed = false;
      var d = s.drag; s.drag = null;
      glide(s.lift, 0, 0.42, easeSoft);
      /* Итоговое состояние определяется ТОЛЬКО здесь, на отпускании. */
      var next = cancelled ? isOn()
        : (d && d.moved ? s.pos.get() > s.travel / 2 : !isOn());
      el.__gswAllowClick = next !== isOn();
      s.want = null;
      goTo(next ? s.travel : 0);
      runDeform();
    }

    el.addEventListener("pointerup", function () { release(false); });
    el.addEventListener("pointercancel", function () { release(true); });
  }

  /* Клик пропускается к родным обработчикам Pillow только если на
     отпускании состояние действительно должно смениться. */
  document.addEventListener("click", function (e) {
    var el = e.target && e.target.closest ? e.target.closest("[data-gsw]") : null;
    if (!el) return;
    var allow = el.__gswAllowClick;
    el.__gswAllowClick = undefined;
    if (allow === false) { e.stopImmediatePropagation(); e.preventDefault(); }
  }, true);

  function scan(root) {
    var list = (root || document).querySelectorAll ? (root || document).querySelectorAll("button.switch") : [];
    for (var i = 0; i < list.length; i++) upgrade(list[i]);
  }

  /* Переключатели в скрытых вкладках и свёрнутых плитках на старте имеют
     нулевой размер. ResizeObserver их подхватывает, но подстраховываемся
     дешёвым обходом: читаем размер только у ещё не измеренных. */
  function sweep() {
    var list = document.querySelectorAll("button.switch[data-gsw]");
    for (var i = 0; i < list.length; i++) {
      var s = list[i].__gsw;
      if (s && !s.size) s.measure();
    }
  }

  function boot() {
    styleSheet();
    scan(document);
    setInterval(sweep, 350);
    new MutationObserver(function (recs) {
      for (var i = 0; i < recs.length; i++) {
        var added = recs[i].addedNodes;
        for (var j = 0; j < added.length; j++) {
          var n = added[j];
          if (n.nodeType !== 1) continue;
          if (n.matches && n.matches("button.switch")) upgrade(n);
          scan(n);
        }
      }
    }).observe(document.documentElement, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  window.PillowGlassSwitch = {
    upgrade: upgrade, scan: scan,
    /* Общее motion-ядро и линза — их же использует glass-slider.js,
       чтобы не держать в проекте второй экземпляр той же физики. */
    core: {
      Track: Track, spring: spring, glide: glide, overdrag: overdrag,
      easeGel: easeGel, easeSoft: easeSoft, lensFilter: lensFilter,
      reduceMotion: reduceMotion, clamp: clamp, now: nowMs
    }
  };
})();
