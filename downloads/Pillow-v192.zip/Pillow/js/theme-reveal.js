/* Pillow — смена темы: Circle Reveal.
 *
 * Эффект как у transition-kit.space/transition/circle-reveal: новая тема
 * проявляется растущим кругом из кнопки темы. Там он построен на
 * document.startViewTransition (Chrome 111+), а в After Effects CEP —
 * Chromium 88–99, поэтому снимок делается вручную:
 *
 *   1. Снимок СТАРОЙ темы: копия body в Shadow DOM поверх интерфейса.
 *      Стили страницы в shadow-дерево не попадают, поэтому туда кладётся
 *      их копия, где html / :root / body переписаны на обёртки .tr-html /
 *      .tr-body с атрибутами старой темы (data-theme, data-pl-glass …).
 *      Так в снимке работают все правила html[data-theme="…"] и
 *      инлайн-стили стекла ровно как были — снимок совпадает с экраном.
 *   2. Настоящий интерфейс сразу переключается на новую тему — под
 *      снимком, пока его не видно. Вся тяжёлая перерисовка проходит до
 *      старта анимации, а не во время неё.
 *   3. В снимке растёт круглое окно (radial-gradient маска), через него
 *      видна уже живая новая тема. Слой снимка отдельный (will-change),
 *      маска меняется без перерисовки содержимого.
 *
 * Скролл, значения полей и canvas переносятся в снимок; анимации в нём
 * стоят в конечном состоянии, переходы выключены.
 *
 * API: PillowThemeReveal.run({ x, y, apply, duration }) → true, если
 *      переход запущен (false — снимок сделать нельзя, apply() вызван сразу).
 */
(function () {
  "use strict";
  if (window.PillowThemeReveal) return;

  var DURATION = 620;
  /* плавный старт, разгон, мягкая посадка — easeInOutCubic */
  function ease(t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }

  /* ── стили страницы для shadow-дерева ─────────────────────────────── */
  var sheetCache = {};

  function readText(href) {
    try {
      var req = (window.cep_node && window.cep_node.require) || window.require;
      if (req) {
        var path = decodeURIComponent(href.replace(/^file:\/\/(localhost)?/, "")).replace(/^\/([A-Za-z]:)/, "$1");
        return req("fs").readFileSync(path, "utf8");
      }
    } catch (e) { /* нет node — пробуем XHR */ }
    try {
      var x = new XMLHttpRequest();
      x.open("GET", href, false);
      x.send(null);
      if (x.status === 0 || x.status === 200) return x.responseText;
    } catch (e2) { /* нет доступа */ }
    return null;
  }

  function rulesOf(sheet) {
    try { return sheet.cssRules; } catch (e) { return null; }
  }

  var SEL_HTML = /(^|[\s,>+~(])(?:html|:root)(?=[\s\[.:#,>+~)]|$)/g;
  var SEL_BODY = /(^|[\s,>+~(])body(?=[\s\[.:#,>+~)]|$)/g;

  /* the snapshot is not under the pointer: what is hovered now (the
     theme button itself) is marked .tr-hover and keeps its hover look */
  function rewriteSelector(sel) {
    return sel.replace(SEL_HTML, "$1.tr-html").replace(SEL_BODY, "$1.tr-body").replace(/:hover(?![\w-])/g, ".tr-hover");
  }

  function serialize(rules) {
    var out = "";
    for (var i = 0; i < rules.length; i++) {
      var r = rules[i];
      if (r.type === 1) out += rewriteSelector(r.selectorText) + "{" + r.style.cssText + "}";
      else if (r.type === 4) out += "@media " + r.media.mediaText + "{" + serialize(r.cssRules) + "}";
      else if (r.type === 12) out += "@supports " + r.conditionText + "{" + serialize(r.cssRules) + "}";
      else if (r.type === 7) out += r.cssText; /* @keyframes */
      else if (r.type === 3 && r.styleSheet) { var ir = rulesOf(r.styleSheet); if (ir) out += serialize(ir); }
      /* @font-face — шрифты документа доступны и в shadow-дереве */
    }
    return out;
  }

  /* The file's own text with only the selectors rewritten. Re-serializing
     parsed rules (cssText) loses values: a rule with a var() shorthand
     and a longhand after it (background: var(--m-grp); background-image:
     none) comes back with empty longhands, and the snapshot drops it —
     tiles and buttons lost their fill. Comments go first; then every
     prelude before "{" that is not an at-rule is a selector list; the
     block of a style rule (and of @keyframes / @font-face) is copied as
     is, @media / @supports blocks are walked into. */
  function rewriteText(text) {
    text = text.replace(/\/\*[\s\S]*?\*\//g, "");
    var out = "", i = 0, n = text.length, start = 0;
    function skipBlock(j) {
      var d = 0;
      for (; j < n; j++) {
        var ch = text.charAt(j);
        if (ch === '"' || ch === "'") { var q = ch; j++; while (j < n && text.charAt(j) !== q) { if (text.charAt(j) === "\\") j++; j++; } continue; }
        if (ch === "{") d++;
        else if (ch === "}") { d--; if (d === 0) return j + 1; }
      }
      return n;
    }
    while (i < n) {
      var c = text.charAt(i);
      if (c === "{") {
        var pre = text.slice(start, i), t = pre.replace(/^\s+/, "");
        if (t.charAt(0) === "@") {
          if (/^@(media|supports|document|layer)\b/i.test(t)) { out += pre + "{"; i++; start = i; continue; }
          var e = skipBlock(i); out += pre + text.slice(i, e); i = e; start = i; continue;
        }
        var e2 = skipBlock(i);
        out += rewriteSelector(pre) + text.slice(i, e2);
        i = e2; start = i; continue;
      }
      if (c === "}" || c === ";") { out += text.slice(start, i + 1); i++; start = i; continue; }
      if (c === '"' || c === "'") { var q2 = c; i++; while (i < n && text.charAt(i) !== q2) { if (text.charAt(i) === "\\") i++; i++; } i++; continue; }
      i++;
    }
    return out + text.slice(start);
  }

  /* относительные url() — от адреса самого файла стилей */
  function absolutize(css, base) {
    if (!base) return css;
    return css.replace(/url\((['"]?)(?!data:|#|[a-z][a-z0-9+.-]*:)([^'")]+)\1\)/gi, function (m, q, u) {
      try { return 'url("' + new URL(u, base).href + '")'; } catch (e) { return m; }
    });
  }

  function cssOfSheet(sheet) {
    var href = sheet.href;
    if (href && sheetCache[href] != null) return sheetCache[href];
    var rules = rulesOf(sheet), css = null;
    /* the source text when there is one (see rewriteText) */
    var src = href ? readText(href) : (sheet.ownerNode && sheet.ownerNode.tagName === "STYLE" ? sheet.ownerNode.textContent : null);
    if (src != null) css = rewriteText(src);
    else if (rules) css = serialize(rules);
    else if (href) {
      /* file:// в Chromium закрывает cssRules — разбираем текст файла
         через временный <style> (у встроенных стилей правила открыты) */
      var text = readText(href);
      if (text != null) {
        var tmp = document.createElement("style");
        tmp.media = "not all";
        tmp.textContent = text;
        document.head.appendChild(tmp);
        var tr = rulesOf(tmp.sheet);
        css = tr ? serialize(tr) : null;
        tmp.parentNode.removeChild(tmp);
      }
    }
    if (css == null) return null;
    css = absolutize(css, href || location.href);
    if (href) sheetCache[href] = css;
    return css;
  }

  function pageCss() {
    var parts = [];
    var sheets = document.styleSheets;
    for (var i = 0; i < sheets.length; i++) {
      var s = sheets[i];
      if (s.disabled || (s.ownerNode && s.ownerNode.media === "not all")) continue;
      var css = cssOfSheet(s);
      if (css == null) {
        if (s.href) return null; /* без основного файла снимок будет кривым */
        continue;
      }
      parts.push(css);
    }
    return parts.join("\n");
  }

  /* ── снимок ───────────────────────────────────────────────────────── */
  var SNAP_CSS =
    ":host{all:initial}" +
    ".tr-html{position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden}" +
    ".tr-body{position:relative;margin:0;width:100%;height:100%;min-height:100%}" +
    /* анимации — в их конечном состоянии, переходы не запускаются */
    "*,*::before,*::after{animation-delay:-60s!important;animation-play-state:paused!important;" +
    "transition:none!important;caret-color:transparent!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important}";

  function copyAttrs(from, to, skipClass) {
    for (var i = 0; i < from.attributes.length; i++) {
      var a = from.attributes[i];
      if (a.name === "id") continue;
      to.setAttribute(a.name, a.value);
    }
    if (skipClass) for (var k = 0; k < skipClass.length; k++) to.classList.remove(skipClass[k]);
  }

  /* Скрытые вкладки (в Curves/Text по 50+ плиток) клонируются пустыми.
     Блоки целиком за краем окна (длинные списки ниже прокрутки) — тоже:
     пустая копия того же размера держит раскладку, а содержимое, которого
     всё равно не видно, не копируется и не пересчитывается. */
  var VIEW_H = 0;
  function offscreen(node) {
    if (node.offsetHeight < 24) return false;
    var r = node.getBoundingClientRect();
    return r.bottom < -40 || r.top > VIEW_H + 40;
  }
  function cloneSkippingHidden(node, depth) {
    if (node.nodeType === 1 && node.classList.contains("pane") && node.classList.contains("hidden")) {
      return node.cloneNode(false);
    }
    if (node.nodeType === 1 && depth > 2 && node.firstChild && offscreen(node)) {
      var ph = node.cloneNode(false);
      ph.style.height = node.offsetHeight + "px";
      ph.style.minHeight = ph.style.height;
      ph.style.boxSizing = "border-box";
      return ph;
    }
    var c = node.cloneNode(false);
    for (var n = node.firstChild; n; n = n.nextSibling) {
      if (n.nodeType === 1 && (n.tagName === "SCRIPT" || n.hasAttribute("data-tr-skip"))) continue;
      c.appendChild(cloneSkippingHidden(n, (depth || 0) + 1));
    }
    return c;
  }

  /* Живое состояние, которое cloneNode не переносит. Метки ставятся на
     оригиналы перед клонированием и снимаются сразу после. */
  function markState(root) {
    var marks = [], i, el, all = root.querySelectorAll("*");
    for (i = 0; i < all.length; i++) {
      el = all[i];
      var t = el.tagName;
      if (t === "CANVAS" || t === "INPUT" || t === "TEXTAREA" || t === "SELECT" ||
          el.scrollTop || el.scrollLeft) {
        el.setAttribute("data-tr-k", String(marks.length));
        marks.push(el);
      }
    }
    return marks;
  }

  function restoreState(marks, cloneRoot) {
    var list = cloneRoot.querySelectorAll("[data-tr-k]");
    for (var i = 0; i < list.length; i++) {
      var c = list[i], o = marks[+c.getAttribute("data-tr-k")];
      c.removeAttribute("data-tr-k");
      if (!o) continue;
      var t = o.tagName;
      try {
        if (t === "CANVAS") {
          c.width = o.width; c.height = o.height;
          if (o.width && o.height) c.getContext("2d").drawImage(o, 0, 0);
        } else if (t === "INPUT" || t === "TEXTAREA") {
          c.value = o.value;
          if (o.type === "checkbox" || o.type === "radio") c.checked = o.checked;
        } else if (t === "SELECT") {
          c.selectedIndex = o.selectedIndex;
        }
      } catch (e) { /* canvas без доступа — оставляем пустым */ }
      if (o.scrollTop) c.scrollTop = o.scrollTop;
      if (o.scrollLeft) c.scrollLeft = o.scrollLeft;
    }
    for (var j = 0; j < marks.length; j++) marks[j].removeAttribute("data-tr-k");
  }

  var sheetObj = null, sheetFor = null;
  function sharedSheet(css) {
    if (sheetFor === css && sheetObj) return sheetObj;
    try {
      if (typeof CSSStyleSheet !== "function" || !("adoptedStyleSheets" in Document.prototype)) return null;
      var sh = new CSSStyleSheet();
      sh.replaceSync(css + "\n" + SNAP_CSS);
      sheetObj = sh; sheetFor = css;
      return sh;
    } catch (e) { return null; }
  }

  /* Снимок текущего состояния страницы: shadow-хост со стилями страницы
     и копией body. circle — снимок внутри круглого окна (см. run). */
  function buildSnapshot(css, circle, cx, cy, R) {
    var host = document.createElement("div");
    host.setAttribute("data-tr-skip", "");
    host.setAttribute("aria-hidden", "true");
    host.style.cssText =
      "position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:2147483647;" +
      "pointer-events:none;contain:strict;";
    var root = host.attachShadow({ mode: "open" });

    /* один разобранный лист стилей на все снимки (Chromium 73+), иначе
       <style> с копией — каждый снимок разбирает CSS заново */
    var style = null, shared = sharedSheet(css);
    if (shared) root.adoptedStyleSheets = [shared];
    else { style = document.createElement("style"); style.textContent = css + "\n" + SNAP_CSS; }
    var h = document.createElement("div");
    copyAttrs(document.documentElement, h, ["theme-wiping", "theme-wiping-vt"]);
    h.classList.add("tr-html");
    var b = document.createElement("div");
    copyAttrs(document.body, b);
    b.classList.add("tr-body");
    b.style.removeProperty("visibility"); /* настоящий body прячется на время перехода */

    VIEW_H = window.innerHeight || document.documentElement.clientHeight || 800;
    var marks = markState(document.body);
    var hov = document.querySelectorAll("body :hover"), hi;
    for (hi = 0; hi < hov.length; hi++) hov[hi].classList.add("tr-hover");
    for (var n = document.body.firstChild; n; n = n.nextSibling) {
      if (n.nodeType === 1 && (n.tagName === "SCRIPT" || n.hasAttribute("data-tr-skip"))) continue;
      b.appendChild(cloneSkippingHidden(n));
    }
    for (hi = 0; hi < hov.length; hi++) hov[hi].classList.remove("tr-hover");
    h.appendChild(b);
    if (style) root.appendChild(style);

    var snap = { host: host, body: b, marks: marks, disc: null, inner: null };
    if (circle) {
      /* Круг: диск 2R×2R со скруглением и обрезкой, масштабируется
         transform'ом; содержимое внутри масштабируется обратно (1/s)
         вокруг той же точки и стоит на месте. Оба transform'а считает
         композитор — кадры анимации ничего не перерисовывают. */
      var disc = document.createElement("div");
      disc.style.cssText =
        "position:absolute;left:" + (cx - R) + "px;top:" + (cy - R) + "px;width:" + 2 * R + "px;height:" + 2 * R + "px;" +
        "border-radius:50%;overflow:hidden;will-change:transform;transform:scale(0.0001);";
      var inner = document.createElement("div");
      inner.style.cssText =
        "position:absolute;left:" + (R - cx) + "px;top:" + (R - cy) + "px;width:100vw;height:100vh;" +
        "transform-origin:" + cx + "px " + cy + "px;will-change:transform;transform:scale(10000);";
      inner.appendChild(h);
      disc.appendChild(inner);
      root.appendChild(disc);
      snap.disc = disc;
      snap.inner = inner;
    } else {
      root.appendChild(h);
    }
    return snap;
  }

  /* ── переход ──────────────────────────────────────────────────────
   * One snapshot, of the OLD theme, over the real interface; the theme
   * flips underneath; a circular hole grows in the snapshot from the
   * button and the live new theme shows through it, crisp (nothing is
   * scaled). The earlier version built two snapshots (old and new) and
   * grew the new one in a disc scaled up from 0.0001 — three copies of
   * the interface to style (the freeze) and a layer drawn tiny and
   * stretched (the soft picture for a moment).
   * The snapshot is made ahead — when the pointer comes onto the theme
   * button (prepare) — so the click itself only flips the theme. */
  var running = null, ready = null;

  function radiusFor(x, y) {
    var w = window.innerWidth || document.documentElement.clientWidth || 360;
    var hh = window.innerHeight || document.documentElement.clientHeight || 640;
    return Math.ceil(Math.max(Math.hypot(x, y), Math.hypot(w - x, y), Math.hypot(x, hh - y), Math.hypot(w - x, hh - y))) + 2;
  }
  function setHole(host, x, y, r) {
    var m = "radial-gradient(circle at " + x.toFixed(1) + "px " + y.toFixed(1) + "px, transparent " + r.toFixed(1) + "px, #000 " + (r + 1.5).toFixed(1) + "px)";
    host.style.webkitMaskImage = m;
    host.style.maskImage = m;
  }

  /* the old-theme snapshot, laid out but not shown yet */
  function build() {
    var css = null;
    try { css = document.body && document.body.attachShadow ? pageCss() : null; } catch (e) { css = null; }
    if (css == null) return null;
    var snap = buildSnapshot(css, false);
    snap.host.style.visibility = "hidden";
    document.documentElement.appendChild(snap.host);
    restoreState(snap.marks, snap.body);
    if (window.PillowThemeIcon) window.PillowThemeIcon.adopt(snap.host.shadowRoot);
    snap.at = Date.now();
    snap.theme = document.documentElement.getAttribute("data-theme");
    return snap;
  }
  function discard() {
    if (ready && ready.host.parentNode) ready.host.parentNode.removeChild(ready.host);
    ready = null;
  }
  function prepare() {
    if (running) return;
    /* a fresh one is kept; an old one (the page moved on) is rebuilt */
    if (ready && Date.now() - ready.at < 2500 && ready.theme === document.documentElement.getAttribute("data-theme")) return;
    discard();
    try { ready = build(); } catch (e) { ready = null; }
  }

  function finish() {
    if (!running) return;
    var r = running;
    running = null;
    if (r.raf) cancelAnimationFrame(r.raf);
    if (r.snap.host.parentNode) r.snap.host.parentNode.removeChild(r.snap.host);
  }

  function run(opts) {
    var apply = opts.apply;
    if (running) finish();
    var snap = ready && Date.now() - ready.at < 2500 && ready.theme === document.documentElement.getAttribute("data-theme") ? ready : null;
    if (!snap) { discard(); try { snap = build(); } catch (e) { snap = null; } }
    ready = null;
    if (!snap) { apply(); return false; }

    var x = opts.x, y = opts.y, R = radiusFor(x, y), dur = opts.duration || DURATION;
    setHole(snap.host, x, y, 0);
    snap.host.style.visibility = "";
    apply();

    var cur = running = { snap: snap, raf: 0, x: x, y: y, R: R };
    var t0 = 0, warm = 0;
    function frame(now) {
      if (running !== cur || cur.held) return;
      /* two frames for the heavy restyle after the flip, so it does not
         eat the start of the wave */
      if (warm < 2) { warm++; cur.raf = requestAnimationFrame(frame); return; }
      if (!t0) t0 = now;
      var p = Math.min(1, (now - t0) / dur);
      setHole(snap.host, x, y, ease(p) * R);
      if (p >= 1) { finish(); return; }
      cur.raf = requestAnimationFrame(frame);
    }
    cur.raf = requestAnimationFrame(frame);
    /* safety: the panel went to the background and rAF does not come */
    setTimeout(function () { if (running === cur) finish(); }, dur + 2500);
    return true;
  }

  window.PillowThemeReveal = {
    run: run,
    prepare: prepare,
    discard: discard,
    isRunning: function () { return !!running; },
    /* frame checks: hold the wave at p (0…1) */
    seek: function (p) {
      if (!running) return false;
      running.held = true;
      setHole(running.snap.host, running.x, running.y, ease(Math.max(0, Math.min(1, p))) * running.R);
      return true;
    },
    finish: finish,
    /* the page's styles, parsed once, so the first prepare does not read files */
    warm: function () { try { var c = pageCss(); if (c != null) sharedSheet(c); } catch (e) { /* не критично */ } }
  };
})();
