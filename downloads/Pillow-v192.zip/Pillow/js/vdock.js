/* Pillow — the vertical dock ("Left" in Settings → Navigation).
 *
 * The top rail stays as it is; this is the other way to move between the
 * tabs: a tall bar on the left with a coloured bead pressed into its right
 * edge. The edge is one SVG path: where the bead sits it dips into a bowl
 * around it, joined to the straight edge by two round shoulders that are
 * tangent to both the edge and the bowl (the meniscus). The shoulder's
 * reach along the edge comes from |C1C2| = s + rb:
 *     reach = √((s + rb)² − (s + d)²)
 * where d is how deep the bowl's centre sits inside the bar. When the bead
 * moves the surface leans with it — the trailing shoulder draws out and
 * the leading one tightens — and the bead's colour slides between the
 * tabs' colours. Tap a tab, or drag the bead along the bar.
 *
 * Tabs are the top rail's own (setTab in js/panel.js); the dock follows
 * whatever is active, however it was chosen.
 */
(function () {
  "use strict";
  if (window.PillowDock) return;

  var KEY = "pillow.railLayout";
  var NAMES = {
    create: "Create", curves: "Curves", bounce: "Bounce", text: "Text", relink: "Relink",
    sfx: "SFX", music: "Music", library: "Library", glass: "Glass"
  };

  /* geometry, px */
  var W = 86, BX = 10, BW = 50, E = BX + BW;     /* bar from BX to E */
  var BEAD_R = 17, GAP = 4.5, D = -1;             /* bowl = bead + gap; its centre 1px outside */
  var S = 9;                                      /* shoulder radius at rest */
  var PAD_T = 64, PAD_B = 56;                     /* room for the logo and favourites */

  var root = null, skin = null, fillP = null, rimP = null, sheenP = null, bloomP = null, bloomG = null, frost = null, bead = null, beadIcon = null, glow = null, list = null;
  var tabs = [], slot = 44, H = 0;
  var sp = { y: 0, v: 0, to: 0, raf: 0, last: 0 }, active = "", dragging = false, ready = false;
  /* the press: the bead gives under the finger (scale toward PRESS_TO)
     and springs back past 1 when let go */
  var PRESS_TO = 0.8;
  var pr = { s: 1, v: 0, to: 1, raf: 0, last: 0 };

  function layout() { try { return localStorage.getItem(KEY) === "left" ? "left" : "top"; } catch (e) { return "top"; } }
  function f(n) { return (Math.round(n * 100) / 100).toString(); }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

  /* SVG arc from P to Q on circle (cx, cy, r) passing through M */
  function arc(r, cx, cy, P, Q, M) {
    var TAU = Math.PI * 2;
    var a1 = Math.atan2(P[1] - cy, P[0] - cx), a2 = Math.atan2(Q[1] - cy, Q[0] - cx), am = Math.atan2(M[1] - cy, M[0] - cx);
    var dq = ((a2 - a1) % TAU + TAU) % TAU, dm = ((am - a1) % TAU + TAU) % TAU;
    var sweep = dm < dq ? 1 : 0, span = sweep ? dq : TAU - dq;
    return "A" + f(r) + " " + f(r) + " 0 " + (span > Math.PI ? 1 : 0) + " " + sweep + " " + f(Q[0]) + " " + f(Q[1]);
  }
  function toward(c, p, r) { var dx = p[0] - c[0], dy = p[1] - c[1], l = Math.sqrt(dx * dx + dy * dy) || 1; return [c[0] + dx / l * r, c[1] + dy / l * r]; }

  /* the bar's outline with the socket at height y; q leans it (−1…1) */
  function barPath(y, q, mag) {
    var top = 8, bot = H - 8, R = BW / 2 - 2;
    var rb = BEAD_R + GAP, C = [E - D, y];
    var sU = S * (1 + 0.06 * mag + 0.4 * q), sL = S * (1 + 0.06 * mag - 0.4 * q);
    /* the shoulder is a rounded corner of the bar itself: its circle sits
       inside the bar, touching the edge and, from outside, the bowl */
    function shoulder(s, dir) {
      var reach = Math.sqrt(Math.max(0, (s + rb) * (s + rb) - (s - D) * (s - D)));
      var c = [E - s, y + dir * reach];
      var onEdge = [E, c[1]];
      var onBowl = toward(c, C, s);
      return { c: c, s: s, edge: onEdge, bowl: onBowl };
    }
    var u = shoulder(sU, -1), l = shoulder(sL, 1);
    var p = "M" + f(BX + R) + " " + f(top) + "L" + f(E - R) + " " + f(top) +
      "A" + f(R) + " " + f(R) + " 0 0 1 " + f(E) + " " + f(top + R);
    if (u.edge[1] > top + R && l.edge[1] < bot - R) {
      p += "L" + f(E) + " " + f(u.edge[1]);
      p += arc(u.s, u.c[0], u.c[1], u.edge, u.bowl, toward(u.c, [(u.edge[0] + u.bowl[0]) / 2, (u.edge[1] + u.bowl[1]) / 2], u.s));
      p += arc(rb, C[0], C[1], u.bowl, l.bowl, [C[0] - rb, C[1]]);
      p += arc(l.s, l.c[0], l.c[1], l.bowl, l.edge, toward(l.c, [(l.edge[0] + l.bowl[0]) / 2, (l.edge[1] + l.bowl[1]) / 2], l.s));
    }
    p += "L" + f(E) + " " + f(bot - R) +
      "A" + f(R) + " " + f(R) + " 0 0 1 " + f(E - R) + " " + f(bot) +
      "L" + f(BX + R) + " " + f(bot) +
      "A" + f(R) + " " + f(R) + " 0 0 1 " + f(BX) + " " + f(bot - R) +
      "L" + f(BX) + " " + f(top + R) +
      "A" + f(R) + " " + f(R) + " 0 0 1 " + f(BX + R) + " " + f(top) + "Z";
    return p;
  }

  function yOf(tab) { for (var i = 0; i < tabs.length; i++) if (tabs[i].tab === tab) return tabs[i].y; return tabs.length ? tabs[0].y : 0; }
  function nearest(y) {
    var best = tabs[0], bd = 1e9;
    for (var i = 0; i < tabs.length; i++) { var d = Math.abs(tabs[i].y - y); if (d < bd) { bd = d; best = tabs[i]; } }
    return best;
  }
  function paint() {
    if (!root || !H) return;
    var q = clamp(sp.v / 1400, -1, 1), mag = Math.min(4, Math.abs(sp.v) / 400);
    var d = barPath(sp.y, q, mag);
    fillP.setAttribute("d", d);
    rimP.setAttribute("d", d);
    sheenP.setAttribute("d", d);
    bloomP.setAttribute("d", d);
    bloomG.setAttribute("cy", f(sp.y));
    /* Liquid Glass: the backdrop is frosted exactly inside the outline */
    if (frost.offsetParent !== null || document.documentElement.getAttribute("data-pl-glass") === "on") frost.style.clipPath = "path('" + d + "')";
    /* a fast bead stretches a little along its way */
    var st = Math.min(0.14, Math.abs(sp.v) / 6000);
    bead.style.transform = "translate3d(" + f(E - D - BEAD_R) + "px," + f(sp.y - BEAD_R) + "px,0) scale(" + f((1 - st * 0.5) * pr.s) + "," + f((1 + st) * pr.s) + ")";
    glow.style.transform = "translate3d(" + f(E - 60) + "px," + f(sp.y - 70) + "px,0)";
  }

  function step(now) {
    var dt = sp.last ? Math.min(0.05, (now - sp.last) / 1000) : 1 / 60;
    sp.last = now;
    var n = Math.ceil(dt / 0.004), h = dt / n;
    for (var i = 0; i < n; i++) { sp.v += (-320 * (sp.y - sp.to) - 26 * sp.v) * h; sp.y += sp.v * h; }
    if (Math.abs(sp.y - sp.to) < 0.05 && Math.abs(sp.v) < 2) { sp.y = sp.to; sp.v = 0; sp.raf = 0; sp.last = 0; paint(); return; }
    paint();
    sp.raf = requestAnimationFrame(step);
  }
  function go(y, instant) {
    sp.to = y;
    if (instant || !ready) { sp.y = y; sp.v = 0; paint(); return; }
    if (!sp.raf) { sp.last = 0; sp.raf = requestAnimationFrame(step); }
  }

  function pressStep(now) {
    var dt = pr.last ? Math.min(0.05, (now - pr.last) / 1000) : 1 / 60;
    pr.last = now;
    var n = Math.ceil(dt / 0.004), h = dt / n;
    /* quick to give, springy on the way back */
    var k = pr.to < 1 ? 900 : 520, c = pr.to < 1 ? 46 : 17;
    for (var i = 0; i < n; i++) { pr.v += (-k * (pr.s - pr.to) - c * pr.v) * h; pr.s += pr.v * h; }
    if (Math.abs(pr.s - pr.to) < 0.001 && Math.abs(pr.v) < 0.01) { pr.s = pr.to; pr.v = 0; pr.raf = 0; pr.last = 0; paint(); return; }
    paint();
    pr.raf = requestAnimationFrame(pressStep);
  }
  function press(down) {
    pr.to = down ? PRESS_TO : 1;
    if (!pr.raf) { pr.last = 0; pr.raf = requestAnimationFrame(pressStep); }
  }

  function markActive(tab) {
    active = tab;
    for (var i = 0; i < tabs.length; i++) tabs[i].el.classList.toggle("active", tabs[i].tab === tab);
    var src = document.querySelector('.rail-btn[data-tab="' + tab + '"] svg');
    beadIcon.innerHTML = src ? src.outerHTML : "";
  }
  function sync(instant) {
    var a = document.querySelector(".rail-btn[data-tab].active");
    var tab = a ? a.getAttribute("data-tab") : (tabs[0] && tabs[0].tab);
    if (!tab) return;
    if (tab !== active || instant) markActive(tab);
    if (!dragging) go(yOf(tab), instant);
  }

  function measure() {
    if (!root) return;
    H = root.clientHeight;
    skin.setAttribute("width", W); skin.setAttribute("height", H);
    skin.setAttribute("viewBox", "0 0 " + W + " " + H);
    var n = tabs.length;
    slot = clamp(Math.floor((H - PAD_T - PAD_B) / Math.max(1, n)), 28, 48);
    var y0 = PAD_T + ((H - PAD_T - PAD_B) - slot * n) / 2 + slot / 2;
    for (var i = 0; i < n; i++) {
      tabs[i].y = y0 + i * slot;
      tabs[i].el.style.top = f(tabs[i].y - slot / 2) + "px";
      tabs[i].el.style.height = slot + "px";
    }
    root.style.setProperty("--vd-slot", slot + "px");
    sync(true);
  }

  function build() {
    if (root) return;
    root = document.createElement("nav");
    root.className = "vdock vdock-flat";
    root.setAttribute("aria-label", "Pillow sections");
    root.innerHTML =
      '<div class="vdock-glow" aria-hidden="true"></div>' +
      '<div class="vdock-frost" aria-hidden="true"></div>' +
      '<svg class="vdock-skin" aria-hidden="true"><defs>' +
        '<linearGradient id="vd-fill" x1="0" y1="0" x2="1" y2="0">' +
          '<stop offset="0" style="stop-color:var(--vd-fill-a)"/><stop offset="1" style="stop-color:var(--vd-fill-b)"/></linearGradient>' +
        '<linearGradient id="vd-rim" x1="0" y1="0" x2="1" y2="1">' +
          '<stop offset="0" style="stop-color:var(--vd-rim-a)"/><stop offset="0.5" style="stop-color:var(--vd-rim-b)"/><stop offset="1" style="stop-color:var(--vd-rim-a)"/></linearGradient>' +
        '<filter id="vd-shadow" x="-40%" y="-10%" width="180%" height="120%" color-interpolation-filters="sRGB"><feDropShadow dx="0" dy="10" stdDeviation="10" style="flood-color:var(--vd-shadow)"/></filter>' +
        '<linearGradient id="vd-sheen" x1="0" y1="0" x2="0" y2="1">' +
          '<stop offset="0" style="stop-color:var(--vd-sheen)"/><stop offset="0.18" style="stop-color:var(--vd-sheen);stop-opacity:0"/></linearGradient>' +
        '<radialGradient id="vd-bloom" gradientUnits="userSpaceOnUse" cx="60" cy="0" r="78">' +
          '<stop offset="0" style="stop-color:var(--vd-bloom)"/><stop offset="0.55" style="stop-color:var(--vd-bloom);stop-opacity:0.25"/>' +
          '<stop offset="1" style="stop-color:var(--vd-bloom);stop-opacity:0"/></radialGradient>' +
      '</defs><path class="vdock-fill" fill="url(#vd-fill)" filter="url(#vd-shadow)"/>' +
      '<path class="vdock-bloom" fill="url(#vd-bloom)"/>' +
      '<path class="vdock-sheen" fill="url(#vd-sheen)"/>' +
      '<path class="vdock-rim" fill="none" stroke="url(#vd-rim)" stroke-width="1"/></svg>' +
      '<button type="button" class="vdock-brand" title="Pillow Settings" aria-label="Pillow settings">' +
        '<img class="logo-img" src="icons/pillow-mark.png" alt="" width="26" height="26"/></button>' +
      '<div class="vdock-list" role="tablist"></div>' +
      '<button type="button" class="vdock-fav" title="Favorites" aria-label="Favorites"></button>' +
      '<div class="vdock-bead" aria-hidden="true"><span class="vdock-bead-i"></span></div>';
    skin = root.querySelector(".vdock-skin");
    fillP = root.querySelector(".vdock-fill");
    rimP = root.querySelector(".vdock-rim");
    sheenP = root.querySelector(".vdock-sheen");
    bloomP = root.querySelector(".vdock-bloom");
    bloomG = root.querySelector("#vd-bloom");
    frost = root.querySelector(".vdock-frost");
    bead = root.querySelector(".vdock-bead");
    beadIcon = root.querySelector(".vdock-bead-i");
    glow = root.querySelector(".vdock-glow");
    list = root.querySelector(".vdock-list");

    var src = document.querySelectorAll(".rail-btn[data-tab]");
    for (var i = 0; i < src.length; i++) {
      var t = src[i].getAttribute("data-tab");
      var b = document.createElement("button");
      b.type = "button";
      b.className = "vdock-tab";
      b.setAttribute("role", "tab");
      b.setAttribute("data-vd-tab", t);
      b.title = src[i].title;
      b.setAttribute("aria-label", src[i].getAttribute("aria-label") || t);
      b.innerHTML = '<span class="vdock-ico">' + (src[i].querySelector("svg") ? src[i].querySelector("svg").outerHTML : "") + "</span>" +
        '<span class="vdock-label">' + (NAMES[t] || t) + "</span>";
      list.appendChild(b);
      tabs.push({ tab: t, el: b, y: 0 });
    }
    var favSrc = document.getElementById("btn-show-favs");
    if (favSrc && favSrc.querySelector("svg")) root.querySelector(".vdock-fav").innerHTML = favSrc.querySelector("svg").outerHTML;

    var main = document.querySelector("#app > .main");
    main.parentNode.insertBefore(root, main);

    /* any tab pressed: the bead gives, and springs back on release */
    list.addEventListener("pointerdown", function (e) {
      if (e.target.closest && e.target.closest("[data-vd-tab]")) press(true);
    });
    window.addEventListener("pointerup", function () { if (pr.to !== 1) press(false); });
    window.addEventListener("pointercancel", function () { if (pr.to !== 1) press(false); });
    list.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-vd-tab]") : null;
      if (b && typeof window.setTab === "function") window.setTab(b.getAttribute("data-vd-tab"));
    });
    root.querySelector(".vdock-fav").addEventListener("click", function () { var fv = document.getElementById("btn-show-favs"); if (fv) fv.click(); });
    root.querySelector(".vdock-brand").addEventListener("click", function (e) {
      e.stopPropagation();
      if (window.PillowSettings) window.PillowSettings.toggle();
    });

    /* drag the bead along the bar */
    bead.addEventListener("pointerdown", function (e) {
      press(true);
      dragging = true;
      try { bead.setPointerCapture(e.pointerId); } catch (x) {}
      var r0 = root.getBoundingClientRect(), off = e.clientY - r0.top - sp.y, lastY = sp.y, lastT = performance.now();
      if (sp.raf) { cancelAnimationFrame(sp.raf); sp.raf = 0; }
      function move(ev) {
        var y = clamp(ev.clientY - r0.top - off, tabs[0].y - slot * 0.4, tabs[tabs.length - 1].y + slot * 0.4);
        var now = performance.now(), dt = Math.max(1, now - lastT);
        sp.v = sp.v * 0.6 + ((y - lastY) / dt * 1000) * 0.4;
        lastY = y; lastT = now;
        sp.y = y; sp.to = y;
        paint();
      }
      function up() {
        dragging = false;
        bead.removeEventListener("pointermove", move);
        bead.removeEventListener("pointerup", up);
        bead.removeEventListener("pointercancel", up);
        var t = nearest(sp.y);
        if (typeof window.setTab === "function" && t.tab !== active) window.setTab(t.tab);
        markActive(t.tab);
        go(t.y);
      }
      bead.addEventListener("pointermove", move);
      bead.addEventListener("pointerup", up);
      bead.addEventListener("pointercancel", up);
    });

    /* follow the active tab, however it was chosen */
    new MutationObserver(function () { sync(false); })
      .observe(document.querySelector(".rail-bar"), { subtree: true, attributes: true, attributeFilter: ["class"] });
    window.addEventListener("resize", measure);
    if (window.ResizeObserver) new ResizeObserver(measure).observe(root);
  }

  function apply(mode, animate) {
    document.documentElement.setAttribute("data-rail", mode);
    if (mode === "left") {
      build();
      ready = false;
      measure();
      ready = true;
    }
    window.dispatchEvent(new Event("resize"));
  }

  function set(mode) {
    try { localStorage.setItem(KEY, mode); } catch (e) {}
    apply(mode, true);
  }

  /* before first paint where possible: the attribute is set right away */
  document.documentElement.setAttribute("data-rail", layout());
  function init() { apply(layout(), false); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();

  window.PillowDock = { get: layout, set: set, _paint: paint, _state: sp };
})();
