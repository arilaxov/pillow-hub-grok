/* Pillow — settings
 *
 * Clicking the Pillow mark in the rail morphs the logo into a large
 * sheet over the panel (js/logo-morph.js) and the settings fade in on
 * it; closing reverses the morph back into the logo. Nothing in the
 * rail's own shape or tab behaviour is changed: the mark simply becomes
 * a toggle. Controls, ids and their handlers are unchanged.
 */

(function () {
  "use strict";

  var panel = null, open = false;

  function build() {
    if (panel) return panel;
    panel = document.createElement("div");
    panel.className = "pl-settings-sheet";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "true");
    panel.setAttribute("aria-label", "Pillow settings");
    /* Секции — GlassAccordion (websiteglass.com/r/glass-accordion.json):
       type="single", открыт один пункт; триггер py-3.5 font-medium,
       white/80 → white, шеврон 16px white/50 с поворотом за 200 мс;
       контент pb-4 white/65, высота раскрывается за 300 мс ease-out;
       пункты px-4 через hairline-разделители. Значение пункта видно в
       триггере, чтобы свёрнутая секция не прятала текущую настройку. */
    var CHEVRON = '<svg class="pl-acc-chev" viewBox="0 0 16 16" fill="none" aria-hidden="true">' +
      '<path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    function item(key, label, metaId, body) {
      return '<div class="pl-acc-item" data-acc="' + key + '">' +
        '<button type="button" class="pl-acc-trigger" aria-expanded="false">' +
          '<span class="pl-acc-label">' + label + '</span>' +
          '<span class="pl-acc-meta" id="' + metaId + '"></span>' + CHEVRON +
        '</button>' +
        '<div class="pl-acc-content"><div class="pl-acc-inner">' + body + '</div></div>' +
      '</div>';
    }
    panel.innerHTML =
      '<div class="pl-settings-body">' +
      '<div class="pl-settings-head">' +
        '<span class="pl-settings-title">Settings</span>' +
        '<button type="button" class="pl-settings-close" id="pl-set-close" aria-label="Close">' +
          /* SVG, а не символ «×»: у глифа своя посадка в шрифте, и он
             стоял не по центру кружка */
          '<svg viewBox="0 0 12 12" width="11" height="11" fill="none" aria-hidden="true">' +
          '<path d="M2.5 2.5l7 7M9.5 2.5l-7 7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>' +
        '</button>' +
      '</div>' +
      '<div class="pl-acc">' +
      item("glass", "Liquid Glass", "pl-set-glass-val",
        '<div class="toggle-row">' +
          '<span>Glass mode</span>' +
          '<button type="button" class="switch" id="pl-set-glass" role="switch" aria-checked="false" aria-label="Liquid Glass"></button>' +
        '</div>' +
        '<div class="pl-settings-hint">ON — glass look for Pillow surfaces, OFF — the classic monochrome look.</div>') +
      item("lang", "Language", "pl-set-lang-val",
        '<div class="pl-fb-kind pl-nav-kind" id="pl-set-lang" data-no-i18n>' +
          '<button type="button" class="pl-fb-k" data-lang="en">English</button>' +
          '<button type="button" class="pl-fb-k" data-lang="ru">\u0420\u0443\u0441\u0441\u043a\u0438\u0439</button>' +
          '<button type="button" class="pl-fb-k" data-lang="uk">\u0423\u043a\u0440\u0430\u0457\u043d\u0441\u044c\u043a\u0430</button>' +
        '</div>') +
      item("nav", "Navigation", "pl-set-nav-val",
        '<div class="pl-fb-kind pl-nav-kind" id="pl-set-nav">' +
          '<button type="button" class="pl-fb-k" data-nav="top">Top</button>' +
          '<button type="button" class="pl-fb-k" data-nav="left">Left</button>' +
        '</div>' +
        '<div class="pl-settings-hint">Top \u2014 the tab bar across the top. Left \u2014 a tall bar on the left with a bead you can tap or drag.</div>') +
      item("feedback", "Feedback", "pl-set-fb-val",
        '<div class="pl-fb" id="pl-fb">' +
          '<div class="pl-fb-kind" role="tablist">' +
            '<button type="button" class="pl-fb-k active" data-fb-kind="review">Review</button>' +
            '<button type="button" class="pl-fb-k" data-fb-kind="problem">Problem</button>' +
          '</div>' +
          '<div class="pl-fb-stars" id="pl-fb-stars" aria-label="Rating">' +
            '<button type="button" data-star="1" aria-label="1 star">\u2605</button>' +
            '<button type="button" data-star="2" aria-label="2 stars">\u2605</button>' +
            '<button type="button" data-star="3" aria-label="3 stars">\u2605</button>' +
            '<button type="button" data-star="4" aria-label="4 stars">\u2605</button>' +
            '<button type="button" data-star="5" aria-label="5 stars">\u2605</button>' +
          '</div>' +
          '<textarea class="pl-fb-text" id="pl-fb-text" rows="3" maxlength="1500" placeholder="What do you like about Pillow?"></textarea>' +
          '<input class="pl-fb-name" id="pl-fb-name" type="text" maxlength="40" placeholder="Name or nickname (optional)" />' +
          '<label class="pl-fb-diag" id="pl-fb-diag-row" hidden><input type="checkbox" id="pl-fb-diag" checked /> ' +
            '<span>Attach Pillow &amp; AE versions and the last error</span></label>' +
          '<pre class="pl-fb-diag-text" id="pl-fb-diag-text" hidden></pre>' +
          '<div class="pl-fb-row"><span class="pl-fb-note" id="pl-fb-note">Reviews appear in the Pillow channel after a quick check.</span>' +
          '<button type="button" class="btn btn-primary pl-fb-send" id="pl-fb-send">Send</button></div>' +
        '</div>') +
      item("updates", "Updates", "pl-set-up-val",
        '<div class="pl-up">' +
          '<div class="pl-up-line" id="pl-up-line"></div>' +
          '<div class="pl-up-notes" id="pl-up-notes" hidden></div>' +
          '<div class="pl-fb-row"><span></span>' +
          '<button type="button" class="btn pl-up-check" id="pl-up-check">Check now</button></div>' +
        '</div>') +
      item("dev", "Developers", "pl-set-dev-val",
        '<div class="pl-devs">' +
          '<a class="pl-dev" href="https://t.me/kaban_shashluk" data-url="https://t.me/kaban_shashluk">' +
            '<span class="pl-dev-name">kaban shashluk</span><span class="pl-dev-link">t.me/kaban_shashluk \u2197</span></a>' +
          '<a class="pl-dev" href="https://t.me/arilaxscp" data-url="https://t.me/arilaxscp">' +
            '<span class="pl-dev-name">Arilax</span><span class="pl-dev-link">t.me/arilaxscp \u2197</span></a>' +
        '</div>') +
      '</div>' +
      '</div>';
    /* стеклянная подложка (Liquid Glass) — под содержимым, прозрачность
       ведёт js/logo-morph.js */
    var glassBg = document.createElement("div");
    glassBg.className = "pl-settings-glass";
    glassBg.setAttribute("aria-hidden", "true");
    panel.insertBefore(glassBg, panel.querySelector(".pl-settings-body"));
    document.body.appendChild(panel);

    /* Liquid Glass — a separate visual mode, saved across restarts. */
    var glassBtn = panel.querySelector("#pl-set-glass");
    function paintGlassBtn(isOn) {
      glassBtn.classList.toggle("on", !!isOn);
      glassBtn.setAttribute("aria-checked", isOn ? "true" : "false");
      panel.querySelector("#pl-set-glass-val").textContent = isOn ? "ON" : "OFF";
    }
    paintGlassBtn(window.PillowGlass ? window.PillowGlass.isOn() : false);
    glassBtn.addEventListener("click", function () {
      if (!window.PillowGlass) return;
      paintGlassBtn(window.PillowGlass.toggle());
    });

    /* компактная карточка по центру: ширина до 380px, высота — по
       содержимому, но не выше панели; морфинг растёт ровно в неё */
    var box = null;
    function layout() {
      var W = window.innerWidth, H = window.innerHeight, M = 16;
      var w = Math.min(380, W - M * 2);
      panel.style.width = w + "px";
      panel.style.height = "auto";
      var h = Math.min(panel.scrollHeight, H - M * 2);
      var x = Math.round((W - w) / 2), y = Math.round((H - h) / 2);
      panel.style.left = x + "px";
      panel.style.top = y + "px";
      panel.style.height = h + "px";
      box = { x: x, y: y, w: w, h: h };
      return box;
    }
    layout();
    if (window.PillowLogoMorph) window.PillowLogoMorph.setBox(function () { return box || layout(); });
    window.addEventListener("resize", function () {
      layout();
      if (window.PillowLogoMorph) window.PillowLogoMorph.setBox(function () { return box; });
    });
    panel._layout = layout;

    /* ники разработчиков — в браузере по умолчанию: внутри CEP ссылка
       открывается через cep.util, а не во встроенном окне панели */
    panel.querySelector(".pl-devs").addEventListener("click", function (e) {
      var a = e.target.closest ? e.target.closest("[data-url]") : null;
      if (!a) return;
      e.preventDefault();
      var url = a.getAttribute("data-url");
      try {
        if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) { window.cep.util.openURLInDefaultBrowser(url); return; }
      } catch (err) {}
      window.open(url, "_blank");
    });
    initAccordion(layout);
    var navBox = panel.querySelector("#pl-set-nav");
    function paintNav() {
      var cur = window.PillowDock ? window.PillowDock.get() : "top";
      var bs = navBox.querySelectorAll("[data-nav]");
      for (var nb = 0; nb < bs.length; nb++) bs[nb].classList.toggle("active", bs[nb].getAttribute("data-nav") === cur);
      panel.querySelector("#pl-set-nav-val").textContent = cur === "left" ? "Left" : "Top";
    }
    navBox.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-nav]") : null;
      if (!b || !window.PillowDock) return;
      window.PillowDock.set(b.getAttribute("data-nav"));
      paintNav();
    });
    paintNav();
    /* interface language — js/i18n.js swaps the words in place */
    var langBox = panel.querySelector("#pl-set-lang");
    function paintLang() {
      var cur = window.PillowI18n ? window.PillowI18n.get() : "en";
      var bs = langBox.querySelectorAll("[data-lang]");
      for (var lb = 0; lb < bs.length; lb++) bs[lb].classList.toggle("active", bs[lb].getAttribute("data-lang") === cur);
      var meta = panel.querySelector("#pl-set-lang-val");
      meta.setAttribute("data-no-i18n", "");
      meta.textContent = window.PillowI18n ? window.PillowI18n.names[cur] : "English";
    }
    langBox.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-lang]") : null;
      if (!b || !window.PillowI18n) return;
      window.PillowI18n.set(b.getAttribute("data-lang"));
      paintLang();
      layout();
    });
    paintLang();
    if (window.PillowFeedback) window.PillowFeedback.mount(panel, layout);
    if (window.PillowUpdate) window.PillowUpdate.mount(panel, layout);
    panel.querySelector("#pl-set-close").addEventListener("click", function () { toggle(false); });
    panel.addEventListener("click", function (e) { e.stopPropagation(); });
    return panel;
  }

  /* ── аккордеон ───────────────────────────────────────────────────── */
  var ACC_MS = 300, ACC_EASE = "cubic-bezier(0, 0, 0.58, 1)"; /* ease-out */
  var accOpen = "glass";

  function initAccordion(layout) {
    var items = panel.querySelectorAll(".pl-acc-item");
    var follow = 0;
    /* карточка растёт/сжимается вместе с секцией: рамку морфинга и
       стеклянную подложку ведём каждый кадр, пока идёт переход */
    function track(until) {
      if (follow) cancelAnimationFrame(follow);
      function f() {
        layout();
        if (window.PillowLogoMorph) window.PillowLogoMorph.refresh();
        follow = window.performance.now() < until ? requestAnimationFrame(f) : 0;
      }
      follow = requestAnimationFrame(f);
    }
    function set(itemEl, on, animate) {
      var btn = itemEl.querySelector(".pl-acc-trigger");
      var box = itemEl.querySelector(".pl-acc-content");
      var inner = box.firstChild;
      itemEl.classList.toggle("is-open", on);
      btn.setAttribute("aria-expanded", on ? "true" : "false");
      box.style.transition = "none";
      if (!animate) {
        box.style.height = on ? "auto" : "0px";
        itemEl.classList.toggle("is-settled", on);
        return;
      }
      var from = box.getBoundingClientRect().height;
      var to = on ? inner.offsetHeight : 0;
      box.style.height = from + "px";
      void box.offsetHeight;
      box.style.transition = "height " + ACC_MS + "ms " + ACC_EASE;
      box.style.height = to + "px";
      clearTimeout(box._accT);
      itemEl.classList.remove("is-settled");
      box._accT = setTimeout(function () {
        box.style.transition = "none";
        if (itemEl.classList.contains("is-open")) {
          box.style.height = "auto";
          itemEl.classList.add("is-settled");
        }
      }, ACC_MS + 30);
    }
    /* open one section without animation (PillowSettings.open) */
    panel._accShow = function (key) {
      accOpen = key;
      for (var k = 0; k < items.length; k++) set(items[k], items[k].getAttribute("data-acc") === key, false);
      layout();
    };
    for (var i = 0; i < items.length; i++) {
      set(items[i], items[i].getAttribute("data-acc") === accOpen, false);
      items[i].querySelector(".pl-acc-trigger").addEventListener("click", (function (el) {
        return function () {
          var key = el.getAttribute("data-acc");
          /* type="single": открытие закрывает остальные, повторный клик сворачивает */
          accOpen = accOpen === key ? null : key;
          var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
          for (var j = 0; j < items.length; j++) {
            var want = items[j].getAttribute("data-acc") === accOpen;
            if (want !== items[j].classList.contains("is-open")) set(items[j], want, !reduce);
          }
          if (reduce) { layout(); if (window.PillowLogoMorph) window.PillowLogoMorph.refresh(); }
          else track(window.performance.now() + ACC_MS + 60);
        };
      })(items[i]));
    }
  }

  /* ── морфинг и появление контента ───────────────────────────────── */
  var EASE_OUT = "cubic-bezier(0.23, 1, 0.32, 1)";
  var fx = [];
  function stopFx() { for (var i = 0; i < fx.length; i++) fx[i].cancel(); fx = []; }

  /* блоки настроек проявляются по очереди: fade + лёгкий scale */
  function contentIn() {
    stopFx();
    var body = panel.querySelector(".pl-settings-body");
    var parts = body.children;
    for (var i = 0; i < parts.length; i++) {
      if (!parts[i].animate) continue;
      fx.push(parts[i].animate([
        { opacity: 0, transform: "translateY(6px) scale(0.97)" },
        { opacity: 1, transform: "translateY(0) scale(1)" }
      ], { duration: 300, delay: Math.min(i, 8) * 28, easing: EASE_OUT, fill: "backwards" }));
    }
    var closeBtn = panel.querySelector("#pl-set-close");
    try { closeBtn.focus({ preventScroll: true }); } catch (e) { closeBtn.focus(); }
  }

  function toggle(next) {
    build();
    var want = typeof next === "boolean" ? next : !open;
    if (want === open) return;
    open = want;
    var brand = document.querySelector(".rail-brand");
    if (brand) brand.setAttribute("aria-expanded", open ? "true" : "false");
    var morph = window.PillowLogoMorph;

    if (open) {
      stopFx();
      panel._layout();
      panel.classList.add("open");
      panel.querySelector(".pl-settings-body").style.opacity = "0";
      if (!morph) { panel.querySelector(".pl-settings-body").style.opacity = ""; return; }
      var shown = false;
      var show = function () {
        if (!open || shown) return;
        shown = true;
        panel.querySelector(".pl-settings-body").style.opacity = "";
        contentIn();
      };
      /* the cushion turns level (css, ~0.2 s) and the morph grows from
         the level cushion */
      var html = document.documentElement, reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      html.classList.add("pl-logo-level");
      setTimeout(function () { if (open) morph.open(show); }, reduce ? 0 : 190);
      /* страховка: содержимое не должно остаться невидимым, даже если
         колбэк морфинга не пришёл (панель ушла в фон и т.п.) */
      setTimeout(show, 1100);
      return;
    }

    /* закрытие: контент гаснет первым, затем форма стекает в логотип */
    stopFx();
    var body = panel.querySelector(".pl-settings-body");
    body.style.opacity = "";
    var out = body.animate ? body.animate([
      { opacity: 1, transform: "scale(1)" },
      { opacity: 0, transform: "scale(0.98)" }
    ], { duration: 140, easing: EASE_OUT, fill: "forwards" }) : null;
    if (out) fx.push(out);
    var go = function () {
      if (open) return;
      if (!morph) { panel.classList.remove("open"); stopFx(); document.documentElement.classList.remove("pl-logo-level"); return; }
      morph.close(function () {
        if (open) return;
        panel.classList.remove("open");
        stopFx();
        /* back on the rail: the cushion settles back to its own tilt */
        document.documentElement.classList.remove("pl-logo-level");
      });
    };
    setTimeout(go, 90);
    if (brand && panel.contains(document.activeElement)) {
      try { brand.focus({ preventScroll: true }); } catch (e) { brand.focus(); }
    }
  }

  /* The choice must survive a closed popover: apply it at startup too. */
  function bootMaterial() {
    /* grain and edge deformation are no longer user settings: the
       surface always uses the default grain */
    var kind = "material", amt = 50;
    document.documentElement.setAttribute("data-pl-material", kind);
    document.documentElement.style.setProperty("--pl-mat", String(amt / 100));
  }

  /* Warm-up: the sheet was built, laid out and drawn for the first time
     on the first click (a long frame, then the opening jumped). Soon
     after start-up, when nothing is going on, it is built and shown for
     a few frames, transparent and untouchable, then hidden again — and
     the morph does the same (js/logo-morph.js warm). A click in the
     middle simply takes over. */
  var warmed = false;
  function warmUp() {
    if (warmed || open || document.hidden) return;
    warmed = true;
    build();
    try { panel._layout(); } catch (e) {}
    panel.style.opacity = "0.01";
    panel.style.pointerEvents = "none";
    panel.classList.add("open");
    var n = 0;
    (function f() {
      if (++n < 4) { requestAnimationFrame(f); return; }
      if (!open) panel.classList.remove("open");
      panel.style.opacity = "";
      panel.style.pointerEvents = "";
      if (window.PillowLogoMorph && window.PillowLogoMorph.warm) window.PillowLogoMorph.warm();
    })();
  }

  function boot() {
    bootMaterial();
    var idle = window.requestIdleCallback || function (fn) { return setTimeout(fn, 60); };
    setTimeout(function () { idle(warmUp, { timeout: 2000 }); }, 3200);
    var brand = document.querySelector(".rail-brand");
    if (!brand) return;
    brand.classList.add("pl-brand-btn");
    brand.setAttribute("role", "button");
    brand.setAttribute("tabindex", "0");
    brand.setAttribute("aria-expanded", "false");
    brand.title = "Pillow Settings";
    brand.addEventListener("click", function (e) { e.stopPropagation(); toggle(); });
    /* the press: the cushion gives under the finger, springs back on release */
    var pressOn = function (e) { var b = e.target.closest && e.target.closest(".rail-brand, .vdock-brand"); if (b) b.classList.add("is-pressed"); };
    var pressOff = function () { var ps = document.querySelectorAll(".rail-brand.is-pressed, .vdock-brand.is-pressed"); for (var q = 0; q < ps.length; q++) ps[q].classList.remove("is-pressed"); };
    document.addEventListener("pointerdown", pressOn, true);
    window.addEventListener("pointerup", pressOff);
    window.addEventListener("pointercancel", pressOff);
    brand.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(); }
    });
    document.addEventListener("click", function (e) {
      if (open) { toggle(false); return; }
      /* пока форма стекает в логотип, сам логотип спрятан, а клики ловит
         подложка морфинга — повторный клик по месту логотипа терялся, и
         настройки открывались через раз. Такой клик разворачивает морфинг
         обратно. */
      if (e.target && e.target.closest && e.target.closest(".pl-morph-scrim")) {
        var r = brand.getBoundingClientRect();
        if (e.clientX >= r.left - 6 && e.clientX <= r.right + 6 && e.clientY >= r.top - 6 && e.clientY <= r.bottom + 6) toggle(true);
      }
    });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && open) toggle(false); });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }

  window.PillowSettings = {
    toggle: toggle,
    /* open the settings on one section ("feedback", "updates", …) */
    open: function (section) {
      build();
      if (section && panel._accShow) panel._accShow(section);
      toggle(true);
    }
  };
})();
