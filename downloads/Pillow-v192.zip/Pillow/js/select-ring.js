/* Pillow — индикатор выбранного пресета (Curves, Text).
 *
 * Порт движения Glass Tabs (websiteglass.com/r/glass-tabs.json) под наши
 * вертикальные списки: одна стеклянная «пилюля» на список, которая
 * плывёт к новому выбору на пружине и деформируется в пути как капля.
 *
 *   позиция и размер  spring 380 / 30 (как xT / wT у TabsList), по обеим
 *                     осям — Curves едет по вертикали, Text (две колонки)
 *                     и по диагонали
 *   капля             deform q → min(0.3, 0.0022·|v|^0.7) от скорости
 *                     пилюли, spring 200 / 13; вытягивается вдоль хода
 *                     (1 + 0.5q) и сужается поперёк (1 − 0.28q), потом
 *                     пружиной возвращается к форме
 *   вид               rgba(255,255,255,.16) + inset 0 1px 0 rgba(255,255,255,.3)
 *                     + 0 2px 10px rgba(0,0,0,.18) — пилюля Glass Tabs
 *
 * Форма пилюли — видимая форма карточки: стеклянный слой (Liquid Glass)
 * или плашка plate.js со своим отступом и радиусом. Пока список
 * перестраивается (фильтр/поиск — FLIP list-fx.js, ресайз, смена темы и
 * режима стекла), пилюля ведётся за карточкой без пружины, а во время
 * переезда — пружина просто получает новую цель. Выбранная карточка
 * спрятана фильтром — пилюля гаснет. Мотор (Track / spring) — тот же
 * порт glass-motion, что в js/glass-switch.js.
 */
(function () {
  "use strict";
  if (window.PillowSelectRing) return;

  var LISTS = [
    { box: "#preset-browser", item: ".curve-preset-row" },
    { box: "#text-grid", item: ".text-card" },
    { box: "#sfx-list", item: "[data-sfx-card]" }
  ];
  var FOLLOW_MS = 700;
  var POS = { tension: 380, friction: 30 };
  var DEFORM = { tension: 200, friction: 13 };

  function now() { return window.performance ? performance.now() : Date.now(); }
  function core() { return window.PillowGlassSwitch && window.PillowGlassSwitch.core; }

  /* видимая форма карточки: стеклянный слой / плашка с отступом / сама карточка */
  function shapeOf(el) {
    var ch = el.querySelector(":scope > .pl-glass-chrome");
    if (ch && ch.offsetWidth) {
      return { r: ch.getBoundingClientRect(), rad: parseFloat(getComputedStyle(ch).borderTopLeftRadius) || 16 };
    }
    var r = el.getBoundingClientRect(), g = el.__plGeom;
    if (g && el.classList.contains("pl-plated")) {
      return { r: { left: r.left + g.inset, top: r.top + g.inset, width: r.width - g.inset * 2, height: r.height - g.inset * 2 }, rad: g.r };
    }
    return { r: r, rad: parseFloat(getComputedStyle(el).borderTopLeftRadius) || 14 };
  }

  function setup(spec) {
    var C = core();
    var box = document.querySelector(spec.box);
    if (!C || !box || box.__selRing) return;
    /* Пилюля живёт внутри списка, в координатах его содержимого: при
       прокрутке она едет вместе с карточками в том же кадре (прокрутку
       двигает сам браузер). Отдельный слой поверх списка догонял
       прокрутку по событию scroll с опозданием на кадр — пилюля дёргалась
       относительно карточки. Размытие фона у строк и списка снято
       (css/glass.css), поэтому внутри списка она ничего не перерисовывает. */
    var pill = document.createElement("div");
    pill.className = "pl-sel-ring";
    pill.setAttribute("aria-hidden", "true");
    if (getComputedStyle(box).position === "static") box.style.position = "relative";
    box.appendChild(pill);
    box.__selRing = pill;

    var xT = new C.Track(0), yT = new C.Track(0), wT = new C.Track(0), hT = new C.Track(0), dT = new C.Track(0);
    var goal = null, current = null, ready = false, moving = false, followUntil = 0, raf = 0;
    /* ось капли: задаётся один раз в начале переезда по направлению хода.
       Раньше выбиралась каждый кадр по большей из скоростей — к концу
       вертикальная пружина вставала первой (скорость ровно 0), а
       горизонтальная ещё дорабатывала доли пикселя, и капля резко
       переворачивалась и вытягивалась вбок. */
    var vertical = true;

    function paint() {
      /* пружина капли по инерции проскакивает ноль — отрицательная
         деформация сплющивала пилюлю (шире и ниже карточки) в самом
         конце переезда. Капля только вытягивается по ходу. */
      var q = Math.max(0, dT.get());
      /* капля вытягивается вдоль хода и сужается поперёк */
      var along = 1 + 0.5 * q, across = 1 - 0.28 * q;
      var sx = vertical ? across : along, sy = vertical ? along : across;
      pill.style.width = wT.get().toFixed(1) + "px";
      pill.style.height = hT.get().toFixed(1) + "px";
      pill.style.transform = "translate(" + xT.get().toFixed(1) + "px," + yT.get().toFixed(1) + "px) scale(" +
        sx.toFixed(4) + "," + sy.toFixed(4) + ")";
    }
    xT.watch(paint); yT.watch(paint); wT.watch(paint); hT.watch(paint); dT.watch(paint);

    function active() {
      var a = box.querySelector(spec.item + ".active");
      return a && !a.hasAttribute("data-lfx-out") && a.offsetWidth ? a : null;
    }

    /* цель пилюли — в координатах содержимого списка */
    function measure() {
      var el = active();
      if (!el || box.offsetParent === null) return null;
      /* по раскладке, без transform: наведение приподнимает и чуть
         увеличивает карточку, и пилюля «доезжала» до надутого размера */
      if (el.offsetParent === box && !el.__lfx && !(el._lfx && el._lfx.length)) {
        var ch = el.querySelector(":scope > .pl-glass-chrome"), g = el.__plGeom;
        var ins = ch && ch.offsetWidth ? { l: ch.offsetLeft, t: ch.offsetTop, w: ch.offsetWidth, h: ch.offsetHeight }
          : g && el.classList.contains("pl-plated") ? { l: g.inset, t: g.inset, w: el.offsetWidth - g.inset * 2, h: el.offsetHeight - g.inset * 2 }
          : { l: 0, t: 0, w: el.offsetWidth, h: el.offsetHeight };
        var rad = ch && ch.offsetWidth ? parseFloat(ch.style.borderRadius) || 16 : g ? g.r : 14;
        return { x: el.offsetLeft + ins.l, y: el.offsetTop + ins.t, w: ins.w, h: ins.h, rad: rad };
      }
      var s = shapeOf(el), br = box.getBoundingClientRect();
      return {
        x: s.r.left - br.left - box.clientLeft + box.scrollLeft,
        y: s.r.top - br.top - box.clientTop + box.scrollTop,
        w: s.r.width, h: s.r.height, rad: s.rad
      };
    }

    function show(g) {
      pill.style.borderRadius = g.rad + "px";
      pill.style.opacity = "1";
    }

    /* выбор сменился — переезд на пружине с каплей */
    function glideTo() {
      goal = measure();
      if (!goal) { pill.style.opacity = "0"; return; }
      show(goal);
      if (!ready || C.reduceMotion()) { snap(); return; }
      vertical = Math.abs(goal.y - yT.get()) >= Math.abs(goal.x - xT.get());
      moving = true;
      C.spring(xT, function () { return goal.x; }, POS);
      C.spring(yT, function () { return goal.y; }, POS);
      C.spring(wT, function () { return goal.w; }, POS);
      C.spring(hT, function () { return goal.h; }, POS);
      var done = false;
      C.spring(dT, function () {
        /* скорость вдоль оси хода — как у TabsList (только x) */
        var v = Math.abs(vertical ? yT.velocity() : xT.velocity());
        return Math.min(0.3, 0.0022 * Math.pow(v, 0.7));
      }, {
        tension: DEFORM.tension, friction: DEFORM.friction,
        canRest: function () {
          var still = done && Math.abs((vertical ? yT : xT).velocity()) < 0.02;
          if (still) moving = false;
          return still;
        }
      });
      setTimeout(function () { done = true; }, 60);
    }

    function snap() {
      xT.snap(goal.x); yT.snap(goal.y); wT.snap(goal.w); hT.snap(goal.h); dT.snap(0);
      ready = true; moving = false;
    }

    /* список двигается/меняет размер — ведём пилюлю за карточкой */
    function follow() {
      followUntil = now() + FOLLOW_MS;
      if (raf) return;
      (function f() {
        var g = measure();
        if (!g) pill.style.opacity = "0";
        else {
          goal = g; show(g);
          if (!moving) snap();   /* во время переезда пружина сама берёт новую цель */
          /* список строился скрытым (вкладка не открыта) — выбранная
             карточка запоминается, когда пилюля встала на неё, иначе
             первый клик считался появлением и пилюля прыгала без пружины */
          if (!current) current = active();
        }
        raf = now() < followUntil ? requestAnimationFrame(f) : 0;
      })();
    }

    function sync() {
      var el = active();
      if (el !== current) {
        var had = current;
        current = el;
        if (el && had && ready) { glideTo(); return; }
      }
      follow();
    }

    /* смена класса значит что-то, только если сменился выбор: ховер,
       нажатие, подсветка карточек тоже меняют class, и каждый раз
       пилюля 700 мс перемеряла список покадрово (≈100 мс работы на клик) */
    function hasActive(cls) { return (" " + (cls || "") + " ").indexOf(" active ") >= 0; }
    function matters(r) {
      if (r.target === pill) return false;
      if (r.type === "childList") {
        for (var k = 0; k < r.addedNodes.length; k++) if (r.addedNodes[k] !== pill) return true;
        for (k = 0; k < r.removedNodes.length; k++) if (r.removedNodes[k] !== pill) return true;
        return false;
      }
      if (r.attributeName === "data-lfx-out") return true;
      return hasActive(r.oldValue) !== hasActive(r.target.getAttribute("class"));
    }
    new MutationObserver(function (recs) {
      /* список перестраивают через innerHTML — пилюлю при этом стирает */
      if (pill.parentNode !== box) { box.appendChild(pill); ready = false; current = null; }
      for (var i = 0; i < recs.length; i++) {
        if (!matters(recs[i])) continue;
        sync();
        return;
      }
    }).observe(box, { attributes: true, attributeOldValue: true, attributeFilter: ["class", "data-lfx-out"], childList: true, subtree: true });
    if (window.ResizeObserver) new ResizeObserver(follow).observe(box);
    window.addEventListener("resize", follow);
    /* смена режима стекла / темы меняет форму карточек */
    new MutationObserver(follow).observe(document.documentElement, { attributes: true, attributeFilter: ["data-pl-glass", "data-theme"] });
    current = active();
    follow();
  }

  function boot() {
    for (var i = 0; i < LISTS.length; i++) setup(LISTS[i]);
  }
  /* списки строятся лениво (curves.js / text.js) — подхватываем, когда появятся */
  function watch() {
    boot();
    var pending = false;
    new MutationObserver(function () {
      if (pending) return;
      pending = true;
      setTimeout(function () { pending = false; boot(); }, 60);
    }).observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", watch);
  else watch();

  window.PillowSelectRing = { refresh: boot };
})();
