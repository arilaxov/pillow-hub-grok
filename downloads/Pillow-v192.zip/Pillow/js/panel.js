/* Pillow 2.3 — UI ↔ ExtendScript bridge + Liquid Glass + theme wipe */

var PILLOW_VERSION = "1.1.1";
var csInterface = null;
var state = {
  tab: "create",
  solidColor: [0.91, 0.91, 0.91],
  solidHex: "#e8e8e8",
  duration: 5,
  matchCompDuration: true,
  parentSelected: false,
  fitSelected: true,
  lastFolder: null,
  missing: [],
  camTwoNode: false
};

var SWATCHES = ["#e8e8e8", "#f0f0f0", "#2a2a2a", "#7c8aa0", "#3d4a3a", "#1a1a1a"];
var TAB_LABELS = { create: "Create", curves: "Curves", bounce: "Bounce", text: "Text", sfx: "SFX", relink: "Relink", music: "Music", library: "Library", glass: "Glass" };

function $(id) {
  return document.getElementById(id);
}

function toast(msg, isErr) {
  var el = $("toast");
  if (!el) return;
  if (window.PillowI18n) msg = window.PillowI18n.tr(msg);
  el.className = "toast show" + (isErr ? " err" : "");
  el.innerHTML = '<span class="dot"></span>' + escapeHtml(msg);
  clearTimeout(toast._t);
  toast._t = setTimeout(function () {
    el.className = "toast";
  }, 2800);
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function hexToRgb01(hex) {
  var h = hex.replace("#", "");
  if (h.length === 3) {
    h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
  }
  var n = parseInt(h, 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}

function esc(s) {
  return String(s || "")
    .replace(/\\/g, "\\\\")
    .replace(/"/g, '\\"')
    .replace(/\r/g, " ")
    .replace(/\n/g, " ");
}

/** Parse ExtendScript JSON result (reusable). */
function parseHostResult(result) {
  var data = { ok: false, error: "Empty response" };
  if (result == null || result === "" || result === "undefined" || result === "null") {
    return data;
  }
  var raw = String(result);
  var trimmed = raw.replace(/^\s+/, "").replace(/\s+$/, "");
  /* JSON first: a good answer may well contain "Error:" (an expression
     in a library preset, a layer name) and must not be read as a failure */
  if (trimmed.charAt(0) === "{" || trimmed.charAt(0) === "[") {
    try { return JSON.parse(trimmed); } catch (e) {}
  }
  return { ok: false, error: trimmed.slice(0, 220) || "Empty response" };
}

/** Load host/pillow.jsx explicitly (Win + Mac path safe). */
var _hostLoaded = false;
var _hostLoading = null;
function ensureHostLoaded(done) {
  if (!csInterface) {
    if (done) done(false);
    return;
  }
  if (_hostLoaded) {
    if (done) done(true);
    return;
  }
  /* one load at a time: callers that arrive meanwhile wait for it */
  if (_hostLoading) {
    _hostLoading.push(done);
    return;
  }
  _hostLoading = [done];
  var finish = function (ok) {
    var list = _hostLoading || [];
    _hostLoading = null;
    for (var i = 0; i < list.length; i++) if (list[i]) list[i](ok);
  };
  var ext = "";
  try {
    ext = csInterface.getSystemPath(SystemPath.EXTENSION);
  } catch (e0) {
    try { ext = csInterface.getSystemPath("extension"); } catch (e1) {}
  }
  if (!ext) {
    finish(false);
    return;
  }
  var jsx = (ext + "/host/pillow.jsx").replace(/\\/g, "/");
  var path = jsx.replace(/"/g, '\\"');
  /* $.evalFile has to run at the top level of the script: called inside a
     function, After Effects keeps everything the file defines local to
     that function, and every later call finds nothing. */
  csInterface.evalScript('$.evalFile("' + path + '")', function (loadRes) {
    csInterface.evalScript(
      'typeof pillowPing==="function"&&typeof pillowGlassMake==="function"?\'{"ok":true,"loaded":true}\':\'{"ok":false,"error":"Host script did not load"}\'',
      function (res) {
        var data = parseHostResult(res);
        _hostLoaded = !!(data && data.ok);
        if (!_hostLoaded) {
          var why = String(loadRes || "");
          toast((data && data.error ? data.error : "Host script did not load") +
            (why && why !== "undefined" && why !== "true" ? " · " + why.slice(0, 160) : ""), true);
        }
        finish(_hostLoaded);
      });
  });
}

/** Force the host script to load again (after an update, or when a call
    finds its functions missing). */
function reloadHostScript(done) {
  _hostLoaded = false;
  ensureHostLoaded(done);
}

/* Coalesce rapid evalScript: serialize calls, merge identical in-flight requests,
   briefly reuse ping results to avoid thrashing CEP Chromium. */
var _hostQueue = [];
var _hostBusy = false;
var _hostInflight = {};
var _pingCache = null;
var _pingCacheAt = 0;
var PING_TTL_MS = 2500;

function fnName(call) { var m = /^([A-Za-z0-9_$.]+)/.exec(String(call)); return m ? m[1] : "host"; }
function _hostDrain() {
  if (_hostBusy || !_hostQueue.length) return;
  _hostBusy = true;
  var job = _hostQueue.shift();
  var key = job.key;
  csInterface.evalScript(job.fnCall, function (result) {
    var data = parseHostResult(result);
    if (!data || typeof data !== "object") data = { ok: false, error: "Empty response" };
    if (key.indexOf("pillowPing") === 0) {
      _pingCache = data;
      _pingCacheAt = Date.now();
    }
    var cbs = _hostInflight[key] || [job.cb];
    delete _hostInflight[key];
    /* the queue is freed first: a callback that throws used to leave it
       busy for good, and from then on no button reached After Effects */
    _hostBusy = false;
    for (var i = 0; i < cbs.length; i++) {
      if (!cbs[i]) continue;
      try { cbs[i](data); }
      catch (e) { try { console.error("Pillow:", fnName(key), e); (window.PILLOW_ERRORS = window.PILLOW_ERRORS || []).push(fnName(key) + ": " + String(e && e.message || e)); } catch (e2) {} }
    }
    _hostDrain();
  });
}

/** Call ExtendScript host function, parse JSON result */
function host(fnCall, cb) {
  if (!csInterface) {
    toast("Not running inside After Effects", true);
    if (cb) cb({ ok: false, error: "No CSInterface" });
    return;
  }
  if (!_hostLoaded && String(fnCall).indexOf("$.evalFile") !== 0) {
    ensureHostLoaded(function (ok) {
      if (!ok) {
        if (cb) cb({ ok: false, error: "Host script failed to load" });
        return;
      }
      host(fnCall, cb);
    });
    return;
  }
  var key = String(fnCall);
  if (key.indexOf("pillowPing") === 0 && _pingCache && Date.now() - _pingCacheAt < PING_TTL_MS) {
    if (cb) cb(_pingCache);
    return;
  }
  if (_hostInflight[key]) {
    _hostInflight[key].push(cb);
    return;
  }
  _hostInflight[key] = [cb];
  _hostQueue.push({ fnCall: fnCall, cb: cb, key: key });
  _hostDrain();
}


/* ─── Rail active pill (horizontal spring capsule) ───────────── */
var RailPill = {
  x: 0,
  vx: 0,
  scale: 1,
  targetX: 0,
  raf: null,
  kissRaf: null,
  kissed: false,
  ready: false,
  reduced: false,
  // ~220ms settle, tiny overshoot — snappy "flick" feel.
  stiffness: 620,
  damping: 37,
  mass: 1
};

function railPillEl() {
  return $("rail-pill-wrap");
}

function railPillMeasureX(tab) {
  var bar = document.querySelector(".rail-bar");
  var btn = document.querySelector('.rail-btn[data-tab="' + tab + '"]');
  if (!bar || !btn) return null;
  var brBar = bar.getBoundingClientRect();
  var brBtn = btn.getBoundingClientRect();
  return brBtn.left + brBtn.width / 2 - brBar.left + bar.scrollLeft;
}

function railPillApplyTransform() {
  var el = railPillEl();
  if (!el) return;
  el.style.transform =
    "translate3d(" + RailPill.x.toFixed(2) + "px,0,0) scale(" + RailPill.scale.toFixed(4) + ")";
  railSurfaceSync();
}

/* ─── Rail surface (continuous wrapped bar) ──────────────────────────
 * The bar is one SVG path instead of a CSS pill + notch cutouts. Its top
 * edge stays flat, then rises through two tangent-matched cubics and ends
 * INSIDE the active circle (junctions sit ~15px from a 21px radius centre),
 * so the join is never visible — the surface simply bends around the
 * floating button. The transition span compresses near the caps so the
 * shape stays valid at the first and last tab. */
var RailSurface = {
  w: 0,
  lastX: null,
  lastW: 0,
  els: null
};

function railSurfaceEls() {
  if (RailSurface.els && RailSurface.els.svg && RailSurface.els.svg.parentNode) {
    return RailSurface.els;
  }
  var svg = $("rail-surface");
  if (!svg) return null;
  RailSurface.els = {
    svg: svg,
    fill: $("rail-surface-fill"),
    clip: $("rail-surface-clip"),
    rim: $("rail-surface-rim"),
    bloom: document.getElementById("rs-bloom")
  };
  return RailSurface.els;
}

function railSurfaceMeasure() {
  var bar = document.querySelector(".rail-bar");
  if (!bar) return;
  RailSurface.w = Math.round(bar.clientWidth);
  railSurfaceSync(true);
}

/** Bar outline. w = bar width, x = active circle centre (null before ready). */
function railSurfacePath(w, x) {
  var H = 48, R = 24;
  var JX = 10.5, JY = -11, IX = 2.5, PY = -12.6, SPAN = 70;
  var d = "M " + R + ",0 ";
  if (x != null && w > 2 * R + 40) {
    var spanL = Math.max(22, Math.min(SPAN, x - (R + 2)));
    var spanR = Math.max(22, Math.min(SPAN, w - (R + 2) - x));
    var rL = spanL / SPAN, rR = spanR / SPAN;
    var yL = Math.sqrt(rL), yR = Math.sqrt(rR);
    var x0 = Math.max(R + 1, x - spanL);
    var x1 = Math.min(w - R - 1, x + spanR);
    d += "L " + x0.toFixed(2) + ",0 ";
    d += "C " + (x - 44 * rL).toFixed(2) + ",0 " +
         (x - 38 * rL).toFixed(2) + "," + (-5.5 * yL).toFixed(2) + " " +
         (x - JX).toFixed(2) + "," + JY + " ";
    d += "C " + (x - IX).toFixed(2) + "," + PY + " " +
         (x + IX).toFixed(2) + "," + PY + " " +
         (x + JX).toFixed(2) + "," + JY + " ";
    d += "C " + (x + 38 * rR).toFixed(2) + "," + (-5.5 * yR).toFixed(2) + " " +
         (x + 44 * rR).toFixed(2) + ",0 " +
         x1.toFixed(2) + ",0 ";
  }
  d += "L " + (w - R) + ",0 " +
       "A " + R + "," + R + " 0 0 1 " + (w - R) + "," + H + " " +
       "L " + R + "," + H + " " +
       "A " + R + "," + R + " 0 0 1 " + R + ",0 Z";
  return d;
}

function railSurfaceSync(force) {
  var els = railSurfaceEls();
  if (!els || !els.fill) return;
  if (!RailSurface.w) {
    var bar = document.querySelector(".rail-bar");
    if (!bar) return;
    RailSurface.w = Math.round(bar.clientWidth);
  }
  var w = RailSurface.w;
  var x = RailPill.ready ? RailPill.x : null;
  if (!force && w === RailSurface.lastW && x === RailSurface.lastX) return;
  RailSurface.lastW = w;
  RailSurface.lastX = x;

  if (w !== +els.svg.getAttribute("width")) {
    els.svg.setAttribute("width", w);
    els.svg.setAttribute("height", 72);
    els.svg.setAttribute("viewBox", "0 -24 " + w + " 72");
  }
  var d = railSurfacePath(w, x);
  els.fill.setAttribute("d", d);
  if (els.clip) els.clip.setAttribute("d", d);
  if (els.rim) els.rim.setAttribute("d", d);
  if (els.bloom && x != null) els.bloom.setAttribute("cx", x.toFixed(2));
}

/** One-shot "kiss" bump as the capsule arrives — deterministic, time-based
 *  (not spring/threshold-based), so it always finishes in exactly 220ms no
 *  matter what. This replaced an earlier version driven by a second spring
 *  with tight convergence tolerances, which could linger animating an
 *  effectively-invisible fraction of a pixel for a long time. */
function railPillRunKiss() {
  if (RailPill.kissRaf) cancelAnimationFrame(RailPill.kissRaf);
  var t0 = performance.now();
  var DUR = 220;
  function step(now) {
    var t = Math.min(1, (now - t0) / DUR);
    var s;
    if (t < 0.45) {
      var p = t / 0.45;
      s = 1 + 0.04 * (1 - (1 - p) * (1 - p));
    } else {
      var p2 = (t - 0.45) / 0.55;
      s = 1.04 - 0.04 * (p2 * p2 * (3 - 2 * p2));
    }
    RailPill.scale = s;
    railPillApplyTransform();
    if (t < 1) {
      RailPill.kissRaf = requestAnimationFrame(step);
    } else {
      RailPill.scale = 1;
      railPillApplyTransform();
      RailPill.kissRaf = null;
    }
  }
  RailPill.kissRaf = requestAnimationFrame(step);
}

function railPillTick(now) {
  RailPill.raf = null;
  var el = railPillEl();
  if (!el) return;
  var dt = RailPill._last ? Math.min(0.032, (now - RailPill._last) / 1000) : 0.016;
  RailPill._last = now;

  var dx = RailPill.x - RailPill.targetX;
  var force = -RailPill.stiffness * dx - RailPill.damping * RailPill.vx;
  RailPill.vx += (force / RailPill.mass) * dt;
  RailPill.x += RailPill.vx * dt;

  railPillApplyTransform();

  if (!RailPill.kissed && Math.abs(dx) < 4 && Math.abs(RailPill.vx) < 40) {
    RailPill.kissed = true;
    railPillRunKiss();
  }

  var moving = Math.abs(dx) > 0.15 || Math.abs(RailPill.vx) > 2;

  if (moving !== RailPill._wasMoving) {
    RailPill._wasMoving = moving;
    el.classList.toggle("is-moving", moving);
  }

  if (moving) {
    RailPill.raf = requestAnimationFrame(railPillTick);
  } else {
    RailPill.x = RailPill.targetX;
    RailPill.vx = 0;
    railPillApplyTransform();
    RailPill._last = 0;
  }
}

/* the press: the white circle gives under the finger when any rail
   icon is pressed, and springs back on release (css .rail-pill.is-pressed) */
function railPillPressInit() {
  var bar = document.querySelector(".rail-bar"), pill = $("rail-pill");
  if (!bar || !pill || railPillPressInit.done) return;
  railPillPressInit.done = true;
  bar.addEventListener("pointerdown", function (e) {
    if (e.target.closest && e.target.closest(".rail-btn")) pill.classList.add("is-pressed");
  });
  function up() { pill.classList.remove("is-pressed"); }
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", up);
}

function railPillStartLoop() {
  if (RailPill.raf) return;
  RailPill._last = 0;
  RailPill.raf = requestAnimationFrame(railPillTick);
}

function railPillGoTo(tab, instant) {
  var x = railPillMeasureX(tab);
  if (x == null) return;
  var el = railPillEl();
  if (!el) return;

  if (RailPill.kissRaf) { cancelAnimationFrame(RailPill.kissRaf); RailPill.kissRaf = null; }

  if (!RailPill.ready || instant || RailPill.reduced) {
    RailPill.x = x;
    RailPill.targetX = x;
    RailPill.vx = 0;
    RailPill.scale = 1;
    RailPill.kissed = false;
    railPillApplyTransform();
    el.classList.add("is-ready");
    el.classList.remove("is-moving");
    RailPill._wasMoving = false;
    RailPill.ready = true;
    railSurfaceSync(true);
    return;
  }

  // Interruptible: retarget mid-flight — keep velocity, new destination
  RailPill.targetX = x;
  RailPill.kissed = false;
  railPillStartLoop();
}

function initRailPill() {
  try {
    RailPill.reduced =
      window.matchMedia &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  } catch (e) {
    RailPill.reduced = false;
  }
  railSurfaceMeasure();
  // Reposition on theme wipe / resize without jumping tabs
  window.addEventListener("resize", function () {
    railSurfaceMeasure();
    if (state.tab) railPillGoTo(state.tab, true);
  });
}


/* ─── Перетаскивание шарика вкладок ────────────────────────────
 * Как у пилюли дока в Bounce (GlassDock): зажать шарик или любую
 * вкладку и вести — шарик едет за пальцем (чуть приподнят, за крайними
 * вкладками тянется с сопротивлением), иконка ближайшей вкладки уже
 * поднимается в него; отпустил — шарик пружиной садится на ближайшую
 * вкладку и она открывается. Короткое нажатие без сдвига — обычный клик. */
var railDragSuppressClick = false;

function initRailDrag(rail) {
  var bar = rail.querySelector(".rail-bar");
  if (!bar) return;
  var drag = null;

  function tabs() {
    var btns = bar.querySelectorAll(".rail-btn[data-tab]"), out = [];
    var brBar = bar.getBoundingClientRect();
    for (var i = 0; i < btns.length; i++) {
      var r = btns[i].getBoundingClientRect();
      out.push({ tab: btns[i].getAttribute("data-tab"), el: btns[i], x: r.left + r.width / 2 - brBar.left + bar.scrollLeft });
    }
    return out;
  }
  function nearest(list, x) {
    var best = list[0], d = Infinity;
    for (var i = 0; i < list.length; i++) {
      var dd = Math.abs(list[i].x - x);
      if (dd < d) { d = dd; best = list[i]; }
    }
    return best;
  }
  /* мягкое сопротивление за краем — как overdrag у GlassDock (22px) */
  function overdrag(v, lim) { return lim * (1 - Math.exp(-Math.abs(v) / lim)) * (v < 0 ? -1 : 1); }

  function setHot(t) {
    if (!drag || drag.hot === t.tab) return;
    drag.hot = t.tab;
    var btns = bar.querySelectorAll(".rail-btn[data-tab]");
    for (var i = 0; i < btns.length; i++) btns[i].classList.toggle("active", btns[i] === t.el);
  }

  rail.addEventListener("pointerdown", function (e) {
    if (e.button !== undefined && e.button !== 0) return;
    var onTab = e.target.closest && e.target.closest(".rail-btn[data-tab], .rail-pill-wrap");
    if (!onTab || !RailPill.ready) return;
    drag = { id: e.pointerId, x0: e.clientX, from: RailPill.x, moved: false, hot: state.tab, list: null, lastX: RailPill.x, lastT: performance.now(), v: 0 };
  });

  rail.addEventListener("pointermove", function (e) {
    if (!drag || e.pointerId !== drag.id) return;
    var dx = e.clientX - drag.x0;
    if (!drag.moved) {
      if (Math.abs(dx) < 5) return;
      drag.moved = true;
      drag.list = tabs();
      try { rail.setPointerCapture(e.pointerId); } catch (err) { /* нет указателя */ }
      if (RailPill.raf) { cancelAnimationFrame(RailPill.raf); RailPill.raf = null; }
      if (RailPill.kissRaf) { cancelAnimationFrame(RailPill.kissRaf); RailPill.kissRaf = null; }
      var el = railPillEl();
      if (el) el.classList.add("is-moving", "is-dragging");
      rail.classList.add("is-dragging");
    }
    var lo = drag.list[0].x, hi = drag.list[drag.list.length - 1].x;
    var raw = drag.from + dx, c = Math.max(lo, Math.min(hi, raw));
    var x = c + overdrag(raw - c, 22);
    var now = performance.now(), dt = Math.max(8, now - drag.lastT);
    drag.v = (x - drag.lastX) / dt * 1000;
    drag.lastX = x; drag.lastT = now;
    RailPill.x = RailPill.targetX = x;
    RailPill.vx = 0;
    RailPill.scale = 1.08;   /* приподнят, пока его держат */
    railPillApplyTransform();
    setHot(nearest(drag.list, x));
  });

  function end(e) {
    if (!drag || (e && e.pointerId !== drag.id)) return;
    var d = drag;
    drag = null;
    if (!d.moved) return;
    railDragSuppressClick = true;
    setTimeout(function () { railDragSuppressClick = false; }, 0);
    var el = railPillEl();
    if (el) el.classList.remove("is-dragging");
    rail.classList.remove("is-dragging");
    var t = nearest(d.list, RailPill.x);
    RailPill.scale = 1;
    /* отпустили — пружина берёт скорость пальца и сажает шарик на вкладку */
    RailPill.vx = Math.max(-2500, Math.min(2500, d.v));
    if (t.tab === state.tab) railPillGoTo(t.tab, false);
    else setTab(t.tab);
  }
  rail.addEventListener("pointerup", end);
  rail.addEventListener("pointercancel", end);
  rail.addEventListener("lostpointercapture", end);
}

/* ─── Rail scroll in a narrow panel ────────────────────────────
 * When the tabs no longer fit, the rail scrolls sideways and a slim strip
 * under the bar shows where you are: drag its thumb, click the strip to
 * jump, or roll the mouse wheel over the tabs. Picking a tab brings it
 * into view. Off (and invisible) whenever everything fits. */
var RailScroll = { rail: null, bar: null, strip: null, thumb: null, on: false, need: 0 };

function railScrollUpdate() {
  var R = RailScroll, rail = R.rail;
  if (!rail || !R.strip) return;
  /* on: the shrunk tabs spill out of the rail; off again only once the
     panel is a little wider than where it switched on, so it never flickers
     on the edge */
  var over;
  if (!R.on) over = rail.scrollWidth - rail.clientWidth > 1;
  else over = rail.clientWidth < R.need + 2;
  if (over !== R.on) {
    /* the width the tabs need at their smallest: measured while they spill */
    if (over) R.need = rail.scrollWidth;
    R.on = over;
    rail.classList.toggle("rail-scroll", over);
    if (!over) rail.scrollLeft = 0;
    railSurfaceMeasure();
    if (state.tab) railPillGoTo(state.tab, true);
  }
  if (!over) return;
  var sw = rail.scrollWidth, cw = rail.clientWidth, sl = rail.scrollLeft;
  var track = R.strip.clientWidth;
  var tw = Math.max(18, Math.round(track * cw / sw));
  var max = Math.max(1, sw - cw);
  var x = Math.round((track - tw) * Math.min(1, sl / max));
  R.thumb.style.width = tw + "px";
  R.thumb.style.transform = "translateX(" + x + "px)";
  /* the strip (and the light theme's grain) sit inside the scroller: keep
     them still while the tabs move */
  R.strip.style.transform = "translateX(" + sl + "px)";
  var grains = rail.querySelectorAll(":scope > .pl-grain");
  for (var i = 0; i < grains.length; i++) grains[i].style.transform = "translateX(" + sl + "px)";
}

function railScrollToTab(tab, smooth) {
  var R = RailScroll, rail = R.rail;
  if (!rail || !R.on) return;
  var btn = rail.querySelector('.rail-btn[data-tab="' + tab + '"]');
  if (!btn) return;
  var rr = rail.getBoundingClientRect(), br = btn.getBoundingClientRect();
  var pad = 36, target = rail.scrollLeft;
  if (br.left < rr.left + pad) target += br.left - rr.left - pad;
  else if (br.right > rr.right - pad) target += br.right - rr.right + pad;
  else return;
  if (smooth && rail.scrollTo) { try { rail.scrollTo({ left: target, behavior: "smooth" }); return; } catch (e) {} }
  rail.scrollLeft = target;
}

function initRailScroll(rail) {
  var R = RailScroll;
  R.rail = rail;
  R.bar = rail.querySelector(".rail-bar");
  R.strip = $("rail-scrollbar");
  R.thumb = $("rail-scrollbar-thumb");
  if (!R.strip || !R.thumb) return;

  rail.addEventListener("scroll", railScrollUpdate, { passive: true });
  window.addEventListener("resize", railScrollUpdate);
  if (window.ResizeObserver) new ResizeObserver(railScrollUpdate).observe(rail);

  /* the wheel scrolls the tabs sideways */
  rail.addEventListener("wheel", function (e) {
    if (!R.on) return;
    var d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
    if (!d) return;
    rail.scrollLeft += d;
    e.preventDefault();
  }, { passive: false });

  /* drag the thumb, or press anywhere on the strip to jump there */
  var drag = null;
  function toScroll(clientX, grabOffset) {
    var sr = R.strip.getBoundingClientRect(), tw = R.thumb.offsetWidth;
    var room = Math.max(1, sr.width - tw);
    var f = (clientX - sr.left - grabOffset) / room;
    rail.scrollLeft = Math.max(0, Math.min(1, f)) * (rail.scrollWidth - rail.clientWidth);
  }
  R.strip.addEventListener("pointerdown", function (e) {
    if (e.button !== undefined && e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();
    var tr = R.thumb.getBoundingClientRect();
    var onThumb = e.clientX >= tr.left && e.clientX <= tr.right;
    drag = { id: e.pointerId, grab: onThumb ? e.clientX - tr.left : R.thumb.offsetWidth / 2 };
    try { R.strip.setPointerCapture(e.pointerId); } catch (err) {}
    R.strip.classList.add("is-dragging");
    toScroll(e.clientX, drag.grab);
  });
  R.strip.addEventListener("pointermove", function (e) {
    if (!drag || e.pointerId !== drag.id) return;
    toScroll(e.clientX, drag.grab);
  });
  function end(e) {
    if (!drag || (e && e.pointerId !== drag.id)) return;
    drag = null;
    R.strip.classList.remove("is-dragging");
  }
  R.strip.addEventListener("pointerup", end);
  R.strip.addEventListener("pointercancel", end);
  R.strip.addEventListener("lostpointercapture", end);

  railScrollUpdate();
  setTimeout(railScrollUpdate, 300);
}

function setTab(tab) {
  var prev = state.tab;
  state.tab = tab;
  var rails = document.querySelectorAll(".rail-btn[data-tab]");
  for (var r = 0; r < rails.length; r++) {
    rails[r].classList.toggle("active", rails[r].getAttribute("data-tab") === tab);
  }
  railPillGoTo(tab, !RailPill.ready || prev === tab);
  railScrollToTab(tab, prev !== tab);

  var panes = document.querySelectorAll(".pane");
  for (var j = 0; j < panes.length; j++) {
    var shown = panes[j].id === "pane-" + tab;
    /* a tab that was on screen is laid out: keep it so (css .pl-warm) */
    if (!shown && !panes[j].classList.contains("hidden")) panes[j].classList.add("pl-warm");
    panes[j].classList.toggle("hidden", !shown);
  }
  var lab = $("tab-label");
  if (lab) lab.textContent = TAB_LABELS[tab] || tab;

  if (window.pillowRescanTactile) window.pillowRescanTactile($("pane-" + tab));
  if (tab === "relink") refreshMissing();
  if (window.PillowCurves) {
    if (tab === "curves") window.PillowCurves.resume();
    else window.PillowCurves.pause();
  }
  if (window.PillowText) {
    if (tab === "text") window.PillowText.resume();
    else window.PillowText.pause();
  }
  if (window.PillowSfx) {
    if (tab === "sfx") window.PillowSfx.resume();
    else window.PillowSfx.pause();
  }
  if (window.PillowBounce) {
    if (tab === "bounce") window.PillowBounce.resume();
    else window.PillowBounce.pause();
  }
  if (window.PillowLiquidGlass) {
    if (tab === "glass") window.PillowLiquidGlass.resume();
    else window.PillowLiquidGlass.pause();
  }
  if (window.PillowLibrary) {
    if (tab === "library") window.PillowLibrary.resume();
    else window.PillowLibrary.pause();
  }
  if (window.PillowMusic && tab === "music" && window.PillowMusic.refresh) {
    window.PillowMusic.refresh();
  }
}

function effectiveDuration() {
  if (state.matchCompDuration) return 0; // host uses comp.duration when <= 0
  return state.duration;
}

/* ─── Create ──────────────────────────────────────────────── */

/* With "Parent to selected layer" on, hovering Adjustment / Null / Solid
   shows what the new layer will hang off before it is made. */
function bindParentHint() {
  var hint = document.createElement("div");
  hint.className = "parent-hint";
  hint.setAttribute("aria-hidden", "true");
  document.body.appendChild(hint);
  var cur = null, seq = 0;
  function place(btn) {
    var r = btn.getBoundingClientRect(), hw = hint.offsetWidth;
    var x = Math.max(8, Math.min(window.innerWidth - hw - 8, r.left + r.width / 2 - hw / 2));
    hint.style.left = x + "px";
    hint.style.top = Math.max(6, r.top - hint.offsetHeight - 6) + "px";
  }
  function show(btn) {
    cur = btn;
    var par = state.parentSelected && btn.id !== "btn-cam";
    if (!(par || state.fitSelected) || typeof host !== "function") return;
    var my = ++seq;
    host("pillowParentTarget()", function (r) {
      if (my !== seq || cur !== btn) return;
      if (!r || !r.ok) return;
      hint.classList.toggle("none", !r.name);
      /* what the button will do with the selection: above it, parented */
      hint.innerHTML = r.name
        ? (state.fitSelected ? '<span class="ph-k">\u2191 above</span> <b>' + escapeHtml(r.top || r.name) + "</b>" : "") +
          (state.fitSelected && par ? " " : "") +
          (par ? '<span class="ph-k">\u2192 parent to</span> <b>' + escapeHtml(r.name) + "</b>" : "")
        : '<span class="ph-k">No layer selected</span>';
      place(btn);
      hint.classList.add("show");
    });
  }
  function hide() { cur = null; seq++; hint.classList.remove("show"); }
  ["btn-adj", "btn-null", "btn-solid", "btn-cam"].forEach(function (id) {
    var b = $(id);
    if (!b) return;
    b.addEventListener("mouseenter", function () { show(b); });
    b.addEventListener("mouseleave", hide);
    b.addEventListener("click", hide);
  });
}

/* "Null (Pillow) added above Clip 3 → parented to Clip 3" */
function addedMsg(name, r) {
  return name + (r.above ? " added above " + r.above : " added") + (r.parent ? " \u2192 parented to " + r.parent : "");
}

function addAdjustment() {
  var name = ($("inp-name") && $("inp-name").value) || "";
  host(
    'pillowAddAdjustment("' + esc(name) + '",' + effectiveDuration() + "," + state.parentSelected + "," + state.fitSelected + ")",
    function (r) {
      if (r.ok) toast(addedMsg(r.name || "Adjustment", r));
      else toast(r.error || "Failed", true);
    }
  );
}

function addNull() {
  var name = ($("inp-name") && $("inp-name").value) || "";
  host(
    'pillowAddNull("' + esc(name) + '",' + state.parentSelected + "," + state.fitSelected + ")",
    function (r) {
      if (r.ok) toast(addedMsg(r.name || "Null", r));
      else toast(r.error || "Failed", true);
    }
  );
}

function addCamera() {
  var name = ($("inp-name") && $("inp-name").value) || "";
  host('pillowAddCamera("' + esc(name) + '",' + !!state.camTwoNode + "," + state.fitSelected + ")", function (r) {
    if (r.ok) toast(addedMsg(r.name || "Camera", r));
    else toast(r.error || "Failed", true);
  });
}

function addSolid() {
  var name = ($("inp-name") && $("inp-name").value) || "";
  var c = state.solidColor;
  host(
    'pillowAddSolid("' + esc(name) + '",' + c[0] + "," + c[1] + "," + c[2] + "," +
      effectiveDuration() + "," + state.parentSelected + "," + state.fitSelected + ")",
    function (r) {
      if (r.ok) toast(addedMsg(r.name || "Solid", r));
      else toast(r.error || "Failed", true);
    }
  );
}

function addPrecomp() {
  var name = ($("inp-name") && $("inp-name").value) || "";
  host('pillowPrecompose("' + esc(name) + '")', function (r) {
    if (r.ok) toast((r.name || "Pre-comp") + " created");
    else toast(r.error || "Failed", true);
  });
}

function stagger() {
  host("pillowStagger()", function (r) {
    if (r.ok) toast("Staggered " + r.count + " layers");
    else toast(r.error || "Failed", true);
  });
}

/* ─── Relink ──────────────────────────────────────────────── */

function refreshMissing() {
  host("pillowFindMissing()", function (r) {
    if (!r.ok) {
      toast(r.error || "Could not scan project", true);
      return;
    }
    state.missing = r.items || [];
    renderMissing();
    var sub = $("relink-sub");
    if (sub) {
      sub.textContent = r.count
        ? r.count + " offline · Pillow finds them for you"
        : "All files are linked";
    }
  });
}

function renderMissing() {
  var list = $("asset-list");
  if (!list) return;
  if (!state.missing.length) {
    list.innerHTML =
      '<li style="text-align:center;color:var(--muted);font-size:11px;padding:16px">No missing footage</li>';
    return;
  }
  var html = "";
  for (var i = 0; i < state.missing.length; i++) {
    var a = state.missing[i];
    html +=
      '<li class="asset-item"><span class="asset-dot"></span><span class="asset-name">' +
      escapeHtml(a.name) +
      '</span><span class="chip missing">Offline</span></li>';
  }
  list.innerHTML = html;
}

/* Relink: one button. The panel lists what is missing (with each file's
   old path), searches the disk for those file names itself (js/relink-
   find.js: next to the old place, the system search index, then every
   drive; asynchronous, AE keeps working) and links back what it found.
   Pressing the button while it searches stops the search. Without Node
   the host does a shallower search of its own. "Search a folder" is
   only there for files kept somewhere unusual. */
var _relinkBusy = false;
function relinkReport(res, scanned) {
  var report = $("relink-report");
  if (!report) return;
  var leftList = res.left || [], left = leftList.length;
  var how = res.how === "disk" ? "Searched the whole computer" + (res.dirs ? " · " + res.dirs + " folders" : "") :
    res.how === "ae" ? "Searched near the project only — disk search is off, restart After Effects" : "";
  var miss = "";
  for (var i = 0; i < leftList.length && i < 8; i++) {
    var L = leftList[i], nm = typeof L === "string" ? L : (L.fname || L.name || ""), old = typeof L === "string" ? "" : (L.old || "");
    miss += '<li><span class="rl-name">' + escapeHtml(nm) + "</span>" + (old ? '<span class="rl-old">' + escapeHtml(old) + "</span>" : "") + "</li>";
  }
  report.className = "report";
  report.innerHTML =
    '<div class="field-label">Report</div>' +
    '<div class="big">' + (res.linked || 0) + " relinked</div>" +
    '<div class="report-stats">' +
    '<div><div class="n">' + (scanned || 0) + '</div><div class="l">Missing</div></div>' +
    '<div><div class="n">' + (res.linked || 0) + '</div><div class="l">Found</div></div>' +
    '<div><div class="n">' + left + '</div><div class="l">Unfound</div></div>' +
    "</div>" +
    (how ? '<div class="rl-how">' + how + "</div>" : "") +
    (miss ? '<div class="field-label rl-head">Not found anywhere — renamed, deleted or on a drive that is not connected</div><ul class="rl-list">' + miss + "</ul>" : "");
}
function relinkSub(text) { var sub = $("relink-sub"); if (sub) sub.textContent = text; }
function relinkDone(res, total) {
  _relinkBusy = false;
  var hero = $("btn-relink");
  if (hero) hero.classList.remove("is-busy");
  if (!res) { refreshMissing(); return; }
  relinkReport(res, total);
  var left = (res.left && res.left.length) || 0;
  if (!left) toast("Relinked " + (res.linked || 0) + ((res.linked || 0) === 1 ? " file" : " files"));
  else toast((res.linked ? "Relinked " + res.linked + " · " : "") + left + " not found on this computer", !res.linked);
  refreshMissing();
}
function runAutoRelink(path, done) {
  host("pillowAutoRelink(" + (path ? JSON.stringify(path) : "") + ")", function (res) {
    if (!res || !res.ok) { toast((res && res.error) || "Relink failed", true); done && done(null); return; }
    done && done(res);
  });
}
/* JSON with every non-ASCII character escaped, safe to hand to evalScript */
function asciiJson(v) {
  return JSON.stringify(v).replace(/[\u007f-\uffff]/g, function (c) {
    return "\\u" + ("000" + c.charCodeAt(0).toString(16)).slice(-4);
  });
}
function startRelink() {
  if (_relinkBusy) {
    /* stop; and should the search not answer, the button is freed anyway
       rather than stay "busy" for good, swallowing every later press */
    if (window.PillowFinder) window.PillowFinder.cancel();
    setTimeout(function () {
      if (!_relinkBusy) return;
      _relinkBusy = false;
      var h = $("btn-relink");
      if (h) h.classList.remove("is-busy");
      relinkSub("Stopped");
      refreshMissing();
    }, 2500);
    return;
  }
  _relinkBusy = true;
  var hero0 = $("btn-relink");
  if (hero0) hero0.classList.add("is-busy");
  relinkSub("Checking the project…");
  host("pillowMissingInfo()", function (info) {
    if (!info || !info.ok) { toast((info && info.error) || "Could not scan project", true); relinkDone(null); return; }
    var items = info.items || [], total = items.length;
    if (!total) { _relinkBusy = false; if (hero0) hero0.classList.remove("is-busy"); toast("All files are linked"); refreshMissing(); return; }
    var hero = $("btn-relink");
    if (hero) hero.classList.add("is-busy");
    if (!window.PillowFinder || !window.PillowFinder.ok) {
      relinkSub("Looking for " + total + " files…");
      runAutoRelink(null, function (res) { if (res) res.how = "ae"; relinkDone(res, total); });
      return;
    }
    relinkSub("Looking for " + total + " files…");
    var started = false;
    try { started = true; window.PillowFinder.find(items, info.project, function (p) {
      var where = p.phase === "near" ? "Next to their old place" : p.phase === "index" ? "In the system search" : "On all drives";
      relinkSub(where + " · " + p.found + "/" + p.total + " found · " + p.dirs + " folders · press to stop");
    }, function (out) {
      var pairs = [];
      for (var i = 0; i < items.length; i++) if (out.found[items[i].id]) pairs.push({ id: items[i].id, path: out.found[items[i].id] });
      var leftItems = [];
      for (var li = 0; li < items.length; li++) if (!out.found[items[li].id]) leftItems.push(items[li]);
      if (!pairs.length) { relinkDone({ linked: 0, left: leftItems, how: "disk", dirs: out.dirs }, total); return; }
      relinkSub("Linking " + pairs.length + " files…");
      host('pillowRelinkApply("' + esc(asciiJson(pairs)) + '")', function (res) {
        if (!res || !res.ok) { toast((res && res.error) || "Relink failed", true); relinkDone(null); return; }
        res.how = "disk"; res.dirs = out.dirs;
        var still = {};
        for (var k = 0; k < (res.left || []).length; k++) still[String(res.left[k]).toLowerCase()] = true;
        var rich = [];
        for (var m = 0; m < items.length; m++) if (still[String(items[m].fname).toLowerCase()]) rich.push(items[m]);
        if (rich.length) res.left = rich;
        relinkDone(res, total);
      });
    }); } catch (eF) { started = false; }
    /* the disk search could not start: the host searches instead */
    if (!started) runAutoRelink(null, function (res) { if (res) res.how = "ae"; relinkDone(res, total); });
  });
}

/* only for files kept somewhere unusual: one folder, searched deep */
function relinkPickFolder() {
  if (_relinkBusy) return;
  host("pillowPickFolder()", function (r) {
    if (!r || r.cancelled || !r.ok || !r.path) return;
    state.lastFolder = r.path;
    try { localStorage.setItem("pillow_last_folder", r.path); } catch (e) {}
    _relinkBusy = true;
    relinkSub("Searching the folder…");
    host("pillowMissingInfo()", function (info) {
      var total = info && info.items ? info.items.length : 0;
      runAutoRelink(r.path, function (res) { relinkDone(res, total); });
    });
  });
}

/* ─── Favorites helpers (shared) ──────────────────────────── */

function loadFavSet(key) {
  try {
    var raw = localStorage.getItem(key);
    if (!raw) return {};
    var arr = JSON.parse(raw);
    var map = {};
    for (var i = 0; i < arr.length; i++) map[arr[i]] = true;
    return map;
  } catch (e) {
    return {};
  }
}

function saveFavSet(key, map) {
  var arr = [];
  for (var k in map) if (map[k]) arr.push(k);
  try {
    localStorage.setItem(key, JSON.stringify(arr));
  } catch (e) {}
}

function toggleFav(key, id) {
  var map = loadFavSet(key);
  map[id] = !map[id];
  if (!map[id]) delete map[id];
  saveFavSet(key, map);
  return !!map[id];
}

function isFav(key, id) {
  return !!loadFavSet(key)[id];
}

window.PillowFav = {
  load: loadFavSet,
  save: saveFavSet,
  toggle: toggleFav,
  is: isFav,
  CURVES: "pillow_fav_curves",
  TEXT: "pillow_fav_text"
};

/* ─── Swatches ────────────────────────────────────────────── */

function renderSwatches() {
  var box = $("swatches");
  if (!box) return;
  try { var saved = localStorage.getItem("pillow.solidHex"); if (saved && /^#[0-9a-f]{6}$/i.test(saved)) { state.solidHex = saved; state.solidColor = hexToRgb01(saved); } } catch (e) {}
  /* one button that opens the colour sheet (js/color-picker.js) */
  if (window.PillowColorPicker) {
    window.PillowColorPicker.mount(box, state.solidHex, function (hex) {
      state.solidHex = hex;
      state.solidColor = hexToRgb01(hex);
      try { localStorage.setItem("pillow.solidHex", hex); } catch (e2) {}
    });
    return;
  }
  var html = "";
  for (var i = 0; i < SWATCHES.length; i++) {
    var c = SWATCHES[i];
    html +=
      '<button type="button" class="swatch' +
      (c === state.solidHex ? " active" : "") +
      '" data-color="' + c + '" style="background:' + c + '" aria-label="' + c + '"></button>';
  }
  box.innerHTML = html;
  box.onclick = function (ev) {
    var btn = ev.target.closest ? ev.target.closest("[data-color]") : null;
    if (!btn) return;
    state.solidHex = btn.getAttribute("data-color");
    state.solidColor = hexToRgb01(state.solidHex);
    renderSwatches();
  };
}

/* ─── Connection status ───────────────────────────────────── */

function updateStatusBar(ping) {
  var dot = $("status-dot");
  var conn = $("status-conn");
  var right = $("status-right");
  if (right) right.textContent = "Pillow " + PILLOW_VERSION + " · After Effects";

  if (!csInterface) {
    if (dot) dot.className = "status-dot off";
    if (conn) conn.textContent = "Offline · open in AE";
    return;
  }

  if (ping && ping.ok) {
    if (dot) dot.className = "status-dot " + (ping.hasComp ? "on" : "warn");
    if (conn) {
      conn.textContent = ping.hasComp
        ? "Connected · Comp ready"
        : "Connected · Open a comp";
    }
  } else {
    if (dot) dot.className = "status-dot on";
    if (conn) conn.textContent = "Connected · Direct mode";
    try {
      var env = csInterface.getHostEnvironment();
      if (right) {
        right.textContent =
          "Pillow " + PILLOW_VERSION + " · " +
          (env.appName || "AE") + " " + (env.appVersion || "");
      }
    } catch (e) {}
  }
}

function pingHost() {
  if (!csInterface) {
    updateStatusBar(null);
    return;
  }
  /* nothing to show while the panel is hidden — don't poke AE for it;
     and not while the user works elsewhere in AE (playing back, rendering
     previews): a script call in the middle of that is a known way to
     crash After Effects */
  if (document.hidden) return;
  if (window.PillowPresence && !window.PillowPresence.awake()) return;
  host("pillowPing()", function (r) {
    if (r && r.ok) { updateStatusBar(r); return; }
    /* be honest: a host that is not answering is not "connected" */
    var dot = $("status-dot"), conn = $("status-conn");
    if (dot) dot.className = "status-dot warn";
    if (conn) conn.textContent = "AE script not loaded";
  });
}

/* ─── Keyboard ────────────────────────────────────────────── */

function bindKeyboard() {
  /* focus ring only while navigating with Tab (css/minimal.css) */
  document.addEventListener("keydown", function (ev) {
    if (ev.key === "Tab") document.documentElement.classList.add("pl-kbd");
  }, true);
  document.addEventListener("pointerdown", function () {
    document.documentElement.classList.remove("pl-kbd");
  }, true);
  document.addEventListener("keydown", function (ev) {
    var tag = (ev.target && ev.target.tagName) || "";
    if (tag === "INPUT" || tag === "TEXTAREA") return;

    if (ev.key === "1") setTab("create");
    else if (ev.key === "2") setTab("curves");
    else if (ev.key === "3") setTab("bounce");
    else if (ev.key === "4") setTab("text");
    else if (ev.key === "5") setTab("relink");
    else if (ev.key === "6") setTab("sfx");
    else if (ev.key === "7") setTab("music");
    else if (ev.key === "8") setTab("library");
    else if (state.tab === "create") {
      if (ev.key === "a" || ev.key === "A") addAdjustment();
      else if (ev.key === "n" || ev.key === "N") addNull();
    } else if (state.tab === "curves" && (ev.key === "Enter") && !ev.metaKey) {
      if (window.PillowCurves && window.PillowCurves.apply) window.PillowCurves.apply();
    } else if (state.tab === "text" && ev.key === "Enter") {
      if (window.PillowText && window.PillowText.apply) window.PillowText.apply();
    } else if (state.tab === "bounce" && ev.key === "Enter") {
      if (window.PillowBounce && window.PillowBounce.apply) window.PillowBounce.apply();
    }
  });
}

/* ─── Tactile ─────────────────────────────────────────────── */

function initTactile() {
  var SELECTOR =
    ".card, .text-card, .curve-preset-row, .relink-hero, " +
    ".btn-primary, .btn-ghost, .rail-btn, .dir-btn, .tool-btn, .inout-btn, .settings-tab, .text-cat, .bnc-preset, " +
    ".sfx-play, .sfx-add, .swatch, .fav-star";
  var SMALL =
    ".btn-ghost, .rail-btn, .dir-btn, .tool-btn, .inout-btn, .settings-tab, .text-cat, " +
    ".sfx-play, .sfx-add, .swatch, .fav-star";
  var TEXT_SELECTOR =
    ".curve-preset-row .name, .curve-preset-row .hint, .text-card .name, .text-card .hint, .graph-name";
  var PUSH_MAX = 2.5;
  var PUSH_DIST = 120;
  var root = document.getElementById("app") || document.body;
  var active = null;
  var activeText = null;

  function markTactile(el) {
    if (!el || el._tactile) return;
    el._tactile = true;
    if ((" " + el.className + " ").indexOf(" tactile ") === -1) el.className += " tactile";
    if (el.matches && el.matches(SMALL)) {
      if ((" " + el.className + " ").indexOf(" tactile-sm ") === -1) el.className += " tactile-sm";
    }
    /* the calm look (css/minimal.css): plain rounded surfaces — no
       crumpled silhouettes, perimeter light or neighbour push */
    if (!MINIMAL) organicShape(el);
  }
  var MINIMAL = true;

  /* ─── Individual silhouettes ─────────────────────────────────────────
   * Every content surface is painted as its own generated silhouette: a
   * rounded rectangle whose four corners have independent radii and whose
   * sides carry two or three soft, asymmetric dents and bulges (about 2px).
   * The shape is drawn as a background SVG with the surface fill and the
   * 1px rim baked in — exactly the technique the primary buttons already
   * use — so nothing is clipped: interior, padding, icons, text, hover,
   * press and displacement all behave as before. Deterministic per DOM
   * order, so a plate keeps its own pattern. The top rail is excluded. */
  var ORGANIC_BOX =
    ".card, .text-card, .curve-preset-row, .relink-hero, .sfx-row, .bnc-preset, " +
    ".btn-ghost, .asset-item, .tool-btn, .dir-btn, .inout-btn, .kbd-row, .glass-panel, " +
    ".text-cat, .settings-tab";
  var _orgSeq = 0;
  var _orgList = [];

  /** Straight run from p0 to p1 as three cubics, each knot pushed along the
   *  edge normal by its own amount: reads as soft pressed material rather
   *  than a wave, because the offsets are uneven and the corners stay at 0. */
  function orgSide(x0, y0, x1, y1, nx, ny, o, n) {
    var segs = o.length - 1;
    var d = "";
    for (var k = 0; k < segs; k++) {
      var t0 = k / segs, t1 = (k + 1) / segs;
      var a0 = o[k], a1 = o[k + 1];
      var px = function (t) { return x0 + (x1 - x0) * t; };
      var py = function (t) { return y0 + (y1 - y0) * t; };
      var oa = function (t) {
        var lt = (t - t0) / (t1 - t0);
        // smooth (cosine) blend between the two knot offsets
        var s = 0.5 - Math.cos(lt * Math.PI) / 2;
        return a0 + (a1 - a0) * s;
      };
      var c1t = t0 + (t1 - t0) / 3, c2t = t0 + ((t1 - t0) * 2) / 3;
      d += " C " + n(px(c1t) + nx * oa(c1t)) + " " + n(py(c1t) + ny * oa(c1t)) +
           " " + n(px(c2t) + nx * oa(c2t)) + " " + n(py(c2t) + ny * oa(c2t)) +
           " " + n(px(t1) + nx * a1) + " " + n(py(t1) + ny * a1);
    }
    return d;
  }

  function orgFacePath(w, h, rnd, base, amp) {
    var r = [], i;
    for (i = 0; i < 4; i++) r.push(base + (rnd() * 2 - 1) * (base < 9 ? 1.2 : 2));
    var maxR = Math.min(w, h) / 2 - 1;
    for (i = 0; i < 4; i++) { if (r[i] < 2.5) r[i] = 2.5; if (r[i] > maxR) r[i] = maxR; }

    /* One dent roughly every 110px, so a long card gets several small
       asymmetric deformations instead of one lazy wave. Ends stay at 0 so
       the corners are clean, and each knot gets its own depth. */
    var side = function (len) {
      var segs = Math.round(len / 110);
      if (segs < 2) segs = 2;
      if (segs > 6) segs = 6;
      var o = [0], k;
      for (k = 1; k < segs; k++) {
        /* Mostly gentle dents pressed inward, with the occasional small
           bulge; the bulge stays within the 1.2px the stroke already has,
           so the plate never grows past its own box. */
        var v = rnd() < 0.28 ? rnd() * 0.9 : -(0.3 + rnd() * 0.7) * amp;
        if (k > 1 && v < 0 && o[k - 1] < 0 && Math.abs(v - o[k - 1]) < amp * 0.3) v *= 0.45;
        o.push(v);
      }
      o.push(0);
      return o;
    };
    var n = function (v) { return Math.round(v * 100) / 100; };
    var pad = 1.2;   // stroke room only: the silhouette fills its real box
    var x = pad, y = pad, x1 = w - pad, y1 = h - pad;

    var d = "M " + n(x + r[0]) + " " + n(y);
    d += orgSide(x + r[0], y, x1 - r[1], y, 0, -1, side(w), n);
    d += " Q " + n(x1) + " " + n(y) + " " + n(x1) + " " + n(y + r[1]);
    d += orgSide(x1, y + r[1], x1, y1 - r[2], 1, 0, side(h), n);
    d += " Q " + n(x1) + " " + n(y1) + " " + n(x1 - r[2]) + " " + n(y1);
    d += orgSide(x1 - r[2], y1, x + r[3], y1, 0, 1, side(w), n);
    d += " Q " + n(x) + " " + n(y1) + " " + n(x) + " " + n(y1 - r[3]);
    d += orgSide(x, y1 - r[3], x, y + r[0], -1, 0, side(h), n);
    d += " Q " + n(x) + " " + n(y) + " " + n(x + r[0]) + " " + n(y);
    return d + " Z";
  }

  function cssVar(name, fallback) {
    try {
      var v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
      return v || fallback;
    } catch (e) { return fallback; }
  }

  /* Чтение (размер, цвет) отделено от записи (background-image): при
     обходе десятков поверхностей чтение сразу после записи заставляло
     браузер пересчитывать раскладку на каждом элементе. */
  function orgFace(el, pre) {
    var w = pre ? pre.w : el.offsetWidth, h = pre ? pre.h : el.offsetHeight;
    if (!w || !h) return;
    var theme = document.documentElement.getAttribute("data-theme");
    if (el._orgW === w && el._orgH === h && el._orgTheme === theme) return;
    el._orgW = w; el._orgH = h; el._orgTheme = theme;

    /* Read fresh every time (not cached): this is the element's own
       background-color, which resolves through the theme's CSS variables
       (e.g. var(--input-bg)). Caching it on first paint froze every organic
       face at whichever theme was active on load — dark<->light toggling
       never changed it again, since the element's real background-color
       is fully hidden beneath this baked SVG. */
    var bc = pre ? pre.bc : getComputedStyle(el).backgroundColor;
    var fill = (bc && bc !== "rgba(0, 0, 0, 0)" && bc !== "transparent") ? bc : (pre ? pre.card : cssVar("--card", "#1a1a1a"));
    var rim = pre ? pre.rim : cssVar("--rim", "rgba(255,255,255,0.10)");
    var amp = h < 26 ? 1.5 : 2.4;
    var d = orgFacePath(w, h, plRand(el._orgSeed), el._orgBase || 10, amp);
    var id = "og" + el._orgSeq;
    var svg =
      "<svg xmlns='http://www.w3.org/2000/svg' width='" + w + "' height='" + h + "'>" +
      "<defs><linearGradient id='" + id + "' x1='0' y1='0' x2='0' y2='1'>" +
      "<stop offset='0' stop-color='" + fill + "'/>" +
      "<stop offset='1' stop-color='" + fill + "'/></linearGradient></defs>" +
      "<path d='" + d + "' fill='url(#" + id + ")' stroke='" + rim + "' stroke-width='1'/>" +
      "</svg>";
    el.style.backgroundImage = 'url("data:image/svg+xml,' + encodeURIComponent(svg) + '")';
    el.classList.add("org-face");
  }

  function organicShape(el) {
    if (!el.matches || el._organic) return;
    if (el.closest && el.closest(".rail")) return;          // top nav stays uniform
    if (el.matches(".btn-primary")) return;                  // has its own silhouette
    if (!el.matches(ORGANIC_BOX)) return;
    el._organic = true;

    _orgSeq++;
    el._orgSeq = _orgSeq;
    el._orgSeed = 4703 * _orgSeq + 271 + (_orgSeq % 7) * 1597;
    /* радиус читается в orgRefresh() в фазе замеров: здесь, сразу после
       правки классов в markTactile, чтение стиля пересчитывало стили на
       каждом элементе */
    _orgList.push(el);
    /* рисуется пачкой в orgRefresh() (scan вызывает его сразу после) */
  }

  /* scope — только элементы внутри него; скрытые вкладки пропускаются без
     чтения размеров (чтение заставляло браузер раскладывать весь интерфейс) */
  function orgRefresh(force, scope) {
    var theme = document.documentElement.getAttribute("data-theme");
    var card = null, rim = null;
    var todo = [], i, e;
    /* 1. только чтение */
    for (i = 0; i < _orgList.length; i++) {
      e = _orgList[i];
      if (!e.isConnected) continue;
      if (scope && !scope.contains(e)) continue;
      if (!force && e.closest && e.closest(".pane.hidden:not(.pl-prewarm)")) continue;
      if (force) e._orgW = 0;
      var w = e.offsetWidth, h = e.offsetHeight;
      if (!w || !h) continue;
      if (e._orgW === w && e._orgH === h && e._orgTheme === theme) continue;
      var cs = getComputedStyle(e);
      if (e._orgBase === undefined) e._orgBase = parseFloat(cs.borderTopLeftRadius) || 10;
      if (card === null) { card = cssVar("--card", "#1a1a1a"); rim = cssVar("--rim", "rgba(255,255,255,0.10)"); }
      todo.push({ el: e, w: w, h: h, bc: cs.backgroundColor, card: card, rim: rim });
    }
    /* 2. только запись */
    for (i = 0; i < todo.length; i++) orgFace(todo[i].el, todo[i]);
  }
  window.pillowRefreshFaces = orgRefresh;

  /* scope — узел, который нужно досмотреть (открытая вкладка); без него —
     весь интерфейс. При смене вкладки полный обход стоил ~60 мс. */
  function scan(scope) {
    var r = scope && scope.nodeType === 1 ? scope : root;
    var nodes = r.querySelectorAll(SELECTOR);
    for (var i = 0; i < nodes.length; i++) markTactile(nodes[i]);
    // controls that are not part of the tactile set still get their own shape
    var org = r.querySelectorAll(ORGANIC_BOX);
    if (!MINIMAL) for (var j = 0; j < org.length; j++) organicShape(org[j]);
    orgRefresh(false, r === root ? null : r);   // plates in panes that were hidden get painted here
    edgePrimaries(r);
  }

  /** Every primary action button gets a slightly crumpled silhouette and a
   *  perimeter light sitting just outside it. Geometry is generated from the
   *  measured box, so it follows resizes and never distorts. */
  var PL_PAD = 5;   // svg breathing room
  var PL_OUT = 3;   // how far the light sits outside the button edge
  var _plSeq = 0;

  function plRand(seed) {
    var s = seed;
    return function () {
      s = (s * 1103515245 + 12345) & 0x7fffffff;
      return s / 0x7fffffff;
    };
  }

  /** Rounded rectangle with uneven corner radii and softly waving sides.
   *  Each side is a cubic with two independently nudged control points, so
   *  the silhouette reads slightly crumpled rather than bulged. Amplitudes
   *  stay within a couple of px — premium, not damaged. */
  function plPath(x, y, w, h, rnd, amp) {
    var r = [];
    var i;
    for (i = 0; i < 4; i++) r.push(8 + rnd() * 8);
    var maxR = Math.min(w, h) / 2 - 1;
    for (i = 0; i < 4; i++) if (r[i] > maxR) r[i] = maxR;
    var a = [];
    for (i = 0; i < 8; i++) a.push((rnd() * 2 - 1) * amp);

    var x1 = x + w, y1 = y + h;
    var n = function (v) { return Math.round(v * 100) / 100; };
    return [
      "M", n(x + r[0]), n(y),
      "C", n(x + w * 0.34), n(y - a[0]), n(x + w * 0.67), n(y - a[1]), n(x1 - r[1]), n(y),
      "Q", n(x1), n(y), n(x1), n(y + r[1]),
      "C", n(x1 + a[2]), n(y + h * 0.34), n(x1 + a[3]), n(y + h * 0.67), n(x1), n(y1 - r[2]),
      "Q", n(x1), n(y1), n(x1 - r[2]), n(y1),
      "C", n(x + w * 0.67), n(y1 + a[4]), n(x + w * 0.34), n(y1 + a[5]), n(x + r[3]), n(y1),
      "Q", n(x), n(y1), n(x), n(y1 - r[3]),
      "C", n(x - a[6]), n(y + h * 0.67), n(x - a[7]), n(y + h * 0.34), n(x), n(y + r[0]),
      "Q", n(x), n(y), n(x + r[0]), n(y),
      "Z"
    ].join(" ");
  }

  function plBuild(btn) {
    var w = btn.offsetWidth, h = btn.offsetHeight;
    if (!w || !h) return;
    var theme = document.documentElement.getAttribute("data-theme");
    /* --accent flips between themes (near-white in dark, near-black in
       light), and it's baked as a literal color into this SVG below — so
       a theme change has to be able to rebuild the face even when the
       button's own size hasn't moved. */
    if (btn._plW === w && btn._plH === h && btn._plTheme === theme) return;
    btn._plW = w; btn._plH = h; btn._plTheme = theme;

    if (!btn._plId) {
      _plSeq++;
      btn._plId = "pl-clip-" + _plSeq;
      btn._plSeed = 7919 * _plSeq + 13;
    }

    // crumpled face painted as a background SVG (clip-path would also clip
    // the perimeter light, which must sit OUTSIDE the button box)
    var rndA = plRand(btn._plSeed);
    var face = plPath(1.2, 1.2, w - 2.4, h - 2.4, rndA, 2.1);
    var fill = "#e8e8e8";
    try {
      var cv = getComputedStyle(document.documentElement).getPropertyValue("--accent");
      if (cv && cv.replace(/\s/g, "")) fill = cv.replace(/\s/g, "");
    } catch (eC) {}
    var faceSvg =
      "<svg xmlns='http://www.w3.org/2000/svg' width='" + w + "' height='" + h + "'>" +
      "<path d='" + face + "' fill='" + fill + "'/></svg>";
    btn.style.backgroundImage = 'url("data:image/svg+xml,' + encodeURIComponent(faceSvg) + '")';
    btn.classList.add("pl-shaped");

    // perimeter light: its own irregularity, so it is not a parallel offset
    var svg = btn._plSvg;
    if (!svg) {
      svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      svg.setAttribute("class", "pl-edge");
      svg.setAttribute("aria-hidden", "true");
      var mk = function (cls) {
        var p = document.createElementNS("http://www.w3.org/2000/svg", "path");
        p.setAttribute("class", cls);
        svg.appendChild(p);
        return p;
      };
      svg._halo = mk("pl-halo");
      svg._base = mk("pl-base");
      svg._travel = mk("pl-travel");
      btn.appendChild(svg);
      btn._plSvg = svg;
    }
    svg.setAttribute("width", w + PL_PAD * 2);
    svg.setAttribute("height", h + PL_PAD * 2);
    svg.style.left = -PL_PAD + "px";
    svg.style.top = -PL_PAD + "px";

    var rndB = plRand(btn._plSeed + 977);
    var ring = plPath(
      PL_PAD - PL_OUT, PL_PAD - PL_OUT,
      w + PL_OUT * 2, h + PL_OUT * 2,
      rndB, 2.8
    );
    svg._halo.setAttribute("d", ring);
    svg._base.setAttribute("d", ring);
    svg._travel.setAttribute("d", ring);

    var len = 0;
    try { len = svg._travel.getTotalLength(); } catch (e) {}
    if (!len) len = (w + h) * 2;
    // three uneven bright arcs with dark gaps between them
    var seg = [0.05, 0.17, 0.028, 0.245, 0.042, 0.465];
    var dash = [];
    for (var s = 0; s < seg.length; s++) dash.push((len * seg[s]).toFixed(2));
    svg._travel.setAttribute("stroke-dasharray", dash.join(" "));
    svg._travel.style.setProperty("--pl-len", len.toFixed(2) + "px");
  }

  function edgePrimaries(scope) {
    if (MINIMAL) return;
    var btns = (scope || root).querySelectorAll(".btn-primary");
    for (var i = 0; i < btns.length; i++) plBuild(btns[i]);
  }

  var _plTimer = null;
  window.addEventListener("resize", function () {
    if (_plTimer) clearTimeout(_plTimer);
    _plTimer = setTimeout(function () {
      var btns = root.querySelectorAll(".btn-primary");
      for (var i = 0; i < btns.length; i++) { btns[i]._plW = 0; plBuild(btns[i]); }
      orgRefresh(true);
    }, 140);
  });

  function setPos(el, e, rect) {
    var r = rect || el.getBoundingClientRect();
    if (!r.width || !r.height) return;
    var x = ((e.clientX - r.left) / r.width) * 100;
    var y = ((e.clientY - r.top) / r.height) * 100;
    el.style.setProperty("--mx", Math.max(0, Math.min(100, x)).toFixed(2) + "%");
    el.style.setProperty("--my", Math.max(0, Math.min(100, y)).toFixed(2) + "%");
  }

  /* only writes what changed: an unchanged custom property set again
     still restyles the element and everything under it */
  function setPush(el, x, y) {
    if (el._pushX === x && el._pushY === y) return;
    el._pushX = x; el._pushY = y;
    el.style.setProperty("--push-x", x);
    el.style.setProperty("--push-y", y);
  }

  function applyPush(el) { writePush(measurePush(el)); }
  function writePush(todo) {
    if (!todo || MINIMAL) return;
    for (var i = 0; i < todo.length; i++) {
      setPush(todo[i][0], todo[i][1] ? todo[i][1].toFixed(2) + "px" : "0px", todo[i][2] ? todo[i][2].toFixed(2) + "px" : "0px");
    }
  }
  /* reads only: where each neighbour is pushed to */
  function measurePush(el) {
    if (MINIMAL) return null;
    var parent = el.parentElement;
    if (!parent) return null;
    var siblings = parent.children;
    /* 1. read every box first, 2. then write: reading after a write made
       the browser restyle the whole list once per sibling */
    var hr = el.getBoundingClientRect();
    var cx0 = hr.left + hr.width / 2;
    var cy0 = hr.top + hr.height / 2;
    var todo = [], i, sib;
    for (i = 0; i < siblings.length; i++) {
      sib = siblings[i];
      if (sib === el || !sib._tactile) continue;
      // a held-down control keeps its press geometry: never nudge it
      if (sib.classList.contains("pl-pressing")) continue;
      // the active rail tab is locked inside the active ball: it must not
      // drift when a neighbouring tab is hovered
      if (sib.classList.contains("rail-btn") && sib.classList.contains("active")) { todo.push([sib, 0, 0]); continue; }
      /* far away along the list: no need to measure it at all */
      if (sib._pushX === undefined || sib._pushX === "0px") {
        var near = Math.abs(sib.offsetTop - el.offsetTop) <= PUSH_DIST + sib.offsetHeight && sib.offsetParent === el.offsetParent;
        if (!near && sib.offsetParent === el.offsetParent) continue;
      }
      var sr = sib.getBoundingClientRect();
      var dx = sr.left + sr.width / 2 - cx0;
      var dy = sr.top + sr.height / 2 - cy0;
      var dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 1 || dist > PUSH_DIST) { todo.push([sib, 0, 0]); continue; }
      var mag = PUSH_MAX * (1 - dist / PUSH_DIST);
      todo.push([sib, (dx / dist) * mag, (dy / dist) * mag]);
    }
    return todo;
  }

  function clearPush(el) {
    if (!el || !el.parentElement) return;
    var siblings = el.parentElement.children;
    for (var i = 0; i < siblings.length; i++) {
      if (siblings[i]._tactile && !siblings[i].classList.contains("pl-pressing")) setPush(siblings[i], "0px", "0px");
    }
  }

  function clearActive() {
    if (!active) return;
    clearPush(active);
    if (!active.classList.contains("pl-pressing")) active.classList.remove("is-hover");
    active = null;
  }

  function clearActiveText() {
    if (!activeText) return;
    activeText.classList.remove("text-hover");
    activeText = null;
  }

  var moveRAF = null;
  var pendingMove = null;
  root.addEventListener(
    "pointermove",
    function (e) {
      pendingMove = e;
      if (moveRAF) return;
      moveRAF = requestAnimationFrame(function () {
        moveRAF = null;
        var e2 = pendingMove;
        if (!e2) return;
        var el = e2.target.closest ? e2.target.closest(SELECTOR) : null;
        if (!el) {
          clearActive();
        } else {
          markTactile(el);
          if (el._organic && !el._orgW) orgFace(el);   /* новый элемент вне scan() */
          /* all reads first, then all writes: a read after a write made
             the browser restyle the panel in the middle of the frame */
          var entering = !el.classList.contains("is-hover");
          var rect = el.getBoundingClientRect();
          var push = entering ? measurePush(el) : null;
          if (active && active !== el) {
            active.classList.remove("is-hover");
            clearPush(active);
          }
          active = el;
          setPos(el, e2, rect);
          if (entering) {
            el.classList.add("is-hover");
            writePush(push);
          }
        }
        var textEl = e2.target.closest ? e2.target.closest(TEXT_SELECTOR) : null;
        if (textEl !== activeText) {
          clearActiveText();
          activeText = textEl;
          if (activeText) activeText.classList.add("text-hover");
        }
      });
    },
    true
  );

  root.addEventListener("pointerleave", function () {
    clearActive();
    clearActiveText();
  }, true);

  window.pillowRescanTactile = scan;
  scan();
}

/* ─── closest polyfill ────────────────────────────────────── */

if (!Element.prototype.closest) {
  Element.prototype.closest = function (sel) {
    var el = this;
    while (el && el.nodeType === 1) {
      if (el.matches ? el.matches(sel) : el.msMatchesSelector(sel)) return el;
      el = el.parentElement;
    }
    return null;
  };
}


/* ─── Theme (dark ↔ light circular wipe) ───────────────────── */

var THEME_KEY = "pillow-theme";
var _themeAnimating = false;

function prefersReducedMotion() {
  try {
    return window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  } catch (e) {
    return false;
  }
}

function getStoredTheme() {
  try {
    var t = localStorage.getItem(THEME_KEY);
    if (t === "light" || t === "dark") return t;
  } catch (e) {}
  return "dark";
}

var _themeSwitchTimer = 0;
function applyThemeInstant(theme) {
  /* No CSS transitions while the theme flips: otherwise every coloured
     surface (300+ on a busy tab) starts its own colour/shadow/filter
     transition at once, and they all run during the reveal — style is
     recalculated for each of them every frame, which is what made the
     switch stutter and hang. The class goes in the same style pass as
     the new theme and comes off once the reveal is over. */
  var html = document.documentElement;
  html.classList.add("theme-switching");
  clearTimeout(_themeSwitchTimer);
  _themeSwitchTimer = setTimeout(function () { html.classList.remove("theme-switching"); }, 1000);
  html.setAttribute("data-theme", theme);
  try { localStorage.setItem(THEME_KEY, theme); } catch (e) {}
  syncThemeToggle(theme);
  /* Every organic-shaped surface (.card, .btn-ghost, .tool-btn, .text-cat,
     .settings-tab, .dir-btn, .inout-btn, .sfx-row, .asset-item, .btn-primary,
     …) paints its real fill as a baked inline SVG background-image, on top
     of the CSS-variable background-color it also carries. That image is
     only (re)generated by initTactile's scan — which switching themes
     itself never triggered — so those surfaces kept showing whichever
     theme was active when they were first painted. pillowRescanTactile is
     the same rescan already reused by curves/bounce/sfx/text after they
     render; it's a safe, idempotent no-op for anything that hasn't
     actually changed. Every plain CSS-variable-driven surface already
     repaints on its own from the data-theme attribute change above. */
  if (window.pillowRescanTactile) window.pillowRescanTactile();
}

var _themeIconReady = false;
function syncThemeToggle(theme) {
  var btn = $("btn-theme");
  if (!btn) return;
  /* dark theme shows the sun (go light), light shows the moon; the first
     paint is instant, every switch after that morphs */
  if (window.PillowThemeIcon) {
    window.PillowThemeIcon.set(theme === "light", _themeIconReady);
    _themeIconReady = true;
  }
  btn.setAttribute("aria-label", theme === "dark" ? "Switch to light theme" : "Switch to dark theme");
  btn.title = theme === "dark" ? "Light theme" : "Dark theme";
}

/** Theme switch: the wave (js/theme-reveal.js) — the new theme opens
 *  from the button in a growing circle. Its snapshot of the old theme is
 *  made ahead, as the pointer comes onto the button, so the click only
 *  flips the theme. */
function runThemeWipe(ev) {
  var html = document.documentElement;
  var next = html.getAttribute("data-theme") === "light" ? "dark" : "light";
  var btn = $("btn-theme");
  var reduced = prefersReducedMotion();
  if (btn && !reduced) {
    btn.classList.remove("is-pressing");
    void btn.offsetWidth;
    btn.classList.add("is-pressing");
  }
  if (reduced || !window.PillowThemeReveal) { applyThemeInstant(next); return; }
  var x, y;
  if (btn) {
    var br = btn.getBoundingClientRect();
    x = br.left + br.width / 2; y = br.top + br.height / 2;
  } else { x = (window.innerWidth || 360) / 2; y = 40; }
  window.PillowThemeReveal.run({ x: x, y: y, apply: function () { applyThemeInstant(next); } });
}

/* ─── No text selection ─────────────────────────────────────── */
/* CSS (panel.css) already blocks selecting text; this also catches what
   CSS can't in CEF: Ctrl/Cmd+A selecting the whole panel, a selection
   started by the host, and dragging images/logos. Inputs stay editable. */
function isEditable(el) {
  if (!el || el.nodeType !== 1) return false;
  var t = el.tagName;
  return t === "INPUT" || t === "TEXTAREA" || el.isContentEditable;
}
function initNoSelect() {
  document.addEventListener("selectstart", function (e) {
    if (!isEditable(e.target && e.target.nodeType === 1 ? e.target : e.target && e.target.parentElement)) e.preventDefault();
  });
  document.addEventListener("dragstart", function (e) {
    if (!isEditable(e.target)) e.preventDefault();
  });
  document.addEventListener("keydown", function (e) {
    if ((e.ctrlKey || e.metaKey) && (e.key === "a" || e.key === "A") && !isEditable(document.activeElement)) {
      e.preventDefault();
    }
  });
}

function initTheme() {
  initNoSelect();
  applyThemeInstant(getStoredTheme());
  /* чёрный логотип светлой темы — заранее, чтобы при первой смене темы
     (и в её снимке) он уже был загружен */
  try { new Image().src = "icons/pillow-mark-dark.png"; } catch (ePre) {}
  var btn = $("btn-theme");
  if (btn) {
    btn.onclick = function (ev) {
      runThemeWipe(ev);
    };
    /* the wave's snapshot is made while the pointer is on the button */
    if (window.PillowThemeReveal) {
      setTimeout(window.PillowThemeReveal.warm, 1500);
      btn.addEventListener("mouseenter", function () { window.PillowThemeReveal.prepare(); });
      btn.addEventListener("pointerdown", function () { window.PillowThemeReveal.prepare(); });
      btn.addEventListener("mouseleave", function () { setTimeout(function () { if (!btn.matches(":hover")) window.PillowThemeReveal.discard(); }, 400); });
    }
  }
}

/* ─── Init ────────────────────────────────────────────────── */

/* ─── Прогрев вкладок ─────────────────────────────────────────
 * Первое открытие Curves / Text / Bounce / SFX стоило 60–230 мс фриза:
 * скрытая (display:none) вкладка впервые раскладывается, её плашки,
 * стекло и формы карточек строятся в момент клика. Повторно — мгновенно.
 * Поэтому вскоре после запуска, в простое, каждая скрытая вкладка по
 * одной на пару кадров раскладывается невидимо (visibility:hidden, вне
 * потока, та же ширина) — вся первичная работа делается заранее, а
 * открытие вкладки потом только показывает готовое. */
function prewarmTabs() {
  var ids = ["curves", "text", "bounce", "sfx", "music", "relink", "library", "glass", "create"];
  var idle = window.requestIdleCallback || function (fn) { return setTimeout(fn, 60); };
  function next() {
    var id = ids.shift();
    if (!id) return;
    var pane = $("pane-" + id);
    if (!pane || !pane.classList.contains("hidden") || pane._warmed) { idle(next, { timeout: 800 }); return; }
    idle(function () {
      if (!pane.classList.contains("hidden")) { next(); return; }
      pane._warmed = true;
      if (id === "sfx" && window.PillowSfx && window.PillowSfx.prebuild) window.PillowSfx.prebuild();
      if (id === "bounce" && window.PillowBounce && window.PillowBounce.prebuild) window.PillowBounce.prebuild();
      /* the very width of the open tab, so the layout made here is the
         one the tab will have (the pane is 4px under its container) */
      var host = pane.parentNode, open = host.querySelector(".pane:not(.hidden)");
      pane.style.width = open && open.offsetWidth ? open.offsetWidth + "px"
        : host.clientWidth ? (host.clientWidth - parseFloat(getComputedStyle(host).paddingLeft) - parseFloat(getComputedStyle(host).paddingRight)) + "px" : "";
      pane.classList.add("pl-prewarm");
      void pane.offsetHeight;
      if (window.pillowRescanTactile) window.pillowRescanTactile(pane);
      /* дать ResizeObserver'ам (плашки, стекло, переключатели) отработать */
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          pane.classList.remove("pl-prewarm");
          pane.style.width = "";
          pane.classList.add("pl-warm");
          setTimeout(next, 40);
        });
      });
    }, { timeout: 1500 });
  }
  setTimeout(next, 500);
}

function init() {
  try {
    csInterface = new CSInterface();
  } catch (e) {
    csInterface = null;
  }

  try {
    state.lastFolder = localStorage.getItem("pillow_last_folder");
  } catch (e2) {}

  var rail = document.querySelector(".rail");
  if (rail) {
    rail.addEventListener("click", function (ev) {
      if (railDragSuppressClick) { railDragSuppressClick = false; ev.stopPropagation(); return; }
      var t = ev.target.closest ? ev.target.closest("[data-tab]") : null;
      if (t) setTab(t.getAttribute("data-tab"));
    }, true);
    initRailDrag(rail);
    initRailScroll(rail);
  }

  var favBtn = $("btn-show-favs");
  if (favBtn) {
    favBtn.onclick = function () {
      if (state.tab === "curves" && window.PillowCurves && window.PillowCurves.toggleFavsOnly) {
        window.PillowCurves.toggleFavsOnly();
      } else if (state.tab === "text" && window.PillowText && window.PillowText.toggleFavsOnly) {
        window.PillowText.toggleFavsOnly();
      } else {
        setTab("curves");
        setTimeout(function () {
          if (window.PillowCurves && window.PillowCurves.toggleFavsOnly) window.PillowCurves.toggleFavsOnly();
        }, 40);
      }
    };
  }

  if ($("btn-adj")) $("btn-adj").onclick = addAdjustment;
  if ($("btn-null")) $("btn-null").onclick = addNull;
  if ($("btn-cam")) $("btn-cam").onclick = addCamera;
  if ($("btn-pre")) $("btn-pre").onclick = addPrecomp;
  if ($("btn-stagger")) $("btn-stagger").onclick = stagger;
  if ($("btn-solid")) $("btn-solid").onclick = addSolid;

  if ($("toggle-parent")) {
    /* off unless the user turned it on: a new layer must not hang off
       whatever happened to be selected */
    var tp = $("toggle-parent");
    var paintParent = function () {
      tp.className = "switch" + (state.parentSelected ? " on" : "");
      tp.setAttribute("aria-checked", state.parentSelected ? "true" : "false");
    };
    try { state.parentSelected = localStorage.getItem("pillow.parentSelected") === "1"; } catch (eP) {}
    paintParent();
    bindParentHint();
    tp.onclick = function () {
      state.parentSelected = !state.parentSelected;
      try { localStorage.setItem("pillow.parentSelected", state.parentSelected ? "1" : "0"); } catch (eP2) {}
      paintParent();
    };
  }

  if ($("toggle-fit")) {
    /* on unless turned off: a new layer lands right above the selected
       one, as long as it is */
    var tf = $("toggle-fit");
    var paintFit = function () {
      tf.className = "switch" + (state.fitSelected ? " on" : "");
      tf.setAttribute("aria-checked", state.fitSelected ? "true" : "false");
    };
    try { state.fitSelected = localStorage.getItem("pillow.fitSelected") !== "0"; } catch (eF) {}
    paintFit();
    tf.onclick = function () {
      state.fitSelected = !state.fitSelected;
      try { localStorage.setItem("pillow.fitSelected", state.fitSelected ? "1" : "0"); } catch (eF2) {}
      paintFit();
    };
  }

  /* the Create options are remembered between sessions; a new solid or
     adjustment layer is the comp's length unless asked otherwise */
  function bindSaved(id, key, def, onPaint) {
    var b = $(id);
    if (!b) return;
    try { var v = localStorage.getItem(key); state[key.split(".")[1]] = v === null ? def : v === "1"; } catch (e) { state[key.split(".")[1]] = def; }
    var paint = function () {
      var on = state[key.split(".")[1]];
      b.className = "switch" + (on ? " on" : "");
      b.setAttribute("aria-checked", on ? "true" : "false");
      if (onPaint) onPaint(on);
    };
    paint();
    b.onclick = function () {
      var k = key.split(".")[1];
      state[k] = !state[k];
      try { localStorage.setItem(key, state[k] ? "1" : "0"); } catch (e2) {}
      paint();
    };
  }
  bindSaved("toggle-comp-dur", "pillow.matchCompDuration", true, function (on) {
    var dur = $("inp-duration");
    if (dur) dur.disabled = on;
  });
  bindSaved("cam-two", "pillow.camTwoNode", false);

  if ($("inp-duration")) {
    try { var dSaved = parseFloat(localStorage.getItem("pillow.duration")); if (dSaved > 0) { state.duration = dSaved; $("inp-duration").value = dSaved; } } catch (eD) {}
    $("inp-duration").onchange = function () {
      state.duration = parseFloat(this.value) || 5;
      try { localStorage.setItem("pillow.duration", String(state.duration)); } catch (eD2) {}
    };
  }

  if ($("btn-relink")) $("btn-relink").onclick = startRelink;
  if ($("btn-refresh-missing")) $("btn-refresh-missing").onclick = refreshMissing;
  if ($("btn-relink-last")) $("btn-relink-last").onclick = relinkPickFolder;

  renderSwatches();
  initTheme();
  prewarmTabs();
  initRailPill();
  railPillPressInit();
  if (window.PillowMusic && window.PillowMusic.init) window.PillowMusic.init();
  setTab("create");
  initTactile();
  bindKeyboard();
  updateStatusBar(null);
  /* The first call into AE waits until AE has finished starting up (the
     panel opens with AE, often while a project is still loading); the
     host script is loaded then, once, by the panel itself. */
  setTimeout(function () {
    ensureHostLoaded(function () { pingHost(); });
    setInterval(pingHost, 15000);
    if (window.PillowPresence) window.PillowPresence.onWakeEach && window.PillowPresence.onWakeEach(pingHost);
  }, 3000);
}

document.addEventListener("DOMContentLoaded", init);
