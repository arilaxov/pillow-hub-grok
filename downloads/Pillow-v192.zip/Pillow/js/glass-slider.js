/* glass-slider.js — Liquid Glass Slider в Pillow.
 *
 * Механика Website Glass Slider (websiteglass.com/r/glass-slider.json),
 * перенесённая на существующие <input type="range"> Pillow. Физика и линза
 * не дублируются: берутся из motion-ядра glass-switch.js (Track / spring /
 * glide / easeGel / overdrag).
 *
 * Почему не родной ползунок: ::-webkit-slider-thumb прыгает по шагам step
 * (у step=5 — всего 18 позиций), а стекло на нём делалось transform:scale()
 * по 14-пиксельному псевдоэлементу — растр увеличивался и мылился, а
 * background-image между solid и стеклом не анимируется, отсюда рывок.
 *
 * Апгрейд делается ПОВЕРХ существующего input: id, min/max/step, .value,
 * события input/change и обработчики (text.js, bounce.js, settings.js,
 * music.js, sfx.js) не меняются. Input остаётся в DOM (фокус, клавиатура,
 * значение), но становится невидимым; рисуют трек, заливку и ручку слои
 * рядом с ним.
 *
 * Поведение:
 *   idle     — маленький чистый solid-platter;
 *   press    — ручка «поднимается»: solid плавно перетекает в линзу, растёт;
 *   drag     — позиция 1:1 за курсором (без шагов и без пружины между мышью
 *              и ручкой), заливка — в том же кадре, линза тянется по
 *              скорости, за краями — мягкий rubber-band;
 *   release  — линза гаснет обратно в solid, позиция пружиной садится на
 *              ближайший шаг, унаследовав скорость броска.
 */
(function () {
  "use strict";
  if (window.PillowGlassSlider) return;

  var H = 14;           /* геометрия трека/ручки; сама строка на 1px выше — как у родного */
  var TRACK_H = 4;      /* тонкий трек, целые пиксели → ровные края */
  var REST = 14;        /* диаметр solid-ручки в покое (как у родной) */
  var LIFT = 26;        /* диаметр линзы при поднятой ручке */
  var GIVE = 6;         /* предел rubber-band за краями, px */
  var MAG = 0.42;       /* увеличение линзы в центре (1/(1-MAG) ≈ 1.7×) */
  var BOX = 48;         /* холст увеличенного трека вокруг центра ручки */

  var THUMB_BG = "linear-gradient(180deg, #ffffff 0%, #f3f3f5 100%)";
  var THUMB_SHADOW = "0 0 0 0.5px rgba(0,0,0,0.12), 0 1px 2.5px rgba(0,0,0,0.30)";
  var RIM_LENS =
    "inset 0 1px 1px rgba(255,255,255,0.60), " +
    "inset 0 -1px 1px rgba(255,255,255,0.18), " +
    "inset 0 0 0 1px rgba(255,255,255,0.16), " +
    "inset 0 0 3px rgba(0,0,0,0.16)";
  /* Тень подъёма — отдельным слоем под линзой. */
  var LIFT_SHADOW = "0 7px 16px -7px rgba(0,0,0,0.55)";
  var SHEEN =
    "radial-gradient(90% 70% at 30% 18%, rgba(255,255,255,0.10) 0%, rgba(255,255,255,0) 60%), " +
    "linear-gradient(135deg, rgba(255,255,255,0.10) 0%, rgba(255,255,255,0) 45%, rgba(255,255,255,0) 65%, rgba(255,255,255,0.07) 100%)";

  var VALUE = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
  var VALUE_NUM = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "valueAsNumber");

  function styleSheet() {
    if (document.getElementById("pl-gsl-style")) return;
    var s = document.createElement("style");
    s.id = "pl-gsl-style";
    s.textContent =
      ".pl-gsl{position:relative;display:block;height:" + (H + 1) + "px;touch-action:none;" +
        "-webkit-user-select:none;user-select:none;cursor:pointer;-webkit-tap-highlight-color:transparent;}" +
      ".pl-gsl>input[type=range]{position:absolute;left:0;top:0;width:100%;height:100%;margin:0;" +
        "opacity:0;pointer-events:none;}" +
      ".pl-gsl[data-disabled]{opacity:.45;cursor:default;}" +
      /* Трек — два сегмента (заливка слева, дорожка справа), между
         которыми под ручкой вырез: там трек рисует band-слой ручки. */
      ".pl-gsl [data-gsl-track]{position:absolute;left:0;right:0;top:" + (H - TRACK_H) / 2 + "px;" +
        "height:" + TRACK_H + "px;}" +
      ".pl-gsl [data-gsl-fill],.pl-gsl [data-gsl-rest]{position:absolute;top:0;bottom:0;width:0;}" +
      ".pl-gsl [data-gsl-fill]{left:0;border-radius:" + TRACK_H / 2 + "px 0 0 " + TRACK_H / 2 + "px;" +
        "background:var(--accent);}" +
      ".pl-gsl [data-gsl-rest]{left:0;border-radius:0 " + TRACK_H / 2 + "px " + TRACK_H / 2 + "px 0;" +
        "background:var(--track-bg);}" +
      ".pl-gsl [data-gsl-thumb]{position:absolute;left:0;top:" + (H - LIFT) / 2 + "px;" +
        "width:" + LIFT + "px;height:" + LIFT + "px;pointer-events:none;}" +
      ".pl-gsl [data-gsl-solid]{position:absolute;border-radius:50%;background:" + THUMB_BG + ";" +
        "box-shadow:" + THUMB_SHADOW + ";}" +
      ".pl-gsl [data-gsl-shadow]{position:absolute;left:0;top:0;width:" + LIFT + "px;height:" + LIFT + "px;" +
        "border-radius:50%;opacity:0;transform-origin:50% 50%;box-shadow:" + LIFT_SHADOW + ";}" +
      ".pl-gsl [data-gsl-glass],.pl-gsl [data-gsl-rim]{position:absolute;left:0;top:0;" +
        "width:" + LIFT + "px;height:" + LIFT + "px;border-radius:50%;opacity:0;transform-origin:50% 50%;}" +
      ".pl-gsl [data-gsl-glass]{background-color:rgba(255,255,255,0.02);" +
        "-webkit-backdrop-filter:saturate(1.4) brightness(1.06);backdrop-filter:saturate(1.4) brightness(1.06);}" +
      ".pl-gsl [data-gsl-rim]{background-image:" + SHEEN + ";box-shadow:" + RIM_LENS + ";}" +
      ".pl-gsl [data-gsl-band]{position:absolute;left:" + (LIFT - BOX) / 2 + "px;top:" + (LIFT - BOX) / 2 + "px;" +
        "width:" + BOX + "px;height:" + BOX + "px;overflow:visible;}" +
      /* без Liquid Glass — ручка как у прежнего родного ползунка */
      "html:not([data-pl-glass=on]) .pl-gsl [data-gsl-solid]{background:linear-gradient(180deg,var(--accent-soft),var(--accent));" +
        "box-shadow:0 0 0 1px rgba(200,200,200,0.2),0 2px 5px rgba(0,0,0,0.3);}" +
      ".pl-gsl>input:focus-visible~[data-gsl-thumb] [data-gsl-solid]{box-shadow:0 0 0 3px var(--accent-glow)," +
        THUMB_SHADOW + ";}";
    document.head.appendChild(s);
  }

  /* ── увеличенный трек внутри линзы ───────────────────────────────── *
   * Раньше увеличение делал SVG feDisplacementMap в backdrop-filter. Он
   * сэмплирует фон целыми пикселями без сглаживания, поэтому на 26px
   * линзе при DPR 1 тонкая яркая полоса рассыпалась «лесенкой». Под
   * линзой всегда только трек и заливка — их увеличенная картина
   * считается здесь как вектор (SVG path) и сглаживается браузером на
   * любой плотности экрана.
   *
   * Модель линзы: точка экрана P внутри эллипса линзы показывает точку
   * фона S = P·(1 − k(ρ)), где ρ — нормированный радиус в эллипсе, а
   * k(ρ) = m·(1 − ρ³): в центре увеличение 1/(1 − m), к кромке плавно
   * сходит к 1. Контур фона (капсулы трека и заливки) переводится в
   * экран обратным отображением — по каждой точке бисекцией по λ,
   * P = λ·S. Сила m растёт вместе с подъёмом ручки, поэтому полоса
   * внутри линзы «вырастает» плавно, а в покое совпадает с треком. */
  var BAND_SEQ = 0;
  var SVGNS = "http://www.w3.org/2000/svg";
  function svgEl(tag, attrs) {
    var el = document.createElementNS(SVGNS, tag);
    for (var k in attrs) if (attrs.hasOwnProperty(k)) el.setAttribute(k, attrs[k]);
    return el;
  }

  function makeBand() {
    var id = "pl-gsl-clip-" + (++BAND_SEQ);
    var svg = svgEl("svg", {
      "data-gsl-band": "", "aria-hidden": "true", focusable: "false",
      width: String(BOX), height: String(BOX),
      viewBox: (-BOX / 2) + " " + (-BOX / 2) + " " + BOX + " " + BOX
    });
    var defs = svgEl("defs", {});
    var clipE = svgEl("clipPath", { id: id + "e" });
    var ell = svgEl("ellipse", { cx: "0", cy: "0", rx: "1", ry: "1" });
    var clipR = svgEl("clipPath", { id: id + "r" });
    var rect = svgEl("rect", { x: "-1", y: String(-BOX / 2), width: "2", height: String(BOX) });
    clipE.appendChild(ell); clipR.appendChild(rect);
    defs.appendChild(clipE); defs.appendChild(clipR);
    var gE = svgEl("g", { "clip-path": "url(#" + id + "e)" });
    var gR = svgEl("g", { "clip-path": "url(#" + id + "r)" });
    var trackP = svgEl("path", { style: "fill:var(--track-bg)" });
    var fillP = svgEl("path", { style: "fill:var(--accent)" });
    gR.appendChild(trackP); gR.appendChild(fillP);
    gE.appendChild(gR);
    svg.appendChild(defs); svg.appendChild(gE);

    var last = "";
    var m = 0, rx = 1, ry = 1;

    function k(rho) { return rho >= 1 ? 0 : m * (1 - rho * rho * rho); }

    /* фон S → экран P */
    function toScreen(x, y, out) {
      var sig = Math.sqrt((x / rx) * (x / rx) + (y / ry) * (y / ry));
      if (m <= 0 || sig >= 1 || sig === 0) { out.push(x, y); return; }
      var lo = 1, hi = Math.min(1 / sig, 1 / (1 - m));
      for (var i = 0; i < 22; i++) {
        var mid = (lo + hi) / 2;
        if (mid * (1 - k(mid * sig)) < 1) lo = mid; else hi = mid;
      }
      var lam = (lo + hi) / 2;
      out.push(x * lam, y * lam);
    }

    /* контур горизонтальной капсулы [a, b] радиуса r, обрезанный окном ±L */
    function capsule(a, b, r, L) {
      var pts = [], i, n, t;
      r = Math.min(r, Math.max(0, (b - a) / 2));
      if (b - a < 0.05 || b < -L || a > L) return "";
      var xl = a + r, xr = b - r;
      var el = Math.max(xl, -L), er = Math.min(xr, L);
      var STEP = 0.35;
      n = Math.max(1, Math.ceil((er - el) / STEP));
      for (i = 0; i <= n; i++) toScreen(el + (er - el) * i / n, -r, pts);
      if (xr <= L) {
        for (i = 1; i < 16; i++) { t = -Math.PI / 2 + Math.PI * i / 16; toScreen(xr + r * Math.cos(t), r * Math.sin(t), pts); }
      }
      for (i = 0; i <= n; i++) toScreen(er - (er - el) * i / n, r, pts);
      if (xl >= -L) {
        for (i = 1; i < 16; i++) { t = Math.PI / 2 + Math.PI * i / 16; toScreen(xl + r * Math.cos(t), r * Math.sin(t), pts); }
      }
      var d = "M" + pts[0].toFixed(2) + " " + pts[1].toFixed(2);
      for (i = 2; i < pts.length; i += 2) d += "L" + pts[i].toFixed(2) + " " + pts[i + 1].toFixed(2);
      return d + "Z";
    }

    return {
      svg: svg,
      /* cx — центр ручки в координатах трека, w — длина трека,
         rx/ry — полуоси линзы, cut — полуширина выреза в треке,
         mag — текущая сила увеличения */
      draw: function (cx, w, nrx, nry, cut, mag) {
        var key = cx.toFixed(2) + "|" + w + "|" + nrx.toFixed(3) + "|" + nry.toFixed(3) + "|" + mag.toFixed(4);
        if (key === last) return;
        last = key;
        m = Math.max(0, Math.min(mag, 0.9)); rx = nrx; ry = nry;
        ell.setAttribute("rx", nrx.toFixed(3));
        ell.setAttribute("ry", nry.toFixed(3));
        rect.setAttribute("x", (-cut).toFixed(3));
        rect.setAttribute("width", (2 * cut).toFixed(3));
        var L = nrx + TRACK_H, r = TRACK_H / 2;
        trackP.setAttribute("d", capsule(-cx, w - cx, r, L));
        fillP.setAttribute("d", capsule(-cx, Math.max(0, Math.min(cx, w)) - cx, r, L));
      }
    };
  }

  function upgrade(input, C) {
    if (input.__gsl || !input.parentNode) return;
    var clamp = C.clamp;

    var wrap = document.createElement("span");
    var track = document.createElement("span");
    var fill = document.createElement("span");
    var thumb = document.createElement("span");
    var solid = document.createElement("span");
    var shadow = document.createElement("span");
    var glass = document.createElement("span");
    var rim = document.createElement("span");
    var rest = document.createElement("span");
    wrap.className = "pl-gsl";
    track.setAttribute("data-gsl-track", "");
    fill.setAttribute("data-gsl-fill", "");
    thumb.setAttribute("data-gsl-thumb", "");
    solid.setAttribute("data-gsl-solid", "");
    shadow.setAttribute("data-gsl-shadow", "");
    glass.setAttribute("data-gsl-glass", "");
    rim.setAttribute("data-gsl-rim", "");
    rest.setAttribute("data-gsl-rest", "");
    track.appendChild(fill);
    track.appendChild(rest);
    var band = makeBand();
    /* снизу вверх: тень, стекло, увеличенный трек, кромка, solid */
    thumb.appendChild(shadow);
    thumb.appendChild(glass);
    thumb.appendChild(band.svg);
    thumb.appendChild(rim);
    thumb.appendChild(solid);
    input.parentNode.insertBefore(wrap, input);
    wrap.appendChild(input);
    wrap.appendChild(track);
    wrap.appendChild(thumb);

    var s = {
      input: input, wrap: wrap, w: 0, travel: 0,
      pressed: false, emitting: false, want: null,
      pointerP: 0, offset: 0, goalOffset: 0, rect: null, ratio: 1,
      startValue: null, catchRaf: 0,
      vel: 0, velStamp: 0,
      pos: new C.Track(0), lift: new C.Track(0), deform: new C.Track(0)
    };
    input.__gsl = s;

    /* ── значение ↔ позиция ───────────────────────────────────────── */
    function num(attr, dflt) {
      var v = parseFloat(input.getAttribute(attr));
      return isFinite(v) ? v : dflt;
    }
    function range() {
      var min = num("min", 0), max = num("max", 100);
      if (max < min) max = min;
      return { min: min, max: max };
    }
    function posOfValue() {
      var r = range(), v = parseFloat(VALUE.get.call(input));
      if (!isFinite(v) || r.max === r.min) return 0;
      return clamp((v - r.min) / (r.max - r.min), 0, 1) * s.travel;
    }
    function valueAtPos(p) {
      var r = range();
      return r.min + (s.travel > 0 ? clamp(p / s.travel, 0, 1) : 0) * (r.max - r.min);
    }

    /* ── отрисовка: всё из трёх треков в один проход ─────────────── */
    function paint() {
      var p = s.pos.get();
      /* Стекло (подъём в линзу, увеличение, деформация от скорости) —
         только в режиме Liquid Glass; без него ручка — прежний solid,
         плавность и пружины остаются. */
      var glassMode = document.documentElement.getAttribute("data-pl-glass") === "on";
      var l = glassMode ? s.lift.get() : 0;
      var lc = clamp(l, 0, 1);
      var q = glassMode ? s.deform.get() : 0;
      var cx = REST / 2 + p;
      /* масштаб в долях LIFT: REST в покое, LIFT при поднятой ручке */
      var g = (REST + (LIFT - REST) * l) / LIFT;
      var sx = g * (1 + 0.62 * q), sy = g * (1 - 0.42 * q);

      thumb.style.transform = "translate(" + (cx - LIFT / 2) + "px,0)";

      /* Трек под ручкой вырезан по ширине линзы на высоте трека, этот
         кусок рисует band — уже увеличенным. На кромке линзы увеличение
         сходит в ноль, так что сегменты и band стыкуются без шва.
         Заливка и дорожка двигаются в том же кадре, что и ручка. */
      var rx = LIFT / 2 * sx, ry = LIFT / 2 * sy, th = TRACK_H / 2;
      var cut = rx * Math.sqrt(Math.max(0, 1 - (th * th) / (ry * ry)));
      var fillEnd = clamp(cx, 0, s.w);
      fill.style.width = Math.max(0, Math.min(fillEnd, cx - cut)) + "px";
      var r0 = Math.max(0, cx + cut);
      rest.style.left = r0 + "px";
      rest.style.width = Math.max(0, s.w - r0) + "px";
      band.draw(cx, s.w, rx, ry, cut, MAG * clamp(l, 0, 1.2));

      /* solid рисуется в собственном размере (а не scale-ом) —
         в покое это честный 14-пиксельный круг без апскейла растра. */
      var w = LIFT * sx, h = LIFT * sy;
      solid.style.width = w + "px";
      solid.style.height = h + "px";
      solid.style.left = (LIFT - w) / 2 + "px";
      solid.style.top = (LIFT - h) / 2 + "px";
      solid.style.opacity = String(1 - lc);

      var sc = "scale(" + sx + "," + sy + ")";
      shadow.style.transform = sc;
      shadow.style.opacity = String(lc);
      glass.style.transform = sc;
      glass.style.opacity = String(lc);
      rim.style.transform = sc;
      rim.style.opacity = String(lc);
      /* линза в покое не должна считать backdrop-filter каждый кадр */
      glass.style.visibility = lc > 0 ? "visible" : "hidden";
    }
    s.pos.watch(paint); s.lift.watch(paint); s.deform.watch(paint);
    new MutationObserver(paint).observe(document.documentElement, { attributes: true, attributeFilter: ["data-pl-glass"] });

    function measure() {
      var w = wrap.clientWidth;
      if (w < 8) return false;
      var changed = w !== s.w;
      s.w = w;
      s.travel = Math.max(0, w - REST);
      if (changed && !s.pressed) { s.want = posOfValue(); s.pos.snap(s.want); }
      return true;
    }
    s.measure = measure;
    measure();
    if (window.ResizeObserver) new ResizeObserver(measure).observe(wrap);

    function settle() {
      var target = posOfValue();
      if (s.want !== null && Math.abs(target - s.want) < 0.01 && !s.pos.activeStop) return;
      s.want = target;
      C.spring(s.pos, function () { return s.want; }, { tension: 300, friction: 26, epsilon: 0.01 });
    }

    /* Внешние изменения значения (пресеты, sync, клавиатура) — пружиной;
       пока ручку держат, ими управляет только указатель. */
    function onExternal() {
      if (s.pressed || s.emitting) return;
      if (!s.w) { measure(); return; }
      settle();
    }
    Object.defineProperty(input, "value", {
      configurable: true, enumerable: true,
      get: function () { return VALUE.get.call(this); },
      set: function (v) { VALUE.set.call(this, v); onExternal(); }
    });
    if (VALUE_NUM) {
      Object.defineProperty(input, "valueAsNumber", {
        configurable: true, enumerable: true,
        get: function () { return VALUE_NUM.get.call(this); },
        set: function (v) { VALUE_NUM.set.call(this, v); onExternal(); }
      });
    }
    input.addEventListener("input", onExternal);
    input.addEventListener("change", onExternal);
    new MutationObserver(function () {
      if (input.disabled) wrap.setAttribute("data-disabled", ""); else wrap.removeAttribute("data-disabled");
      onExternal();
    }).observe(input, { attributes: true, attributeFilter: ["value", "min", "max", "step", "disabled"] });
    if (input.disabled) wrap.setAttribute("data-disabled", "");

    /* ── деформация от скорости ──────────────────────────────────── */
    function speed() {
      /* скорость без свежих движений затухает сама — ручка, остановленная
         под пальцем, снова округляется */
      var age = C.now() - s.velStamp;
      if (!s.pressed) return Math.abs(s.pos.velocity());
      return age > 90 ? 0 : Math.abs(s.vel) * Math.exp(-age / 60);
    }
    function runDeform() {
      if (C.reduceMotion()) return;
      C.spring(s.deform, function () {
        /* как в оригинале: удерживаемая линза уже чуть приплюснута
           (0.14), скорость тянет её дальше по ходу движения */
        var q = 0.0026 * Math.pow(speed(), 0.7);
        return clamp(Math.max(q, s.pressed ? 0.14 : 0), 0, 0.34) * clamp(s.lift.get(), 0, 1);
      }, {
        tension: 230, friction: 15,
        canRest: function () { return !s.pressed && speed() < 1; }
      });
    }

    /* ── drag ────────────────────────────────────────────────────── */
    function emit(type) {
      s.emitting = true;
      try { input.dispatchEvent(new Event(type, { bubbles: true })); }
      finally { s.emitting = false; }
    }

    function localP(clientX) {
      return (clientX - s.rect.left) * s.ratio - REST / 2;
    }

    function apply() {
      var raw = s.pointerP + s.offset;
      var c = clamp(raw, 0, s.travel);
      var prev = s.pos.get();
      s.pos.push(c + C.overdrag(raw - c, GIVE));
      /* своя, сглаженная оценка скорости для деформации */
      var t = C.now(), dt = t - s.velStamp;
      if (dt > 0) {
        var inst = ((s.pos.get() - prev) / clamp(dt, 6, 40)) * 1000;
        s.vel = dt > 90 ? inst : s.vel + (inst - s.vel) * 0.55;
        s.velStamp = t;
      }
      /* значение — от места, куда ведёт указатель (с учётом точки хвата),
         а не от догоняющей визуальной позиции */
      var before = VALUE.get.call(input);
      VALUE.set.call(input, String(valueAtPos(s.pointerP + s.goalOffset)));
      if (VALUE.get.call(input) !== before) emit("input");
    }

    /* Нажатие на трек мимо ручки: ручка не телепортируется, а за ~100 мс
       догоняет точку нажатия. Движение указателя при этом по-прежнему
       передаётся 1:1 — затухает только начальный зазор. */
    function catchUp() {
      cancelAnimationFrame(s.catchRaf);
      var last = -1;
      function tick(t) {
        if (!s.pressed) return;
        if (last < 0) last = t;
        var dt = Math.min((t - last) / 1000, 0.05); last = t;
        var d = s.offset - s.goalOffset;
        d *= Math.exp(-dt / 0.045);
        if (Math.abs(d) < 0.05) d = 0;
        s.offset = s.goalOffset + d;
        apply();
        if (d !== 0) s.catchRaf = requestAnimationFrame(tick);
      }
      s.catchRaf = requestAnimationFrame(tick);
    }

    wrap.addEventListener("pointerdown", function (e) {
      if (e.button !== undefined && e.button !== 0) return;
      if (input.disabled) return;
      if (!measure()) return;
      e.preventDefault();
      try { wrap.setPointerCapture(e.pointerId); } catch (err) { /* нет активного указателя */ }
      try { input.focus({ preventScroll: true }); } catch (err) { input.focus(); }

      s.pressed = true;
      s.startValue = VALUE.get.call(input);
      s.rect = wrap.getBoundingClientRect();
      s.ratio = s.rect.width > 0 ? s.w / s.rect.width : 1;
      s.pos.halt();
      s.want = null;

      var cur = s.pos.get();
      s.pointerP = localP(e.clientX);
      var gap = cur - s.pointerP;
      s.offset = gap;
      /* схватили саму ручку — держим её за эту точку без скачка;
         нажали в трек — ручка едет под палец */
      s.goalOffset = Math.abs(gap) <= LIFT / 2 ? gap : 0;
      s.vel = 0; s.velStamp = C.now();

      C.glide(s.lift, 1, 0.26, C.easeGel);
      runDeform();
      apply();
      if (s.offset !== s.goalOffset) catchUp();
    });

    wrap.addEventListener("pointermove", function (e) {
      if (!s.pressed) return;
      s.pointerP = localP(e.clientX);
      apply();
    });

    function release() {
      if (!s.pressed) return;
      cancelAnimationFrame(s.catchRaf);
      s.offset = s.goalOffset;
      s.pressed = false;
      C.glide(s.lift, 0, 0.38, C.easeSoft);
      s.want = null;
      settle();
      runDeform();
      if (VALUE.get.call(input) !== s.startValue) emit("change");
    }
    wrap.addEventListener("pointerup", release);
    wrap.addEventListener("pointercancel", release);
    wrap.addEventListener("lostpointercapture", release);
  }

  function scan(root) {
    var C = window.PillowGlassSwitch && window.PillowGlassSwitch.core;
    if (!C) return;
    var scope = root || document;
    if (scope.matches && scope.matches('input[type="range"]')) upgrade(scope, C);
    if (!scope.querySelectorAll) return;
    var list = scope.querySelectorAll('input[type="range"]');
    for (var i = 0; i < list.length; i++) upgrade(list[i], C);
  }

  function boot() {
    styleSheet();
    scan(document);
    new MutationObserver(function (recs) {
      for (var i = 0; i < recs.length; i++) {
        var added = recs[i].addedNodes;
        for (var j = 0; j < added.length; j++) {
          if (added[j].nodeType === 1) scan(added[j]);
        }
      }
    }).observe(document.documentElement, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  window.PillowGlassSlider = { scan: scan };
})();
