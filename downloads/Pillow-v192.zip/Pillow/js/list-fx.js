/* Pillow — плавная фильтрация списков (категории, поиск, избранное).
 *
 * Общий движок для Text, SFX и Curves. Раньше каждый из них на любой
 * смене фильтра пересобирал весь список через innerHTML: все карточки
 * создавались заново и заново одевались стеклом/плашкой/материалом
 * (SVG-скины, фильтры линз, ResizeObserver'ы) — отсюда лаги, а карточки
 * просто «выпрыгивали» на новые места.
 *
 * Теперь список строится один раз, а PillowListFx.apply() только
 * показывает/прячет готовые элементы и анимирует переход (FLIP):
 *   · оставшиеся едут из текущего положения в новое, сверху вниз со
 *     stagger;
 *   · уходящие вынимаются из потока на месте и мягко гаснут (opacity +
 *     сдвиг вниз + scale), под поднимающимися;
 *   · появляющиеся (и приехавшие из-за края прокрутки) поднимаются на
 *     своё место;
 *   · контент под списком доезжает transform'ом, без анимации height.
 * Любой новый переход стартует из того, что сейчас на экране
 * (getBoundingClientRect / computed opacity), поэтому быстрые
 * переключения прерываются без скачков. Анимируется только видимое в
 * прокрутке.
 *
 * Спрятанный элемент НЕ получает display:none: размер 0 → N будил бы
 * ResizeObserver'ы стекла (glass.js) и плашки (plate.js) у каждого
 * элемента. Он вынимается из потока с тем же размером и становится
 * невидимым (data-lfx-out) — наблюдатели молчат, backdrop-filter не
 * считается. Флаг — атрибут, а не класс: смену класса ловит glass.js.
 *
 * API: PillowListFx.apply(container, elements, show[], { animate })
 *      PillowListFx.isShown(el)
 */
(function () {
  "use strict";
  if (window.PillowListFx) return;

  var MOVE_MS = 440, IN_MS = 380, OUT_MS = 180, STAGGER_MS = 26, IN_DELAY_MS = 110;
  var EASE = "cubic-bezier(0.22, 1, 0.36, 1)";
  var EASE_OUT = "cubic-bezier(0.4, 0, 1, 1)";

  function reduceMotion() {
    return !!window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }

  function styleSheet() {
    if (document.getElementById("pl-lfx-style")) return;
    var st = document.createElement("style");
    st.id = "pl-lfx-style";
    st.textContent =
      "[data-lfx-out]{position:absolute!important;left:0!important;top:0!important;" +
      "margin:0!important;visibility:hidden!important;pointer-events:none!important;}";
    document.head.appendChild(st);
  }

  function isShown(el) { return !el.hasAttribute("data-lfx-out"); }

  function setShown(el, on) {
    if (on) {
      if (!el.hasAttribute("data-lfx-out")) return;
      el.removeAttribute("data-lfx-out");
      el.style.removeProperty("width");
      el.style.removeProperty("height");
    } else {
      if (el._lfxW) {
        el.style.setProperty("width", el._lfxW + "px", "important");
        el.style.setProperty("height", el._lfxH + "px", "important");
      }
      el.setAttribute("data-lfx-out", "");
    }
  }

  var LEAVE_PROPS = ["position", "left", "top", "width", "height", "margin", "z-index", "pointer-events"];

  function stopFx(el) {
    if (el._lfx) {
      for (var i = 0; i < el._lfx.length; i++) el._lfx[i].cancel();
      el._lfx = null;
    }
    if (el._lfxLeaving) {
      el._lfxLeaving = false;
      for (var j = 0; j < LEAVE_PROPS.length; j++) el.style.removeProperty(LEAVE_PROPS[j]);
    }
  }

  /* ближайшая прокрутка: сам контейнер или его предок */
  function scrollerOf(el) {
    for (var n = el; n && n !== document.body; n = n.parentElement) {
      var oy = window.getComputedStyle(n).overflowY;
      if ((oy === "auto" || oy === "scroll") && n.scrollHeight > n.clientHeight) return n;
    }
    return null;
  }

  function apply(container, els, show, opts) {
    if (!container) return;
    styleSheet();
    if (window.getComputedStyle(container).position === "static") container.style.position = "relative";
    var animate = !(opts && opts.animate === false) && !reduceMotion() &&
      !!container.animate && container.offsetParent !== null;
    var i, el;

    /* 1. все чтения — до первой записи: один layout на весь переход.
       Прозрачность — только у анимирующихся, размер — только у тех,
       кого предстоит спрятать. */
    var before = [];
    for (i = 0; i < els.length; i++) {
      el = els[i];
      if (!isShown(el)) { before[i] = null; continue; }
      if (!show[i] && !el._lfxLeaving && el.offsetWidth) {
        /* точный размер без transform: у колонок сетки он дробный
           (347.5px), а округлённый offsetWidth — это уже «resize» */
        var cs = window.getComputedStyle(el);
        el._lfxW = parseFloat(cs.width) || el.offsetWidth;
        el._lfxH = parseFloat(cs.height) || el.offsetHeight;
      }
      if (!animate) continue;
      var op = el._lfx ? parseFloat(window.getComputedStyle(el).opacity) : 1;
      before[i] = { r: el.getBoundingClientRect(), op: isNaN(op) ? 1 : op };
    }
    var below = [];
    if (animate) {
      for (var sib = container.nextElementSibling; sib; sib = sib.nextElementSibling) {
        if (sib.offsetParent === null) continue;
        below.push({ el: sib, top: sib.getBoundingClientRect().top });
      }
    }

    /* 2. сбросить прошлый переход и применить новый фильтр */
    for (i = 0; i < els.length; i++) stopFx(els[i]);
    if (container._lfxBelow) {
      for (i = 0; i < container._lfxBelow.length; i++) container._lfxBelow[i].cancel();
      container._lfxBelow = null;
    }
    for (i = 0; i < els.length; i++) setShown(els[i], show[i]);
    if (!animate) return;

    /* 3. FLIP — только то, что видно в прокрутке */
    var g = container.getBoundingClientRect();
    var sc = scrollerOf(container) || (container.closest ? container.closest(".content") : null);
    var view = sc ? sc.getBoundingClientRect() : { top: -1e9, bottom: 1e9 };
    function inView(r) { return r && r.bottom > view.top - 40 && r.top < view.bottom + 40; }

    var order = 0;
    for (i = 0; i < els.length; i++) {
      if (!show[i]) continue;
      el = els[i];
      var r1 = el.getBoundingClientRect();
      var was = before[i];
      if (!inView(r1) && !(was && inView(was.r))) continue;
      var delay = Math.min(order, 10) * STAGGER_MS;
      order++;
      if (was && was.op > 0.02 && !inView(r1)) {
        /* уезжает в невидимую часть списка — не тащим её через весь
           список, а мягко уводим вниз и гасим */
        var ox = was.r.left - r1.left, oy = was.r.top - r1.top;
        el._lfx = [el.animate([
          { transform: "translate(" + ox + "px," + oy + "px)", opacity: was.op },
          { transform: "translate(" + ox + "px," + (oy + 10) + "px) scale(0.965)", opacity: 0 }
        ], { duration: OUT_MS, easing: EASE_OUT })];
      } else if (was && was.op > 0.02 && inView(was.r)) {
        var dx = was.r.left - r1.left, dy = was.r.top - r1.top;
        if (Math.abs(dx) < 0.5 && Math.abs(dy) < 0.5 && was.op > 0.98) continue;
        el._lfx = [el.animate([
          { transform: "translate(" + dx + "px," + dy + "px)", opacity: was.op },
          { transform: "translate(0,0)", opacity: 1 }
        ], { duration: MOVE_MS, delay: delay, easing: EASE, fill: "backwards" })];
      } else {
        el._lfx = [el.animate([
          { transform: "translate(0," + (was ? 22 : 10) + "px) scale(0.965)", opacity: 0 },
          { transform: "translate(0,0) scale(1)", opacity: 1 }
        ], { duration: IN_MS, delay: IN_DELAY_MS + delay, easing: EASE, fill: "backwards" })];
      }
    }

    /* уходящие: вынуть из потока там, где они сейчас видны, и погасить.
       В прокручиваемом контейнере absolute считается от начала
       содержимого, поэтому добавляется его scroll. */
    var offX = container.scrollLeft - container.clientLeft;
    var offY = container.scrollTop - container.clientTop;
    for (i = 0; i < els.length; i++) {
      if (show[i] || !before[i] || !inView(before[i].r)) continue;
      el = els[i];
      var r0 = before[i].r;
      el._lfxLeaving = true;
      setShown(el, true);
      var st = el.style;
      st.setProperty("position", "absolute", "important");
      st.setProperty("left", (r0.left - g.left + offX) + "px", "important");
      st.setProperty("top", (r0.top - g.top + offY) + "px", "important");
      st.setProperty("width", (el._lfxW || r0.width) + "px", "important");
      st.setProperty("height", (el._lfxH || r0.height) + "px", "important");
      st.setProperty("margin", "0", "important");
      st.setProperty("z-index", "-1", "important");
      st.setProperty("pointer-events", "none", "important");
      var fx = el.animate([
        { transform: "translate(0,0) scale(1)", opacity: before[i].op },
        { transform: "translate(0,8px) scale(0.955)", opacity: 0 }
      ], { duration: OUT_MS, easing: EASE_OUT, fill: "forwards" });
      el._lfx = [fx];
      fx.onfinish = (function (node) {
        return function () {
          if (!node._lfxLeaving) return;
          stopFx(node);
          setShown(node, false);
        };
      })(el);
    }

    /* контент под списком плавно доезжает до нового места */
    var fxs = [];
    for (i = 0; i < below.length; i++) {
      var nb = below[i].el.getBoundingClientRect();
      var shift = below[i].top - nb.top;
      if (Math.abs(shift) < 0.5) continue;
      if (!inView(nb) && !inView({ top: below[i].top, bottom: below[i].top + nb.height })) continue;
      fxs.push(below[i].el.animate([
        { transform: "translate(0," + shift + "px)" },
        { transform: "translate(0,0)" }
      ], { duration: MOVE_MS, easing: EASE }));
    }
    container._lfxBelow = fxs.length ? fxs : null;
  }

  window.PillowListFx = { apply: apply, isShown: isShown };
})();
