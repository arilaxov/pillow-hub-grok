/* Pillow — Liquid Glass for layers
 *
 * The tab turns selected shape / text layers into Apple-style liquid
 * glass in AE (host: pillowGlassMake). The preview here renders the same
 * recipe on a canvas, per pixel, for any form (a pill, a circle, a
 * squircle or text), and the form can be dragged over the background:
 *   the form is rasterised, a distance transform gives every inside pixel
 *   its distance to the edge; near the edge the background is sampled
 *   from further inside (the lens bends it, strongest at the rim, none in
 *   the middle), through a blurred copy (frost); a tint is mixed in; a
 *   thin specular rim lights the edge facing the light and, weaker, the
 *   opposite one; a soft shadow falls outside.
 */
(function () {
  "use strict";
  if (window.PillowLiquidGlass) return;

  var PRESETS = {
    clear:   { label: "Clear",   refraction: 38, edge: 20, frost: 1,  highlight: 70, tint: 4,  shadow: 14, dispersion: 45, fresnel: 65, dark: false },
    regular: { label: "Regular", refraction: 34, edge: 20, frost: 3,  highlight: 65, tint: 8,  shadow: 18, dispersion: 35, fresnel: 60, dark: false },
    frosted: { label: "Frosted", refraction: 24, edge: 18, frost: 12, highlight: 55, tint: 16, shadow: 22, dispersion: 20, fresnel: 55, dark: false },
    dark:    { label: "Dark",    refraction: 34, edge: 20, frost: 5,  highlight: 50, tint: 24, shadow: 28, dispersion: 30, fresnel: 45, dark: true }
  };
  var CONTROLS = [
    { key: "refraction", label: "Refraction", min: 0, max: 100, step: 1 },
    { key: "edge",       label: "Edge",       min: 4, max: 60,  step: 1 },
    { key: "frost",      label: "Frost",      min: 0, max: 30,  step: 0.5 },
    { key: "highlight",  label: "Highlight",  min: 0, max: 100, step: 1 },
    { key: "tint",       label: "Tint",       min: 0, max: 50,  step: 1, unit: "%" },
    { key: "shadow",     label: "Shadow",     min: 0, max: 60,  step: 1, unit: "%" },
    { key: "dispersion", label: "Dispersion", min: 0, max: 100, step: 1 },
    { key: "fresnel",    label: "Fresnel",    min: 0, max: 100, step: 1 }
  ];

  /* the shape of a new glass, in comp pixels */
  var SHAPE_CONTROLS = {
    pill:     [{ key: "w", label: "Width", min: 80, max: 1800 }, { key: "h", label: "Height", min: 40, max: 1200 }, { key: "r", label: "Roundness", min: 0, max: 100, unit: "%" },
               { key: "n", label: "Smoothness", min: 2, max: 6, step: 0.1, unit: "" }],
    squircle: [{ key: "w", label: "Width", min: 80, max: 1800 }, { key: "h", label: "Height", min: 40, max: 1200 }, { key: "r", label: "Roundness", min: 0, max: 100, unit: "%" },
               { key: "n", label: "Smoothness", min: 2, max: 6, step: 0.1, unit: "" }],
    circle:   [{ key: "w", label: "Size", min: 40, max: 1600 }]
  };
  var state = {
    preset: "regular", p: null, shape: "pill", scene: "sunset", source: "new",
    dims: { pill: { w: 600, h: 180, r: 100, n: 2 }, squircle: { w: 360, h: 360, r: 52, n: 3 }, circle: { w: 360 } },
    cx: 0.5, cy: 0.52, built: false, active: false, dirty: true, raf: 0
  };

  function $(id) { return document.getElementById(id); }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function copy(o) { var r = {}; for (var k in o) if (o.hasOwnProperty(k)) r[k] = o[k]; return r; }

  /* ── background scenes ─────────────────────────────────────────── */
  function drawScene(ctx, w, h, scene) {
    ctx.clearRect(0, 0, w, h);
    if (scene === "grid") {
      ctx.fillStyle = "#f4f1ea"; ctx.fillRect(0, 0, w, h);
      var s = Math.round(h / 9);
      for (var x = 0; x < w; x += s) for (var y = 0; y < h; y += s) {
        if (((x / s) + (y / s)) % 2 === 0) { ctx.fillStyle = "#1c1c1e"; ctx.fillRect(x, y, s, s); }
      }
      ctx.fillStyle = "#ff4d2e"; ctx.beginPath(); ctx.arc(w * 0.3, h * 0.45, h * 0.18, 0, 7); ctx.fill();
      ctx.fillStyle = "#2e7dff"; ctx.beginPath(); ctx.arc(w * 0.72, h * 0.6, h * 0.14, 0, 7); ctx.fill();
      return;
    }
    if (scene === "type") {
      ctx.fillStyle = "#101014"; ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = "#f2f2f4";
      ctx.font = "700 " + Math.round(h * 0.2) + "px system-ui, sans-serif";
      ctx.textBaseline = "middle";
      var lines = ["LIQUID GLASS", "liquid glass", "LIQUID GLASS", "liquid glass", "LIQUID GLASS"];
      for (var i = 0; i < lines.length; i++) {
        ctx.fillStyle = i % 2 ? "#ff9f1a" : "#f2f2f4";
        ctx.fillText(lines[i], -h * 0.3 * (i % 3), h * (0.12 + i * 0.2));
      }
      return;
    }
    /* sunset photo-ish: sky gradient, sun, hills, bokeh */
    var g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, "#1b2a6b"); g.addColorStop(0.45, "#e25b8b"); g.addColorStop(0.75, "#ffb347"); g.addColorStop(1, "#ffd88a");
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "rgba(255,240,200,0.95)"; ctx.beginPath(); ctx.arc(w * 0.62, h * 0.62, h * 0.16, 0, 7); ctx.fill();
    ctx.fillStyle = "#2a1638";
    ctx.beginPath(); ctx.moveTo(0, h);
    for (var k = 0; k <= 12; k++) ctx.lineTo(w * k / 12, h * (0.74 + 0.08 * Math.sin(k * 1.7)));
    ctx.lineTo(w, h); ctx.fill();
    for (var b = 0; b < 16; b++) {
      var bx = (Math.sin(b * 12.9) * 0.5 + 0.5) * w, by = (Math.cos(b * 7.3) * 0.5 + 0.5) * h * 0.6;
      ctx.fillStyle = "rgba(255,255,255," + (0.12 + 0.18 * ((b * 37) % 5) / 5) + ")";
      ctx.beginPath(); ctx.arc(bx, by, h * (0.02 + 0.03 * ((b * 13) % 4) / 4), 0, 7); ctx.fill();
    }
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.font = "800 " + Math.round(h * 0.14) + "px system-ui, sans-serif";
    ctx.textBaseline = "middle";
    ctx.fillText("Pillow", w * 0.06, h * 0.22);
  }

  /* ── form: mask + distance to the edge (exact Euclidean, Felzenszwalb) ── */
  var INF = 1e20;
  function edt1d(f, n, d, v, z) {
    var k = 0; v[0] = 0; z[0] = -INF; z[1] = INF;
    for (var q = 1; q < n; q++) {
      var s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]);
      while (s <= z[k]) { k--; s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]); }
      k++; v[k] = q; z[k] = s; z[k + 1] = INF;
    }
    k = 0;
    for (var q2 = 0; q2 < n; q2++) { while (z[k + 1] < q2) k++; d[q2] = (q2 - v[k]) * (q2 - v[k]) + f[v[k]]; }
  }
  function distanceInside(mask, w, h) {
    /* squared distance of each inside pixel to the nearest outside pixel */
    var grid = new Float64Array(w * h), n = Math.max(w, h);
    var f = new Float64Array(n), d = new Float64Array(n), v = new Int32Array(n), z = new Float64Array(n + 1);
    for (var i = 0; i < w * h; i++) grid[i] = mask[i] > 127 ? INF : 0;
    for (var x = 0; x < w; x++) {
      for (var y = 0; y < h; y++) f[y] = grid[y * w + x];
      edt1d(f, h, d, v, z);
      for (y = 0; y < h; y++) grid[y * w + x] = d[y];
    }
    for (var y2 = 0; y2 < h; y2++) {
      for (var x2 = 0; x2 < w; x2++) f[x2] = grid[y2 * w + x2];
      edt1d(f, w, d, v, z);
      for (x2 = 0; x2 < w; x2++) grid[y2 * w + x2] = Math.sqrt(d[x2]);
    }
    return grid;
  }
  function boxBlur(src, w, h, r, out) {
    /* separable box blur ×2 on a single channel float array */
    r = Math.max(0, Math.round(r));
    var tmp = new Float32Array(w * h), a = src, b = tmp, pass, x, y, acc, i;
    if (!r) { for (i = 0; i < w * h; i++) out[i] = src[i]; return out; }
    for (pass = 0; pass < 2; pass++) {
      for (y = 0; y < h; y++) {
        acc = 0;
        for (x = -r; x <= r; x++) acc += a[y * w + clamp(x, 0, w - 1)];
        for (x = 0; x < w; x++) {
          b[y * w + x] = acc / (2 * r + 1);
          acc += a[y * w + clamp(x + r + 1, 0, w - 1)] - a[y * w + clamp(x - r, 0, w - 1)];
        }
      }
      var c = pass === 1 ? out : new Float32Array(w * h);
      for (x = 0; x < w; x++) {
        acc = 0;
        for (y = -r; y <= r; y++) acc += b[clamp(y, 0, h - 1) * w + x];
        for (y = 0; y < h; y++) {
          c[y * w + x] = acc / (2 * r + 1);
          acc += b[clamp(y + r + 1, 0, h - 1) * w + x] - b[clamp(y - r, 0, h - 1) * w + x];
        }
      }
      a = c;
    }
    return out;
  }

  /* the form is built once per shape / size in its own padded box */
  var formCache = null;
  function buildForm(shape, W, H, dpr) {
    var dm = state.dims[shape] || {};
    var key = shape + "|" + W + "x" + H + "|" + dm.w + "," + dm.h + "," + dm.r + "," + dm.n;
    if (formCache && formCache.key === key) return formCache;
    var fw, fh, k = H / 620, rr = null;
    if (shape === "circle") { fw = fh = Math.round(Math.min(dm.w * k, H * 0.86)); }
    else if (shape === "text") { fw = Math.round(Math.min(W * 0.62, H * 1.35)); fh = Math.round(H * 0.62); }
    else {
      fw = Math.round(clamp(dm.w * k, 8 * dpr, W * 0.9)); fh = Math.round(clamp(dm.h * k, 8 * dpr, H * 0.84));
      rr = dm.r / 100 * Math.min(fw, fh) / 2;
    }
    var pad = Math.round(H * 0.18), bw = fw + pad * 2, bh = fh + pad * 2;
    var cv = document.createElement("canvas"); cv.width = bw; cv.height = bh;
    var c = cv.getContext("2d");
    c.fillStyle = "#fff";
    c.beginPath();
    if (shape === "circle") c.arc(bw / 2, bh / 2, fw / 2, 0, 7);
    else if (shape === "text") {
      c.font = "900 " + Math.round(fh * 0.95) + "px system-ui, -apple-system, sans-serif";
      c.textAlign = "center"; c.textBaseline = "middle";
      c.fillText("Aa", bw / 2, bh / 2 + fh * 0.04);
    } else {
      /* superellipse corners, as the AE shape draws them */
      var r = Math.max(0.5, rr), sn = Math.max(1.5, dm.n || 3), CS = [[1, 1], [-1, 1], [-1, -1], [1, -1]];
      for (var ck = 0; ck < 4; ck++) {
        var ccx = bw / 2 + CS[ck][0] * (fw / 2 - r), ccy = bh / 2 + CS[ck][1] * (fh / 2 - r);
        for (var ci = 0; ci <= 28; ci++) {
          var an = (ck + ci / 28) * Math.PI / 2, co = Math.cos(an), si = Math.sin(an);
          var qx = ccx + r * (co < 0 ? -1 : 1) * Math.pow(Math.abs(co), 2 / sn), qy = ccy + r * (si < 0 ? -1 : 1) * Math.pow(Math.abs(si), 2 / sn);
          if (ck === 0 && ci === 0) c.moveTo(qx, qy); else c.lineTo(qx, qy);
        }
      }
      c.closePath();
    }
    if (shape !== "text") c.fill();
    var px = c.getImageData(0, 0, bw, bh).data, mask = new Uint8ClampedArray(bw * bh), alpha = new Float32Array(bw * bh);
    for (var i = 0; i < bw * bh; i++) { mask[i] = px[i * 4 + 3]; alpha[i] = px[i * 4 + 3] / 255; }
    var dist = distanceInside(mask, bw, bh);
    /* the direction to the edge: gradient of a softened distance field —
       the raw one is stepped on a pixel grid, which frays the rim */
    var dsm = boxBlur(dist, bw, bh, 2, new Float32Array(bw * bh));
    var gx = new Float32Array(bw * bh), gy = new Float32Array(bw * bh), maxD = 0;
    for (var y = 1; y < bh - 1; y++) for (var x = 1; x < bw - 1; x++) {
      var j = y * bw + x;
      if (!mask[j]) continue;
      var dx = dsm[j + 1] - dsm[j - 1], dy = dsm[j + bw] - dsm[j - bw], l = Math.sqrt(dx * dx + dy * dy);
      if (l > 1e-4) { gx[j] = -dx / l; gy[j] = -dy / l; }   /* outward normal */
      if (dist[j] > maxD) maxD = dist[j];
    }
    var md = shape === "text" ? Math.max(3, fh * 0.14) : Math.min(fw, fh) / 2;
    formCache = { key: key, w: bw, h: bh, pad: pad, mask: mask, alpha: alpha, dist: dist, gx: gx, gy: gy, maxD: maxD, md: md, shadowKey: "", shadow: null, mapKey: "" };
    return formCache;
  }

  /* The refraction map, as the AE glass builds it: the slope of the
     form blurred at two widths — a narrow one that squeezes the rim (its
     width from Edge) and a wide one that magnifies the whole inside.
     mx/my: how far to look, in units of the lens strength. */
  function lensMap(f, edge) {
    var mk = f.key + "|" + edge;
    if (f.mapKey === mk) return f;
    var n = f.w * f.h, w = f.w, h = f.h;
    var r1 = Math.max(1.5, edge / 100 * f.md), s1 = Math.max(1, Math.round(r1 * 0.75));
    var r2 = f.md, s2 = Math.max(1, Math.round(f.md * 0.5));
    var a1 = boxBlur(f.alpha, w, h, r1 * 0.85, new Float32Array(n));
    var a2 = boxBlur(f.alpha, w, h, r2 * 0.85, new Float32Array(n));
    var mx = new Float32Array(n), my = new Float32Array(n);
    var at = function (a, x, y) { return a[clamp(y, 0, h - 1) * w + clamp(x, 0, w - 1)]; };
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
      var j = y * w + x;
      if (!f.mask[j]) continue;
      var vx = 0.5 * (at(a1, x + s1, y) - at(a1, x - s1, y)) + 0.4 * (at(a2, x + s2, y) - at(a2, x - s2, y));
      var vy = 0.5 * (at(a1, x, y + s1) - at(a1, x, y - s1)) + 0.4 * (at(a2, x, y + s2) - at(a2, x, y - s2));
      mx[j] = clamp(vx, -1, 1); my[j] = clamp(vy, -1, 1);
    }
    f.mx = mx; f.my = my; f.mapKey = mk;
    return f;
  }
  function bilinear(ch, W, fx, fy) {
    var x0 = fx | 0, y0 = fy | 0, ax = fx - x0, ay = fy - y0, i = y0 * W + x0;
    return ch[i] * (1 - ax) * (1 - ay) + ch[i + 1] * ax * (1 - ay) + ch[i + W] * (1 - ax) * ay + ch[i + W + 1] * ax * ay;
  }

  /* ── render ─────────────────────────────────────────────────────── */
  var bg = null;  /* { key, w, h, rgb: [R,G,B Float32], blur: {r, R,G,B} } */
  function sceneData(W, H) {
    var key = state.scene + "|" + W + "x" + H;
    if (bg && bg.key === key) return bg;
    var cv = document.createElement("canvas"); cv.width = W; cv.height = H;
    var c = cv.getContext("2d");
    drawScene(c, W, H, state.scene);
    var d = c.getImageData(0, 0, W, H).data, n = W * H;
    var R = new Float32Array(n), G = new Float32Array(n), B = new Float32Array(n);
    for (var i = 0; i < n; i++) { R[i] = d[i * 4]; G[i] = d[i * 4 + 1]; B[i] = d[i * 4 + 2]; }
    bg = { key: key, w: W, h: H, R: R, G: G, B: B, blurR: -1, cv: cv };
    return bg;
  }
  /* the frosted backdrop. The browser's own blur (ctx.filter) does it in
     a few ms; the box blur in JS took ~50 ms a step, on every move of the
     Frost slider. Same look: two box passes of radius r ≈ a gaussian of
     sigma √(((2r+1)² − 1) / 6). The edges are padded with the stretched
     scene, so they do not fade to black as the filter's transparent
     surround would make them. */
  function blurred(s, r) {
    if (s.blurR === r) return s;
    var n = s.w * s.h, i;
    var sigma = Math.sqrt(((2 * r + 1) * (2 * r + 1) - 1) / 6), pad = Math.ceil(sigma * 3);
    var done = false;
    if (r > 0) {
      try {
        var cv = document.createElement("canvas");
        cv.width = s.w + pad * 2; cv.height = s.h + pad * 2;
        var c = cv.getContext("2d");
        if (typeof c.filter === "string") {
          c.filter = "blur(" + sigma.toFixed(2) + "px)";
          c.drawImage(s.cv, -pad, -pad, s.w + pad * 4, s.h + pad * 4);
          c.drawImage(s.cv, pad, pad);
          c.filter = "none";
          var d = c.getImageData(pad, pad, s.w, s.h).data;
          s.bR = new Float32Array(n); s.bG = new Float32Array(n); s.bB = new Float32Array(n);
          for (i = 0; i < n; i++) { s.bR[i] = d[i * 4]; s.bG[i] = d[i * 4 + 1]; s.bB[i] = d[i * 4 + 2]; }
          done = true;
        }
      } catch (e) {}
    }
    if (!done) {
      s.bR = boxBlur(s.R, s.w, s.h, r, new Float32Array(n));
      s.bG = boxBlur(s.G, s.w, s.h, r, new Float32Array(n));
      s.bB = boxBlur(s.B, s.w, s.h, r, new Float32Array(n));
    }
    s.blurR = r;
    return s;
  }

  function render() {
    state.raf = 0;
    var cv = $("lg-canvas");
    if (!cv || !cv.offsetWidth) return;
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var W = Math.round(cv.clientWidth * dpr), H = Math.round(cv.clientHeight * dpr);
    if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
    var p = state.p, s = sceneData(W, H), f = buildForm(state.shape, W, H, dpr);
    var frost = Math.round(p.frost * dpr * 0.6);
    blurred(s, frost);
    var ctx = cv.getContext("2d"), img = ctx.createImageData(W, H), out = img.data;
    var n = W * H, i;
    /* start from the background */
    for (i = 0; i < n; i++) { out[i * 4] = s.R[i]; out[i * 4 + 1] = s.G[i]; out[i * 4 + 2] = s.B[i]; out[i * 4 + 3] = 255; }

    var ox = Math.round(state.cx * W - f.w / 2), oy = Math.round(state.cy * H - f.h / 2);
    /* the rim band follows the form's real thickness (a letter's stroke
       is much thinner than a pill) */
    var band = clamp((p.edge / 100) * 2.2 * f.maxD, 2.5 * dpr, f.maxD * 1.15);
    lensMap(f, p.edge);
    /* the lens is as thick as a thick glass, not as the whole form: a
       big circle bends as much as a small one (capped like the AE glass) */
    var amt = 2 * (p.refraction / 100) * Math.min(f.md, 110 * H / 620);
    var spread = (p.dispersion || 0) / 100 * 0.25, fres = (p.fresnel || 0) / 100 * 0.3;
    var hi = p.highlight / 100, tintA = p.tint / 100, tintC = p.dark ? 0 : 255;
    var LX = -0.7071, LY = -0.7071;

    /* shadow outside: blurred, offset form alpha */
    var shA = p.shadow / 100;
    if (shA > 0) {
      var sk = f.key + "|" + dpr;
      if (f.shadowKey !== sk) { f.shadow = boxBlur(f.alpha, f.w, f.h, Math.round(f.pad * 0.45), new Float32Array(f.w * f.h)); f.shadowKey = sk; }
      var off = Math.round(f.pad * 0.28);
      for (var sy = 0; sy < f.h; sy++) {
        var ty = oy + sy + off; if (ty < 0 || ty >= H) continue;
        for (var sx = 0; sx < f.w; sx++) {
          var tx = ox + sx; if (tx < 0 || tx >= W) continue;
          var a = f.shadow[sy * f.w + sx] * shA * (1 - f.alpha[(sy + off < f.h ? sy + off : sy) * f.w + sx]);
          if (a <= 0.001) continue;
          var o = (ty * W + tx) * 4;
          out[o] *= 1 - a; out[o + 1] *= 1 - a; out[o + 2] *= 1 - a;
        }
      }
    }

    /* the glass */
    for (var y = 0; y < f.h; y++) {
      var py = oy + y; if (py < 0 || py >= H) continue;
      for (var x = 0; x < f.w; x++) {
        var j = y * f.w + x, a0 = f.alpha[j];
        if (a0 <= 0) continue;
        var pxx = ox + x; if (pxx < 0 || pxx >= W) continue;
        var d = f.dist[j], t = clamp(d / band, 0, 1), rim = 1 - t;
        var nx = f.gx[j], ny = f.gy[j];
        /* lens: look along the map — magnified inside, squeezed at the rim */
        var ux = f.mx[j] * amt, uy = f.my[j] * amt;
        var fxp = clamp(pxx + ux, 0, W - 1.001), fyp = clamp(py + uy, 0, H - 1.001);
        var r = bilinear(s.bR, W, fxp, fyp), g = bilinear(s.bG, W, fxp, fyp), b = bilinear(s.bB, W, fxp, fyp);
        /* dispersion: red bends a bit more, blue a bit less (Lighten) */
        if (spread > 0) {
          r = Math.max(r, bilinear(s.bR, W, clamp(pxx + ux * (1 + spread), 0, W - 1.001), clamp(py + uy * (1 + spread), 0, H - 1.001)));
          b = Math.max(b, bilinear(s.bB, W, clamp(pxx + ux * (1 - spread), 0, W - 1.001), clamp(py + uy * (1 - spread), 0, H - 1.001)));
        }
        /* a touch brighter and livelier behind glass */
        r = r * 1.04 + 4; g = g * 1.04 + 4; b = b * 1.04 + 4;
        /* tint */
        r += (tintC - r) * tintA; g += (tintC - g) * tintA; b += (tintC - b) * tintA;
        /* specular rim: facing the light, and weaker on the far side */
        var facing = nx * LX + ny * LY;
        var edgeLine = Math.pow(rim, 6);
        var spec = hi * edgeLine * (Math.pow(Math.max(0, facing), 1.2) * 1.0 + Math.pow(Math.max(0, -facing), 1.4) * 0.45);
        /* fresnel: a thin even line just inside the edge */
        var line = fres * clamp(Math.min(4, Math.max(1.2, f.md * 0.018)) * dpr * 0.5 + 0.5 - d, 0, 1);
        var add = 255 * (spec + line);
        r += add; g += add; b += add;
        var o2 = (py * W + pxx) * 4;
        out[o2] = out[o2] * (1 - a0) + clamp(r, 0, 255) * a0;
        out[o2 + 1] = out[o2 + 1] * (1 - a0) + clamp(g, 0, 255) * a0;
        out[o2 + 2] = out[o2 + 2] * (1 - a0) + clamp(b, 0, 255) * a0;
      }
    }
    ctx.putImageData(img, 0, 0);
  }
  function schedule() { if (!state.raf) state.raf = requestAnimationFrame(render); }

  /* ── UI ──────────────────────────────────────────────────────────── */
  function renderControls() {
    var box = $("lg-controls");
    if (!box) return;
    var html = "";
    for (var i = 0; i < CONTROLS.length; i++) {
      var c = CONTROLS[i];
      html += '<div class="slider-row lg-ctl"><div class="slider-head"><span>' + c.label + '</span><span id="lg-v-' + c.key + '"></span></div>' +
        '<input type="range" id="lg-r-' + c.key + '" data-lg="' + c.key + '" min="' + c.min + '" max="' + c.max + '" step="' + c.step + '" /></div>';
    }
    box.innerHTML = html;
    syncControls();
  }
  function syncControls() {
    for (var i = 0; i < CONTROLS.length; i++) {
      var c = CONTROLS[i], r = $("lg-r-" + c.key), v = $("lg-v-" + c.key);
      if (r && document.activeElement !== r) r.value = state.p[c.key];
      if (v) v.textContent = (Math.round(state.p[c.key] * 10) / 10) + (c.unit || "");
    }
  }
  function renderShapeControls() {
    var box = $("lg-shape-controls");
    if (!box) return;
    var list = SHAPE_CONTROLS[state.shape];
    box.hidden = !list || state.source !== "new";
    if (!list) { box.innerHTML = ""; box.removeAttribute("data-for"); return; }
    if (box.getAttribute("data-for") !== state.shape) {
      var html = "";
      for (var i = 0; i < list.length; i++) {
        var c = list[i];
        html += '<div class="slider-row lg-ctl"><div class="slider-head"><span>' + c.label + '</span><span id="lg-sv-' + c.key + '"></span></div>' +
          '<input type="range" id="lg-sr-' + c.key + '" data-lgs="' + c.key + '" min="' + c.min + '" max="' + c.max + '" step="' + (c.step || 1) + '" /></div>';
      }
      box.innerHTML = html;
      box.setAttribute("data-for", state.shape);
    }
    var d = state.dims[state.shape];
    for (var j = 0; j < list.length; j++) {
      var k = list[j].key, r = $("lg-sr-" + k), v = $("lg-sv-" + k);
      if (r && document.activeElement !== r) r.value = d[k];
      if (v) v.textContent = (list[j].step ? Math.round(d[k] * 10) / 10 : Math.round(d[k])) + (list[j].unit != null ? list[j].unit : " px");
    }
  }
  function paintSwitch(id, attr, val) {
    var bs = document.querySelectorAll("#" + id + " [" + attr + "]");
    for (var i = 0; i < bs.length; i++) bs[i].classList.toggle("active", bs[i].getAttribute(attr) === val);
  }
  function setPreset(id) {
    if (!PRESETS[id]) return;
    state.preset = id;
    state.p = copy(PRESETS[id]);
    paintSwitch("lg-presets", "data-preset", id);
    syncControls();
    save();
    schedule();
  }
  function save() {
    try { localStorage.setItem("pillow.lglass", JSON.stringify({ preset: state.preset, p: state.p, shape: state.shape, scene: state.scene, source: state.source, dims: state.dims })); } catch (e) {}
  }
  function load() {
    state.p = copy(PRESETS.regular);
    try {
      var d = JSON.parse(localStorage.getItem("pillow.lglass") || "null");
      if (d && d.p) {
        for (var k in state.p) if (typeof d.p[k] === typeof state.p[k]) state.p[k] = d.p[k];
        state.preset = PRESETS[d.preset] ? d.preset : "custom";
        if (d.shape) state.shape = d.shape;
        if (d.scene) state.scene = d.scene;
        if (d.source === "new" || d.source === "layer") state.source = d.source;
        if (d.dims) for (var sh in state.dims) if (d.dims[sh]) for (var dk in state.dims[sh]) if (typeof d.dims[sh][dk] === "number") state.dims[sh][dk] = d.dims[sh][dk];
      }
    } catch (e) {}
  }

  /* Every glass call runs inside a guard: it checks that the host
     functions are there (and reloads the host script once if they are
     not), catches any error, and never lets an empty reply through. */
  var STEP_FILE = 'Folder.temp.fsName+"/pillow-glass-step.txt"';
  function guarded(call) {
    return "(function(){try{" +
      "if(typeof pillowGlassMake!==\"function\")return '{\"ok\":false,\"missing\":true}';" +
      "var r=" + call + ";" +
      "if(r===undefined||r===null||r==='')return '{\"ok\":false,\"error\":\"host returned '+(r===''?'empty':String(r))+' (build '+(typeof PILLOW_HOST_BUILD!=='undefined'?PILLOW_HOST_BUILD:'?')+')\"}';" +
      "return String(r);" +
      "}catch(e){return '{\"ok\":false,\"error\":\"'+String(e).replace(/[\\\"\\\\\\r\\n]/g,' ')+(e.line?' (line '+e.line+')':'')+'\"}';}})()";
  }
  function readStepFile(cb) {
    var js = "(function(){try{var f=new File(" + STEP_FILE + ");if(!f.exists)return 'glass never started';" +
      "f.encoding='UTF-8';f.open('r');var s=f.read();f.close();return 'last step: '+s;}catch(e){return 'no step log';}})()";
    if (!csInterface) { cb("no host"); return; }
    try { csInterface.evalScript(js, function (res) { cb(res || "no reply at all"); }); } catch (e) { cb("no host"); }
  }
  function runGlass(call, done, retried) {
    host(guarded(call), function (r) {
      if (r && r.missing) {
        if (retried) { toast("Liquid Glass functions are missing in the host script", true); return; }
        reloadHostScript(function (ok) {
          if (ok) runGlass(call, done, true);
        });
        return;
      }
      if (r && r.error === "Empty response") {
        /* the engine stopped without an error: the step file says where */
        readStepFile(function (msg) { toast("After Effects stopped the glass · " + msg, true); });
        return;
      }
      done(r);
    });
  }

  function make() {
    var p = state.p;
    var payload = {
      refraction: p.refraction, edge: p.edge, depth: Math.round(p.edge * 1.6), frost: p.frost,
      specular: Math.round(p.highlight * 0.8), highlight: p.highlight, tint: p.tint, shadow: p.shadow,
      dispersion: p.dispersion, fresnel: p.fresnel,
      tintColor: p.dark ? [0, 0, 0] : [1, 1, 1]
    };
    if (state.source === "new") { payload.create = state.shape; if (state.dims[state.shape]) payload.dims = state.dims[state.shape]; }
    runGlass('pillowGlassMake("' + esc(JSON.stringify(payload)) + '")', function (r) {
      if (!r || !r.ok) { toast((r && r.error) || "Could not make glass", true); return; }
      if (r.notes && r.notes.length && typeof console !== "undefined") console.log("[Liquid Glass]", r.notes.join(" | "));
      toast("Liquid Glass on " + r.count + (r.count === 1 ? " layer" : " layers") + (r.notes && r.notes.length ? " · " + r.notes[0] + (r.notes.length > 1 ? " (+" + (r.notes.length - 1) + " more)" : "") : " · move it like any layer"),
        !!(r.notes && r.notes.length));
    });
  }
  function updateGlass() {
    var p = state.p;
    var payload = {
      refraction: p.refraction, edge: p.edge, frost: p.frost, highlight: p.highlight, tint: p.tint, shadow: p.shadow,
      dispersion: p.dispersion, fresnel: p.fresnel,
      tintColor: p.dark ? [0, 0, 0] : [1, 1, 1]
    };
    if (state.source === "new" && state.dims[state.shape]) payload.dims = state.dims[state.shape];
    runGlass('pillowGlassUpdate("' + esc(JSON.stringify(payload)) + '")', function (r) {
      if (!r || !r.ok) { toast((r && r.error) || "Could not update the glass", true); return; }
      toast("Updated " + r.count + (r.count === 1 ? " glass" : " glasses"));
    });
  }
  function removeGlass() {
    runGlass("pillowGlassRemove()", function (r) {
      if (!r || !r.ok) { toast((r && r.error) || "Nothing to remove", true); return; }
      toast("Glass removed · original layer is back");
    });
  }

  function bind() {
    var ctl = $("lg-controls");
    if (ctl) ctl.addEventListener("input", function (e) {
      var k = e.target.getAttribute("data-lg");
      if (!k) return;
      state.p[k] = parseFloat(e.target.value);
      state.preset = "custom";
      paintSwitch("lg-presets", "data-preset", "");
      syncControls();
      save();
      schedule();
    });
    var pr = $("lg-presets");
    if (pr) pr.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-preset]") : null;
      if (b) setPreset(b.getAttribute("data-preset"));
    });
    var sh = $("lg-shapes");
    if (sh) sh.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-shape]") : null;
      if (!b) return;
      state.shape = b.getAttribute("data-shape");
      paintSwitch("lg-shapes", "data-shape", state.shape);
      syncSource();
      save(); schedule();
    });
    var shc = $("lg-shape-controls");
    if (shc) shc.addEventListener("input", function (e) {
      var k = e.target.getAttribute("data-lgs"), d = state.dims[state.shape];
      if (!k || !d) return;
      d[k] = parseFloat(e.target.value);
      renderShapeControls();
      save();
      schedule();
    });
    var so = $("lg-source");
    if (so) so.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-source]") : null;
      if (!b) return;
      state.source = b.getAttribute("data-source");
      syncSource();
      save();
    });
    var sc = $("lg-scenes");
    if (sc) sc.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-scene]") : null;
      if (!b) return;
      state.scene = b.getAttribute("data-scene");
      paintSwitch("lg-scenes", "data-scene", state.scene);
      save(); schedule();
    });
    /* drag the glass over the background */
    var cv = $("lg-canvas");
    if (cv) {
      var drag = false;
      var move = function (e) {
        var r = cv.getBoundingClientRect();
        state.cx = clamp((e.clientX - r.left) / r.width, 0.08, 0.92);
        state.cy = clamp((e.clientY - r.top) / r.height, 0.1, 0.9);
        schedule();
      };
      cv.addEventListener("pointerdown", function (e) { drag = true; try { cv.setPointerCapture(e.pointerId); } catch (x) {} move(e); });
      cv.addEventListener("pointermove", function (e) { if (drag) move(e); });
      cv.addEventListener("pointerup", function () { drag = false; });
      cv.addEventListener("pointercancel", function () { drag = false; });
    }
    if ($("btn-lg-make")) $("btn-lg-make").onclick = make;
    if ($("btn-lg-remove")) $("btn-lg-remove").onclick = removeGlass;
    if ($("btn-lg-update")) $("btn-lg-update").onclick = updateGlass;
    if (window.ResizeObserver && cv) new ResizeObserver(function () { schedule(); }).observe(cv);
  }

  var SHAPE_NAMES = { pill: "Pill", circle: "Circle", squircle: "Squircle", text: "Text" };
  function syncSource() {
    paintSwitch("lg-source", "data-source", state.source);
    renderShapeControls();
    var lab = $("lg-make-label"), foot = $("lg-foot");
    if (lab) lab.textContent = state.source === "new" ? "Create Glass " + (SHAPE_NAMES[state.shape] || "Shape") : "Make Selected Layer Glass";
    if (foot) foot.textContent = state.source === "new"
      ? "Adds a new " + (SHAPE_NAMES[state.shape] || "shape").toLowerCase() + " glass: one \u201cPillow Liquid Glass\u201d layer (its lens, shape and map sit just under it and follow it) \u2014 move, scale and animate it as you like. Change it later: select it and press Update."
      : "Your layer becomes glass inside one \u201cPillow Liquid Glass\u201d precomp and keeps its animation. Select it and press Update to change it later.";
  }

  function build() {
    if (state.built) return;
    state.built = true;
    load();
    renderControls();
    paintSwitch("lg-presets", "data-preset", state.preset);
    paintSwitch("lg-shapes", "data-shape", state.shape);
    paintSwitch("lg-scenes", "data-scene", state.scene);
    syncSource();
    bind();
  }

  window.PillowLiquidGlass = {
    prebuild: build,
    resume: function () { build(); state.active = true; schedule(); },
    pause: function () { state.active = false; },
    _render: render,
    _state: state
  };
})();
