/* Pillow — Bounce (procedural, expression-driven)
 *
 * This tab NEVER writes keyframes. It writes one expression onto the
 * selected property; the bounce is derived at render time from the user's
 * own keyframes and their velocity, so moving/retiming a key recalculates.
 *
 * Parts:
 *   PRESETS          preset definitions
 *   bounceOffset()   bounce math (mirrors the AE expression, for preview)
 *   buildExpression()AE expression generation
 *   inspect/apply/remove  host communication + validation
 *   preview loop     UI only
 */

(function () {
  "use strict";

  var TAG = "PILLOW-BOUNCE";

  /* Two modes, the way BOUNCr and Dan Ebberts' classic "Realistic Bounce
     and Overshoot" expressions work:
       overshoot — a damped spring that starts with the speed the layer
                   had arriving at the keyframe: it swings past the key
                   and settles (Amplitude × arrival speed, Frequency,
                   Decay);
       bounce    — the layer hits the key value and bounces back off it in
                   parabolas under gravity, each bounce losing energy by
                   Elasticity, up to Max Bounces.
     The amplitude comes from the real arrival speed, so a fast move
     springs more than a slow one — that is what makes it look natural. */
  var MODES = {
    overshoot: {
      label: "Overshoot",
      presets: [
        { id: "soft",    label: "Soft",    desc: "Gentle settle",       p: { amp: 0.7, freq: 2.0, decay: 6.0, floor: 0 } },
        { id: "smooth",  label: "Smooth",  desc: "Natural, balanced",   p: { amp: 1.0, freq: 2.5, decay: 4.5, floor: 0 } },
        { id: "snappy",  label: "Snappy",  desc: "Quick and tight",     p: { amp: 1.1, freq: 4.0, decay: 7.0, floor: 0 } },
        { id: "elastic", label: "Elastic", desc: "Spring, many swings", p: { amp: 1.2, freq: 3.0, decay: 2.2, floor: 0 } },
        { id: "hit",     label: "Hit",     desc: "Bumps the key, never past it", p: { amp: 1.0, freq: 3.0, decay: 5.0, floor: 1 } }
      ],
      controls: [
        { key: "amp",   label: "Amplitude", slider: "Bounce Amplitude", min: 0,   max: 3,  step: 0.05 },
        { key: "freq",  label: "Frequency", slider: "Bounce Frequency", min: 0.5, max: 10, step: 0.1 },
        { key: "decay", label: "Decay",     slider: "Bounce Decay",     min: 0.5, max: 15, step: 0.1 },
        { key: "floor", label: "Floor",     slider: "Bounce Floor",     toggle: true, hint: "Never swing past the key: it bumps the key and comes back, like hitting a wall" }
      ]
    },
    bounce: {
      label: "Bounce Back",
      presets: [
        { id: "ball",   label: "Ball",   desc: "Classic bounce",    p: { elast: 0.6,  grav: 5000, maxb: 9 } },
        { id: "rubber", label: "Rubber", desc: "Light and springy", p: { elast: 0.78, grav: 3500, maxb: 14 } },
        { id: "heavy",  label: "Heavy",  desc: "Solid landing",     p: { elast: 0.35, grav: 9000, maxb: 4 } },
        { id: "floaty", label: "Floaty", desc: "Slow and airy",     p: { elast: 0.65, grav: 1600, maxb: 8 } }
      ],
      controls: [
        { key: "elast", label: "Elasticity",  slider: "Bounce Elasticity", min: 0.05, max: 0.95,  step: 0.01 },
        { key: "grav",  label: "Gravity",     slider: "Bounce Gravity",    min: 500,  max: 20000, step: 100 },
        { key: "maxb",  label: "Max Bounces", slider: "Bounce Max",        min: 1,    max: 20,    step: 1 }
      ]
    }
  };
  var PRESETS = MODES.overshoot.presets;
  var CONTROLS = MODES.overshoot.controls;

  var MOVE = 0.45;      // preview: seconds of the arriving move
  var DIST = 300;       // preview: px travelled in it (gravity is in px/s²)
  var HOLD = 0.5;       // preview: seconds of rest before looping

  var state = {
    mode: "overshoot",
    preset: "smooth",
    p: null,
    hover: null,
    targets: null,
    conflict: null,
    raf: null,
    t0: 0,
    active: false
  };

  function el(id) { return document.getElementById(id); }
  function clone(o) { var r = {}; for (var k in o) if (o.hasOwnProperty(k)) r[k] = o[k]; return r; }
  function modeOf(id) {
    for (var m in MODES) for (var i = 0; i < MODES[m].presets.length; i++) if (MODES[m].presets[i].id === id) return m;
    return null;
  }
  function preset(id) {
    for (var m in MODES) for (var i = 0; i < MODES[m].presets.length; i++) if (MODES[m].presets[i].id === id) return MODES[m].presets[i];
    return MODES[state.mode].presets[1] || MODES[state.mode].presets[0];
  }

  /* ─── Bounce math (same as the expression) ─────────────────────
     Offset from the key value t seconds after the key, for an arrival
     speed v (units/s, along the move). Overshoot swings forward first;
     bounce goes back (negative). */
  function bounceOffset(p, t, v, mode) {
    mode = mode || state.mode;
    if (t <= 0) return 0;
    if (mode === "bounce") {
      var e = p.elast, g = p.grav, vl = v * e;
      var tCur = 0, seg = 2 * vl / g, tNext = seg, nb = 1;
      while (tNext < t && nb <= p.maxb) { vl *= e; seg *= e; tCur = tNext; tNext += seg; nb++; }
      if (nb > p.maxb) return 0;
      var d = t - tCur;
      return -d * (vl - g * d / 2);
    }
    var w = p.freq * Math.PI * 2, s = Math.sin(t * w);
    /* Floor: the swings stay on the arriving side of the key */
    if (p.floor) s = -Math.abs(s);
    return v * p.amp * s / Math.exp(p.decay * t) / w;
  }
  /* how long the effect visibly lasts */
  function bounceSpan(p, mode) {
    mode = mode || state.mode;
    if (mode === "bounce") {
      var v = DIST / MOVE, seg0 = 2 * v * p.elast / p.grav, e = p.elast;
      var total = seg0 * (1 - Math.pow(e, p.maxb)) / (1 - e);
      return Math.max(0.4, Math.min(3, total * 1.08));
    }
    return Math.max(0.5, Math.min(3, Math.log(50) / p.decay));
  }

  /* ─── AE expression generation ───────────────────────────────────
     Works after every keyframe of the property. Parameters live on the
     layer as sliders (like BOUNCr's controller), so they can be tweaked
     in AE afterwards. Vector maths is done by hand — it runs the same in
     the legacy and the JavaScript expression engines. An eased-in key
     (arrival speed ~0) lands early at the move's top speed and bounces
     from there (arrival() in the expression), so it does not stop on the
     key first and bounce after. */
  function buildExpression(p, label, mode) {
    mode = mode || state.mode;
    var head = [
      "// " + TAG + " · " + (mode === "bounce" ? "Bounce Back" : "Overshoot") + " · " + label,
      "// Procedural — no keyframes are created. Tweak the Bounce sliders on",
      "// the layer; remove via Pillow › Bounce.",
      "function vadd(a, b) { if (a instanceof Array) { var r = []; for (var i = 0; i < a.length; i++) r.push(a[i] + b[i]); return r; } return a + b; }",
      "function vsub(a, b) { if (a instanceof Array) { var r = []; for (var i = 0; i < a.length; i++) r.push(a[i] - b[i]); return r; } return a - b; }",
      "function vmul(a, s) { if (a instanceof Array) { var r = []; for (var i = 0; i < a.length; i++) r.push(a[i] * s); return r; } return a * s; }",
      "function vlen(a) { if (a instanceof Array) { var s = 0; for (var i = 0; i < a.length; i++) s += a[i] * a[i]; return Math.sqrt(s); } return Math.abs(a); }",
      "function vdot(a, b) { if (a instanceof Array) { var s = 0; for (var i = 0; i < a.length; i++) s += a[i] * b[i]; return s; } return a * b; }",
      /* where the move into key j really lands, and how fast. A key that
         is reached at speed lands on the key. An eased-in key (the move
         slows to a stop on it) would stop first and only then bounce, so
         its slow-down is cut: from the last moment whose speed, held,
         lands by 85% of the move (or from its top speed), the move
         carries on at that speed, lands a little before the key and
         bounces from there, in one motion. */
      "var fd = thisComp.frameDuration;",
      "function arrival(j) {",
      "  var A = key(j - 1).value, B = key(j).value, t0 = key(j - 1).time, t1 = key(j).time;",
      "  var D = vsub(B, A), L2 = vdot(D, D), vk = velocityAtTime(t1 - fd / 10);",
      "  var r = { t: t1, v: vk, s: t1, p: 0, vp: 0, A: A, D: D, eased: false, avg: vmul(D, 1 / Math.max(t1 - t0, fd)) };",
      "  if (!(L2 > 0) || t1 - t0 < fd * 2) return r;",
      "  var M = 32, prev = 0, top = 0, cap = t0 + (t1 - t0) * 0.85, ts = t1, ps = 0, i;",
      "  for (i = 1; i <= M; i++) {",
      "    var pi = vdot(vsub(valueAtTime(t0 + (t1 - t0) * i / M), A), D) / L2, rate = (pi - prev) * M / (t1 - t0);",
      "    var tm = t0 + (t1 - t0) * (i - 0.5) / M, pm = (pi + prev) / 2;",
      /* the top speed, and the latest point whose speed, held, lands by
         85% of the move (so a quick-start ease keeps its timing) */
      "    if (rate > top) { top = rate; ts = tm; ps = pm; }",
      "    if (rate > 0 && tm + (1 - pm) / rate <= cap) { r.vp = rate; r.s = tm; r.p = pm; }",
      "    prev = pi;",
      "  }",
      "  if (r.vp <= 0) { r.vp = top; r.s = ts; r.p = ps; }",
      "  if (top <= 0 || vdot(vk, D) / L2 > top * 0.5) { r.s = t1; r.vp = 0; return r; }",
      "  r.eased = true;",
      "  r.t = Math.min(t1, r.s + (1 - r.p) / r.vp);",
      "  r.v = vmul(D, r.vp);",
      "  return r;",
      "}",
      "var out = value, base = value, n = 0, t = -1, v = 0, ar, landing = false;",
      "if (numKeys > 1) { n = nearestKey(time).index; if (key(n).time > time) n--; }",
      /* inside an eased landing: straight on at top speed, then the bounce */
      "if (n >= 1 && n < numKeys) {",
      "  ar = arrival(n + 1);",
      "  if (ar.eased && time >= ar.s) {",
      "    if (time < ar.t) { out = vadd(ar.A, vmul(ar.D, ar.p + ar.vp * (time - ar.s))); landing = true; }",
      "    else { base = key(n + 1).value; t = time - ar.t; v = ar.v; }",
      "  }",
      "}",
      "if (t < 0 && n > 1 && !landing) {",
      "  ar = arrival(n);",
      "  t = time - ar.t; v = ar.v;",
      "  if (!ar.eased && vlen(v) < vlen(ar.avg) * 0.2) v = ar.avg;",
      "}",
      "if (t >= 0) {"
    ];
    var body;
    if (mode === "bounce") {
      body = [
        "  var e = effect(\"Bounce Elasticity\")(\"Slider\"), g = effect(\"Bounce Gravity\")(\"Slider\"), nMax = effect(\"Bounce Max\")(\"Slider\");",
        "  var rv = vmul(v, -e), vl = vlen(rv);",
        "  if (vl > 0 && t > 0) {",
        "    var vu = vmul(rv, 1 / vl), tCur = 0, seg = 2 * vl / g, tNext = seg, nb = 1;",
        "    while (tNext < t && nb <= nMax) { vl *= e; seg *= e; tCur = tNext; tNext += seg; nb++; }",
        "    out = nb <= nMax ? vadd(base, vmul(vu, (t - tCur) * (vl - g * (t - tCur) / 2))) : base;",
        "  } else out = base;",
        "}",
        "out"
      ];
    } else {
      body = [
        "  var amp = effect(\"Bounce Amplitude\")(\"Slider\"), freq = effect(\"Bounce Frequency\")(\"Slider\"), decay = effect(\"Bounce Decay\")(\"Slider\");",
        "  var floor = 0; try { floor = effect(\"Bounce Floor\")(\"Slider\"); } catch (eF) {}",
        "  var w = freq * Math.PI * 2, s = Math.sin(t * w);",
        "  if (floor > 0.5) s = -Math.abs(s); // Floor: never past the key",
        "  out = vadd(base, vmul(v, amp * s / Math.exp(decay * t) / w));",
        "}",
        "out"
      ];
    }
    return head.concat(body).join("\n");
  }
  /* slider name → value for the host */
  function sliderParams() {
    var out = {}, cs = MODES[state.mode].controls;
    for (var i = 0; i < cs.length; i++) out[cs[i].slider] = state.p[cs[i].key];
    return out;
  }

  /* ─── Markup ───────────────────────────────────────────────── */

  function miniPath(pr) {
    // Displacement-over-time sparkline, 62 × 22, baseline at y = 11.
    var W = 62, H = 22, mid = 11, mode = modeOf(pr.id) || state.mode;
    var span = bounceSpan(pr.p, mode);
    var v = DIST / MOVE, sign = mode === "bounce" ? -1 : 1;
    var peak = 0.0001, pts = [], i, t, y;
    for (i = 0; i <= 44; i++) {
      t = (i / 44) * span;
      y = sign * bounceOffset(pr.p, t, v, mode);
      pts.push(y);
      if (Math.abs(y) > peak) peak = Math.abs(y);
    }
    var d = "";
    for (i = 0; i < pts.length; i++) {
      var x = 1 + (i / 44) * (W - 2);
      var py = mid - (pts[i] / peak) * (mid - 2.5);
      d += (i ? "L" : "M") + (Math.round(x * 10) / 10) + " " + (Math.round(py * 10) / 10);
    }
    return { d: d, peak: peak, span: span, H: H, W: W, sign: sign, mode: mode };
  }

  /* Пресеты. В режиме Liquid Glass — GlassDock (js/glass-dock.js):
     стеклянная панель с пилюлей выбора, которую можно нажать или
     перетащить; иконка пункта — кривая пресета, подпись — имя, описание —
     в подсказке. Без стекла — прежние карточки. При переключении режима
     ряд перестраивается (см. watchGlassMode). */
  var dock = null;
  function glassOn() {
    return document.documentElement.getAttribute("data-pl-glass") === "on" && !!window.PillowGlassDock;
  }

  function renderPresets() {
    if (glassOn()) renderDock(); else renderTiles();
  }

  function renderTiles() {
    var host = el("bnc-presets");
    if (!host) return;
    dock = null;
    host.classList.remove("is-dock");
    var html = "";
    for (var i = 0; i < PRESETS.length; i++) {
      var pr = PRESETS[i];
      var m = miniPath(pr);
      html +=
        '<button type="button" class="bnc-preset' + (pr.id === state.preset ? " active" : "") +
          '" data-bnc-preset="' + pr.id + '">' +
          '<span class="bnc-preset-head">' +
            '<span class="bnc-preset-name">' + pr.label + "</span>" +
          "</span>" +
          '<svg class="bnc-mini" viewBox="0 0 62 22" width="62" height="22" aria-hidden="true" preserveAspectRatio="none">' +
            '<line class="bnc-mini-base" x1="1" y1="11" x2="61" y2="11"></line>' +
            '<path class="bnc-mini-line" d="' + m.d + '" fill="none"></path>' +
            '<circle class="bnc-mini-dot" r="2" cx="1" cy="11"></circle>' +
          "</svg>" +
          '<span class="bnc-preset-desc">' + pr.desc + "</span>" +
        "</button>";
    }
    host.innerHTML = html;
    if (window.pillowRescanTactile) window.pillowRescanTactile();
  }

  function renderDock() {
    var host = el("bnc-presets");
    if (!host) return;
    host.classList.add("is-dock");
    var items = [];
    for (var i = 0; i < PRESETS.length; i++) {
      var pr = PRESETS[i];
      var m = miniPath(pr);
      items.push({
        value: pr.id,
        label: pr.label,
        title: pr.desc,
        attrs: { "data-bnc-preset": pr.id },
        icon:
          '<svg class="bnc-mini" viewBox="0 0 62 22" width="44" height="22" aria-hidden="true" preserveAspectRatio="none">' +
            '<line class="bnc-mini-base" x1="1" y1="11" x2="61" y2="11"></line>' +
            '<path class="bnc-mini-line" d="' + m.d + '" fill="none"></path>' +
            '<circle class="bnc-mini-dot" r="2" cx="1" cy="11"></circle>' +
          "</svg>"
      });
    }
    if (window.PillowGlassDock) {
      dock = window.PillowGlassDock.create(host, {
        items: items,
        value: state.preset === "custom" ? null : state.preset,
        accent: "var(--fg)",
        onValueChange: function (v) { setPreset(v); }
      });
    }
  }

  function setModeVars(mode) {
    state.mode = mode;
    PRESETS = MODES[mode].presets;
    CONTROLS = MODES[mode].controls;
  }
  function paintModeSwitch() {
    var bs = document.querySelectorAll("#bnc-mode [data-mode]");
    for (var i = 0; i < bs.length; i++) bs[i].classList.toggle("active", bs[i].getAttribute("data-mode") === state.mode);
  }
  function setMode(mode) {
    if (!MODES[mode] || mode === state.mode) return;
    setModeVars(mode);
    paintModeSwitch();
    state.preset = MODES[mode].presets[1].id;
    state.p = clone(MODES[mode].presets[1].p);
    renderPresets();
    renderControls();
    updateExpr();
    resetPreview();
    save();
  }

  function renderControls() {
    var host = el("bnc-controls");
    if (!host) return;
    var html = "";
    for (var i = 0; i < CONTROLS.length; i++) {
      var c = CONTROLS[i];
      if (c.toggle) {
        html += '<div class="toggle-row bnc-toggle" title="' + (c.hint || "") + '"><span>' + c.label + '</span>' +
          '<button type="button" class="switch" id="bnc-t-' + c.key + '" data-bnc-toggle="' + c.key + '" role="switch" aria-checked="false"></button></div>';
        continue;
      }
      html +=
        '<div class="bnc-ctl">' +
          '<div class="bnc-ctl-head">' +
            '<label for="bnc-r-' + c.key + '">' + c.label + "</label>" +
            '<input class="bnc-num" id="bnc-n-' + c.key + '" data-bnc-num="' + c.key +
              '" type="number" min="' + c.min + '" max="' + c.max + '" step="' + c.step + '" />' +
          "</div>" +
          '<input class="bnc-range" id="bnc-r-' + c.key + '" data-bnc-range="' + c.key +
            '" type="range" min="' + c.min + '" max="' + c.max + '" step="' + c.step + '" />' +
        "</div>";
    }
    host.innerHTML = html;
    syncControls();
  }

  function syncControls() {
    for (var i = 0; i < CONTROLS.length; i++) {
      var c = CONTROLS[i];
      var v = state.p[c.key];
      if (c.toggle) {
        var tb = el("bnc-t-" + c.key);
        if (tb) { tb.classList.toggle("on", !!v); tb.setAttribute("aria-checked", v ? "true" : "false"); }
        continue;
      }
      var r = el("bnc-r-" + c.key);
      var n = el("bnc-n-" + c.key);
      if (r && document.activeElement !== r) r.value = v;
      if (n && document.activeElement !== n) n.value = c.step >= 1 ? Math.round(v) : Math.round(v * 100) / 100;
    }
  }

  function setPreset(id) {
    state.preset = id;
    if (dock) dock.setValue(id);
    state.p = clone(preset(id).p);
    var btns = document.querySelectorAll("[data-bnc-preset]");
    for (var i = 0; i < btns.length; i++) {
      btns[i].classList.toggle("active", btns[i].getAttribute("data-bnc-preset") === id);
    }
    syncControls();
    updateExpr();
    resetPreview();
    save();
  }

  function markCustom() {
    var btns = document.querySelectorAll("[data-bnc-preset]");
    for (var i = 0; i < btns.length; i++) btns[i].classList.remove("active");
    state.preset = "custom";
    if (dock) dock.setValue(null);
    updateExpr();
    save();
  }

  function currentLabel() {
    return state.preset === "custom" ? "Custom" : preset(state.preset).label;
  }

  function updateExpr() {
    var box = el("bnc-expr-code");
    if (box) box.textContent = buildExpression(state.p, currentLabel());
    var lg = el("bnc-legend-mode");
    if (lg) lg.textContent = MODES[state.mode].label;
  }

  /* ─── Live preview (UI only) ────────────────────────────────── */

  function resetPreview() { state.t0 = 0; drawGraph(); }

  /* ─── Preview graph ─────────────────────────────────────────
     The bounce itself, drawn: displacement after the keyframe over time,
     the key as a diamond on the rest line at the left, and a dot running
     along the curve. The vertical scale is fixed (so Amount / Overshoot
     visibly change the height) but passes through tanh — however strong
     the settings, the curve and the dot stay inside the box. */
  var GRAPH_PAD_X = 14, GRAPH_PAD_Y = 10;
  var graphRef = 0;
  function graphSpan() { return bounceSpan(state.p) * 1.06; }
  var graphRefMode = null;
  function graphGeom() {
    var svg = el("bnc-graph");
    if (!svg) return null;
    var W = svg.clientWidth || (svg.parentNode && svg.parentNode.clientWidth) || 300;
    var H = svg.clientHeight || 88;
    if (graphRefMode !== state.mode) {
      /* reference height per mode: its middle preset peaks at ~50% */
      var ref = MODES[state.mode].presets[1].p, pk = 0, sp = bounceSpan(ref);
      for (var i = 1; i <= 300; i++) pk = Math.max(pk, Math.abs(bounceOffset(ref, i / 300 * sp, DIST / MOVE)));
      graphRef = pk / Math.atanh(0.5);
      graphRefMode = state.mode;
    }
    return { svg: svg, W: W, H: H, x0: GRAPH_PAD_X, x1: W - GRAPH_PAD_X, mid: H / 2, amp: H / 2 - GRAPH_PAD_Y, span: graphSpan() };
  }
  function graphPoint(g, t) {
    /* bounce back is drawn as arcs above the rest line, like a ball off
       the floor; overshoot swings up past it first */
    var off = (state.mode === "bounce" ? -1 : 1) * bounceOffset(state.p, t, DIST / MOVE);
    return [g.x0 + (t / g.span) * (g.x1 - g.x0), g.mid - Math.tanh(off / graphRef) * g.amp];
  }
  function drawGraph() {
    var g = graphGeom();
    if (!g) return;
    g.svg.setAttribute("viewBox", "0 0 " + g.W + " " + g.H);
    var d = "", N = Math.max(60, Math.round((g.x1 - g.x0) / 2));
    for (var i = 0; i <= N; i++) {
      var p = graphPoint(g, (i / N) * g.span);
      d += (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1);
    }
    el("bnc-g-curve").setAttribute("d", d);
    el("bnc-g-fill").setAttribute("d", d + "L" + g.x1.toFixed(1) + " " + g.mid + "L" + g.x0 + " " + g.mid + "Z");
    var base = el("bnc-g-base");
    base.setAttribute("x1", g.x0); base.setAttribute("x2", g.x1);
    base.setAttribute("y1", g.mid); base.setAttribute("y2", g.mid);
    var key = el("bnc-g-key");
    key.setAttribute("x", g.x0 - 4); key.setAttribute("y", g.mid - 4);
    key.setAttribute("transform", "rotate(45 " + g.x0 + " " + g.mid + ")");
    state.graph = g;
  }

  /* ── the demo: an object really doing the move ──────────────────
     Overshoot: a layer arrives from the left at the keyframe's speed,
     passes the key and springs back onto it. Bounce back: a ball falls
     onto the floor and bounces, losing height each time. Positions come
     from the same bounceOffset() as the curve and the AE expression; the
     object stretches along its speed, squashes on each landing, and
     leaves a short trail. */
  var demo = null;
  function demoEls() {
    if (demo && demo.box.isConnected) return demo;
    var box = el("bnc-demo");
    if (!box) return null;
    demo = { box: box, obj: el("bnc-demo-obj"), ghosts: box.querySelectorAll(".bnc-demo-ghost"), w: 0, h: 0 };
    return demo;
  }
  function demoPos(ct, D) {
    /* returns { x, y } of the object's centre at cycle time ct */
    var v = DIST / MOVE, bounce = state.mode === "bounce";
    var size = D.size, off;
    if (bounce) {
      var floor = D.h - 6 - size / 2, top = size / 2 + 4, drop = floor - top;
      var k = drop / DIST;
      if (ct < MOVE) return { x: D.w / 2, y: top + (ct / MOVE) * drop };
      off = bounceOffset(state.p, ct - MOVE, v);           /* < 0: above the floor */
      /* the first bounce rises to 3/4 of the drop; the later ones keep
         their true proportion to it (in real pixels they are a few px) */
      var e1 = v * state.p.elast, h1 = e1 * e1 / (2 * state.p.grav) || 1;
      var up = Math.min(drop, (-off / h1) * drop * 0.75);
      return { x: D.w / 2, y: floor - Math.max(0, up) };
    }
    var x0 = size / 2 + 6, xKey = D.w * 0.68, kx = (xKey - x0) / DIST;
    if (ct < MOVE) return { x: x0 + (ct / MOVE) * (xKey - x0), y: D.h / 2 };
    off = bounceOffset(state.p, ct - MOVE, v);
    var room = D.w - size / 2 - 4 - xKey, back = xKey - x0;
    var dx = off * kx;
    dx = dx > 0 ? Math.tanh(dx / room) * room : -Math.tanh(-dx / back) * back;
    return { x: xKey + dx, y: D.h / 2 };
  }
  function drawDemo(ct) {
    var D = demoEls();
    if (!D) return;
    if (!D.w || D.box.clientWidth !== D.w) {
      D.w = D.box.clientWidth; D.h = D.box.clientHeight || 64;
      D.box.classList.toggle("is-bounce", state.mode === "bounce");
    }
    if (D.mode !== state.mode) { D.mode = state.mode; D.box.classList.toggle("is-bounce", state.mode === "bounce"); }
    D.size = state.mode === "bounce" ? 20 : 22;
    if (!D.w) return;
    var bounce = state.mode === "bounce";
    var P = demoPos(ct, D), Pb = demoPos(Math.max(0, ct - 1 / 120), D);
    var vx = (P.x - Pb.x) * 120, vy = (P.y - Pb.y) * 120, sp = Math.sqrt(vx * vx + vy * vy);
    /* stretch along the motion, up to 22% */
    var st = 1 + 0.22 * Math.tanh(sp / 1400);
    var sx = bounce ? 1 / st : st, sy = bounce ? st : 1 / st;
    if (bounce) {
      /* squash on landing: close to the floor and turning round */
      var floor = D.h - 6 - D.size / 2, near = floor - P.y;
      /* only at an impact: still bouncing and arriving fast, not at rest */
      if (ct > MOVE - 0.02 && ct < MOVE + state.graph.span && near < 3 && sp > 120) {
        var q = (1 - near / 3) * Math.min(1, sp / 600); sx = 1 + 0.32 * q; sy = 1 - 0.28 * q;
      }
    }
    var fade = ct > MOVE + state.graph.span + HOLD * 0.55 ? Math.max(0, 1 - (ct - MOVE - state.graph.span - HOLD * 0.55) / (HOLD * 0.45)) : Math.min(1, ct / 0.08);
    var o = D.obj;
    o.style.transform = "translate(" + (P.x - D.size / 2).toFixed(1) + "px," + (P.y - D.size / 2).toFixed(1) + "px) scale(" + sx.toFixed(3) + "," + sy.toFixed(3) + ")";
    o.style.opacity = fade.toFixed(3);
    for (var i = 0; i < D.ghosts.length; i++) {
      var Gp = demoPos(Math.max(0, ct - (i + 1) * 0.028), D), gh = D.ghosts[i];
      gh.style.transform = "translate(" + (Gp.x - D.size / 2).toFixed(1) + "px," + (Gp.y - D.size / 2).toFixed(1) + "px)";
      gh.style.opacity = (fade * Math.min(1, sp / 900) * (0.22 - i * 0.06)).toFixed(3);
    }
  }

  /* asleep while nobody looks at the panel (js/presence.js) */
  function wakeLoop() { if (state.active && !state.raf) state.raf = requestAnimationFrame(tick); }
  function tick(now) {
    state.raf = null;
    if (!state.active) return;
    if (window.PillowPresence && !window.PillowPresence.awake()) { window.PillowPresence.onWake(wakeLoop); return; }
    if (!state.t0) state.t0 = now;

    var g = state.graph;
    if (!g || !g.W) { drawGraph(); g = state.graph; }
    if (g) {
      /* one cycle: the arriving move (MOVE s), the bounce after the key,
         a rest; the demo object and the dot on the curve share it */
      var cycle = MOVE + g.span + HOLD;
      var ct = ((now - state.t0) / 1000) % cycle;
      var t = Math.max(0, Math.min(ct - MOVE, g.span));
      drawDemo(ct);
      var pt = graphPoint(g, t);
      var dot = el("bnc-g-dot"), glow = el("bnc-g-glow"), head = el("bnc-g-head");
      dot.setAttribute("cx", pt[0].toFixed(1)); dot.setAttribute("cy", pt[1].toFixed(1));
      glow.setAttribute("cx", pt[0].toFixed(1)); glow.setAttribute("cy", pt[1].toFixed(1));
      head.setAttribute("x1", pt[0].toFixed(1)); head.setAttribute("x2", pt[0].toFixed(1));
      head.setAttribute("y1", GRAPH_PAD_Y / 2); head.setAttribute("y2", g.H - GRAPH_PAD_Y / 2);
    }

    // preset sparkline dots: only the hovered / active card animates
    var live = state.hover || (state.preset === "custom" ? null : state.preset);
    /* the cards are found once, and a dot is written only when it
       changes: every card's dot set to opacity 0 again on every frame
       was ~800 DOM writes a second for nothing */
    var cards = state.miniCards;
    if (!cards || !cards.length || !cards[0].isConnected) cards = state.miniCards = document.querySelectorAll("[data-bnc-preset]");
    for (var c = 0; c < cards.length; c++) {
      var card = cards[c];
      var dot = card._miniDot || (card._miniDot = card.querySelector(".bnc-mini-dot"));
      if (!dot) continue;
      var id = card.getAttribute("data-bnc-preset");
      if (id !== live) { if (dot._op !== "0") { dot._op = "0"; dot.setAttribute("opacity", "0"); } continue; }
      var pr = preset(id);
      var m = card._mini || (card._mini = miniPath(pr));
      var mt = ((now - state.t0) / 1000) % (m.span + 0.35);
      if (mt > m.span) { if (dot._op !== "0") { dot._op = "0"; dot.setAttribute("opacity", "0"); } }
      else {
        var y = m.sign * bounceOffset(pr.p, mt, DIST / MOVE, m.mode);
        if (dot._op !== "1") { dot._op = "1"; dot.setAttribute("opacity", "1"); }
        dot.setAttribute("cx", (1 + (mt / m.span) * 60).toFixed(1));
        dot.setAttribute("cy", (11 - (y / m.peak) * 8.5).toFixed(1));
      }
    }

    state.raf = requestAnimationFrame(tick);
  }

  function startLoop() {
    if (state.raf) return;
    drawGraph();
    var svg = el("bnc-graph");
    if (svg && !svg._ro && window.ResizeObserver) {
      svg._ro = new ResizeObserver(function () { drawGraph(); });
      svg._ro.observe(svg);
    }
    state.raf = requestAnimationFrame(tick);
  }

  function stopLoop() {
    if (state.raf) cancelAnimationFrame(state.raf);
    state.raf = null;
  }

  /* ─── Host communication ───────────────────────────────────── */

  function setStatus(text, kind) {
    var n = el("bnc-target");
    if (!n) return;
    n.textContent = text;
    n.className = "bnc-target" + (kind ? " " + kind : "");
  }

  function inspect(quiet) {
    if (typeof host !== "function") { setStatus("Not connected to After Effects", "warn"); return; }
    host("pillowBounceInspect()", function (r) {
      if (!r || !r.ok) {
        state.targets = null;
        var msg = (r && r.error) || "Select an animated property";
        if (/CSInterface|not running/i.test(msg)) msg = "Open the panel in After Effects to apply";
        setStatus(msg, "warn");
        return;
      }
      state.targets = r.targets || [];
      if (!state.targets.length) {
        setStatus("Select an animated property in the Timeline", "warn");
        return;
      }
      var t = state.targets[0];
      var extra = state.targets.length > 1 ? " +" + (state.targets.length - 1) + " more" : "";
      var keys = t.keys + (t.keys === 1 ? " key" : " keys");
      if (t.keys < 2) setStatus(t.layer + " \u00b7 " + t.name + " \u00b7 " + keys, "warn");
      else setStatus(t.layer + " \u00b7 " + t.name + " \u00b7 " + keys + extra, t.pillow ? "on" : "");
      if (!quiet && t.keys < 2) toast("Two keyframes required", true);
    });
  }

  function showConflict(names) {
    state.conflict = names;
    var box = el("bnc-conflict");
    var txt = el("bnc-conflict-text");
    if (txt) {
      txt.textContent =
        names.length === 1
          ? names[0] + " already has an expression."
          : names.length + " properties already have expressions.";
    }
    if (box) box.className = "bnc-conflict";
  }

  function hideConflict() {
    state.conflict = null;
    var box = el("bnc-conflict");
    if (box) box.className = "bnc-conflict hidden";
  }

  function apply(force) {
    if (typeof host !== "function") { toast("Not running inside After Effects", true); return; }
    var payload = {
      preset: state.preset,
      label: currentLabel(),
      mode: state.mode,
      params: sliderParams(),
      expression: buildExpression(state.p, currentLabel()),
      force: !!force
    };
    var btn = el("btn-bnc-apply");
    if (btn) btn.classList.add("busy");
    host('pillowBounceApply("' + esc(JSON.stringify(payload)) + '")', function (r) {
      if (btn) btn.classList.remove("busy");
      if (r && r.conflict) { showConflict(r.conflict); return; }
      hideConflict();
      if (!r || !r.ok) {
        toast((r && r.error) || "Could not apply bounce", true);
        inspect(true);
        return;
      }
      if (window.toast) {
        toast(
          currentLabel() + " bounce on " + r.count + (r.count === 1 ? " property" : " properties") +
          " \u00b7 no keyframes added"
        );
      }
      inspect(true);
    });
  }

  function remove() {
    if (typeof host !== "function") { toast("Not running inside After Effects", true); return; }
    host("pillowBounceRemove()", function (r) {
      hideConflict();
      if (!r || !r.ok) {
        toast((r && r.error) || "Nothing to remove", true);
        return;
      }
      if (window.toast) {
        toast(
          r.count ? "Bounce removed from " + r.count + (r.count === 1 ? " property" : " properties")
                  : "No Pillow bounce found"
        );
      }
      inspect(true);
    });
  }

  /* ─── Persistence ──────────────────────────────────────────── */

  function save() {
    try {
      localStorage.setItem("pillow.bounce2", JSON.stringify({ mode: state.mode, preset: state.preset, p: state.p }));
    } catch (e) {}
  }

  function load() {
    try {
      var raw = localStorage.getItem("pillow.bounce2");
      if (raw) {
        var d = JSON.parse(raw);
        if (d && d.p && MODES[d.mode]) {
          setModeVars(d.mode);
          state.p = clone(MODES[d.mode].presets[1].p);
          for (var k in d.p) if (state.p.hasOwnProperty(k) && typeof d.p[k] === "number") state.p[k] = d.p[k];
          state.preset = d.preset || "custom";
          return;
        }
      }
    } catch (e) {}
    setModeVars("overshoot");
    state.preset = "smooth";
    state.p = clone(preset("smooth").p);
  }

  /* ─── Binding ──────────────────────────────────────────────── */

  /* Liquid Glass включают/выключают в настройках — ряд пресетов
     перестраивается: док ↔ карточки. */
  var modeWatched = false;
  function watchGlassMode() {
    if (modeWatched || !window.MutationObserver) return;
    modeWatched = true;
    new MutationObserver(function () {
      if (glassOn() === !!dock) return;
      renderPresets();
    }).observe(document.documentElement, { attributes: true, attributeFilter: ["data-pl-glass"] });
  }

  function bind() {
    var presets = el("bnc-presets");
    if (presets && !presets._bound) {
      presets._bound = true;
      /* карточки (без стекла) — по клику; в GlassDock выбор (нажатие,
         перетаскивание пилюли, клавиатура) делает сам док → setPreset */
      presets.addEventListener("click", function (ev) {
        if (dock) return;
        var b = ev.target.closest ? ev.target.closest("[data-bnc-preset]") : null;
        if (b) setPreset(b.getAttribute("data-bnc-preset"));
      });
      presets.addEventListener("mouseover", function (ev) {
        var b = ev.target.closest ? ev.target.closest("[data-bnc-preset]") : null;
        state.hover = b ? b.getAttribute("data-bnc-preset") : null;
      });
      presets.addEventListener("mouseleave", function () { state.hover = null; });
    }

    var ms = el("bnc-mode");
    if (ms && !ms._bound) {
      ms._bound = true;
      ms.addEventListener("click", function (ev) {
        var b = ev.target.closest ? ev.target.closest("[data-mode]") : null;
        if (b) setMode(b.getAttribute("data-mode"));
      });
    }
    paintModeSwitch();

    watchGlassMode();

    var ctl = el("bnc-controls");
    if (ctl && !ctl._bound) {
      ctl._bound = true;
      ctl.addEventListener("click", function (ev) {
        var b = ev.target.closest ? ev.target.closest("[data-bnc-toggle]") : null;
        if (!b) return;
        var k = b.getAttribute("data-bnc-toggle");
        state.p[k] = state.p[k] ? 0 : 1;
        syncControls();
        markCustom();
        graphRefMode = null;
        drawGraph();
      });
      ctl.addEventListener("input", function (ev) {
        var t = ev.target;
        var key = t.getAttribute("data-bnc-range") || t.getAttribute("data-bnc-num");
        if (!key) return;
        var v = parseFloat(t.value);
        if (isNaN(v)) return;
        for (var i = 0; i < CONTROLS.length; i++) {
          if (CONTROLS[i].key === key) {
            v = Math.max(CONTROLS[i].min, Math.min(CONTROLS[i].max, v));
          }
        }
        state.p[key] = v;
        var other = t.getAttribute("data-bnc-range") ? el("bnc-n-" + key) : el("bnc-r-" + key);
        if (other) other.value = t.getAttribute("data-bnc-range") ? Math.round(v * 100) / 100 : v;
        markCustom();
        drawGraph();   /* the curve follows the slider live; the dot keeps running */
      });
    }

    var apl = el("btn-bnc-apply");
    if (apl && !apl._bound) { apl._bound = true; apl.onclick = function () { apply(false); }; }
    var rmv = el("btn-bnc-remove");
    if (rmv && !rmv._bound) { rmv._bound = true; rmv.onclick = remove; }
    var rfr = el("btn-bnc-refresh");
    if (rfr && !rfr._bound) { rfr._bound = true; rfr.onclick = function () { inspect(false); }; }

    var rep = el("btn-bnc-replace");
    if (rep && !rep._bound) { rep._bound = true; rep.onclick = function () { apply(true); }; }
    var can = el("btn-bnc-cancel");
    if (can && !can._bound) { can._bound = true; can.onclick = hideConflict; }

    var dis = el("bnc-expr");
    if (dis && !dis._bound) {
      dis._bound = true;
      var head = el("bnc-expr-head");
      if (head) {
        head.onclick = function () {
          dis.classList.toggle("open");
          head.setAttribute("aria-expanded", dis.classList.contains("open") ? "true" : "false");
        };
      }
      var cp = el("btn-bnc-copy");
      if (cp) {
        cp.onclick = function (ev) {
          ev.stopPropagation();
          var code = el("bnc-expr-code");
          if (!code) return;
          try {
            var sel = window.getSelection();
            var range = document.createRange();
            range.selectNodeContents(code);
            sel.removeAllRanges();
            sel.addRange(range);
            document.execCommand("copy");
            sel.removeAllRanges();
            toast("Expression copied");
          } catch (e) {
            toast("Could not copy", true);
          }
        };
      }
    }
  }

  var built = false;

  window.PillowBounce = {
    /* разметка и привязки без запуска превью — для прогрева вкладки */
    prebuild: function () {
      if (built) return;
      built = true;
      load();
      renderPresets();
      renderControls();
      updateExpr();
      bind();
    },
    resume: function () {
      if (!built) {
        built = true;
        load();
        renderPresets();
        renderControls();
        updateExpr();
        bind();
      }
      state.active = true;
      resetPreview();
      startLoop();
      inspect(true);
    },
    pause: function () {
      state.active = false;
      stopLoop();
    },
    apply: function () { apply(false); }
  };
})();
