/* Pillow — Curves / Graph Editor
 * A large easing preset library plus an interactive, editable multi-point
 * bezier graph editor. Relies on globals already defined in panel.js:
 * $, host, toast, esc, escapeHtml, csInterface.
 */
(function () {
  "use strict";

  /* ───────────────────────── math helpers ───────────────────────── */

  function r3(n) {
    return Math.round(n * 1000) / 1000;
  }
  function clamp(n, a, b) {
    return n < a ? a : n > b ? b : n;
  }
  function deepCopyAnchors(anchors) {
    var out = [];
    for (var i = 0; i < anchors.length; i++) {
      var a = anchors[i];
      var c = { x: a.x, y: a.y };
      if (a.hout) c.hout = { x: a.hout.x, y: a.hout.y };
      if (a.hin) c.hin = { x: a.hin.x, y: a.hin.y };
      out.push(c);
    }
    return out;
  }
  function anchorsEqual(a, b) {
    if (!a || !b || a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (Math.abs(a[i].x - b[i].x) > 0.003 || Math.abs(a[i].y - b[i].y) > 0.003) return false;
      var ah = a[i].hout, bh = b[i].hout;
      if (!!ah !== !!bh) return false;
      if (ah && (Math.abs(ah.x - bh.x) > 0.003 || Math.abs(ah.y - bh.y) > 0.003)) return false;
      var ai = a[i].hin, bi = b[i].hin;
      if (!!ai !== !!bi) return false;
      if (ai && (Math.abs(ai.x - bi.x) > 0.003 || Math.abs(ai.y - bi.y) > 0.003)) return false;
    }
    return true;
  }

  function bez1(p0, p1, p2, p3, u) {
    var v = 1 - u;
    return v * v * v * p0 + 3 * v * v * u * p1 + 3 * v * u * u * p2 + u * u * u * p3;
  }

  function segAt(anchors, x) {
    for (var i = 0; i < anchors.length - 1; i++) {
      if (x >= anchors[i].x - 1e-6 && x <= anchors[i + 1].x + 1e-6) return i;
    }
    return anchors.length - 2;
  }

  function solveU(p0x, p1x, p2x, p3x, targetX) {
    var lo = 0, hi = 1, u = 0.5;
    for (var iter = 0; iter < 20; iter++) {
      u = (lo + hi) / 2;
      var x = bez1(p0x, p1x, p2x, p3x, u);
      if (Math.abs(x - targetX) < 0.0004) break;
      if (x < targetX) lo = u;
      else hi = u;
    }
    return u;
  }

  /** Value of the curve (may exceed 0..1 for overshoot/bounce/elastic) at time t (0..1). */
  function curveValueAt(anchors, t) {
    t = clamp(t, 0, 1);
    if (anchors.length < 2) return t;
    if (t <= anchors[0].x) return anchors[0].y;
    if (t >= anchors[anchors.length - 1].x) return anchors[anchors.length - 1].y;
    var i = segAt(anchors, t);
    var a = anchors[i], b = anchors[i + 1];
    var h1 = a.hout || { x: a.x, y: a.y };
    var h2 = b.hin || { x: b.x, y: b.y };
    var u = solveU(a.x, h1.x, h2.x, b.x, t);
    return bez1(a.y, h1.y, h2.y, b.y, u);
  }

  /* ───────────────────── preset-curve construction ───────────────────── */

  function bezierAnchors(x1, y1, x2, y2) {
    return [
      { x: 0, y: 0, hout: { x: x1, y: y1 } },
      { x: 1, y: 1, hin: { x: x2, y: y2 } }
    ];
  }

  /** Smooth finite-difference tangents through a set of anchor points (no handles yet). */
  function autoTangents(pts, tension) {
    tension = tension == null ? 0.24 : tension;
    var n = pts.length;
    var out = [];
    for (var i = 0; i < n; i++) {
      var p = pts[i], mx, my;
      if (i === 0) {
        mx = pts[1].x - p.x;
        my = pts[1].y - p.y;
      } else if (i === n - 1) {
        mx = p.x - pts[i - 1].x;
        my = p.y - pts[i - 1].y;
      } else {
        mx = (pts[i + 1].x - pts[i - 1].x) / 2;
        my = (pts[i + 1].y - pts[i - 1].y) / 2;
      }
      var a = { x: p.x, y: p.y };
      if (i < n - 1) a.hout = { x: r3(p.x + mx * tension), y: r3(p.y + my * tension) };
      if (i > 0) a.hin = { x: r3(p.x - mx * tension), y: r3(p.y - my * tension) };
      out.push(a);
    }
    return out;
  }

  function reflectPts(pts) {
    var out = [];
    for (var i = pts.length - 1; i >= 0; i--) out.push({ x: r3(1 - pts[i].x), y: r3(1 - pts[i].y) });
    return out;
  }
  function scalePts(pts, sx, sy, ox, oy) {
    var out = [];
    for (var i = 0; i < pts.length; i++) out.push({ x: r3(pts[i].x * sx + ox), y: r3(pts[i].y * sy + oy) });
    return out;
  }
  function combineHalves(a, b) {
    return a.slice(0, a.length - 1).concat(b);
  }
  function scaleAmplitude(pts, scale) {
    var out = [];
    for (var i = 0; i < pts.length; i++) out.push({ x: pts[i].x, y: r3(1 - (1 - pts[i].y) * scale) });
    return out;
  }

  /* ───────────────────── generated point sets ───────────────────── */

  var BOUNCE_OUT_PTS = [
    { x: 0, y: 0 }, { x: 0.1, y: 0.34 }, { x: 0.2, y: 1 }, { x: 0.32, y: 0.72 }, { x: 0.48, y: 1 },
    { x: 0.62, y: 0.88 }, { x: 0.78, y: 1 }, { x: 0.9, y: 0.94 }, { x: 1, y: 1 }
  ];
  var BOUNCE_IN_PTS = reflectPts(BOUNCE_OUT_PTS);
  var BOUNCE_INOUT_PTS = combineHalves(
    scalePts(BOUNCE_IN_PTS, 0.5, 0.5, 0, 0),
    scalePts(BOUNCE_OUT_PTS, 0.5, 0.5, 0.5, 0.5)
  );

  var ELASTIC_OUT_PTS = [
    { x: 0, y: 0 }, { x: 0.12, y: 0 }, { x: 0.32, y: 1.2 }, { x: 0.55, y: 0.9 }, { x: 0.75, y: 1.05 }, { x: 1, y: 1 }
  ];
  var ELASTIC_IN_PTS = reflectPts(ELASTIC_OUT_PTS);
  var ELASTIC_INOUT_PTS = combineHalves(
    scalePts(ELASTIC_IN_PTS, 0.5, 0.5, 0, 0),
    scalePts(ELASTIC_OUT_PTS, 0.5, 0.5, 0.5, 0.5)
  );

  var SNAPPY_BOUNCE_PTS = [
    { x: 0, y: 0 }, { x: 0.15, y: 0.4 }, { x: 0.3, y: 1 }, { x: 0.5, y: 0.8 }, { x: 0.72, y: 1 }, { x: 1, y: 1 }
  ];

  function bez(id, name, hint, x1, y1, x2, y2) {
    return { id: id, name: name, hint: hint, anchors: bezierAnchors(x1, y1, x2, y2) };
  }
  function spline(id, name, hint, pts, tension) {
    return { id: id, name: name, hint: hint, anchors: autoTangents(pts, tension) };
  }

  var CURVE_LIBRARY = [
    { category: "Standard", items: [
      bez("linear", "Linear", "Constant rate, no ease", 0.33, 0.33, 0.67, 0.67),
      bez("ease", "Ease", "Default, gentle both ends", 0.25, 0.1, 0.25, 1),
      bez("ease-in", "Ease In", "Slow start", 0.42, 0, 1, 1),
      bez("ease-out", "Ease Out", "Slow finish", 0, 0, 0.58, 1),
      bez("ease-inout", "Ease In Out", "Slow both ends", 0.42, 0, 0.58, 1)
    ]},
    { category: "Power", items: [
      bez("quad-in", "Quad In", "Mild acceleration", 0.55, 0.085, 0.68, 0.53),
      bez("quad-out", "Quad Out", "Mild deceleration", 0.25, 0.46, 0.45, 0.94),
      bez("quad-inout", "Quad In Out", "Mild both ends", 0.455, 0.03, 0.515, 0.955),
      bez("cubic-in", "Cubic In", "Building speed", 0.55, 0.055, 0.675, 0.19),
      bez("cubic-out", "Cubic Out", "Settles smoothly", 0.215, 0.61, 0.355, 1),
      bez("cubic-inout", "Cubic In Out", "Balanced curve", 0.645, 0.045, 0.355, 1),
      bez("quart-in", "Quart In", "Sharp acceleration", 0.895, 0.03, 0.685, 0.22),
      bez("quart-out", "Quart Out", "Sharp deceleration", 0.165, 0.84, 0.44, 1),
      bez("quart-inout", "Quart In Out", "Strong both ends", 0.77, 0, 0.175, 1),
      bez("quint-in", "Quint In", "Very sharp start", 0.755, 0.05, 0.855, 0.06),
      bez("quint-out", "Quint Out", "Very sharp stop", 0.23, 1, 0.32, 1),
      bez("quint-inout", "Quint In Out", "Extreme both ends", 0.86, 0, 0.07, 1)
    ]},
    { category: "Expo", items: [
      bez("expo-in", "Expo In", "Explosive start", 0.95, 0.05, 0.795, 0.035),
      bez("expo-out", "Expo Out", "Explosive stop", 0.19, 1, 0.22, 1),
      bez("expo-inout", "Expo In Out", "Explosive both ends", 1, 0, 0, 1)
    ]},
    { category: "Circ", items: [
      bez("circ-in", "Circ In", "Circular acceleration", 0.6, 0.04, 0.98, 0.335),
      bez("circ-out", "Circ Out", "Circular deceleration", 0.075, 0.82, 0.165, 1),
      bez("circ-inout", "Circ In Out", "Circular both ends", 0.785, 0.135, 0.15, 0.86)
    ]},
    { category: "Back", items: [
      bez("back-in", "Back In", "Pulls back first", 0.36, 0, 0.66, -0.56),
      bez("back-out", "Back Out", "Overshoots the mark", 0.34, 1.56, 0.64, 1),
      bez("back-inout", "Back In Out", "Wind-up and overshoot", 0.68, -0.6, 0.32, 1.6)
    ]},
    { category: "Sine", items: [
      bez("sine-in", "Sine In", "Soft, natural start", 0.12, 0, 0.39, 0),
      bez("sine-out", "Sine Out", "Soft, natural stop", 0.61, 1, 0.88, 1),
      bez("sine-inout", "Sine In Out", "Gentle glide", 0.37, 0, 0.63, 1)
    ]},
    { category: "Elastic", items: [
      spline("elastic-in", "Elastic In", "Wind-up, then snap", ELASTIC_IN_PTS, 0.14),
      spline("elastic-out", "Elastic Out", "Spring past, then rest", ELASTIC_OUT_PTS, 0.14),
      spline("elastic-inout", "Elastic In Out", "Spring on both ends", ELASTIC_INOUT_PTS, 0.14)
    ]},
    { category: "Bounce", items: [
      spline("bounce-in", "Bounce In", "Builds into impact", BOUNCE_IN_PTS, 0.05),
      spline("bounce-out", "Bounce Out", "Classic ball drop", BOUNCE_OUT_PTS, 0.05),
      spline("bounce-inout", "Bounce In Out", "Bounces both ends", BOUNCE_INOUT_PTS, 0.05),
      spline("soft-bounce", "Soft Bounce", "Soft landing", scaleAmplitude(BOUNCE_OUT_PTS, 0.5), 0.05),
      spline("snappy-bounce", "Snappy Bounce", "Tight, editorial pop", SNAPPY_BOUNCE_PTS, 0.06),
      spline("heavy-bounce", "Heavy Bounce", "Mass, squash, settle", scaleAmplitude(BOUNCE_OUT_PTS, 1.4), 0.05),
      spline("elastic-bounce", "Elastic Bounce", "Long spring decay", scaleAmplitude(ELASTIC_OUT_PTS, 1.1), 0.14),
      spline("micro-bounce", "Micro Bounce", "Almost a settle", scaleAmplitude(BOUNCE_OUT_PTS, 0.15), 0.05)
    ]},
    { category: "Editorial", items: [
      bez("smooth", "Smooth Ease", "Even, unhurried settle", 0.4, 0, 0.2, 1),
      bez("fast-in", "Fast In", "Arrives with weight", 0.55, 0, 1, 0.45),
      bez("fast-out", "Fast Out", "Leaves quickly, lands soft", 0, 0.55, 0.45, 1),
      bez("snappy", "Snappy", "Short, decisive, no lag", 0.9, 0, 0.1, 1),
      bez("overshoot", "Overshoot", "One elegant pass of the mark", 0.34, 1.4, 0.64, 1),
      bez("cinematic", "Cinematic", "Slow open, slower close", 0.65, 0, 0.35, 1)
    ]}
  ];

  function findItem(id) {
    for (var c = 0; c < CURVE_LIBRARY.length; c++) {
      for (var i = 0; i < CURVE_LIBRARY[c].items.length; i++) {
        if (CURVE_LIBRARY[c].items[i].id === id) return CURVE_LIBRARY[c].items[i];
      }
    }
    return null;
  }

  /* ───────────────────────── editor state ───────────────────────── */

  /* Ширина viewBox подстраивается под пропорции области (fitViewBox):
     260…340 при высоте 200. Шире 1.7:1 график не растягивается — SVG
     в режиме meet, по бокам остаются ровные поля; точки остаются
     круглыми, а не овалами. */
  var VB_W = 260, VB_H = 200, PAD = 18;
  var VB_W_MIN = 260, VB_W_MAX = 340;
  var Y_MIN = -0.55, Y_MAX = 1.55;

  var state = {
    anchors: [],
    original: [],
    presetId: null,
    presetName: "Ease",
    history: [],
    historyIndex: -1,
    drag: null,
    filter: "",
    favsOnly: false,
    active: false
  };

  var cachedTrackW = 0;
  var applyDebounceT = null;

  function mapX(x) {
    return PAD + x * (VB_W - PAD * 2);
  }
  function mapY(y) {
    return PAD + (1 - (y - Y_MIN) / (Y_MAX - Y_MIN)) * (VB_H - PAD * 2);
  }
  function unmapX(px) {
    return clamp((px - PAD) / (VB_W - PAD * 2), 0, 1);
  }
  function unmapY(py) {
    return Y_MIN + (1 - (py - PAD) / (VB_H - PAD * 2)) * (Y_MAX - Y_MIN);
  }

  function pushHistory() {
    state.history = state.history.slice(0, state.historyIndex + 1);
    state.history.push(deepCopyAnchors(state.anchors));
    if (state.history.length > 40) state.history.shift();
    state.historyIndex = state.history.length - 1;
    updateUndoRedoButtons();
  }
  function resetHistory() {
    state.history = [deepCopyAnchors(state.anchors)];
    state.historyIndex = 0;
    updateUndoRedoButtons();
  }
  function undo() {
    if (state.historyIndex <= 0) return;
    state.historyIndex--;
    state.anchors = deepCopyAnchors(state.history[state.historyIndex]);
    finalizeCustomState();
    renderGraph();
    restartMotionPreview();
    updateUndoRedoButtons();
  }
  function redo() {
    if (state.historyIndex >= state.history.length - 1) return;
    state.historyIndex++;
    state.anchors = deepCopyAnchors(state.history[state.historyIndex]);
    finalizeCustomState();
    renderGraph();
    restartMotionPreview();
    updateUndoRedoButtons();
  }
  function updateUndoRedoButtons() {
    var u = $("btn-curve-undo"), rd = $("btn-curve-redo");
    if (u) u.disabled = state.historyIndex <= 0;
    if (rd) rd.disabled = state.historyIndex >= state.history.length - 1;
  }

  /* ───────────────────────── SVG rendering ───────────────────────── */

  var SVG_NS = "http://www.w3.org/2000/svg";
  function svgEl(tag, attrs) {
    var el = document.createElementNS(SVG_NS, tag);
    for (var k in attrs) el.setAttribute(k, attrs[k]);
    return el;
  }

  function pathD(anchors) {
    var d = "M " + mapX(anchors[0].x) + " " + mapY(anchors[0].y);
    for (var i = 0; i < anchors.length - 1; i++) {
      var a = anchors[i], b = anchors[i + 1];
      var h1 = a.hout || { x: a.x, y: a.y };
      var h2 = b.hin || { x: b.x, y: b.y };
      d += " C " + mapX(h1.x) + " " + mapY(h1.y) + ", " + mapX(h2.x) + " " + mapY(h2.y) + ", " + mapX(b.x) + " " + mapY(b.y);
    }
    return d;
  }

  var graphCache = null;

  function buildGraph() {
    var svg = $("graph-svg");
    if (!svg) return;
    while (svg.firstChild) svg.removeChild(svg.firstChild);

    svg.appendChild(svgEl("line", { class: "ge-baseline", x1: mapX(0), y1: mapY(0), x2: mapX(1), y2: mapY(0) }));
    svg.appendChild(svgEl("line", { class: "ge-baseline", x1: mapX(0), y1: mapY(1), x2: mapX(1), y2: mapY(1) }));
    svg.appendChild(svgEl("line", { class: "ge-grid-line", x1: mapX(0), y1: PAD, x2: mapX(0), y2: VB_H - PAD }));
    svg.appendChild(svgEl("line", { class: "ge-grid-line", x1: mapX(1), y1: PAD, x2: mapX(1), y2: VB_H - PAD }));

    var hit = svgEl("path", { class: "ge-hitzone", d: pathD(state.anchors), stroke: "transparent", "stroke-width": 18, fill: "none" });
    hit.addEventListener("dblclick", onCurveDblClick);
    svg.appendChild(hit);
    var pathEl = svgEl("path", { class: "ge-curve-path", d: pathD(state.anchors) });
    svg.appendChild(pathEl);

    var handleLineEls = [];
    for (var i = 0; i < state.anchors.length; i++) {
      var a = state.anchors[i];
      if (a.hout) {
        var l1 = svgEl("line", { class: "ge-handle-line", x1: mapX(a.x), y1: mapY(a.y), x2: mapX(a.hout.x), y2: mapY(a.hout.y) });
        svg.appendChild(l1);
        handleLineEls.push({ el: l1, index: i, which: "hout" });
      }
      if (a.hin) {
        var l2 = svgEl("line", { class: "ge-handle-line", x1: mapX(a.x), y1: mapY(a.y), x2: mapX(a.hin.x), y2: mapY(a.hin.y) });
        svg.appendChild(l2);
        handleLineEls.push({ el: l2, index: i, which: "hin" });
      }
    }
    var handleEls = [];
    for (var j = 0; j < state.anchors.length; j++) {
      var an = state.anchors[j];
      if (an.hout) {
        var hEl = makeHandleCircle(j, "hout", an.hout);
        svg.appendChild(hEl);
        handleEls.push({ el: hEl, index: j, which: "hout" });
      }
      if (an.hin) {
        var hEl2 = makeHandleCircle(j, "hin", an.hin);
        svg.appendChild(hEl2);
        handleEls.push({ el: hEl2, index: j, which: "hin" });
      }
    }
    var anchorEls = [];
    for (var k = 0; k < state.anchors.length; k++) {
      var aEl = makeAnchorCircle(k, state.anchors[k]);
      svg.appendChild(aEl);
      anchorEls.push({ el: aEl, index: k });
    }

    graphCache = { pathEl: pathEl, hitEl: hit, handleLineEls: handleLineEls, handleEls: handleEls, anchorEls: anchorEls };
  }

  /** Lightweight update used while dragging: only touches attributes on
   *  already-existing cached nodes, no DOM removal/creation, no new
   *  listeners. Anchor count never changes mid-drag, so the cache stays
   *  valid for the whole gesture. */
  function updateGraphFast() {
    if (!graphCache) { buildGraph(); return; }
    var d = pathD(state.anchors);
    graphCache.pathEl.setAttribute("d", d);
    graphCache.hitEl.setAttribute("d", d);
    for (var i = 0; i < graphCache.handleLineEls.length; i++) {
      var hl = graphCache.handleLineEls[i];
      var a = state.anchors[hl.index];
      var h = hl.which === "hout" ? a.hout : a.hin;
      if (!h) continue;
      hl.el.setAttribute("x1", mapX(a.x));
      hl.el.setAttribute("y1", mapY(a.y));
      hl.el.setAttribute("x2", mapX(h.x));
      hl.el.setAttribute("y2", mapY(h.y));
    }
    for (var j = 0; j < graphCache.handleEls.length; j++) {
      var he = graphCache.handleEls[j];
      var a2 = state.anchors[he.index];
      var h2 = he.which === "hout" ? a2.hout : a2.hin;
      if (!h2) continue;
      he.el.setAttribute("cx", mapX(h2.x));
      he.el.setAttribute("cy", mapY(h2.y));
    }
    for (var k = 0; k < graphCache.anchorEls.length; k++) {
      var ae = graphCache.anchorEls[k];
      var a3 = state.anchors[ae.index];
      ae.el.setAttribute("cx", mapX(a3.x));
      ae.el.setAttribute("cy", mapY(a3.y));
    }
  }

  /** Full rebuild — anchor count/structure may have changed (preset switch,
   *  add/remove point, undo/redo, reset). Kept under the original name so
   *  every existing call site keeps working unchanged. */
  function renderGraph() {
    fitViewBox(false);
    buildGraph();
  }

  function fitViewBox(rebuild) {
    var svg = $("graph-svg");
    if (!svg) return;
    var r = svg.getBoundingClientRect();
    if (!r.width || !r.height) return;
    var w = Math.round(clamp(VB_H * r.width / r.height, VB_W_MIN, VB_W_MAX));
    if (w === VB_W && svg.getAttribute("viewBox") === "0 0 " + w + " " + VB_H) return;
    VB_W = w;
    svg.setAttribute("viewBox", "0 0 " + w + " " + VB_H);
    if (rebuild && !state.drag) buildGraph();
  }

  function makeAnchorCircle(index, a) {
    var fixed = index === 0 || index === state.anchors.length - 1;
    var c = svgEl("circle", {
      class: "ge-anchor" + (fixed ? " fixed" : ""),
      cx: mapX(a.x), cy: mapY(a.y), r: fixed ? 4 : 6
    });
    if (!fixed) {
      c.addEventListener("pointerdown", function (ev) {
        startDrag(ev, { type: "anchor", index: index });
      });
      c.addEventListener("dblclick", function (ev) {
        ev.stopPropagation();
        removeAnchor(index);
      });
      c.addEventListener("contextmenu", function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        removeAnchor(index);
      });
    }
    return c;
  }
  function makeHandleCircle(index, which, h) {
    /* a bigger dot, and an invisible ring around it you can grab: no
       need to aim at the dot itself (css: .ge-handle stroke) */
    var c = svgEl("circle", { class: "ge-handle", cx: mapX(h.x), cy: mapY(h.y), r: 5.5 });
    c.addEventListener("pointerdown", function (ev) {
      startDrag(ev, { type: "handle", index: index, which: which });
    });
    return c;
  }

  /* ───────────────────────── drag interaction ───────────────────────── */

  function svgPoint(svg, ev) {
    /* через матрицу SVG: учитывает поля по бокам (preserveAspectRatio meet) */
    var m = svg.getScreenCTM && svg.getScreenCTM();
    if (m && svg.createSVGPoint) {
      var pt = svg.createSVGPoint();
      pt.x = ev.clientX; pt.y = ev.clientY;
      var p = pt.matrixTransform(m.inverse());
      return { x: unmapX(p.x), y: unmapY(p.y) };
    }
    var r = svg.getBoundingClientRect();
    var px = ((ev.clientX - r.left) / r.width) * VB_W;
    var py = ((ev.clientY - r.top) / r.height) * VB_H;
    return { x: unmapX(px), y: unmapY(py) };
  }

  function startDrag(ev, info) {
    if (!state.active) return;
    ev.preventDefault();
    ev.stopPropagation();
    state.drag = info;
    var svg = $("graph-svg");
    try { svg.setPointerCapture(ev.pointerId); } catch (e) {}
    svg.addEventListener("pointermove", onDragMove);
    svg.addEventListener("pointerup", onDragEnd);
    svg.addEventListener("pointercancel", onDragEnd);
  }

  var dragRAF = null;
  var pendingPointerEv = null;

  function onDragMove(ev) {
    if (!state.drag) return;
    pendingPointerEv = ev;
    if (dragRAF) return;
    dragRAF = requestAnimationFrame(applyDragFrame);
  }

  function applyDragFrame() {
    dragRAF = null;
    if (!state.drag || !pendingPointerEv) return;
    var svg = $("graph-svg");
    var p = svgPoint(svg, pendingPointerEv);
    var d = state.drag;
    if (d.type === "anchor") {
      var idx = d.index;
      var minX = state.anchors[idx - 1].x + 0.02;
      var maxX = state.anchors[idx + 1].x - 0.02;
      state.anchors[idx].x = r3(clamp(p.x, minX, maxX));
      state.anchors[idx].y = r3(clamp(p.y, Y_MIN + 0.05, Y_MAX - 0.05));
    } else if (d.type === "handle") {
      var a = state.anchors[d.index];
      var target = d.which === "hout" ? a.hout : a.hin;
      target.x = r3(clamp(p.x, -0.4, 1.4));
      target.y = r3(clamp(p.y, Y_MIN + 0.03, Y_MAX - 0.03));
    }
    updateGraphFast();
  }

  function onDragEnd() {
    var svg = $("graph-svg");
    svg.removeEventListener("pointermove", onDragMove);
    svg.removeEventListener("pointerup", onDragEnd);
    svg.removeEventListener("pointercancel", onDragEnd);
    if (dragRAF) { cancelAnimationFrame(dragRAF); dragRAF = null; }
    pendingPointerEv = null;
    state.drag = null;
    pushHistory();
    finalizeCustomState();
  }

  function onCurveDblClick(ev) {
    var svg = $("graph-svg");
    var p = svgPoint(svg, ev);
    addAnchorAt(clamp(p.x, 0.03, 0.97));
  }

  function addAnchorAt(x) {
    var idx = 0;
    while (idx < state.anchors.length - 1 && state.anchors[idx + 1].x < x) idx++;
    if (Math.abs(state.anchors[idx].x - x) < 0.03 || Math.abs(state.anchors[idx + 1].x - x) < 0.03) return;
    var y = curveValueAt(state.anchors, x);
    var raw = [];
    for (var i = 0; i < state.anchors.length; i++) raw.push({ x: state.anchors[i].x, y: state.anchors[i].y });
    raw.splice(idx + 1, 0, { x: r3(x), y: r3(y) });
    state.anchors = autoTangents(raw, 0.22);
    renderGraph();
    pushHistory();
    finalizeCustomState();
  }

  function removeAnchor(index) {
    if (index === 0 || index === state.anchors.length - 1) return;
    if (state.anchors.length <= 2) return;
    var raw = [];
    for (var i = 0; i < state.anchors.length; i++) {
      if (i === index) continue;
      raw.push({ x: state.anchors[i].x, y: state.anchors[i].y, hout: state.anchors[i].hout, hin: state.anchors[i].hin });
    }
    state.anchors = raw;
    renderGraph();
    pushHistory();
    finalizeCustomState();
  }

  /* ───────────────────────── preset selection / naming ───────────────────────── */

  function setGraphName(name) {
    var el = $("graph-name");
    if (el) el.textContent = name;
  }
  function clearActivePresetRow() {
    var rows = document.querySelectorAll(".curve-preset-row.active");
    for (var i = 0; i < rows.length; i++) rows[i].className = rows[i].className.replace(/\s*active/g, "");
  }
  function finalizeCustomState() {
    if (anchorsEqual(state.anchors, state.original)) {
      setGraphName(state.presetName);
      if (state.presetId) {
        var rows = document.querySelectorAll(".curve-preset-row[data-curve-id='" + state.presetId + "']");
        if (rows[0]) {
          clearActivePresetRow();
          rows[0].className += " active";
        }
      }
    } else {
      setGraphName("Custom");
      clearActivePresetRow();
    }
  }

  function selectPreset(item, rowEl) {
    state.anchors = deepCopyAnchors(item.anchors);
    state.original = deepCopyAnchors(item.anchors);
    state.presetId = item.id;
    state.presetName = item.name;
    setGraphName(item.name);
    clearActivePresetRow();
    if (rowEl) rowEl.className += " active";
    resetHistory();
    renderGraph();
    restartMotionPreview();
    if (typeof syncCurveFavBtn === "function") syncCurveFavBtn();
  }

  function createCustom() {
    var base = autoTangents([{ x: 0, y: 0 }, { x: 1, y: 1 }], 0.33);
    state.anchors = base;
    state.original = deepCopyAnchors(base);
    state.presetId = null;
    state.presetName = "Custom";
    setGraphName("Custom");
    clearActivePresetRow();
    resetHistory();
    renderGraph();
    restartMotionPreview();
  }

  function resetCurve() {
    state.anchors = deepCopyAnchors(state.original);
    setGraphName(state.presetName);
    if (state.presetId) {
      var rows = document.querySelectorAll(".curve-preset-row[data-curve-id='" + state.presetId + "']");
      clearActivePresetRow();
      if (rows[0]) rows[0].className += " active";
    }
    resetHistory();
    renderGraph();
    restartMotionPreview();
  }

  /* ───────────────────────── preset browser (left list) ───────────────────────── */

  function buildThumbSvg(anchors) {
    var w = 40, h = 24, pad = 3;
    var lo = -0.35, hi = 1.35;
    function tx(x) { return pad + x * (w - pad * 2); }
    function ty(y) { return pad + (1 - (y - lo) / (hi - lo)) * (h - pad * 2); }
    var d = "M " + tx(anchors[0].x) + " " + ty(anchors[0].y);
    for (var i = 0; i < anchors.length - 1; i++) {
      var a = anchors[i], b = anchors[i + 1];
      var h1 = a.hout || { x: a.x, y: a.y };
      var h2 = b.hin || { x: b.x, y: b.y };
      d += " C " + tx(h1.x) + " " + ty(h1.y) + ", " + tx(h2.x) + " " + ty(h2.y) + ", " + tx(b.x) + " " + ty(b.y);
    }
    return '<svg viewBox="0 0 ' + w + " " + h + '"><path d="' + d + '" stroke="#c8c8c8" stroke-width="1.6" fill="none" stroke-linecap="round"/></svg>';
  }

  /* Список строится один раз вместе с заголовками категорий; поиск и
     «только избранное» только показывают/прячут строки и заголовки с
     анимацией (js/list-fx.js) — без пересборки innerHTML. */
  function buildPresetBrowser(box) {
    var html = "";
    for (var c = 0; c < CURVE_LIBRARY.length; c++) {
      var group = CURVE_LIBRARY[c];
      html += '<div class="curve-category-label" data-curve-group="' + c + '">' + escapeHtml(group.category) +
        "<span>" + group.items.length + "</span></div>";
      for (var i = 0; i < group.items.length; i++) {
        var it = group.items[i];
        var favOn = window.PillowFav && window.PillowFav.is(window.PillowFav.CURVES, it.id);
        html +=
          '<button type="button" class="curve-preset-row' + (it.id === state.presetId ? " active" : "") + '" data-curve-id="' + it.id + '" data-curve-group="' + c + '">' +
          '<span class="thumb">' + buildThumbSvg(it.anchors) + "</span>" +
          '<span class="info"><span class="name">' + escapeHtml(it.name) + '</span><span class="hint">' + escapeHtml(it.hint) + "</span></span>" +
          '<span class="fav-star' + (favOn ? " on" : "") + '" data-fav="' + it.id + '" title="Favorite">' + (favOn ? "★" : "☆") + "</span>" +
          "</button>";
      }
    }
    html += '<div class="curve-browser-empty" style="display:none;text-align:center;color:var(--muted);font-size:11px;padding:16px">No presets match</div>';
    box.innerHTML = html;
    box._built = true;
    box.onclick = function (ev) {
      var fav = ev.target.closest ? ev.target.closest("[data-fav]") : null;
      if (fav && window.PillowFav) {
        ev.preventDefault();
        ev.stopPropagation();
        var fid = fav.getAttribute("data-fav");
        var on = window.PillowFav.toggle(window.PillowFav.CURVES, fid);
        fav.className = "fav-star" + (on ? " on" : "");
        fav.textContent = on ? "★" : "☆";
        if (state.favsOnly) renderPresetBrowser();
        syncCurveFavBtn();
        return;
      }
      var row = ev.target.closest ? ev.target.closest(".curve-preset-row") : null;
      if (!row) return;
      var id = row.getAttribute("data-curve-id");
      var item = findItem(id);
      if (item) selectPreset(item, row);
    };
    if (window.pillowRescanTactile) window.pillowRescanTactile();
  }

  function renderPresetBrowser(animate) {
    var box = $("preset-browser");
    if (!box) return;
    var first = !box._built;
    if (first) buildPresetBrowser(box);
    var q = (state.filter || "").toLowerCase();
    var nodes = box.querySelectorAll(".curve-category-label, .curve-preset-row");
    var show = [], perGroup = {}, total = 0, i, n, g;
    /* строки */
    for (i = 0; i < nodes.length; i++) {
      n = nodes[i];
      if (!n.classList.contains("curve-preset-row")) continue;
      var it = findItem(n.getAttribute("data-curve-id"));
      g = n.getAttribute("data-curve-group");
      var favOn = !!(window.PillowFav && it && window.PillowFav.is(window.PillowFav.CURVES, it.id));
      /* звезда могла смениться кнопкой избранного над графиком */
      var star = n.querySelector(".fav-star");
      if (star && star.classList.contains("on") !== favOn) {
        star.className = "fav-star" + (favOn ? " on" : "");
        star.textContent = favOn ? "★" : "☆";
      }
      var ok = !!it && !(state.favsOnly && !favOn) &&
        !(q && (it.name + " " + it.hint + " " + CURVE_LIBRARY[+g].category).toLowerCase().indexOf(q) < 0);
      show[i] = ok;
      if (ok) { perGroup[g] = (perGroup[g] || 0) + 1; total++; }
    }
    /* заголовки категорий: видны, если в группе что-то осталось */
    var firstLabel = true;
    for (i = 0; i < nodes.length; i++) {
      n = nodes[i];
      if (!n.classList.contains("curve-category-label")) continue;
      g = n.getAttribute("data-curve-group");
      show[i] = !!perGroup[g];
      var cnt = n.querySelector("span");
      if (cnt && show[i]) cnt.textContent = perGroup[g];
      /* :first-child больше не работает — прячущиеся остаются в DOM */
      n.style.marginTop = show[i] && firstLabel ? "0" : "";
      if (show[i]) firstLabel = false;
    }
    var empty = box.querySelector(".curve-browser-empty");
    if (empty) empty.style.display = total ? "none" : "";
    if (window.PillowListFx) {
      window.PillowListFx.apply(box, nodes, show, { animate: !first && animate !== false });
    }
  }

  /* ───────────────────────── live motion preview ───────────────────────── */

  var previewRAF = null;
  var previewStart = 0;
  var cachedDot = null, cachedTrack = null;
  var PREVIEW_DURATION = 1100, PREVIEW_HOLD = 450;

  function restartMotionPreview() {
    previewStart = performance.now();
  }

  /* asleep while nobody looks at the panel (js/presence.js) */
  function wakePreview() { if (state.active && !previewRAF) previewRAF = requestAnimationFrame(tickPreview); }
  function tickPreview(now) {
    if (!state.active) {
      previewRAF = null;
      return;
    }
    if (window.PillowPresence && !window.PillowPresence.awake()) {
      previewRAF = null;
      window.PillowPresence.onWake(wakePreview);
      return;
    }
    if (!cachedDot) cachedDot = $("motion-dot");
    if (!cachedTrack) cachedTrack = document.querySelector(".motion-track");
    if (cachedDot && cachedTrack) {
      if (!cachedTrackW) cachedTrackW = cachedTrack.clientWidth - 12;
      var cycle = PREVIEW_DURATION + PREVIEW_HOLD;
      var elapsed = (now - previewStart) % cycle;
      var t = clamp(elapsed / PREVIEW_DURATION, 0, 1);
      var v = curveValueAt(state.anchors, t);
      var left = clamp(v, -0.15, 1.15) * cachedTrackW;
      cachedDot.style.transform = "translate3d(" + left + "px,0,0)";
      cachedDot.style.left = "0";
    }
    previewRAF = requestAnimationFrame(tickPreview);
  }

  function pausePreview() {
    state.active = false;
    if (previewRAF) {
      cancelAnimationFrame(previewRAF);
      previewRAF = null;
    }
    if (dragRAF) {
      cancelAnimationFrame(dragRAF);
      dragRAF = null;
    }
    pendingPointerEv = null;
    state.drag = null;
  }
  function resumePreview() {
    state.active = true;
    cachedTrackW = 0;
    cachedDot = null;
    cachedTrack = null;
    if (!previewRAF) {
      restartMotionPreview();
      previewRAF = requestAnimationFrame(tickPreview);
    }
  }

  /* ───────────────────────── apply to After Effects ───────────────────────── */

  function buildCurvePayload() {
    if (state.anchors.length === 2) {
      var a0 = state.anchors[0], a1 = state.anchors[1];
      var h1 = a0.hout, h2 = a1.hin;
      var outInfl = clamp(h1.x * 100, 0.1, 100);
      var inInfl = clamp((1 - h2.x) * 100, 0.1, 100);
      var outSpeed = h1.y > 1 ? Math.min((h1.y - 1) * 60, 80) : h1.y < 0 ? Math.max(h1.y * 60, -80) : 0;
      var inSpeed = h2.y < 0 ? Math.max(h2.y * 60, -80) : h2.y > 1 ? Math.min((h2.y - 1) * 60, 80) : 0;
      return { mode: "ease", outInfl: r3(outInfl), inInfl: r3(inInfl), outSpeed: r3(outSpeed), inSpeed: r3(inSpeed) };
    }
    var samples = [];
    var N = 32;
    for (var i = 0; i <= N; i++) {
      var t = i / N;
      samples.push({ t: r3(t), v: r3(curveValueAt(state.anchors, t)) });
    }
    return { mode: "bake", samples: samples };
  }

  function applyCurveNow() {
    var payload = buildCurvePayload();
    var json = JSON.stringify(payload);
    host('pillowApplyCurve("' + esc(json) + '")', function (r) {
      if (r.ok) {
        var what = payload.mode === "bake" ? " · " + (r.keys || 0) + " layer(s) baked" : " · " + (r.keys || 0) + " key(s) eased";
        toast((state.presetName || "Curve") + what);
      } else {
        toast(r.error || "Failed", true);
      }
    });
  }

  function applyCurve() {
    if (applyDebounceT) clearTimeout(applyDebounceT);
    applyDebounceT = setTimeout(function () {
      applyDebounceT = null;
      applyCurveNow();
    }, 120);
  }

  /* ───────────────────────── init ───────────────────────── */

  function syncCurveFavBtn() {
    var btn = $("btn-curve-fav");
    if (!btn || !window.PillowFav) return;
    var on = state.presetId && window.PillowFav.is(window.PillowFav.CURVES, state.presetId);
    btn.textContent = on ? "★" : "☆";
    btn.className = "tool-btn" + (on ? " on" : "");
  }

  function bindControls() {
    var undoBtn = $("btn-curve-undo");
    var redoBtn = $("btn-curve-redo");
    var resetBtn = $("btn-curve-reset");
    var customBtn = $("btn-curve-custom");
    var applyBtn = $("btn-curve-apply");
    if (undoBtn) undoBtn.onclick = undo;
    if (redoBtn) redoBtn.onclick = redo;
    if (resetBtn) resetBtn.onclick = resetCurve;
    if (customBtn) customBtn.onclick = createCustom;
    if (applyBtn) applyBtn.onclick = applyCurve;

    var favBtn = $("btn-curve-fav");
    if (favBtn) {
      favBtn.onclick = function () {
        if (!state.presetId || !window.PillowFav) return;
        window.PillowFav.toggle(window.PillowFav.CURVES, state.presetId);
        syncCurveFavBtn();
        renderPresetBrowser();
      };
    }

    var filter = $("inp-curve-filter");
    if (filter) {
      var filterT = null;
      filter.oninput = function () {
        var v = this.value || "";
        if (filterT) clearTimeout(filterT);
        filterT = setTimeout(function () {
          state.filter = v;
          renderPresetBrowser();
        }, 80);
      };
    }
    var favOnly = $("btn-curve-favs-only");
    if (favOnly) {
      favOnly.onclick = function () {
        state.favsOnly = !state.favsOnly;
        this.style.color = state.favsOnly ? "var(--accent-soft)" : "";
        renderPresetBrowser();
      };
    }

    var easePlus = $("btn-ease-plus-text");
    if (easePlus) {
      easePlus.onclick = function () {
        applyCurve();
        if (window.setTab) {
          /* setTab is local in panel.js — use rail click */
        }
        var textRail = document.querySelector('.rail-btn[data-tab="text"]');
        if (textRail) textRail.click();
        toast("Curve applied · pick a text animation");
      };
    }
  }

  function toggleFavsOnly() {
    state.favsOnly = !state.favsOnly;
    var btn = $("btn-curve-favs-only");
    if (btn) btn.style.color = state.favsOnly ? "var(--accent-soft)" : "";
    renderPresetBrowser();
  }

  function initCurves() {
    var def = findItem("ease");
    if (def) {
      state.anchors = deepCopyAnchors(def.anchors);
      state.original = deepCopyAnchors(def.anchors);
      state.presetId = def.id;
      state.presetName = def.name;
    }
    resetHistory();
    renderPresetBrowser();
    renderGraph();
    bindControls();
    syncCurveFavBtn();
    state.active = false;
    // Preview starts only when Curves tab becomes active (resume)
    try {
      window.addEventListener("resize", function () { cachedTrackW = 0; });
    } catch (e) {}
    /* панель растягивают — пропорции графика пересчитываются (и когда
       вкладка Curves впервые становится видимой) */
    var gsvg = $("graph-svg");
    if (gsvg && window.ResizeObserver) new ResizeObserver(function () { fitViewBox(true); }).observe(gsvg);
  }

  window.PillowCurves = {
    init: initCurves,
    pause: pausePreview,
    resume: resumePreview,
    apply: applyCurve,
    toggleFavsOnly: toggleFavsOnly
  };

  document.addEventListener("DOMContentLoaded", initCurves);
})();
