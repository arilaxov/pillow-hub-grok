/* Pillow — where Pillow talks to the outside world.
 *
 * server: the Pillow feedback server (a Cloudflare Worker, see
 *   server/README.md), e.g. "https://pillow-feedback.you.workers.dev".
 *   Reviews and problem reports are sent to <server>/feedback, and the
 *   latest version is read from <server>/version.
 *   Empty: nothing is sent anywhere — Send copies the message and opens
 *   the fallback chat instead, and the update check is off.
 * fallbackChat: opened when a message can't be sent.
 */
window.PILLOW_CONFIG = {
  server: "",
  fallbackChat: "https://t.me/kaban_shashluk"
};

/* the last few errors, for problem reports (js/feedback.js) */
(function () {
  var list = window.PILLOW_ERRORS = [];
  function keep(msg) {
    msg = String(msg || "").slice(0, 300);
    if (!msg) return;
    list.push(new Date().toISOString().slice(11, 19) + " " + msg);
    if (list.length > 6) list.shift();
  }
  window.addEventListener("error", function (e) { keep((e && e.message) || "error"); });
  window.addEventListener("unhandledrejection", function (e) { keep("promise: " + (e && e.reason && (e.reason.message || e.reason))); });
  window.pillowNoteError = keep;
})();
