/* Pillow — морфинг логотипа в окно настроек.
 *
 * Мягкая белая «подушка» логотипа в рейле перетекает в большую
 * скруглённую плашку почти на всю панель (и обратно при закрытии).
 * Форма — один SVG-path, пересчитываемый каждый кадр:
 *   · контур логотипа — полярный профиль, снятый с icons/pillow-mark.png
 *     (48 радиусов от центра силуэта, нормированы к максимальному);
 *   · контур плашки — точки, разнесённые равномерно по периметру;
 *     каждой точке плашки соответствует точка логотипа на том же угле от
 *     центра логотипа, поэтому форма «разливается» из логотипа;
 *   · каждая точка едет со своей задержкой (дальние отстают), по
 *     пружинной кривой с лёгким перелётом, плюс затухающая волна по
 *     нормали — отсюда ощущение мягкого материала;
 *   · цвет остывает от белого логотипа к поверхности панели, объёмная
 *     светотень логотипа гаснет по мере того, как форма становится
 *     плоской карточкой.
 * Переход в любой момент можно развернуть: новый стартует из формы,
 * которая сейчас на экране.
 *
 * API: PillowLogoMorph.open(onContent) / close(onClosed) / isOpen() / setBox(fn)
 */
(function () {
  "use strict";
  if (window.PillowLogoMorph) return;

  /* силуэт логотипа: радиус на углах k·7.5°, 0° — вправо, по часовой (экранные оси) */
  var LOGO_R_WHITE = [0.995,1.000,0.990,0.971,0.922,0.883,0.816,0.752,0.709,0.684,0.699,0.738,
    0.772,0.796,0.816,0.835,0.845,0.825,0.816,0.796,0.796,0.811,0.874,0.913,0.961,0.990,
    0.990,0.971,0.932,0.864,0.801,0.762,0.762,0.757,0.767,0.786,0.796,0.806,0.806,0.801,
    0.786,0.772,0.748,0.762,0.782,0.825,0.908,0.942];
  /* чёрный логотип светлой темы (icons/pillow-mark-dark.png, та же
     рамка и масштаб) — снят тем же способом */
  var LOGO_R_DARK = [0.988,1.000,0.990,0.966,0.924,0.869,0.787,0.712,0.676,0.654,0.664,0.694,
    0.736,0.775,0.803,0.823,0.827,0.823,0.805,0.783,0.771,0.797,0.853,0.911,0.954,0.976,
    0.976,0.958,0.918,0.857,0.793,0.746,0.728,0.734,0.748,0.759,0.765,0.771,0.771,0.771,
    0.757,0.744,0.734,0.740,0.773,0.833,0.899,0.952];
  var LOGO_RMAX = 0.4598;               /* максимальный радиус в долях ширины картинки */
  var LOGO_CX = 0.4974, LOGO_CY = 0.5019; /* центр силуэта в долях картинки */
  /* the cushion is drawn ~6.5° askew; while Settings are open it stands
     level (html.pl-logo-level, css), so the morph starts from — and
     folds back into — the level silhouette */
  var LOGO_LEVEL = -6.5 * Math.PI / 180;
  function logoRot() { return document.documentElement.classList.contains("pl-logo-level") ? LOGO_LEVEL : 0; }

  var N = 200;          /* точек контура */
  var INSET = 10;       /* отступ плашки от краёв панели, если рамку не задали */
  var RADIUS = 20;      /* скругление плашки */
  var boxFn = null;     /* рамка плашки: { x, y, w, h } — задаёт settings.js */
  var OPEN_MS = 760, CLOSE_MS = 560;
  var LAG = 0.22;       /* разбег прогресса между ближними и дальними точками */

  var SVGNS = "http://www.w3.org/2000/svg";
  function svgEl(tag, attrs) {
    var el = document.createElementNS(SVGNS, tag);
    for (var k in attrs) if (attrs.hasOwnProperty(k)) el.setAttribute(k, attrs[k]);
    return el;
  }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function now() { return window.performance ? performance.now() : Date.now(); }
  function reduceMotion() {
    return !!window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }
  function isLight() { return document.documentElement.getAttribute("data-theme") === "light"; }
  function glassOn() { return document.documentElement.getAttribute("data-pl-glass") === "on"; }
  /* GlassAccordion — radius 18; обычная карточка — 20 */
  function radius() { return glassOn() ? 18 : RADIUS; }

  /* easeInOutCubic (easings.net, cubic-bezier(0.65, 0, 0.35, 1)) доходит
     до цели к 82% времени, дальше — лёгкая пружина: перелёт ~2% и
     возврат к 1 */
  function bezier(x1, y1, x2, y2) {
    function a(p1, p2) { return 1 - 3 * p2 + 3 * p1; }
    function b(p1, p2) { return 3 * p2 - 6 * p1; }
    function c(p1) { return 3 * p1; }
    function at(t, p1, p2) { return ((a(p1, p2) * t + b(p1, p2)) * t + c(p1)) * t; }
    function slope(t, p1, p2) { return 3 * a(p1, p2) * t * t + 2 * b(p1, p2) * t + c(p1); }
    return function (x) {
      var t = x;
      for (var i = 0; i < 8; i++) {
        var dx = at(t, x1, x2) - x, sl = slope(t, x1, x2);
        if (Math.abs(dx) < 1e-5 || Math.abs(sl) < 1e-6) break;
        t -= dx / sl;
      }
      return at(clamp(t, 0, 1), y1, y2);
    };
  }
  /* the iOS sheet curve (cubic-bezier(0.32, 0.72, 0, 1)): the form starts
     growing at once and settles slowly. The old ease-in-out held the logo
     small for the first third and then blew it up in two frames - the
     opening felt abrupt. A touch of overshoot at the end stays. */
  var EASE_SHEET = bezier(0.32, 0.72, 0, 1);
  var REACH = 0.9, OVERSHOOT = 0.012;
  function springEase(x) {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    var base = EASE_SHEET(clamp(x / REACH, 0, 1));
    var tail = clamp((x - 0.55) / 0.45, 0, 1);
    return base + OVERSHOOT * Math.sin(Math.PI * tail) * (1 - tail * 0.35);
  }
  function smooth(a, b, x) { var t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); }

  /* радиус логотипа на произвольном угле — периодический Catmull-Rom по профилю */
  function logoRadius(theta) {
    var LOGO_R = isLight() ? LOGO_R_DARK : LOGO_R_WHITE;
    var n = LOGO_R.length;
    var f = ((theta / (Math.PI * 2)) % 1 + 1) % 1 * n;
    var i = Math.floor(f), t = f - i;
    var p0 = LOGO_R[(i - 1 + n) % n], p1 = LOGO_R[i % n], p2 = LOGO_R[(i + 1) % n], p3 = LOGO_R[(i + 2) % n];
    return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t + (-p0 + 3 * p1 - 3 * p2 + p3) * t * t * t);
  }

  /* N точек, равномерно по периметру скруглённого прямоугольника */
  function rectPoints(x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    var sw = w - 2 * r, sh = h - 2 * r, arc = Math.PI * r / 2;
    var segs = [sw, arc, sh, arc, sw, arc, sh, arc];
    var total = 0, i;
    for (i = 0; i < segs.length; i++) total += segs[i];
    var pts = [];
    for (var k = 0; k < N; k++) {
      var d = (k / N) * total, s = 0;
      while (s < 7 && d > segs[s]) { d -= segs[s]; s++; }
      var a;
      switch (s) {
        case 0: pts.push([x + r + d, y]); break;                                   /* верх → */
        case 1: a = -Math.PI / 2 + d / r; pts.push([x + w - r + r * Math.cos(a), y + r + r * Math.sin(a)]); break;
        case 2: pts.push([x + w, y + r + d]); break;                               /* право ↓ */
        case 3: a = d / r; pts.push([x + w - r + r * Math.cos(a), y + h - r + r * Math.sin(a)]); break;
        case 4: pts.push([x + w - r - d, y + h]); break;                           /* низ ← */
        case 5: a = Math.PI / 2 + d / r; pts.push([x + r + r * Math.cos(a), y + h - r + r * Math.sin(a)]); break;
        case 6: pts.push([x, y + h - r - d]); break;                               /* лево ↑ */
        default: a = Math.PI + d / r; pts.push([x + r + r * Math.cos(a), y + r + r * Math.sin(a)]); break;
      }
    }
    return pts;
  }

  /* сглаженный замкнутый путь через точки (Catmull-Rom → кубические Безье) */
  function pathOf(p) {
    var n = p.length, d = "M" + p[0][0].toFixed(2) + " " + p[0][1].toFixed(2);
    for (var i = 0; i < n; i++) {
      var p0 = p[(i - 1 + n) % n], p1 = p[i], p2 = p[(i + 1) % n], p3 = p[(i + 2) % n];
      d += "C" + (p1[0] + (p2[0] - p0[0]) / 6).toFixed(2) + " " + (p1[1] + (p2[1] - p0[1]) / 6).toFixed(2) + " " +
        (p2[0] - (p3[0] - p1[0]) / 6).toFixed(2) + " " + (p2[1] - (p3[1] - p1[1]) / 6).toFixed(2) + " " +
        p2[0].toFixed(2) + " " + p2[1].toFixed(2);
    }
    return d + "Z";
  }

  function mix(a, b, t) { return a + (b - a) * t; }
  function mixColor(a, b, t) {
    return "rgb(" + Math.round(mix(a[0], b[0], t)) + "," + Math.round(mix(a[1], b[1], t)) + "," + Math.round(mix(a[2], b[2], t)) + ")";
  }
  /* цвет логотипа, из которого вырастает форма: белый в тёмной теме,
     чёрный в светлой */
  function logoRGB() { return isLight() ? [26, 26, 28] : [243, 243, 245]; }
  function surfaceRGB() { return isLight() ? [244, 244, 246] : [22, 23, 26]; }

  /* ── слой ─────────────────────────────────────────────────────────── */
  var layer = null, svg, shade, shape, gloss, rim, scrim, glass;
  function build() {
    if (layer) return;
    layer = document.createElement("div");
    layer.className = "pl-morph";
    scrim = document.createElement("div");
    scrim.className = "pl-morph-scrim";
    svg = svgEl("svg", { "class": "pl-morph-svg", "aria-hidden": "true" });
    var defs = svgEl("defs", {});
    var g1 = svgEl("radialGradient", { id: "pl-morph-vol", cx: "0.34", cy: "0.3", r: "0.85" });
    g1.appendChild(svgEl("stop", { offset: "0", "stop-color": "#fff", "stop-opacity": "0.9" }));
    g1.appendChild(svgEl("stop", { offset: "0.55", "stop-color": "#fff", "stop-opacity": "0" }));
    g1.appendChild(svgEl("stop", { offset: "1", "stop-color": "#000", "stop-opacity": "0.13" }));
    var g2 = svgEl("linearGradient", { id: "pl-morph-gloss", x1: "0", y1: "0", x2: "0", y2: "1" });
    g2.appendChild(svgEl("stop", { offset: "0", "stop-color": "#fff", "stop-opacity": "0.07" }));
    g2.appendChild(svgEl("stop", { offset: "0.35", "stop-color": "#fff", "stop-opacity": "0.015" }));
    g2.appendChild(svgEl("stop", { offset: "1", "stop-color": "#000", "stop-opacity": "0.08" }));
    defs.appendChild(g1); defs.appendChild(g2);
    svg.appendChild(defs);
    shape = svgEl("path", {});
    shade = svgEl("path", { fill: "url(#pl-morph-vol)" });
    gloss = svgEl("path", { fill: "url(#pl-morph-gloss)" });
    rim = svgEl("path", { fill: "none", stroke: "#fff", "stroke-width": "1", "vector-effect": "non-scaling-stroke" });
    svg.appendChild(shape); svg.appendChild(shade); svg.appendChild(gloss); svg.appendChild(rim);
    layer.appendChild(scrim);
    layer.appendChild(svg);
    document.body.appendChild(layer);
    window.addEventListener("resize", function () { if (state.target === 1 && !state.raf) render(1); });
    /* Liquid Glass / тема переключены при открытых настройках */
    new MutationObserver(function () { if (state.target === 1 && !state.raf) render(1); })
      .observe(document.documentElement, { attributes: true, attributeFilter: ["data-pl-glass", "data-theme"] });
  }

  /* ── геометрия ───────────────────────────────────────────────────── *
   * Полярная интерполяция вокруг движущегося центра: логотип растёт как
   * капля, его центр переезжает из рейла в центр панели, а радиус на
   * каждом угле перетекает от бугристого профиля логотипа к контуру
   * плашки. На полпути это большая мягкая «подушка», а не клин.
   * Прогресс P — одна величина для всей формы; у точек есть сдвиг
   * P ± LAG·sin(πP) (ближние к логотипу впереди при открытии, дальние —
   * при закрытии), который исчезает на концах, поэтому разворот с
   * полпути идёт без скачка. */
  var state = { target: 0, raf: 0, P: 0, P0: 0, t0: 0, dur: 0, done: null, on: false };
  var geo = null;

  function logoBox() {
    var left = document.documentElement.getAttribute("data-rail") === "left";
    var img = (left && document.querySelector(".vdock-brand .logo-img")) ||
      document.querySelector(".rail-brand .logo-img") || document.querySelector(".rail-brand");
    if (!img) return null;
    /* the size from the layout box: a turned or pressed logo has a larger /
       smaller bounding box, the cushion itself is the same size */
    var r = img.getBoundingClientRect(), w0 = img.offsetWidth || r.width;
    return { cx: r.left + r.width * LOGO_CX, cy: r.top + r.height * LOGO_CY, s: w0 * LOGO_RMAX, el: img };
  }

  function geometry() {
    var lb = logoBox();
    if (!lb) return null;
    var W = window.innerWidth, H = window.innerHeight;
    var bx = (boxFn && boxFn()) || { x: INSET, y: INSET, w: W - INSET * 2, h: H - INSET * 2 };
    var rect = rectPoints(bx.x, bx.y, bx.w, bx.h, radius());
    var rcx = bx.x + bx.w / 2, rcy = bx.y + bx.h / 2;
    var th = [], rDist = [], lR = [], d = [], maxD = 0, minR = 1e9, i;
    for (i = 0; i < N; i++) {
      var dx = rect[i][0] - rcx, dy = rect[i][1] - rcy;
      var a = Math.atan2(dy, dx);
      th[i] = a;
      rDist[i] = Math.sqrt(dx * dx + dy * dy);
      if (rDist[i] < minR) minR = rDist[i];
      var al = a - logoRot();
      lR[i] = logoRadius(((al % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2)) * lb.s;
      /* удалённость точки плашки от логотипа — для задержки */
      var ex = rect[i][0] - lb.cx, ey = rect[i][1] - lb.cy;
      d[i] = Math.sqrt(ex * ex + ey * ey);
      if (d[i] > maxD) maxD = d[i];
    }
    for (i = 0; i < N; i++) d[i] /= maxD || 1;
    /* во сколько раз надуть профиль логотипа: капля дорастает до краёв
       плашки (вписанный радиус), не вылезая за них, а потом перетекает
       в углы */
    var grow = (minR * 0.97) / lb.s;
    return { lb: lb, rcx: rcx, rcy: rcy, th: th, rDist: rDist, lR: lR, d: d, grow: grow, box: bx };
  }

  function shapeAt(P, wave, t) {
    var g = geo, pts = [];
    /* центр — общий для всей формы (от P), задержка точек влияет только
       на радиус: иначе ближняя к логотипу сторона, забежав вперёд,
       утягивала бы свой центр внутрь и форма сначала сжималась */
    var pc = clamp(P, 0, 1);
    var cm = 1 - (1 - pc) * (1 - pc);
    var cx = mix(g.lb.cx, g.rcx, cm), cy = mix(g.lb.cy, g.rcy, cm);
    for (var i = 0; i < N; i++) {
      var e = P - LAG * (g.d[i] - 0.5) * Math.sin(Math.PI * clamp(P, 0, 1));
      e = clamp(e, -0.04, 1.04);
      var ec = clamp(e, 0, 1);
      /* сначала растёт сама бугристая «подушка» логотипа, и только ближе
         к концу её контур расправляется в скруглённый прямоугольник */
      /* масштаб растёт экспоненциально — равный прирост за кадр, а не
         рывок в середине (разница размеров ~30×) */
      var blob = g.lR[i] * Math.pow(g.grow, clamp(e / 0.8, 0, 1));
      var r = mix(blob, g.rDist[i], smooth(0.35, 1, e));
      /* перелёт пружины — лёгкое «вздутие» плашки, ~1% */
      if (e > 1) r *= 1 + (e - 1) * 0.5;
      var ph = (i / N) * Math.PI * 2;
      /* волна живёт в фазе капли и гаснет, когда форма становится плашкой */
      r += wave * (1 - smooth(0.55, 0.95, ec)) * Math.min(7, r * 0.035) *
        (0.55 * Math.sin(ph * 3 + t * 5) + 0.45 * Math.sin(ph * 5 - t * 4));
      pts.push([cx + Math.cos(g.th[i]) * r, cy + Math.sin(g.th[i]) * r]);
    }
    return pts;
  }

  /* рисует форму и материал; o — «открытость» 0…1 */
  function draw(pts, o) {
    var d = pathOf(pts);
    shape.setAttribute("d", d); shade.setAttribute("d", d);
    gloss.setAttribute("d", d); rim.setAttribute("d", d);
    shape.setAttribute("fill", mixColor(logoRGB(), surfaceRGB(), smooth(0.18, 0.8, o)));
    /* объёмный блик белого логотипа; у чёрного — приглушённый */
    shade.setAttribute("opacity", String((isLight() ? 0.3 : 1) * (1 - smooth(0.3, 0.9, o))));
    /* в стекле плотная форма уступает место стеклу на последней трети */
    var g = glassOn() ? smooth(0.6, 1, o) : 0;
    shape.setAttribute("fill-opacity", String(1 - g));
    gloss.setAttribute("opacity", String(smooth(0.5, 1, o) * (1 - g)));
    rim.setAttribute("stroke-opacity", String((isLight() ? 0.5 : 0.1) * smooth(0.55, 1, o) * (1 - g)));
    /* Liquid Glass: к концу морфинга непрозрачная форма перетекает в
       стеклянную подложку карточки. Подложка живёт внутри самого окна
       настроек (.pl-settings-glass, под его содержимым), а не отдельным
       слоем здесь: в Chromium внутри AE отдельный слой с backdrop-filter
       мог перекрыть содержимое окна. */
    if (!glass || !glass.isConnected) glass = document.querySelector(".pl-settings-glass");
    if (glass) glass.style.opacity = String(g);
    /* затемнение с лёгким блюром интерфейса — растёт вместе с формой */
    scrim.style.opacity = String(clamp(o, 0, 1));
  }

  function render(P) {
    geo = geometry();
    if (!geo) return;
    state.P = P;
    draw(shapeAt(P, 0, 0), P);
  }

  function step() {
    var t = clamp((now() - state.t0) / state.dur, 0, 1);
    state.P = mix(state.P0, state.target, springEase(t));
    var wave = Math.sin(Math.PI * t) * (1 - t * 0.4);
    draw(shapeAt(state.P, wave, t), state.P);
    if (t < 1) { state.raf = requestAnimationFrame(step); return; }
    state.raf = 0;
    render(state.target);
    var done = state.done; state.done = null;
    if (done) done();
  }

  function run(target, dur, done) {
    build();
    if (state.raf) cancelAnimationFrame(state.raf);
    geo = geometry();
    if (!geo) { if (done) done(); return; }
    /* старт — из того P, что сейчас на экране */
    state.P0 = state.on ? state.P : 1 - target;
    state.target = target;
    state.done = done || null;
    state.on = true;
    layer.classList.add("on");
    geo.lb.el.style.visibility = "hidden";
    state.t0 = now();
    /* на развороте с полпути — пропорционально короче */
    state.dur = dur * (0.45 + 0.55 * Math.abs(target - state.P0));
    state.raf = requestAnimationFrame(step);
  }

  function finishClosed() {
    if (state.target !== 0) return;
    layer.classList.remove("on");
    state.on = false;
    var lb = logoBox();
    if (lb) lb.el.style.visibility = "";
  }

  function open(onContent) {
    if (reduceMotion()) {
      build(); render(1); layer.classList.add("on"); state.on = true;
      var lb = logoBox(); if (lb) lb.el.style.visibility = "hidden";
      state.target = 1;
      if (onContent) onContent();
      return;
    }
    run(1, OPEN_MS, null);
    /* контент — на последней трети морфинга */
    if (onContent) setTimeout(function () { if (state.target === 1) onContent(); }, OPEN_MS * 0.42);
  }

  function close(onClosed) {
    if (!layer) { if (onClosed) onClosed(); return; }
    if (reduceMotion()) {
      state.target = 0; finishClosed();
      if (onClosed) onClosed();
      return;
    }
    run(0, CLOSE_MS, function () { finishClosed(); if (onClosed) onClosed(); });
  }

  /* Warm-up: the first open of a session built the layer and drew the
     big shape for the first time in the middle of its animation. Once,
     in a quiet moment, the layer is built and the half-open shape drawn
     for two frames, transparent; the logo itself is not touched. */
  function warm() {
    if (state.on) return;
    build();
    var g = geometry();
    if (!g) return;
    geo = g;
    layer.style.opacity = "0.01";
    layer.classList.add("on");
    draw(shapeAt(0.5, 0, 0.5), 0.5);
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        if (!state.on) { layer.classList.remove("on"); draw(shapeAt(0, 0, 0), 0); }
        layer.style.opacity = "";
      });
    });
  }

  window.PillowLogoMorph = {
    warm: warm,
    open: open,
    close: close,
    isOpen: function () { return state.target === 1; },
    /* рамка изменилась (секция настроек раскрывается) — перерисовать */
    refresh: function () { if (layer && state.target === 1 && !state.raf) render(1); },
    /* рамка плашки; при открытом окне форма сразу перерисовывается */
    setBox: function (fn) {
      boxFn = fn;
      if (layer && state.target === 1 && !state.raf) render(1);
    }
  };
})();
