/* Pillow — feedback: a review (stars + words) or a problem report.
 *
 * Lives in Settings → Feedback. Sent as JSON to <server>/feedback
 * (js/config.js, server/feedback-worker.js): a review goes to the
 * developers for a quick check and then to the Pillow channels; a problem
 * report goes to the developers only, with the Pillow / After Effects
 * versions, the OS and the last errors if the box is ticked (the exact
 * text is shown before it is sent). Without a server, or when sending
 * fails, the message is copied and the fallback chat opens instead.
 */
(function () {
  "use strict";
  if (window.PillowFeedback) return;

  var kind = "review", rating = 0, lastSent = 0, root = null, relayout = null;
  function $(id) { return document.getElementById(id); }
  function cfg() { return window.PILLOW_CONFIG || {}; }
  function say(msg, bad) { if (typeof window.toast === "function") window.toast(msg, !!bad); }

  function diagnostics() {
    var lines = [];
    lines.push("Pillow " + (typeof PILLOW_VERSION !== "undefined" ? PILLOW_VERSION : "?"));
    try {
      var cs = window.csInterface || (window.CSInterface ? new CSInterface() : null);
      var env = cs && cs.getHostEnvironment ? cs.getHostEnvironment() : null;
      if (env) lines.push("After Effects " + env.appVersion + " · " + (env.appLocale || ""));
      var os = cs && cs.getOSInformation ? cs.getOSInformation() : "";
      if (os) lines.push(os);
    } catch (e) {}
    if (lines.length < 3) lines.push(navigator.platform || "");
    var errs = window.PILLOW_ERRORS || [];
    if (errs.length) lines.push("Last errors:\n" + errs.slice(-3).join("\n"));
    return lines.join("\n");
  }

  function paint() {
    var ks = root.querySelectorAll("[data-fb-kind]");
    for (var i = 0; i < ks.length; i++) ks[i].classList.toggle("active", ks[i].getAttribute("data-fb-kind") === kind);
    var review = kind === "review";
    $("pl-fb-stars").hidden = !review;
    $("pl-fb-name").hidden = !review;
    $("pl-fb-diag-row").hidden = review;
    $("pl-fb-diag-text").hidden = review || !$("pl-fb-diag").checked;
    if (!review) $("pl-fb-diag-text").textContent = diagnostics();
    /* a textarea is left alone by the page translator: translate here */
    var ph = review ? "What do you like about Pillow? What would you add?" : "What happened? What did you click just before?";
    $("pl-fb-text").placeholder = window.PillowI18n ? window.PillowI18n.tr(ph) : ph;
    $("pl-fb-note").textContent = review ? "Reviews appear in the Pillow channel after a quick check." : "Goes to the developers only.";
    var st = root.querySelectorAll("[data-star]");
    for (var j = 0; j < st.length; j++) st[j].classList.toggle("on", +st[j].getAttribute("data-star") <= rating);
    var meta = $("pl-set-fb-val");
    if (meta) meta.textContent = review ? (rating ? rating + "★" : "") : "Problem";
    if (relayout) relayout();
    if (window.PillowLogoMorph && window.PillowLogoMorph.refresh) window.PillowLogoMorph.refresh();
  }

  function message() {
    var text = $("pl-fb-text").value.trim();
    var m = { type: kind, text: text, version: typeof PILLOW_VERSION !== "undefined" ? PILLOW_VERSION : "" };
    if (kind === "review") { m.rating = rating; m.name = $("pl-fb-name").value.trim(); }
    else if ($("pl-fb-diag").checked) m.diag = diagnostics();
    return m;
  }
  function asText(m) {
    var t = (m.type === "review" ? "Pillow review " + (m.rating ? new Array(m.rating + 1).join("★") : "") : "Pillow problem") + "\n\n" + m.text;
    if (m.name) t += "\n\n— " + m.name;
    if (m.diag) t += "\n\n" + m.diag;
    return t;
  }
  function openUrl(url) {
    if (!url) return;
    try { if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) { window.cep.util.openURLInDefaultBrowser(url); return; } } catch (e) {}
    window.open(url, "_blank");
  }
  function copy(text) {
    var ok = false;
    try {
      var ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      ok = document.execCommand("copy");
      ta.remove();
    } catch (e) {}
    return ok;
  }
  /* no server, or it failed: copy, and open the chat */
  function fallback(m) {
    var ok = copy(asText(m));
    say(ok ? "Copied — paste it in the chat that opens" : "Couldn't send — write to us in Telegram", !ok);
    openUrl(cfg().fallbackChat);
  }
  function done(m) {
    $("pl-fb-text").value = "";
    rating = 0;
    paint();
    say(m.type === "review" ? "Thank you! Your review is on its way" : "Sent — thanks, we'll look into it");
    if (window.PillowNotch && window.PillowNotch._react) window.PillowNotch._react("happy", 1600);
  }

  function send() {
    var m = message();
    if (m.text.length < 3) { say("Write a few words first", true); $("pl-fb-text").focus(); return; }
    if (m.type === "review" && !m.rating) { say("Tap the stars to rate Pillow", true); return; }
    if (Date.now() - lastSent < 30000) { say("One moment — you've just sent one", true); return; }
    var server = String(cfg().server || "").replace(/\/+$/, "");
    if (!server || !window.fetch) { fallback(m); return; }
    var btn = $("pl-fb-send");
    btn.disabled = true;
    var ctl = window.AbortController ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctl) ctl.abort(); }, 12000);
    fetch(server + "/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(m),
      signal: ctl ? ctl.signal : undefined
    }).then(function (res) {
      clearTimeout(timer);
      btn.disabled = false;
      if (!res.ok) throw new Error("HTTP " + res.status);
      lastSent = Date.now();
      done(m);
    }).catch(function () {
      clearTimeout(timer);
      btn.disabled = false;
      fallback(m);
    });
  }

  function mount(panel, layout) {
    root = panel.querySelector("#pl-fb");
    if (!root || root.__fb) return;
    root.__fb = true;
    relayout = layout;
    root.addEventListener("click", function (e) {
      var k = e.target.closest ? e.target.closest("[data-fb-kind]") : null;
      if (k) { kind = k.getAttribute("data-fb-kind"); paint(); return; }
      var s = e.target.closest ? e.target.closest("[data-star]") : null;
      if (s) { rating = +s.getAttribute("data-star"); paint(); }
    });
    $("pl-fb-diag").addEventListener("change", paint);
    $("pl-fb-send").addEventListener("click", send);
    paint();
  }

  window.PillowFeedback = { mount: mount, _diag: diagnostics, _message: message };
})();
