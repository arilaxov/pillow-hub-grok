/* Pillow beat detection — runs in the panel, on the audio file itself.
 * The file is decoded with Web Audio, mixed to mono, and an onset curve is
 * built from spectral flux (log magnitudes, positive change frame to
 * frame, lows weighted up so kicks lead). Peaks are kept where the curve
 * stands above its own running average by a margin set by Sensitivity,
 * no closer than the minimum gap. Times are in seconds of the source file. */
(function () {
  var WIN = 1024;
  var OFFSET = 0.77;   /* where in the window an onset reads, as a share of it */

  function fft(re, im) {
    var n = re.length, i, j, k, len, h, t;
    for (i = 1, j = 0; i < n; i++) {
      var bit = n >> 1;
      for (; j & bit; bit >>= 1) j ^= bit;
      j ^= bit;
      if (i < j) { t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; }
    }
    for (len = 2; len <= n; len <<= 1) {
      var ang = -2 * Math.PI / len, wr = Math.cos(ang), wi = Math.sin(ang);
      h = len >> 1;
      for (i = 0; i < n; i += len) {
        var cr = 1, ci = 0;
        for (k = 0; k < h; k++) {
          var a = i + k, b = a + h;
          var xr = re[b] * cr - im[b] * ci, xi = re[b] * ci + im[b] * cr;
          re[b] = re[a] - xr; im[b] = im[a] - xi;
          re[a] += xr; im[a] += xi;
          t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t;
        }
      }
    }
  }

  /* mono at ~22 kHz: average the channels, then pairs of samples */
  function mono(buf) {
    var chs = buf.numberOfChannels, len = buf.length, sr = buf.sampleRate;
    var step = sr >= 40000 ? 2 : 1, n = Math.floor(len / step);
    var out = new Float32Array(n), c, i, s;
    for (c = 0; c < chs; c++) {
      var d = buf.getChannelData(c);
      for (i = 0; i < n; i++) {
        s = d[i * step];
        if (step === 2) s = (s + d[i * step + 1]) * 0.5;
        out[i] += s / chs;
      }
    }
    return { x: out, sr: sr / step };
  }

  /* onset curve, built a slice at a time so the panel stays responsive */
  function flux(x, sr, done) {
    var hop = Math.max(1, Math.round(sr * 0.01));
    var frames = Math.max(0, Math.floor((x.length - WIN) / hop));
    var win = new Float32Array(WIN), i;
    for (i = 0; i < WIN; i++) win[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / (WIN - 1));
    var half = WIN >> 1, prev = new Float32Array(half), cur = new Float32Array(half);
    /* bands: 0 lows (kick, bass), 1 mids (snare, voice), 2 highs (hats) */
    var band = new Uint8Array(half);
    for (i = 0; i < half; i++) {
      var hz = i * sr / WIN;
      band[i] = hz < 160 ? 0 : hz < 2500 ? 1 : 2;
    }
    var re = new Float32Array(WIN), im = new Float32Array(WIN);
    var bands = [new Float32Array(frames), new Float32Array(frames), new Float32Array(frames)], f = 0;
    function slice() {
      var end = Math.min(frames, f + 1500);
      for (; f < end; f++) {
        var o = f * hop;
        for (i = 0; i < WIN; i++) { re[i] = x[o + i] * win[i]; im[i] = 0; }
        fft(re, im);
        var s0 = 0, s1 = 0, s2 = 0;
        for (i = 1; i < half; i++) {
          var m = Math.log(1 + 100 * Math.sqrt(re[i] * re[i] + im[i] * im[i]));
          cur[i] = m;
          var d = m - prev[i];
          if (d > 0 && f > 0) { if (band[i] === 0) s0 += d; else if (band[i] === 1) s1 += d; else s2 += d; }
        }
        var t = prev; prev = cur; cur = t;
        bands[0][f] = s0; bands[1][f] = s1; bands[2][f] = s2;
      }
      if (f < frames) { setTimeout(slice, 0); return; }
      /* each band on its own scale, so the many bins of the highs don't
         drown the few of a kick; lows lead the mix */
      var out = new Float32Array(frames), W = [1, 0.6, 0.35];
      for (var bi = 0; bi < 3; bi++) {
        var r = pct(bands[bi], 0.98);
        if (r <= 0) continue;
        for (i = 0; i < frames; i++) out[i] += W[bi] * bands[bi][i] / r;
      }
      done(out, hop / sr);
    }
    slice();
  }

  function pct(a, q) {
    if (!a.length) return 0;
    var s = Array.prototype.slice.call(a).sort(function (x, y) { return x - y; });
    return s[Math.min(s.length - 1, Math.floor(s.length * q))] || s[s.length - 1] || 0;
  }

  function pick(c, dt, sens, gap, off) {
    off = off || 0;
    var n = c.length, i;
    if (!n) return [];
    /* scale: the 98th percentile of the curve is 1 */
    var ref = pct(c, 0.98);
    if (ref <= 0) return [];
    var v = new Float32Array(n);
    for (i = 0; i < n; i++) v[i] = c[i] / ref;
    /* running average over ±0.25 s */
    var W = Math.max(2, Math.round(0.25 / dt)), pre = new Float64Array(n + 1);
    for (i = 0; i < n; i++) pre[i + 1] = pre[i] + v[i];
    var s = Math.max(0.05, Math.min(0.95, sens));
    var delta = 0.04 + (1 - s) * 0.5, mult = 1.15 + (1 - s) * 0.6;
    var L = Math.max(1, Math.round(0.03 / dt));
    var out = [], last = -1e9;
    for (i = 1; i < n - 1; i++) {
      var a = Math.max(0, i - W), b = Math.min(n, i + W + 1);
      var mean = (pre[b] - pre[a]) / (b - a);
      if (v[i] < mean * mult + delta) continue;
      var peak = true;
      for (var j = Math.max(0, i - L); j <= Math.min(n - 1, i + L); j++) {
        if (v[j] > v[i] || (v[j] === v[i] && j < i)) { peak = false; break; }
      }
      if (!peak) continue;
      var t = Math.max(0, i * dt + off);
      if (t - last < gap) {
        /* inside the gap: keep the stronger of the two */
        if (out.length && v[i] > out[out.length - 1].v) { out[out.length - 1] = { t: t, v: v[i] }; last = t; }
        continue;
      }
      out.push({ t: t, v: v[i] });
      last = t;
    }
    var times = [];
    for (i = 0; i < out.length; i++) times.push(Math.round(out[i].t * 1000) / 1000);
    return times;
  }

  function readFile(path) {
    var req = (window.cep_node && window.cep_node.require) || (typeof window.require === "function" ? window.require : null);
    if (!req) return null;
    try {
      var b = req("fs").readFileSync(path);
      return b.buffer.slice(b.byteOffset, b.byteOffset + b.length);
    } catch (e) { return null; }
  }

  function decode(ab, ok, fail) {
    var Ctx = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    if (!Ctx) { fail("no-audio"); return; }
    var ctx;
    try { ctx = new Ctx(1, 1, 44100); } catch (e) { fail("no-audio"); return; }
    var settled = false;
    function good(buf) { if (!settled) { settled = true; ok(buf); } }
    function bad() { if (!settled) { settled = true; fail("decode"); } }
    try {
      var p = ctx.decodeAudioData(ab, good, bad);
      if (p && p.then) p.then(good, bad);
    } catch (e2) { bad(); }
  }

  /* analyse(ArrayBuffer, {sensitivity 0…1, gap s}, cb(err, times)) */
  function analyse(ab, opt, cb) {
    decode(ab, function (buf) {
      var m = mono(buf);
      flux(m.x, m.sr, function (c, dt) {
        cb(null, pick(c, dt, opt.sensitivity, opt.gap, OFFSET * WIN / m.sr), buf.duration);
      });
    }, function (why) { cb(why); });
  }

  function analyseFile(path, opt, cb) {
    var ab = readFile(path);
    if (!ab) { cb("read"); return; }
    analyse(ab, opt, cb);
  }

  window.PillowBeatDetect = { analyse: analyse, analyseFile: analyseFile, _pick: pick };
})();
