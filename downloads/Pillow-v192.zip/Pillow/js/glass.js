/* Pillow — Liquid Glass mode (одобренная версия)
 *
 * Отдельный визуальный режим, по умолчанию выключенный. Движок —
 * тот же, что в утверждённом прототипе: порт реестра Website Glass
 * (websiteglass.com/r/glass.json + glass-motion / glass-switch /
 * glass-tabs). Карта смещения рисуется на canvas (плоский центр,
 * преломление у кромки), подаётся в SVG feDisplacementMap, а фильтр
 * запускается как backdrop-filter — там входом фильтра является
 * содержимое ЗА элементом, поэтому интерфейс физически гнётся под
 * стеклом. Только Chromium умеет url() в backdrop-filter; в остальных
 * средах остаётся frosted-фоллбэк.
 *
 * Режим ничего не переставляет: он лишь подменяет инлайновые
 * background / box-shadow / backdrop-filter у подходящих поверхностей и
 * возвращает их ровно как было при OFF. Компоновка, размеры, иконки,
 * навигация, анимации и логика не затрагиваются.
 *
 * API: PillowGlass.isOn() / setEnabled(bool) / toggle() / scan(root)
 */

(function () {
  "use strict";

  var KEY = "pillow.liquidGlass";
  var ATTR = "data-pl-glass";

  /* ── одобренная палитра материала (ЧБ) ───────────────────────────── */
  var SHEEN = "linear-gradient(176deg, rgba(255,255,255,0.11) 0%, rgba(255,255,255,0.045) 34%, rgba(255,255,255,0.012) 62%, rgba(0,0,0,0.05) 100%)";
  /* Glass (websiteglass.com/r/glass.json) — оформление дословно:
     rimShadow(dark), sheen(dark), тон rgba(70,72,78 | 255,255,255,
     max(tint·0.4, 0.04)), backdrop url(линза) blur(b) saturate(1.6). */
  /* Crystal: a thick clear edge, the way a slab of glass reads — a bright
     hairline, a lit top line and a fainter one at the bottom, a light band
     along the inside of the edge and a soft inner glow where the glass is
     thick; the middle stays clear, a touch frosted and a touch darker so
     the interface on it reads easily. */
  function crystal(k, light) {
    if (light) return "inset 0 0 0 1px rgba(255,255,255," + (0.85 * k).toFixed(2) + "), inset 0 1px 0 rgba(255,255,255,1)," +
      " inset 0 -1px 0 rgba(0,0,0,0.05), inset 0 0 0 3px rgba(255,255,255," + (0.32 * k).toFixed(2) + ")," +
      " inset 0 0 9px 1px rgba(255,255,255," + (0.3 * k).toFixed(2) + "), 0 0 0 0.5px rgba(0,0,0,0.07)";
    return "inset 0 0 0 1px rgba(255,255,255," + (0.3 * k).toFixed(2) + "), inset 0 1.5px 0 rgba(255,255,255," + (0.5 * k).toFixed(2) + ")," +
      " inset 0 -1px 0 rgba(255,255,255," + (0.18 * k).toFixed(2) + "), inset 0 0 0 3px rgba(255,255,255," + (0.03 * k).toFixed(3) + ")," +
      " inset 0 0 9px 1px rgba(255,255,255," + (0.055 * k).toFixed(3) + "), inset 5px 6px 10px -8px rgba(255,255,255," + (0.12 * k).toFixed(2) + ")," +
      " inset -5px -5px 10px -8px rgba(255,255,255," + (0.08 * k).toFixed(2) + ")";
  }
  var GLASS_RIM = crystal(1, false);
  var GLASS_RIM_LIGHT = crystal(1, true);
  var GLASS_SHEEN = "linear-gradient(135deg, rgba(255,255,255,0.14) 0%, transparent 36%, transparent 64%, rgba(255,255,255,0.06) 100%)";
  var GLASS_SHEEN_LIGHT = "linear-gradient(135deg, rgba(255,255,255,0.32) 0%, transparent 38%, transparent 62%, rgba(255,255,255,0.14) 100%)";
  /* the middle of the glass: a little darker than what is behind it */
  var DARKEN = "rgba(12,12,16,0.24)", DARKEN_LIGHT = "rgba(236,236,240,0.42)";
  function surfaceTint(t, light) { return light ? DARKEN_LIGHT : DARKEN; }
  function glassTint(t, light) { return light ? DARKEN_LIGHT : DARKEN; }

  /* Третий слой каждой тени — внешний ambient-свет плашки (§3 референса:
     L1 панель / L2 контрол / L3 floating получают разную глубину). Токены
     --lg-ambient* уже разведены по тёмной/светлой теме в panel.css, так
     что здесь не нужна отдельная ветка isLight() под них. */
  var RIM = crystal(1, false) + ", var(--lg-ambient)";
  var RIM_SOFT = crystal(0.85, false) + ", var(--lg-ambient-sm)";
  var RIM_LIGHT = crystal(1, true) + ", var(--lg-ambient)";
  var RIM_LIGHT_SOFT = crystal(0.85, true) + ", var(--lg-ambient-sm)";
  /* L3 floating (поповер настроек, тост) — та же кромка, что у панели,
     но сильнее (rim-strong) и на самой глубокой ambient-тени. */
  var RIM_FLOAT = crystal(1.2, false) + ", var(--lg-ambient-float)";
  var RIM_LIGHT_FLOAT = crystal(1.1, true) + ", var(--lg-ambient-float)";
  /* Liquid Glass 2A — selected/active fill. Tokens (css/panel.css §lg-*)
     already flip per theme, so referencing them here means this needs no
     isLight() branch of its own. Elements this replaces SHEEN/rimFor() on
     (.text-cat.active, .settings-tab.active, .inout-btn.active,
     .dir-btn.active, .bnc-preset.active, .curve-preset-row.active, …)
     otherwise lose their "selected" look entirely once dress() overwrites
     background-image/box-shadow — see paintFill() below. */
  var ACTIVE_FILL = "var(--lg-active-fill)";
  var ACTIVE_RIM = "var(--lg-active-rim)";

  /* Поверхности режима. Ровно те, что были в утверждённом наборе:
     плашки, карточки, панели, индикатор вкладок, поля, тихие кнопки,
     дорожки переключателей, попап настроек и тост. */
  var SURFACES = [
    /* Панели — компонент Glass из websiteglass.com/r/glass.json со
       значениями из его playground: strength 0 · blur 2 · tint 0.3 ·
       dome 0.22 (recipe "glass": тон, блик, кромка и backdrop — ровно
       по формулам Glass, см. GLASS_* ниже). */
    { sel: ".glass-panel",    recipe: "glass", strength: 0, blur: 2, tint: 0.3, dome: 0.22 },
    /* Quick Create: капсулы того же стекла, что и блок параметров над
       ними (тот же SHEEN, блюр 6), чтобы верх и низ читались одним
       материалом. Стоит ПЕРЕД .card: у плиток оба класса, берётся первое
       совпадение. Тон чуть светлее, чем у .glass-panel, — фон под нижней
       частью панели темнее, и с тем же тоном капсулы казались плотнее;
       кромка мягкая, линза слабее — на низкой капсуле краевое преломление
       иначе затягивает внутрь чёрный фон по всей высоте.
       border-radius на полную капсулу задаёт glass.css. */
    { sel: ".create-tile",    recipe: "glass", strength: 0, blur: 2, tint: 0.3, dome: 0.22 },
    { sel: ".sfx-list > .card", recipe: "glass", strength: 0, blur: 2, tint: 0.3, dome: 0.22 },
    { sel: ".card",           bg: "rgba(72,74,80,0.13)",  bgLight: "rgba(255,255,255,0.32)", blur: 5, strength: 0.55, dome: 0,    rim: "panel" },
    { sel: ".text-card",      recipe: "glass", strength: 0, blur: 2, tint: 0.3, dome: 0.22 },
    { sel: ".bnc-stage",      bg: "rgba(72,74,80,0.13)",  bgLight: "rgba(255,255,255,0.32)", blur: 5, strength: 0.55, dome: 0,    rim: "panel" },
    { sel: ".bnc-preset",     bg: "rgba(72,74,80,0.12)",  bgLight: "rgba(255,255,255,0.30)", blur: 4, strength: 0.5,  dome: 0,    rim: "soft"  },
    { sel: ".graph-panel",    bg: "rgba(72,74,80,0.13)",  bgLight: "rgba(255,255,255,0.32)", blur: 5, strength: 0.55, dome: 0,    rim: "panel" },
    { sel: ".preset-browser", bg: "rgba(72,74,80,0.12)",  bgLight: "rgba(255,255,255,0.30)", blur: 5, strength: 0.5,  dome: 0,    rim: "soft"  },
    { sel: ".relink-hero",    recipe: "glass", strength: 0, blur: 2, tint: 0.3, dome: 0.22 },
    { sel: ".asset-item",     bg: "rgba(72,74,80,0.12)",  bgLight: "rgba(255,255,255,0.30)", blur: 4, strength: 0.5,  dome: 0,    rim: "soft"  },
    /* GlassCard (glass-card.json) = GlassSurface tint .75 (playground), radius 20:
       blur 14·(0.4+0.6t), saturate 1+0.6·max(t,.25), тон max(.04, .42t) */
    { sel: ".curve-preset-row", recipe: "surface", tint: 0.75, blur: 14, sat: 1.6, strength: 0, dome: 0 },
    /* .filter-row и .toggle-row НЕ одеваются: это чисто layout-обёртки
       (display:flex, без padding и без border-radius) вокруг уже своих
       стеклянных детей (.field-input, .switch/.btn-ghost). Одеть саму
       обёртку означало бы дать ей собственные фон/кромку/backdrop-filter
       вплотную к скруглённым краям ребёнка, но без padding и без
       border-radius её прямоугольник виден именно там, где ребёнок уже
       скруглил свой угол — квадратный контур торчит из-под скруглённого
       поля. Дети остаются одетыми сами по себе — этого достаточно. */
    /* .field-input здесь больше нет: поля ввода — GlassInput со своим
       материалом в css/panel.css (одинаково со стеклом и без). */
    { sel: ".btn-ghost",      bg: "rgba(72,74,80,0.10)",  bgLight: "rgba(255,255,255,0.34)", blur: 4, strength: 0.45, dome: 0.18, rim: "soft"  },
    { sel: ".tool-btn",       bg: "rgba(72,74,80,0.10)",  bgLight: "rgba(255,255,255,0.34)", blur: 4, strength: 0.45, dome: 0.18, rim: "soft"  },
    { sel: ".settings-tab",   bg: "rgba(72,74,80,0.10)",  bgLight: "rgba(255,255,255,0.34)", blur: 4, strength: 0.45, dome: 0.18, rim: "soft"  },
    /* Единые segmented controls (js/glass-tabs.js): стекло несёт сам
       трек, а «выбранное» состояние — не независимый фон на каждой
       кнопке, а один плавающий индикатор поверх. Поэтому кнопки внутри
       (.inout-btn, .text-cat, .dir-btn) здесь больше НЕ одеваются —
       иначе под и над индикатором оказались бы два конкурирующих фона. */
    { sel: ".inout-switch",   bg: "rgba(72,74,80,0.10)",  bgLight: "rgba(255,255,255,0.30)", blur: 4, strength: 0.4,  dome: 0,    rim: "track" },
    { sel: ".text-cats",      bg: "rgba(72,74,80,0.10)",  bgLight: "rgba(255,255,255,0.30)", blur: 4, strength: 0.4,  dome: 0,    rim: "track" },
    { sel: ".dir-row",        bg: "rgba(72,74,80,0.10)",  bgLight: "rgba(255,255,255,0.30)", blur: 4, strength: 0.4,  dome: 0,    rim: "track" },
    { sel: ".switch",         bg: null,                   bgLight: null,                     blur: 3, strength: 0.5,  dome: 0,    rim: "track" },
    { sel: ".rail-pill",      bg: "rgba(255,255,255,0.14)", bgLight: "rgba(0,0,0,0.10)",     blur: 2, strength: 0.6,  dome: 0.1,  rim: "pill"  },
    { sel: ".glass-chip",     bg: "rgba(72,74,80,0.12)",  bgLight: "rgba(255,255,255,0.34)", blur: 4, strength: 0.45, dome: 0,    rim: "soft"  },
    { sel: ".anchor-tile",    bg: "rgba(72,74,80,0.13)",  bgLight: "rgba(255,255,255,0.32)", blur: 5, strength: 0.5,  dome: 0.12, rim: "panel" },
    /* L3 floating (§3 референса): поповер настроек и тост сидят НАД
       остальным интерфейсом, а не в его толще — сильнее блюр/сатурация
       и самая глубокая кромка (rim "float"), а не как у обычной панели. */
    { sel: ".pl-settings",    bg: "rgba(60,62,68,0.40)",  bgLight: "rgba(255,255,255,0.52)", blur: 15, strength: 0.45, dome: 0,   rim: "float" },
    { sel: ".toast",          bg: "rgba(60,62,68,0.42)",  bgLight: "rgba(255,255,255,0.56)", blur: 15, strength: 0.4,  dome: 0,   rim: "float" },
    /* Дополнено при аудите консистентности стекла: поверхности, которые
       раньше оставались плоскими (нижний статус-бар, кнопка темы, плашки
       и мелкие поля Bounce, крестик настроек) — тот же материал, что и у
       их ближайших аналогов (tool-btn / filter-row / field-input / chip). */
    { sel: ".status-bar",     bg: "rgba(72,74,80,0.13)",  bgLight: "rgba(255,255,255,0.32)", blur: 5, strength: 0.5,  dome: 0,    rim: "soft"  },
    { sel: ".theme-toggle",   bg: "rgba(72,74,80,0.10)",  bgLight: "rgba(255,255,255,0.34)", blur: 4, strength: 0.45, dome: 0.18, rim: "soft"  },
    { sel: ".bnc-badge",      bg: "rgba(72,74,80,0.12)",  bgLight: "rgba(255,255,255,0.34)", blur: 4, strength: 0.45, dome: 0,    rim: "soft"  },
    { sel: ".bnc-target",     bg: "rgba(72,74,80,0.11)",  bgLight: "rgba(255,255,255,0.28)", blur: 4, strength: 0.45, dome: 0,    rim: "soft"  },
    { sel: ".bnc-num",        bg: "rgba(72,74,80,0.12)",  bgLight: "rgba(255,255,255,0.40)", blur: 5, strength: 0.5,  dome: 0,    rim: "soft"  },
    { sel: ".bnc-conflict",   bg: "rgba(72,74,80,0.12)",  bgLight: "rgba(255,255,255,0.30)", blur: 4, strength: 0.5,  dome: 0,    rim: "soft"  },
    { sel: ".pl-settings-close", bg: "rgba(72,74,80,0.10)", bgLight: "rgba(255,255,255,0.34)", blur: 3, strength: 0.4, dome: 0.18, rim: "soft" }
  ];

  /* the calm look (css/minimal.css): glass belongs to what floats over the
     content — the tab pill, switches, segmented tracks, the settings sheet
     and toasts — never to the content itself (cards, lists, panels) */
  var GLASS_KEEP = [".rail-pill", ".switch", ".inout-switch", ".text-cats", ".dir-row", ".pl-settings", ".toast", ".pl-settings-close"];
  SURFACES = SURFACES.filter(function (s) { return GLASS_KEEP.indexOf(s.sel) >= 0; });
  var SEL = SURFACES.map(function (s) { return s.sel; }).join(",");

  /* Линза (SVG-преломление у кромки) — только у мелких контролов, где
     она читается как стекло и стоит дёшево. На крупных плашках, карточках,
     строках и чипах преломление размытого фона давало неровные светлые и
     тёмные разводы вдоль края, а 150+ линз (с картой смещения каждая,
     включая скрытые вкладки) — долгий фриз при включении режима. Там —
     чистое матовое стекло: тот же тон, блик и кромка, ровный край. */
  var LENS_SEL = ".rail-pill, .switch, .btn-ghost, .tool-btn, .theme-toggle, .pl-settings-close, .settings-tab";
  var NO_LENS = { css: null, update: function () { return null; }, node: null };

  /* Таблетки-кнопки в panel.css объявлены через !important — материал
     режима пишется им с тем же приоритетом. */
  var FORCED = ".btn-ghost, .tool-btn, .settings-tab, .inout-btn, .dir-btn, .text-cat";
  function prioFor(el) {
    return (el.matches && el.matches(FORCED)) || el.classList.contains("pl-plated") ? "important" : "";
  }

  /* ── карта смещения ──────────────────────────────────────────────── */
  var MAPS = {}, MAP_KEYS = [], MAP_MAX = 90;

  function cb(v) { return v < 0 ? 0 : v > 255 ? 255 : Math.round(v); }
  function sg(v) { return v < 0 ? -1 : v > 0 ? 1 : 0; }

  function buildLensMap(w, h, radius, band, dome) {
    var res = 190;
    var key = Math.round(w) + "x" + Math.round(h) + "|r" + Math.round(radius) + "|b" + Math.round(band) + "|d" + dome;
    if (MAPS[key]) return MAPS[key];
    if (w < 1 || h < 1) return null;

    var aspect = w / h;
    var mw = aspect >= 1 ? res : Math.round(res * aspect);
    var mh = aspect >= 1 ? Math.round(res / aspect) : res;
    if (mw < 1 || mh < 1) return null;

    var canvas = document.createElement("canvas");
    canvas.width = mw; canvas.height = mh;
    var ctx = canvas.getContext("2d");
    if (!ctx) return null;

    var img = ctx.createImageData(mw, mh), buf = img.data;
    var hw = w / 2, hh = h / 2, r = Math.min(radius, hw, hh);
    band = Math.max(1, band);

    for (var y = 0; y < mh; y++) {
      for (var x = 0; x < mw; x++) {
        var px = ((x + 0.5) / mw - 0.5) * w;
        var py = ((y + 0.5) / mh - 0.5) * h;
        var qx = Math.abs(px) - (hw - r);
        var qy = Math.abs(py) - (hh - r);
        var ox = Math.max(qx, 0), oy = Math.max(qy, 0);
        var sdf = Math.sqrt(ox * ox + oy * oy) + Math.min(Math.max(qx, qy), 0) - r;
        var nx = 0, ny = 0;
        if (sdf < 0) {
          var depth = -sdf;
          var dirX = qx > qy ? sg(px) : 0;
          var dirY = qy >= qx ? sg(py) : 0;
          if (qx > 0 && qy > 0) {
            var len = Math.sqrt(qx * qx + qy * qy) || 1;
            dirX = (sg(px) * qx) / len;
            dirY = (sg(py) * qy) / len;
          }
          var ramp = depth < band ? 1 - depth / band : 0;
          var rim = ramp * ramp * (3 - 2 * ramp);
          nx = dirX * rim; ny = dirY * rim;
          if (dome) {
            var u = px / hw, v = py / hh;
            var fall = Math.max(0, 1 - (u * u + v * v));
            nx += u * fall * dome; ny += v * fall * dome;
          }
        }
        var i = (y * mw + x) * 4;
        buf[i] = cb(128 + nx * 127);
        buf[i + 1] = cb(128 + ny * 127);
        buf[i + 2] = 128;
        buf[i + 3] = 255;
      }
    }

    ctx.putImageData(img, 0, 0);
    var url = canvas.toDataURL("image/png");
    MAPS[key] = url;
    MAP_KEYS.push(key);
    if (MAP_KEYS.length > MAP_MAX) delete MAPS[MAP_KEYS.shift()];
    return url;
  }

  /* ── окружение и фильтры ─────────────────────────────────────────── */
  var canRefract = null;
  function supported() {
    if (canRefract !== null) return canRefract;
    try {
      var ua = navigator.userAgent || "";
      var chromium = /\b(Chrome|Chromium|Edg|OPR|CEF)\//.test(ua);
      var safari = /^((?!chrome|android).)*safari/i.test(ua);
      canRefract = chromium && !safari && !!window.CSS && !!window.CSS.supports &&
        (CSS.supports("backdrop-filter", "url(#x)") || CSS.supports("-webkit-backdrop-filter", "url(#x)"));
    } catch (e) { canRefract = false; }
    return canRefract;
  }

  var SVGNS = "http://www.w3.org/2000/svg";
  function svgEl(tag, attrs) {
    var el = document.createElementNS(SVGNS, tag);
    for (var k in attrs) if (attrs.hasOwnProperty(k)) el.setAttribute(k, attrs[k]);
    return el;
  }

  var seq = 0, sseq = 0;
  /* standalone-линзы (attachLens) живут в отдельном контейнере: undress()
     при выключении режима удаляет pl-glass-defs целиком и сбрасывает seq */
  function defsHost(hostId) {
    hostId = hostId || "pl-glass-defs";
    var host = document.getElementById(hostId);
    if (!host) {
      host = svgEl("svg", { id: hostId, "aria-hidden": "true", width: "0", height: "0" });
      host.style.position = "absolute";
      host.appendChild(svgEl("defs", {}));
      document.body.appendChild(host);
    }
    return host.firstChild;
  }

  function makeLens(strength, dome, standalone, glassBand) {
    if (!supported()) return { css: null, update: function () { return null; }, node: null };

    function build(map, w, h) {
      var id = standalone ? "pl-slens-" + (++sseq) : "pl-lens-" + (++seq);
      var filter = svgEl("filter", {
        id: id, x: "0", y: "0", width: "100%", height: "100%",
        filterUnits: "objectBoundingBox", primitiveUnits: "userSpaceOnUse",
        "color-interpolation-filters": "sRGB"
      });
      var feImage = svgEl("feImage", {
        result: "map", x: "0", y: "0", preserveAspectRatio: "none",
        width: String(w), height: String(h)
      });
      if (map) {
        feImage.setAttributeNS("http://www.w3.org/1999/xlink", "href", map);
        feImage.setAttribute("href", map);
      }
      filter.appendChild(feImage);
      filter.appendChild(svgEl("feDisplacementMap", {
        "in": "SourceGraphic", in2: "map", xChannelSelector: "R", yChannelSelector: "G",
        scale: String(8 + strength * 60)
      }));
      defsHost(standalone ? "pl-glass-defs-s" : null).appendChild(filter);
      return { id: id, node: filter };
    }

    var first = build(null, 1, 1);
    var lastKey = "";
    var lens = {
      css: "url(#" + first.id + ")",
      node: first.node,
      /* Карта меняется только вместе с размером. Правка feImage на месте
         (href/width у уже применённого фильтра) Chromium в backdrop-filter
         не всегда перерисовывает: у полей, которые одевались до того, как
         раскладка устоялась, оставалась старая карта — светлая размытая
         полоса по ширине, которая была при первом показе. Поэтому на
         новый размер собирается новый фильтр с новым id, а старый
         удаляется. Тот же размер — ничего не трогаем. */
      update: function (w, h, radius, onLoaded) {
        if (w < 4 || h < 4) return null;
        /* ширина полосы преломления у кромки: у Glass (glass.json) —
           max(6, min(w,h)·(0.12 + strength·0.16)) */
        var band = glassBand
          ? Math.max(6, Math.min(w, h) * (0.12 + strength * 0.16))
          : Math.max(5, Math.min(w, h) * (0.14 + strength * 0.2));
        var map = buildLensMap(w, h, radius, band, dome);
        if (!map) return null;
        var key = w + "x" + h + "|" + radius;
        if (key === lastKey) return map;
        lastKey = key;
        var next = build(map, w, h);
        if (lens.node && lens.node.parentNode) lens.node.parentNode.removeChild(lens.node);
        lens.node = next.node;
        lens.css = "url(#" + next.id + ")";
        /* feImage грузит карту асинхронно. Если backdrop-filter успел
           посчитаться с пустой картой, Chromium не пересчитывает его, когда
           картинка догружается, — отсюда светлая размытая полоса в полях
           Layer name / Duration при первом включении стекла. Поэтому после
           загрузки карты (или по таймеру-подстраховке) фильтр один раз
           переприменяется. */
        if (onLoaded) {
          var fired = false, node = next.node;
          var fire = function () {
            if (fired || lens.node !== node) return;
            fired = true;
            onLoaded();
          };
          node.firstChild.addEventListener("load", fire);
          setTimeout(fire, 160);
        }
        return map;
      }
    };
    return lens;
  }

  /* ── применение / снятие режима ──────────────────────────────────── */
  var on = false, dressed = [], mo = null;

  function isLight() {
    return document.documentElement.getAttribute("data-theme") === "light";
  }

  function rimFor(kind) {
    var light = isLight();
    if (kind === "soft") return light ? RIM_LIGHT_SOFT : RIM_SOFT;
    if (kind === "track") return crystal(0.7, light);
    if (kind === "pill") return "inset 0 1px 0 rgba(255,255,255,0.3), 0 2px 10px rgba(0,0,0,0.25)";
    if (kind === "float") return light ? RIM_LIGHT_FLOAT : RIM_FLOAT;
    return light ? RIM_LIGHT : RIM;
  }

  /* Glass-слой (recipe) — absolute-ребёнок; в прокручиваемом контейнере
     (.preset-browser — он же .glass-panel) он уезжал бы вместе со
     строками, а overflow:visible из css/glass.css снял бы прокрутку.
     Такие контейнеры берут следующую подходящую запись SURFACES. */
  var SCROLLERS = ".preset-browser";
  function isScroller(el) {
    /* по классу, а не getComputedStyle: тот на каждую поверхность при
       одевании давал заметную долю фриза включения режима */
    return el.matches(SCROLLERS);
  }

  function cfgFor(el) {
    var scroller = null;
    for (var i = 0; i < SURFACES.length; i++) {
      if (!(el.matches && el.matches(SURFACES[i].sel))) continue;
      if (SURFACES[i].recipe) {
        if (scroller === null) scroller = isScroller(el);
        if (scroller) continue;
      }
      return SURFACES[i];
    }
    return null;
  }

  /* Замер отдельно от записи: общий ResizeObserver сначала меряет все
     изменившиеся поверхности, потом красит — раскладка не пересчитывается
     на каждой. Радиус нужен только линзе и glass-слою. */
  function measure(entry) {
    var el = entry.el;
    var m = { w: el.offsetWidth, h: el.offsetHeight, R: 0 };
    if (entry.chrome || entry.lens.css) {
      m.R = el.__plGeom && !entry.chrome ? el.__plGeom.r
        : (parseFloat(window.getComputedStyle(el).borderTopLeftRadius) || (entry.chrome ? 20 : 12));
    }
    return m;
  }

  function paint(entry, m) {
    var el = entry.el, cfg = entry.cfg, lens = entry.lens;
    m = m || measure(entry);
    var w = m.w, h = m.h;
    if (w < 4 || h < 4) return;
    if (entry.chrome) { paintChrome(entry, w, h, m.R); return; }
    /* У плашек с мягкой геометрией видимая форма задана clip-path, а не
       border-radius — линза строится по тому же радиусу, иначе преломление
       у кромки сидит не на кромке. */
    var radius = m.R || 12;
    var ok = lens.css ? lens.update(w, h, radius, function () {
      if (el.__plEntry !== entry) return;
      var prio2 = prioFor(el), v = el.style.getPropertyValue("backdrop-filter");
      el.style.setProperty("backdrop-filter", "none", prio2);
      el.style.setProperty("-webkit-backdrop-filter", "none", prio2);
      void window.getComputedStyle(el).backdropFilter;
      el.style.setProperty("backdrop-filter", v, prio2);
      el.style.setProperty("-webkit-backdrop-filter", v, prio2);
    }) : null;
    var glassRecipe = cfg.recipe === "glass";
    var tailFx = glassRecipe ? " saturate(1.6)" : " saturate(1.35) brightness(1.03)";
    var value = ok
      ? lens.css + " blur(" + Math.max(cfg.blur, 4) + "px)" + tailFx
      : "blur(" + Math.max(cfg.blur + 4, 8) + "px) saturate(" + (glassRecipe ? "1.6" : "1.35") + ")";
    var prio = prioFor(el);
    el.style.setProperty("backdrop-filter", value, prio);
    el.style.setProperty("-webkit-backdrop-filter", value, prio);
  }

  /* Glass-слой панели: та же форма, что у плашки plate.js (отступ inset,
     радиус r — формулы из plate.js update()), без плашки — весь бокс. */
  function paintChrome(entry, w, h, R) {
    var el = entry.el, cfg = entry.cfg, lens = entry.lens, ch = entry.chrome;
    R = R || 20;
    var inset = el.classList.contains("pl-plated") ? Math.max(2, Math.min(6, Math.min(w, h) * 0.07)) : 0;
    var cw = w - inset * 2, chh = h - inset * 2;
    var r = Math.max(1, Math.min(R - inset, Math.min(cw, chh) / 2));
    ch.style.left = ch.style.top = ch.style.right = ch.style.bottom = inset + "px";
    ch.style.borderRadius = r + "px";
    /* для CSS: содержимое, идущее до краёв (превью Text, зерно, hover-блик),
       обрезается по этой же форме — раньше это делал clip-path плашки */
    el.style.setProperty("--gl-inset", inset + "px");
    el.style.setProperty("--gl-r", r + "px");
    if (cfg.recipe === "surface") {
      var t = cfg.tint;
      var sv = "blur(" + Math.max(3, cfg.blur * (0.4 + t * 0.6)).toFixed(2) + "px) saturate(" +
        (1 + (cfg.sat - 1) * Math.max(t, 0.25)).toFixed(3) + ")";
      ch.style.setProperty("backdrop-filter", sv);
      ch.style.setProperty("-webkit-backdrop-filter", sv);
      el.style.setProperty("backdrop-filter", "none", prioFor(el));
      el.style.setProperty("-webkit-backdrop-filter", "none", prioFor(el));
      return;
    }
    var ok = lens.css ? lens.update(cw, chh, r, function () {
      if (el.__plEntry !== entry) return;
      var v = ch.style.getPropertyValue("backdrop-filter");
      ch.style.setProperty("backdrop-filter", "none");
      ch.style.setProperty("-webkit-backdrop-filter", "none");
      void window.getComputedStyle(ch).backdropFilter;
      ch.style.setProperty("backdrop-filter", v);
      ch.style.setProperty("-webkit-backdrop-filter", v);
    }) : null;
    var value = ok
      ? lens.css + " blur(" + Math.max(cfg.blur, 4) + "px) saturate(1.6)"
      : "blur(" + Math.max(cfg.blur + 4, 8) + "px) saturate(1.6)";
    ch.style.setProperty("backdrop-filter", value);
    ch.style.setProperty("-webkit-backdrop-filter", value);
    var prio = prioFor(el);
    el.style.setProperty("backdrop-filter", "none", prio);
    el.style.setProperty("-webkit-backdrop-filter", "none", prio);
  }

  /* Селекторы поверхностей режима, у которых класс .active переключает
     «выбранное» состояние — карточку пресета, вкладку, сегмент. dress()
     красит их один раз; без этого класс .active продолжает меняться (тот
     же клик, что переключает вкладку/пресет в curves.js/text.js/bounce.js,
     не трогается), а стекло — нет, и «выбранная» плашка визуально не
     отличается от соседних. Проверяется через el.matches(), так что
     список — это подмножество тех же селекторов SURFACES, а не новый. */
  /* .anchor-tile is not here: its selection is one indicator that slides
     between the tiles (js/anchor.js); a tile lighting up on its own showed
     the selection twice while the indicator was on its way */
  var ACTIVE_AWARE = ".settings-tab, .bnc-preset, .curve-preset-row";

  function paintFill(entry) {
    var el = entry.el, cfg = entry.cfg;
    var prio = prioFor(el);
    var activeNow = !!(el.matches && el.matches(ACTIVE_AWARE) &&
      (el.classList.contains("active") || el.classList.contains("on")));
    if (cfg.recipe) activeNow = false; /* выбранное — CSS .pl-gl-glass.active */
    if (activeNow) {
      el.style.setProperty("background-color", "transparent", prio);
      el.style.setProperty("background-image", ACTIVE_FILL, prio);
      el.style.setProperty("box-shadow", ACTIVE_RIM, prio);
    } else if (cfg.recipe) {
      el.style.setProperty("background-color", "transparent", prio);
      el.style.setProperty("background-image", "none", prio);
      el.style.setProperty("box-shadow", "none", prio);
      var ch = entry.chrome;
      if (ch) {
        ch.style.backgroundColor = cfg.recipe === "surface" ? surfaceTint(cfg.tint, isLight()) : glassTint(cfg.tint, isLight());
        ch.style.backgroundImage = isLight() ? GLASS_SHEEN_LIGHT : GLASS_SHEEN;
        ch.style.boxShadow = isLight() ? GLASS_RIM_LIGHT : GLASS_RIM;
      }
    } else {
      var bg = isLight() ? cfg.bgLight : cfg.bg;
      if (bg) el.style.setProperty("background-color", isLight() ? DARKEN_LIGHT : DARKEN, prio);
      el.style.setProperty("background-image", (!isLight() && cfg.sheen) || SHEEN, prio);
      el.style.setProperty("box-shadow", rimFor(cfg.rim), prio);
    }
  }

  function dress(el) {
    if (!el || el.__plGlass) return;
    var cfg = cfgFor(el);
    if (!cfg) return;
    el.__plGlass = true;

    /* инлайн-стили до режима, чтобы вернуть ровно как было */
    el.__plGlassSave = {
      background: el.style.background,
      backgroundColor: el.style.backgroundColor,
      backgroundImage: el.style.backgroundImage,
      boxShadow: el.style.boxShadow,
      backdrop: el.style.backdropFilter,
      webkitBackdrop: el.style.getPropertyValue("-webkit-backdrop-filter")
    };

    var lens = el.matches(LENS_SEL) ? makeLens(cfg.strength, cfg.dome, false, cfg.recipe === "glass") : NO_LENS;
    var entry = { el: el, cfg: cfg, lens: lens, ro: null, chrome: null };
    /* Glass-панель: тон, блик, кромка и линза — на отдельном слое ровно
       по видимой форме плашки (plate.js рисует её с отступом внутрь). На
       самом элементе кромка оказалась бы за его clip-path. */
    if (cfg.recipe) {
      var chrome = document.createElement("span");
      chrome.className = "pl-glass-chrome";
      chrome.setAttribute("aria-hidden", "true");
      el.insertBefore(chrome, el.firstChild);
      el.classList.add("pl-gl-glass");
      entry.chrome = chrome;
    }
    el.__plEntry = entry;
    paintFill(entry);
    /* первую отрисовку делает общий ResizeObserver — он срабатывает до
       ближайшего кадра, пачкой для всех одетых сразу */
    if (sharedRO()) sharedRO().observe(el);
    else paint(entry);
    dressed.push(entry);
  }

  var ro = null;
  function sharedRO() {
    if (ro || !window.ResizeObserver) return ro;
    ro = new ResizeObserver(function (recs) {
      var list = [], i, e;
      for (i = 0; i < recs.length; i++) {
        e = recs[i].target.__plEntry;
        if (e) list.push([e, measure(e)]);   /* 1. только замеры */
      }
      for (i = 0; i < list.length; i++) paint(list[i][0], list[i][1]); /* 2. запись */
    });
    return ro;
  }

  function undress() {
    for (var i = 0; i < dressed.length; i++) {
      var e = dressed[i], el = e.el, s = el.__plGlassSave || {};
      if (ro) ro.unobserve(el);
      if (e.lens && e.lens.node && e.lens.node.parentNode) e.lens.node.parentNode.removeChild(e.lens.node);
      if (e.chrome && e.chrome.parentNode) e.chrome.parentNode.removeChild(e.chrome);
      if (e.chrome) el.classList.remove("pl-gl-glass");
      el.style.background = s.background || "";
      el.style.backgroundColor = s.backgroundColor || "";
      el.style.backgroundImage = s.backgroundImage || "";
      el.style.boxShadow = s.boxShadow || "";
      if (s.backdrop) el.style.backdropFilter = s.backdrop; else el.style.removeProperty("backdrop-filter");
      if (s.webkitBackdrop) el.style.setProperty("-webkit-backdrop-filter", s.webkitBackdrop);
      else el.style.removeProperty("-webkit-backdrop-filter");
      el.__plGlass = false;
      el.__plGlassSave = null;
      el.__plEntry = null;
    }
    dressed = [];
    var host = document.getElementById("pl-glass-defs");
    if (host && host.parentNode) host.parentNode.removeChild(host);
    seq = 0;
  }

  function scan(root) {
    if (!on) return;
    var scope = root && root.querySelectorAll ? root : document;
    if (scope.matches && scope.matches(SEL)) dress(scope);
    var list = scope.querySelectorAll(SEL);
    for (var i = 0; i < list.length; i++) dress(list[i]);
  }

  /* .active/.on переключаются кликами в curves.js/text.js/bounce.js/
     panel.js — тем же кодом, что работал и до режима стекла. Вместо
     правки всех этих мест наблюдаем за классом уже одетых поверхностей и
     перекрашиваем только их. Тот же приём, что уже использует
     glass-switch.js для .switch. */
  var classMo = null;
  function watchActive() {
    if (classMo || !document.body) return;
    classMo = new MutationObserver(function (recs) {
      if (!on) return;
      for (var i = 0; i < recs.length; i++) {
        var el = recs[i].target;
        if (el && el.__plEntry) paintFill(el.__plEntry);
      }
    });
    classMo.observe(document.body, { attributes: true, attributeFilter: ["class"], subtree: true });
  }

  /* панели строят свои строки лениво — дожимаем появившееся позже */
  function observe() {
    if (mo || !document.body) return;
    mo = new MutationObserver(function (recs) {
      if (!on) return;
      for (var i = 0; i < recs.length; i++) {
        var added = recs[i].addedNodes;
        for (var j = 0; j < added.length; j++) {
          if (added[j].nodeType === 1) scan(added[j]);
        }
      }
    });
    mo.observe(document.body, { childList: true, subtree: true });
  }

  /* тема меняется живьём — от темы зависят только тон, блик и кромка
     (paintFill); линзы, слои и наблюдатели остаются как есть. Раньше тут
     было полное снятие и повторное одевание всех поверхностей — именно
     оно и давало долгий фриз на кнопке темы. */
  function watchTheme() {
    var tm = new MutationObserver(function () {
      if (!on) return;
      for (var i = 0; i < dressed.length; i++) paintFill(dressed[i]);
    });
    tm.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
  }

  /* ── состояние режима ────────────────────────────────────────────── */
  function read() {
    /* first run (nothing saved yet): on — people meet Pillow in its glass */
    try { return window.localStorage.getItem(KEY) !== "off"; } catch (e) { return true; }
  }
  function save(next) {
    try { window.localStorage.setItem(KEY, next ? "on" : "off"); } catch (e) {}
  }

  function apply(next) {
    on = !!next;
    var root = document.documentElement;
    root.setAttribute(ATTR, on ? "on" : "off");
    root.setAttribute("data-pl-glass-refract", on && supported() ? "on" : "off");
    if (on) { observe(); watchActive(); scan(document); }
    else undress();
    /* радиус плашек в стеклянном режиме другой — пересобираем силуэт */
    if (window.PillowPlate && window.PillowPlate.refresh) {
      requestAnimationFrame(function () { window.PillowPlate.refresh(); });
    }
  }

  function setEnabled(next, persist) {
    apply(next);
    if (persist !== false) save(on);
  }

  function boot() {
    apply(read());
    watchTheme();
  }

  /* сохранённый режим встаёт на место до первой отрисовки */
  document.documentElement.setAttribute(ATTR, read() ? "on" : "off");

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }

  /* Постоянная стеклянная поверхность вне режима Liquid Glass — для
     компонентов, которые стеклянные всегда (GlassInput, js/glass-input.js):
     та же линза (преломление у кромки) + блюр, пересчёт по размеру. */
  function attachLens(el, opts) {
    opts = opts || {};
    var blur = opts.blur != null ? opts.blur : 12;
    var tail = " blur(" + blur + "px) saturate(" + (opts.saturate || 1.5) + ")";
    var lens = makeLens(opts.strength != null ? opts.strength : 0.5, opts.dome || 0, true, !!opts.glassBand);
    function apply(v) {
      el.style.setProperty("backdrop-filter", v);
      el.style.setProperty("-webkit-backdrop-filter", v);
    }
    function paintIt() {
      var w = el.offsetWidth, h = el.offsetHeight;
      if (w < 4 || h < 4) return;
      var r = parseFloat(window.getComputedStyle(el).borderTopLeftRadius) || h / 2;
      r = Math.min(r, w / 2, h / 2);
      var ok = lens.css ? lens.update(w, h, r, function () {
        apply("none"); void window.getComputedStyle(el).backdropFilter; apply(lens.css + tail);
      }) : null;
      apply(ok ? lens.css + tail : tail.slice(1));
    }
    paintIt();
    if (window.ResizeObserver) new ResizeObserver(paintIt).observe(el);
    return { repaint: paintIt };
  }

  window.PillowGlass = {
    /* оформление Glass для компонентов (GlassDock и др.) */
    chrome: function () {
      var light = isLight();
      return { rim: light ? GLASS_RIM_LIGHT : GLASS_RIM, sheen: light ? GLASS_SHEEN_LIGHT : GLASS_SHEEN, tint: function (t) { return glassTint(t, light); } };
    },
    attachLens: attachLens,
    isOn: function () { return on; },
    setEnabled: setEnabled,
    toggle: function () { setEnabled(!on); return on; },
    scan: scan,
    /* paint one dressed element again (its shape changed without a resize) */
    repaint: function (el) {
      var e = el && el.__plEntry;
      if (!e) return;
      if (ro) { ro.unobserve(el); ro.observe(el); } else paint(e, measure(e));
    },
    supported: supported
  };
})();
