/* Pillow — GlassInput (порт websiteglass.com/r/glass-input.json).
 *
 * Как в оригинале: поле ввода прозрачное, весь вид даёт стеклянная
 * капсула вокруг него — GlassSurface из glass.json (frosted-панель без
 * преломления: blur + tint + блик + кромка, значения — в css/panel.css):
 *
 *   <GlassSurface tint radius=9999>          → span.pl-gi
 *     <div focus glow ring />                → span.pl-gi-glow
 *     <div flex items-center gap-2.5 px-4>   → span.pl-gi-row
 *       <span icon text-white/35 />          → span.pl-gi-icon (у поиска)
 *       <input bg-transparent … />           → сам input.field-input
 *
 * Фокус: кольцо проявляется за 200 мс, иконка 0.35 → 0.55, тон
 * поверхности поднимается на 0.1 (setTintLift(0.1)). Всё это — классом
 * .is-focused на капсуле, стили — в css/panel.css (блок GlassInput).
 *
 * Разметка страницы не меняется: input только оборачивается, его id,
 * атрибуты и обработчики остаются на месте.
 */
(function () {
  "use strict";
  if (window.PillowGlassInput) return;

  /* Lucide Search (className="size-4" → 16px), как в примере GlassInput */
  var SEARCH_ICON =
    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" ' +
    'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
    '<circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.3-4.3"></path></svg>';

  function upgrade(input) {
    if (input.__gi || !input.parentNode) return;
    input.__gi = true;

    var surface = document.createElement("span");
    surface.className = "pl-gi";
    var glow = document.createElement("span");
    glow.className = "pl-gi-glow";
    glow.setAttribute("aria-hidden", "true");
    var row = document.createElement("span");
    row.className = "pl-gi-row";

    input.parentNode.insertBefore(surface, input);
    surface.appendChild(glow);
    surface.appendChild(row);
    if (input.type === "search") {
      var icon = document.createElement("span");
      icon.className = "pl-gi-icon";
      icon.innerHTML = SEARCH_ICON;
      row.appendChild(icon);
    }
    row.appendChild(input);

    input.addEventListener("focus", function () { surface.classList.add("is-focused"); });
    input.addEventListener("blur", function () { surface.classList.remove("is-focused"); });
    /* клик по капсуле мимо текста (иконка, поля) — фокус в поле */
    surface.addEventListener("mousedown", function (e) {
      if (e.target !== input) { e.preventDefault(); input.focus(); }
    });

  }

  function scan(root) {
    var list = (root || document).querySelectorAll ? (root || document).querySelectorAll("input.field-input") : [];
    for (var i = 0; i < list.length; i++) upgrade(list[i]);
  }

  function boot() {
    scan(document);
    new MutationObserver(function (recs) {
      for (var i = 0; i < recs.length; i++) {
        var added = recs[i].addedNodes;
        for (var j = 0; j < added.length; j++) {
          var n = added[j];
          if (n.nodeType !== 1 || n.classList.contains("pl-gi")) continue;
          if (n.matches && n.matches("input.field-input")) upgrade(n);
          else scan(n);
        }
      }
    }).observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  window.PillowGlassInput = { scan: scan };
})();
