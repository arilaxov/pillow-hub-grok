/* Pillow — Carousel (Library → Pillow Presets)
 *
 * The selected layers go round in one of four shapes: a ring (Radial), a
 * ball (Spherical), a loop round a rectangle (Rectangular) or along a
 * line bent by three points (Curved Line). The preview draws exactly what
 * the host's expressions do (host/pillow.jsx, pillowCarExpr): the same
 * places, the same turn, the same way each picture faces. On the Curved
 * Line the three points are dragged right on the preview; they become the
 * controller's mask "Carousel Path" in After Effects.
 */
(function () {
  "use strict";
  if (window.PillowGrid3D) return;

  var CELL = 46, F = 820;
  var DEF = { style: "radial", size: 100, spread: 360, aspect: 160, tilt: 25, speed: 20, gap: 18, mid: 190, face: 1, faces: { radial: 1, rect: 1, sphere: 2 }, blur: true,
    blend: false, blendDur: 1.2, blendStagger: 0.06,
    pts: [[0.12, 0.7], [0.5, 0.6], [0.88, 0.3]] };
  var FACES = { radial: ["Forward", "Screen", "Center"], rect: ["Forward", "Screen", "Center"], sphere: ["Inward", "Outward", "Screen"] };
  var HINTS = {
    shape: "Select two or more layers. Every setting lands on the “Carousel (Pillow)” layer — change or keyframe it there. Select the layers (or that layer) and press again to update.",
    curve: "Drag the three points to bend the line; the middle one makes the pictures bigger. The line becomes the mask “Carousel Path” on the “Carousel (Pillow)” layer — edit it there, or here and press again."
  };
  var o = {}, k0;
  function copyDef() { for (var k in DEF) o[k] = typeof DEF[k] === "object" ? JSON.parse(JSON.stringify(DEF[k])) : DEF[k]; }
  /* each style keeps its own facing (Spherical starts facing out) */
  function syncFace() { if (o.faces[o.style]) o.face = o.faces[o.style]; }
  copyDef();
  var raf = 0, last = 0, built = false, active = false;
  /* the preview eases to the settings, so a slider move reads as motion */
  var cur = null, spin = 0, drag = -1, hover = -1, morph = 1, bt = 0;
  /* "From my animation": the pictures start as a plain grid (the user's
     own layout) and each one glides into the carousel, a stagger apart,
     on the host's Mix ease (0.65, 0, 0.35, 1); then it starts over */
  var mixEase = null;
  function mixOf(k, N) {
    if (!o.blend) return 1;
    if (!mixEase) mixEase = cubic(0.65, 0, 0.35, 1);
    var x = (bt - 0.7 - k * cur.blendStagger) / Math.max(0.1, cur.blendDur);
    return x <= 0 ? 0 : x >= 1 ? 1 : mixEase(x);
  }
  function cubic(x1, y1, x2, y2) {
    return function (x) {
      var lo = 0, hi = 1, u = x;
      for (var i = 0; i < 22; i++) { u = (lo + hi) / 2; if (3 * x1 * u * (1 - u) * (1 - u) + 3 * x2 * u * u * (1 - u) + u * u * u < x) lo = u; else hi = u; }
      return 3 * y1 * u * (1 - u) * (1 - u) + 3 * y2 * u * u * (1 - u) + u * u * u;
    };
  }
  /* the grid tile k of N on the stage, as four corners */
  function gridQuad(k, N, W, H) {
    var cols = Math.ceil(N / 2), rows = Math.ceil(N / cols);
    var sz = Math.min((W - 40) / cols, (H - 40) / rows) * 0.7, gap = sz * 0.3;
    var x0 = W / 2 - (cols * sz + (cols - 1) * gap) / 2, y0 = H / 2 - (rows * sz + (rows - 1) * gap) / 2;
    var cx = x0 + (k % cols) * (sz + gap), cy = y0 + Math.floor(k / cols) * (sz + gap);
    return [[cx, cy], [cx + sz, cy], [cx + sz, cy + sz], [cx, cy + sz]];
  }
  function lerpQ(a, b, m) {
    if (m >= 1) return b;
    var q = [];
    for (var i = 0; i < 4; i++) q.push([a[i][0] + (b[i][0] - a[i][0]) * m, a[i][1] + (b[i][1] - a[i][1]) * m]);
    return q;
  }

  function $(id) { return document.getElementById(id); }
  function D2R(x) { return x * Math.PI / 180; }
  function n() { return o.style === "curve" ? 7 : 8; }

  /* host: pillowCarRadius */
  function radius(N) {
    var c = CELL;
    if (o.style === "sphere") return Math.max(c * 0.9, c * Math.sqrt(N * 2.2 / (4 * Math.PI)));
    if (o.style === "rect") return Math.max(c * 0.9, N * c * 0.1625);
    return Math.max(N * c * 1.15 / (2 * Math.PI), c * 0.9);
  }

  /* the curve: the mask's three points with the host's tangents
     (pillowCarPath), sampled for its length (pointOnPath) */
  function curvePoly(P) {
    var m1 = [(P[2][0] - P[0][0]) / 6, (P[2][1] - P[0][1]) / 6];
    var seg = [
      [P[0], [P[0][0] + (P[1][0] - P[0][0]) / 3, P[0][1] + (P[1][1] - P[0][1]) / 3], [P[1][0] - m1[0], P[1][1] - m1[1]], P[1]],
      [P[1], [P[1][0] + m1[0], P[1][1] + m1[1]], [P[2][0] + (P[1][0] - P[2][0]) / 3, P[2][1] + (P[1][1] - P[2][1]) / 3], P[2]]
    ];
    var poly = [], cum = [0], s, i;
    for (s = 0; s < 2; s++) {
      var a = seg[s][0], b = seg[s][1], c = seg[s][2], d = seg[s][3];
      for (i = s ? 1 : 0; i <= 40; i++) {
        var u = i / 40, m = 1 - u;
        poly.push([m * m * m * a[0] + 3 * m * m * u * b[0] + 3 * m * u * u * c[0] + u * u * u * d[0],
          m * m * m * a[1] + 3 * m * m * u * b[1] + 3 * m * u * u * c[1] + u * u * u * d[1]]);
      }
    }
    for (i = 1; i < poly.length; i++) cum.push(cum[i - 1] + Math.hypot(poly[i][0] - poly[i - 1][0], poly[i][1] - poly[i - 1][1]));
    return { poly: poly, cum: cum, L: Math.max(1, cum[cum.length - 1]) };
  }
  function onPath(C, u) {
    var tl = Math.max(0, Math.min(1, u)) * C.L, i = 1;
    while (i < C.cum.length - 1 && C.cum[i] < tl) i++;
    var f = (tl - C.cum[i - 1]) / ((C.cum[i] - C.cum[i - 1]) || 1), a = C.poly[i - 1], b = C.poly[i];
    return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f];
  }
  /* the stage area the three points (0..1) map to */
  function box(W, H) { var pad = 22; return { x: pad, y: pad, w: W - pad * 2, h: H - pad * 2 }; }

  /* place k of N, after pillowCarExpr: [position, front direction, scale, alpha] */
  function place(k, N, R, v) {
    var t = D2R(cur.tilt), F1 = Math.round(o.face);
    function tl(p) { return [p[0], p[1] * Math.cos(t) + p[2] * Math.sin(t), -p[1] * Math.sin(t) + p[2] * Math.cos(t)]; }
    var P, D, screen = 2;
    if (o.style === "radial") {
      var sa = cur.spread, full = sa >= 359.9, st = full ? 360 / N : (N > 1 ? sa / (N - 1) : 0);
      var a = D2R(v + (full ? k * st : (k - (N - 1) / 2) * st));
      P = tl([R * Math.sin(a), -R * Math.cos(a), 0]);
      D = F1 === 1 ? tl([0, 0, -1]) : tl([-Math.sin(a), Math.cos(a), 0]);
    } else if (o.style === "sphere") {
      screen = 3;
      var y = N > 1 ? 1 - 2 * (k + 0.5) / N : 0, r = Math.sqrt(Math.max(0, 1 - y * y)), ph = k * 2.39996323 + D2R(v);
      var u = tl([r * Math.sin(ph), y, -r * Math.cos(ph)]);
      P = [u[0] * R, u[1] * R, u[2] * R];
      D = F1 === 1 ? [-u[0], -u[1], -u[2]] : u;
    } else {
      var as = Math.max(0.05, cur.aspect / 100), A = R * Math.sqrt(as), B = R / Math.sqrt(as);
      var s = (((k / N + v / 360) % 1) + 1) % 1 * 4 * (A + B), x, yy, nx = 0, ny = 0;
      if (s < 2 * A) { x = -A + s; yy = -B; ny = -1; }
      else if (s < 2 * A + 2 * B) { x = A; yy = -B + s - 2 * A; nx = 1; }
      else if (s < 4 * A + 2 * B) { x = A - (s - 2 * A - 2 * B); yy = B; ny = 1; }
      else { x = -A; yy = B - (s - 4 * A - 2 * B); nx = -1; }
      P = tl([x, yy, 0]);
      D = F1 === 1 ? tl([0, 0, -1]) : tl([-nx, -ny, 0]);
    }
    if (F1 === screen) D = [0, 0, -1];
    return [P, D];
  }

  function frame(now) {
    var cv = $("g3d-stage");
    if (!cv || !cv.offsetParent || !active) { raf = 0; last = 0; return; }
    /* asleep while nobody looks at the panel (js/presence.js) */
    if (window.PillowPresence && !window.PillowPresence.awake()) { raf = 0; last = 0; window.PillowPresence.onWake(kick); return; }
    var dpr = Math.min(2, window.devicePixelRatio || 1), W = cv.clientWidth, H = cv.clientHeight;
    if (cv.width !== Math.round(W * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
    var t = now / 1000, dt = last ? Math.min(0.05, t - last) : 1 / 60; last = t;
    var k;
    for (k in cur) {
      var to = o[k];
      if (typeof to !== "number") continue;
      var nx = cur[k] + (to - cur[k]) * Math.min(1, dt * 9);
      cur[k] = Math.abs(nx - to) < 0.01 ? to : nx;
    }
    morph = Math.min(1, morph + dt * 3.2);
    if (o.blend) {
      bt += dt;
      if (bt > 0.7 + cur.blendDur + cur.blendStagger * (n() - 1) + 2.2) bt = 0;
    }
    spin += dt * cur.speed;
    var ctx = cv.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    var light = document.documentElement.getAttribute("data-theme") === "light";
    var N = n(), list = [], i;
    ctx.globalAlpha = 0.35 + 0.65 * (1 - Math.pow(1 - morph, 3));
    if (o.style === "curve") drawCurve(ctx, W, H, N, light, dpr);
    else {
      var R = radius(N) * cur.size / 100;
      var fit = Math.min(W, H) / (2 * (R * 1.05 + CELL) + 30) * 1.25;
      fit = Math.min(fit, (W - 40) / (2 * (R * (o.style === "rect" ? Math.sqrt(cur.aspect / 100) : 1) + CELL)));
      for (i = 0; i < N; i++) {
        var pl = place(i, N, R, spin), P = pl[0], D = pl[1];
        var q = quad(P, D, CELL / 2, W, H, fit), mk = mixOf(i, N);
        if (q && mk < 1) q = lerpQ(gridQuad(i, N, W, H), q, mk);
        if (q) list.push({ i: i, q: q, z: P[2] * mk });
      }
      list.sort(function (x, y) { return y.z - x.z; });
      for (i = 0; i < list.length; i++) card(ctx, list[i].q, list[i].i, light, list[i].z, radius(N) * cur.size / 100);
    }
    ctx.globalAlpha = 1;
    raf = requestAnimationFrame(frame);
  }
  /* the four corners of a picture at P looking along D (lookAt: no roll) */
  function quad(P, D, hw, W, H, fit) {
    var f = [-D[0], -D[1], -D[2]], l = Math.hypot(f[0], f[1], f[2]) || 1;
    f = [f[0] / l, f[1] / l, f[2] / l];
    var h = Math.hypot(f[0], f[2]), xa = h > 1e-4 ? [f[2] / h, 0, -f[0] / h] : [1, 0, 0];
    var ya = [f[1] * xa[2] - f[2] * xa[1], f[2] * xa[0] - f[0] * xa[2], f[0] * xa[1] - f[1] * xa[0]];
    var lc = [[-1, -1], [1, -1], [1, 1], [-1, 1]], q = [], c;
    for (c = 0; c < 4; c++) {
      var p = [P[0] + (xa[0] * lc[c][0] + ya[0] * lc[c][1]) * hw, P[1] + (xa[1] * lc[c][0] + ya[1] * lc[c][1]) * hw, P[2] + (xa[2] * lc[c][0] + ya[2] * lc[c][1]) * hw];
      var zz = F + p[2];
      if (zz < 80) return null;
      var pr = F / zz * fit;
      q.push([W / 2 + p[0] * pr, H / 2 + p[1] * pr]);
    }
    return q;
  }
  function drawCurve(ctx, W, H, N, light, dpr) {
    var b = box(W, H), P = [], i;
    for (i = 0; i < 3; i++) P.push([b.x + o.pts[i][0] * b.w, b.y + o.pts[i][1] * b.h]);
    var C = curvePoly(P), cell = CELL * 0.62;
    /* the line */
    ctx.save();
    ctx.setLineDash([3, 4]);
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = light ? "rgba(0,0,0,0.3)" : "rgba(255,255,255,0.32)";
    ctx.beginPath();
    for (i = 0; i < C.poly.length; i++) { if (i) ctx.lineTo(C.poly[i][0], C.poly[i][1]); else ctx.moveTo(C.poly[i][0], C.poly[i][1]); }
    ctx.stroke();
    ctx.restore();
    /* the pictures (host: the curve expressions) */
    var sp = Math.max(1, cell * (1 + cur.gap / 100)), per = Math.max(C.L, N * sp), list = [];
    for (i = 0; i < N; i++) {
      var d = C.L / 2 + (i - (N - 1) / 2) * sp + spin / 360 * C.L;
      d = ((d % per) + per) % per;
      var pt = onPath(C, Math.min(1, d / C.L));
      var w = Math.max(0, 1 - Math.hypot(pt[0] - P[1][0], pt[1] - P[1][1]) / (C.L / 2)); w = w * w * (3 - 2 * w);
      var sc = 1 + (cur.mid / 100 - 1) * w, al = d > C.L ? 0 : Math.max(0, Math.min(1, Math.min(d, C.L - d) / (sp * 0.5)));
      if (al <= 0 && mixOf(i, N) >= 1) continue;
      var hw = cell / 2 * sc;
      var mk = mixOf(i, N), cq = [[pt[0] - hw, pt[1] - hw], [pt[0] + hw, pt[1] - hw], [pt[0] + hw, pt[1] + hw], [pt[0] - hw, pt[1] + hw]];
      list.push({ i: i, z: -w * mk, a: 1 - mk + mk * al, q: mk < 1 ? lerpQ(gridQuad(i, N, W, H), cq, mk) : cq });
    }
    list.sort(function (x, y) { return y.z - x.z; });
    var ga = ctx.globalAlpha;
    for (i = 0; i < list.length; i++) { ctx.globalAlpha = ga * list[i].a; card(ctx, list[i].q, list[i].i, light, 60 * list[i].z, 60); }
    ctx.globalAlpha = ga;
    /* the three handles */
    for (i = 0; i < 3; i++) {
      var on = drag === i || hover === i;
      ctx.beginPath();
      ctx.arc(P[i][0], P[i][1], on ? 7 : 5.5, 0, Math.PI * 2);
      ctx.fillStyle = light ? "#ffffff" : "#1c1c1e";
      ctx.fill();
      ctx.lineWidth = 1.6;
      ctx.strokeStyle = getAccent();
      ctx.stroke();
    }
  }
  var accent = "", accentOf = null;
  function getAccent() {
    var th = document.documentElement.getAttribute("data-theme");
    if (accentOf !== th) {
      accentOf = th;
      try { accent = getComputedStyle(document.documentElement).getPropertyValue("--m-accent").trim() || "#ffffff"; } catch (e) { accent = "#ffffff"; }
    }
    return accent;
  }
  /* one plain colour, the theme's ink: near tiles full, far ones fade
     toward the stage (solid, so overlaps stay clean) */
  function card(ctx, q, idx, light, z, R) {
    var near = Math.max(0, Math.min(1, 0.5 - z / (2.4 * R + 1)));
    var lo = light ? [196, 196, 201] : [72, 72, 76], hi = light ? [28, 28, 30] : [242, 242, 247], c = [];
    for (var j = 0; j < 3; j++) c.push(Math.round(lo[j] + (hi[j] - lo[j]) * (0.25 + 0.75 * near)));
    ctx.beginPath();
    for (var k = 0; k < 4; k++) {
      var a = q[k], b2 = q[(k + 1) % 4], pv = q[(k + 3) % 4];
      var m1 = [a[0] + (pv[0] - a[0]) * 0.24, a[1] + (pv[1] - a[1]) * 0.24], m2 = [a[0] + (b2[0] - a[0]) * 0.24, a[1] + (b2[1] - a[1]) * 0.24];
      if (k === 0) ctx.moveTo(m1[0], m1[1]); else ctx.lineTo(m1[0], m1[1]);
      ctx.quadraticCurveTo(a[0], a[1], m2[0], m2[1]);
    }
    ctx.closePath();
    ctx.fillStyle = "rgb(" + c.join(",") + ")";
    ctx.fill();
  }
  function kick() { if (!raf && active) { last = 0; raf = requestAnimationFrame(frame); } }

  /* ── dragging the three points ── */
  function stagePt(e) {
    var cv = $("g3d-stage"), r = cv.getBoundingClientRect();
    return [e.clientX - r.left, e.clientY - r.top, r.width, r.height];
  }
  function hit(e) {
    if (o.style !== "curve") return -1;
    var s = stagePt(e), b = box(s[2], s[3]), best = -1, bd = 16;
    for (var i = 0; i < 3; i++) {
      var d = Math.hypot(b.x + o.pts[i][0] * b.w - s[0], b.y + o.pts[i][1] * b.h - s[1]);
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }
  function bindDrag(cv) {
    cv.addEventListener("pointerdown", function (e) {
      var h = hit(e);
      if (h < 0) return;
      e.preventDefault();
      drag = h;
      try { cv.setPointerCapture(e.pointerId); } catch (x) {}
      cv.classList.add("is-drag");
      kick();
    });
    cv.addEventListener("pointermove", function (e) {
      if (drag < 0) {
        var h = hit(e);
        if (h !== hover) { hover = h; cv.classList.toggle("is-grab", h >= 0); kick(); }
        return;
      }
      var s = stagePt(e), b = box(s[2], s[3]);
      o.pts[drag] = [Math.round(Math.max(0, Math.min(1, (s[0] - b.x) / b.w)) * 1000) / 1000,
        Math.round(Math.max(0, Math.min(1, (s[1] - b.y) / b.h)) * 1000) / 1000];
      kick();
    });
    var up = function () { if (drag < 0) return; drag = -1; cv.classList.remove("is-drag"); save(); };
    cv.addEventListener("pointerup", up);
    cv.addEventListener("pointercancel", up);
    cv.addEventListener("pointerleave", function () { if (hover >= 0 && drag < 0) { hover = -1; cv.classList.remove("is-grab"); } });
  }

  var SL = [
    ["g3d-size", "size", function (v) { return v + "%"; }],
    ["g3d-spread", "spread", function (v) { return v + "°"; }],
    ["g3d-aspect", "aspect", function (v) { return v + "%"; }],
    ["g3d-tilt", "tilt", function (v) { return v + "°"; }],
    ["g3d-gap", "gap", function (v) { return v + "%"; }],
    ["g3d-mid", "mid", function (v) { return v + "%"; }],
    ["g3d-speed", "speed", function (v) { return v ? v + "°/s" : "—"; }],
    ["g3d-bdur", "blendDur", function (v) { return v.toFixed(1) + "s"; }],
    ["g3d-bstag", "blendStagger", function (v) { return Math.round(v * 1000) + "ms"; }]
  ];
  function tr(s) { return window.PillowI18n && window.PillowI18n.tr ? window.PillowI18n.tr(s) : s; }
  function paint() {
    var i;
    for (i = 0; i < SL.length; i++) {
      var el = $(SL[i][0]);
      if (document.activeElement !== el) el.value = o[SL[i][1]];
      $(SL[i][0] + "-val").textContent = SL[i][2](o[SL[i][1]]);
    }
    var b = $("g3d-blur");
    b.classList.toggle("on", !!o.blur); b.setAttribute("aria-checked", o.blur ? "true" : "false");
    var bl = $("g3d-blend");
    bl.classList.toggle("on", !!o.blend); bl.setAttribute("aria-checked", o.blend ? "true" : "false");
    var brs = document.querySelectorAll("#g3d [data-blend]");
    for (i = 0; i < brs.length; i++) brs[i].hidden = !o.blend;
    var st = document.querySelectorAll("#g3d-styles [data-style]");
    for (i = 0; i < st.length; i++) {
      var on = st[i].getAttribute("data-style") === o.style;
      st[i].classList.toggle("active", on); st[i].setAttribute("aria-checked", on ? "true" : "false");
    }
    var rows = document.querySelectorAll("#g3d [data-for]");
    for (i = 0; i < rows.length; i++) rows[i].hidden = (" " + rows[i].getAttribute("data-for") + " ").indexOf(" " + o.style + " ") < 0;
    var names = FACES[o.style], fb = document.querySelectorAll("#g3d-face [data-face]");
    for (i = 0; i < fb.length && names; i++) {
      fb[i].textContent = tr(names[i]);
      fb[i].classList.toggle("active", o.face === i + 1);
    }
    $("g3d-hint").textContent = tr(o.style === "curve" ? HINTS.curve : HINTS.shape);
    $("g3d-stage").classList.toggle("is-curve", o.style === "curve");
  }
  function save() { try { localStorage.setItem("pillow.carousel", JSON.stringify(o)); } catch (e) {} }
  function load() {
    try {
      var d = JSON.parse(localStorage.getItem("pillow.carousel") || "null");
      if (d) for (var k in o) if (typeof d[k] === typeof o[k]) o[k] = d[k];
      if (!(o.pts instanceof Array) || o.pts.length !== 3) o.pts = JSON.parse(JSON.stringify(DEF.pts));
      if (!FACES[o.style] && o.style !== "curve") o.style = "radial";
      if (!o.faces || typeof o.faces !== "object") o.faces = JSON.parse(JSON.stringify(DEF.faces));
      syncFace();
    } catch (e) {}
  }

  function apply() {
    if (typeof window.host !== "function") return;
    var payload = JSON.stringify(o);
    window.host('pillowRing("' + payload.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '")', function (r) {
      if (!r || !r.ok) { if (window.toast) window.toast((r && r.error) || "Couldn't make the carousel", true); return; }
      if (window.toast) window.toast(r.count + " layers on the carousel · tweak it on “" + r.controller + "”");
    });
  }

  function build() {
    if (built || !$("g3d")) return;
    built = true;
    load();
    cur = {}; for (var k in o) cur[k] = o[k];
    SL.forEach(function (d) {
      $(d[0]).addEventListener("input", function () { o[d[1]] = parseFloat($(d[0]).value); paint(); save(); kick(); });
    });
    $("g3d-blur").addEventListener("click", function () { o.blur = !o.blur; paint(); save(); });
    $("g3d-blend").addEventListener("click", function () { o.blend = !o.blend; bt = 0; paint(); save(); kick(); });
    $("g3d-styles").addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-style]") : null;
      if (!b || b.getAttribute("data-style") === o.style) return;
      o.style = b.getAttribute("data-style");
      syncFace();
      morph = 0;
      paint(); save(); kick();
    });
    $("g3d-face").addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-face]") : null;
      if (!b) return;
      o.face = parseInt(b.getAttribute("data-face"), 10);
      o.faces[o.style] = o.face;
      paint(); save(); kick();
    });
    $("g3d-reset").addEventListener("click", function () { var s = o.style; copyDef(); o.style = s; syncFace(); paint(); save(); kick(); });
    $("btn-g3d").addEventListener("click", apply);
    bindDrag($("g3d-stage"));
    paint();
  }

  window.PillowGrid3D = {
    show: function () { build(); active = true; kick(); },
    hide: function () { active = false; },
    _o: o
  };
})();
