/* Pillow Music — Auto Beat detection */
(function () {
  var sensitivity = 50;
  var gap = 120;
  var clearMarkers = true;

  function $(id) { return document.getElementById(id); }

  function updateLabels() {
    var s = $("music-sensitivity-val"), g = $("music-gap-val");
    if (s) s.textContent = sensitivity + "%";
    if (g) g.textContent = gap + "ms";
  }

  function refresh() {
    refreshBeats();
    host("pillowGetAudioSelection()", function (r) {
      var el = $("music-target");
      if (!el) return;
      if (!r.ok || !r.name) {
        el.textContent = "Select an audio or video layer with sound";
        el.style.color = "var(--bad)";
      } else {
        el.textContent = r.name;
        el.style.color = "var(--fg-dim)";
      }
    });
  }

  function refreshBeats() {
    host("pillowBeatInfo()", function (r) {
      var el = $("bs-source");
      if (!el) return;
      if (r && r.ok) { el.textContent = r.count + " beats · " + r.source; el.classList.remove("is-empty"); }
      else { el.textContent = (r && r.error) || "No beat markers yet"; el.classList.add("is-empty"); }
    });
  }

  function done(btn, r) {
    btn.disabled = false;
    btn.textContent = btn._label;
    if (!r || !r.ok) { toast((r && r.error) || "Beat detection failed", true); return; }
    toast("Added " + (r.count || 0) + " beat markers");
    refreshBeats();
  }

  /* AE's own route, for audio the panel can't read */
  function viaAE(btn) {
    host("pillowAddBeatMarkers(" + (sensitivity / 100) + "," + gap + "," + (clearMarkers ? "true" : "false") + ")", function (r) { done(btn, r); });
  }

  function detect(btn) {
    btn._label = btn._label || btn.textContent;
    btn.disabled = true;
    btn.textContent = "Listening…";
    host("pillowBeatAudioInfo()", function (info) {
      if (!info || !info.ok) { done(btn, info); return; }
      var D = window.PillowBeatDetect;
      /* time-remapped or reversed layers: their source time isn't a
         straight line, so AE's amplitude route maps them */
      if (!D || !info.file || info.remap || !(info.stretch > 0)) { viaAE(btn); return; }
      D.analyseFile(info.file, { sensitivity: sensitivity / 100, gap: gap / 1000 }, function (err, src) {
        if (err) { viaAE(btn); return; }
        var k = info.stretch / 100, times = [];
        for (var i = 0; i < src.length; i++) {
          var t = info.start + src[i] * k;
          if (t >= info.inPoint - 0.001 && t < info.outPoint) times.push(Math.round(t * 1000) / 1000);
        }
        var arg = JSON.stringify({ index: info.index, name: info.name, times: times, clear: clearMarkers });
        host('pillowSetBeatMarkers("' + encodeURIComponent(arg) + '")', function (r) { done(btn, r); });
      });
    });
  }

  function init() {
    var s = $("music-sensitivity");
    if (s) s.oninput = function () { sensitivity = parseInt(this.value, 10) || 50; updateLabels(); };
    var g = $("music-gap");
    if (g) g.oninput = function () { gap = parseInt(this.value, 10) || 120; updateLabels(); };

    var sw = $("toggle-music-clear");
    if (sw) sw.onclick = function () {
      clearMarkers = !clearMarkers;
      this.className = "switch" + (clearMarkers ? " on" : "");
      this.setAttribute("aria-checked", clearMarkers ? "true" : "false");
    };

    var btn = $("btn-music-beats");
    if (btn) btn.onclick = function () { if (!btn.disabled) detect(btn); };
    updateLabels();
    /* no AE call at start-up: the Music tab refreshes when it is opened */
  }

  window.PillowMusic = { init: init, refresh: refresh };
})();
