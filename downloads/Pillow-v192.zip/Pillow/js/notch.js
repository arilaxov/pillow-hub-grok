/* Pillow — the notch.
 *
 * A capsule in the middle of the header with the Pillow cushion in it,
 * made of the same material as the rest of Pillow (dark / light plate,
 * or glass in Liquid Glass mode). The cushion is alive: it breathes
 * while After Effects is idle, hops after a Pillow action and wobbles if
 * you tap it too fast. A tap opens it, on springs, into a card:
 *
 *   Today — how long you worked in After Effects today, per project, the
 *           week at a glance and how many Pillow actions you ran; the
 *           summary copies as text for a client or a time sheet.
 *   Tip   — one After Effects / Pillow tip a day (and the rest on demand).
 *   Share — send any preset as a short text code, or paste a friend's
 *           code and the preset lands in your Library.
 *
 * Time counts only while something is happening: every 30 s the host
 * reports a fingerprint of the open project (comp, playhead, selection,
 * edits …); with no change for 5 minutes, and no use of the panel, the
 * clock stops and the cushion falls asleep.
 */
(function () {
  "use strict";
  if (window.PillowNotch) return;

  var $ = function (id) { return document.getElementById(id); };
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function escHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; });
  }
  function pad(n) { return n < 10 ? "0" + n : "" + n; }
  function dayKey(d) { d = d || new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
  function fmt(sec) {
    var m = Math.floor(sec / 60), h = Math.floor(m / 60);
    if (h) return h + "h " + pad(m % 60) + "m";
    return m + "m";
  }
  function fmtLong(sec) {
    var m = Math.floor(sec / 60), h = Math.floor(m / 60);
    if (h) return h + " h " + (m % 60) + " min";
    return m + " min";
  }

  /* ── today's numbers ─────────────────────────────────────────────── */
  var KEY = "pillow.today";
  var db = { days: {}, tipSeen: "", tipOffset: 0 };
  try {
    var raw = JSON.parse(localStorage.getItem(KEY) || "null");
    if (raw && raw.days) db = raw;
  } catch (e) {}
  db.days = db.days || {};
  function today() {
    var k = dayKey();
    if (!db.days[k]) db.days[k] = { p: {}, a: 0 };
    return db.days[k];
  }
  var saveTimer = 0;
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(function () {
      var keys = Object.keys(db.days).sort();
      while (keys.length > 21) delete db.days[keys.shift()];
      try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) {}
    }, 400);
  }
  function dayTotal(d) {
    var s = 0;
    if (d && d.p) for (var k in d.p) if (d.p.hasOwnProperty(k)) s += d.p[k];
    return s;
  }

  /* ── tracking ────────────────────────────────────────────────────── */
  var IDLE_MS = 5 * 60 * 1000;
  var track = { sig: null, lastChange: Date.now(), lastTick: 0, project: "", asleep: false };
  function poke() {
    track.lastChange = Date.now();
    if (track.asleep) { track.asleep = false; mood(); }
  }
  function tick() {
    if (typeof window.host !== "function" || !window.csInterface) return;
    window.host("pillowActivity()", function (r) {
      var now = Date.now();
      if (r && r.ok && r.open) {
        if (r.sig !== track.sig) {
          if (track.sig !== null) track.lastChange = now;
          track.sig = r.sig;
        }
        track.project = r.name || "Untitled Project";
        if (track.lastTick && now - track.lastChange < IDLE_MS) {
          var t = today(), dt = Math.min(now - track.lastTick, 75000) / 1000;
          t.p[track.project] = (t.p[track.project] || 0) + dt;
          save();
        }
      }
      track.lastTick = now;
      var asleep = now - track.lastChange >= IDLE_MS;
      if (asleep !== track.asleep) { track.asleep = asleep; mood(); }
      paintPeek();
      if (open) paintToday();
    });
  }

  /* Pillow actions: calls that change the project (not the polling ones) */
  var ACTION = /pillow(Add[A-Z]|Apply|Set[A-Z]|Split|Stagger|Precompose|QueueRender|RelinkAll|BounceApply|BounceRemove|BeatSync|BeatRemove|LibApply|GlassMake|GlassUpdate|GlassRemove|RemoveGlass)\w*\(/;
  function wrapHost() {
    var orig = window.host;
    if (typeof orig !== "function" || orig.__plNotch) return;
    var wrapped = function (fnCall, cb) {
      if (!ACTION.test(String(fnCall))) return orig(fnCall, cb);
      return orig(fnCall, function (r) {
        if (r && r.ok) {
          today().a++;
          save();
          poke();
          react("happy", 1300);
          paintPeek();
          if (open) paintToday();
        }
        if (cb) cb(r);
      });
    };
    wrapped.__plNotch = true;
    window.host = wrapped;
  }

  /* ── tips ────────────────────────────────────────────────────────── */
  var TIPS = [
    ["Snap to a keyframe", "Hold Shift while you drag the playhead and it snaps to keyframes, markers and layer edges."],
    ["Jump between keys", "J and K jump to the previous and next visible keyframe of the selected layers."],
    ["Only what's animated", "Select a layer and press U: just the properties with keyframes. UU shows everything you changed."],
    ["Trim in a keystroke", "Alt+[ and Alt+] trim the selected layer's in and out point to the playhead."],
    ["Move by a frame", "Alt+PageUp / PageDown nudges selected layers or keyframes by one frame, Shift for ten."],
    ["Precompose to tidy up", "Ctrl+Shift+C precomposes. In Pillow, Create → Pre-compose names it for you."],
    ["Ease in one click", "Select keyframes and pick a curve in Curves — the speed graph shows exactly what you get."],
    ["Bounce that feels real", "Bounce → Bounce Back makes a layer land and settle. Tweak it later on the sliders it adds to the layer."],
    ["Split text instantly", "Text → Split breaks a text layer into letters, words or lines, each its own layer, in reading order."],
    ["Glass in a second", "Liquid Glass → New shape drops an Apple-style glass pill in the middle of your comp. Move it like any layer."],
    ["Update a glass later", "Select a Pillow Liquid Glass layer, change the sliders in the panel and press Update."],
    ["Beats as markers", "Music → Detect & Add Beats listens to the track and drops a marker on every hit. Snap cuts and keys to them with Shift."],
    ["Save your own moves", "Library → Save Animation stores the keyframes of a layer. Apply them to any layer later."],
    ["Save whole setups", "Library → Layers saves selected layers with all effects — a colour grade or a transition, reusable."],
    ["Share a preset as text", "In the Library press the code button on a preset. Send the code; your friend pastes it in the notch → Share."],
    ["Stagger without math", "Select layers and press Create → Stagger: each one starts a little after the previous."],
    ["Anchor where you need it", "Create → Anchor Point moves the anchor to a corner or the centre without moving the layer."],
    ["Relink in one go", "Relink finds every missing file in the project and points them to a folder in one pass."],
    ["Preview faster", "Half resolution (Ctrl+J / Ctrl+Shift+J for full) and Draft 3D make previews much faster."],
    ["Region of interest", "The region-of-interest button in the Composition panel renders only part of the frame while you work."],
    ["Purge when it crawls", "Edit → Purge → All Memory & Disk Cache when previews get slow or AE feels heavy."],
    ["Solo what matters", "Solo a layer (the dot left of the eye) to preview it alone without hiding the rest by hand."],
    ["Lock the background", "Lock layers you are done with (Ctrl+L) so stray clicks never move them."],
    ["Shy layers", "Mark helper layers shy and hide them with the timeline's shy switch — the timeline stays readable."],
    ["Parent with the pick whip", "Drag a layer's pick whip onto another to parent it. Shift-drag snaps the child to the parent."],
    ["Null as a handle", "Animate a null and parent layers to it: one set of keys moves the whole group."],
    ["Motion blur, properly", "Turn on motion blur for the layer and the comp switch. Raise the shutter angle for smoother blur."],
    ["Loop an animation", "loopOut(\"cycle\") on a property repeats its keyframes forever. \"pingpong\" plays them back and forth."],
    ["Wiggle with control", "wiggle(2, 30): 2 times a second, up to 30 px. Link the numbers to sliders to animate them."],
    ["Time remap for speed", "Ctrl+Alt+T enables time remapping: keyframe it to speed up, slow down or freeze footage."],
    ["Graph editor view", "Shift+F3 toggles the graph editor. The speed graph is where smooth motion is really made."],
    ["Copy just the ease", "Pillow's curves apply to selected keys only — select the keys first, then the curve."],
    ["Keep the comp clean", "File → Dependencies → Reduce Project removes everything the selected comps don't use."],
    ["Collect files", "File → Dependencies → Collect Files gathers the project and all footage into one folder for handoff."],
    ["Render without waiting", "Queue in Media Encoder (Ctrl+Alt+M) and keep working while it renders."],
    ["Safe text", "Keep text inside the title-safe guide (the ' key toggles safe zones) — phones crop the edges."],
    ["Name as you go", "Rename layers with Enter. A tidy timeline is half the speed on big projects."],
    ["Colour labels", "Right-click a layer → Label to colour code it. Select the whole label group from the same menu."],
    ["Favourites in Pillow", "Star the curves and text animations you use most — they wait for you under the star in the rail."],
    ["Theme to taste", "The sun/moon button switches Pillow between dark and light. The setting icon has Liquid Glass mode."]
  ];
  function tipIndex() {
    var d = new Date();
    var n = Math.floor(new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() / 86400000);
    return ((n + (db.tipOffset || 0)) % TIPS.length + TIPS.length) % TIPS.length;
  }
  function tipUnseen() { return db.tipSeen !== dayKey(); }

  /* ── preset codes ────────────────────────────────────────────────── */
  var CODE_PREFIX = "PILLOW-1:";
  function b64urlFromBytes(bytes) {
    var s = "", CH = 0x8000;
    for (var i = 0; i < bytes.length; i += CH) s += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function bytesFromB64url(t) {
    t = t.replace(/-/g, "+").replace(/_/g, "/");
    while (t.length % 4) t += "=";
    var s = atob(t), out = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
    return out;
  }
  function pipe(bytes, stream) {
    return new Response(new Blob([bytes]).stream().pipeThrough(stream)).arrayBuffer().then(function (b) { return new Uint8Array(b); });
  }
  function exportable(p) {
    var o = {};
    for (var k in p) if (p.hasOwnProperty(k) && k.charAt(0) !== "_" && k !== "builtin" && k !== "folder" && k !== "id" && k !== "thumb") o[k] = p[k];
    return o;
  }
  /* "PILLOW-1:" + z (deflate) or j (plain) + base64url */
  function encode(preset) {
    var bytes = new TextEncoder().encode(JSON.stringify(exportable(preset)));
    if (typeof CompressionStream === "function") {
      return pipe(bytes, new CompressionStream("deflate")).then(function (z) {
        return CODE_PREFIX + "z" + b64urlFromBytes(z);
      }, function () { return CODE_PREFIX + "j" + b64urlFromBytes(bytes); });
    }
    return Promise.resolve(CODE_PREFIX + "j" + b64urlFromBytes(bytes));
  }
  function decode(code) {
    var s = String(code || "").replace(/\s+/g, "");
    var i = s.indexOf(CODE_PREFIX);
    if (i < 0) return Promise.reject(new Error("That isn't a Pillow preset code."));
    s = s.slice(i + CODE_PREFIX.length);
    var kind = s.charAt(0), body = s.slice(1);
    var bytes;
    try { bytes = bytesFromB64url(body); } catch (e) { return Promise.reject(new Error("The code is damaged — copy it again.")); }
    var got;
    if (kind === "z") {
      if (typeof DecompressionStream !== "function") return Promise.reject(new Error("This code needs a newer After Effects."));
      got = pipe(bytes, new DecompressionStream("deflate"));
    } else if (kind === "j") got = Promise.resolve(bytes);
    else return Promise.reject(new Error("Unknown code version."));
    return got.then(function (b) {
      var p = JSON.parse(new TextDecoder().decode(b));
      if (!p || typeof p !== "object" || !((p.props && p.props.length) || (p.kind === "layers" && p.layers && p.layers.length))) {
        throw new Error("The code has no animation in it.");
      }
      return p;
    }, function () { throw new Error("The code is incomplete — copy all of it."); });
  }
  function copyText(text) {
    var ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.cssText = "position:fixed;left:-9999px;top:0;opacity:0";
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand("copy"); } catch (e) {}
    ta.remove();
    if (!ok && navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(function () {});
      ok = true;
    }
    return ok;
  }
  function shareCode(preset) {
    return encode(preset).then(function (code) {
      var ok = copyText(code);
      var msg = ok ? "Code copied — send it to anyone, they paste it in the notch → Share" : "Couldn't copy the code";
      if (ok && code.length > 4000) msg = "Code copied (" + Math.round(code.length / 1000) + "k characters — long for a chat; Export sends a file)";
      if (typeof window.toast === "function") window.toast(msg, !ok);
      if (ok) write();
      return code;
    });
  }

  /* ── the feather ─────────────────────────────────────────────────────
   * The notch's character: a feather, drawn in SVG, alive through motion
   * only. It sways and floats in a light draught, leans away from the
   * cursor as if blown, droops and breathes when AE is idle, flutters up
   * with a puff of air after a Pillow action, spins when tapped too fast,
   * shivers under the pointer and squashes when pressed. Its colour is the
   * notch text colour, so it follows the theme. */
  var face = { state: "idle", reactTimer: 0 };
  var FEATHER =
    '<svg class="nt-feather" viewBox="0 0 24 24" aria-hidden="true"><g class="nf-lean"><g class="nf-sway"><g class="nf-body">' +
      '<path class="nf-vane" d="M8.1 17.7C7.5 13.2 10.5 8.3 14.6 5.4C16.2 4.3 17.7 3.7 19 3.5C19.6 6.9 18.5 10.5 16.1 13.3C14 15.8 11 17.3 8.1 17.7Z"/>' +
      '<path class="nf-cut" d="M15.9 13.5l1.2-.3M10.3 9.7l-.6-.9"/>' +
      '<path class="nf-barbs" d="M10.4 14.9l-1.3-1.5M12.2 12.4l-1.2-1.7M14 9.9l-.9-1.8M15.9 7.4l-.6-1.6M11.5 15.4l1.9.2M13.5 12.8l2 .1M15.3 10.2l1.9-.3M17 7.6l1.4-.6"/>' +
      '<path class="nf-quill" d="M5.3 22.2C6.4 20.5 7.4 19 8.4 17.5"/>' +
      '<path class="nf-shaft" d="M8.4 17.5C11.3 13.1 14.6 8.3 19 3.5"/>' +
    '</g></g></g>' +
    '<g class="nf-air"><circle cx="15" cy="17" r="1.1"/><circle cx="18.6" cy="13.6" r="0.8"/><circle cx="12" cy="20" r="0.7"/></g>' + '</svg>';
  /* down on hover: a few soft tufts come loose from the feather, drift
     down swaying and melt away */
  var fluffLayer = null, lastFluff = 0;
  function fluff(mark, count) {
    var now = Date.now();
    if (now - lastFluff < 700 || reduced() || !mark) return;
    lastFluff = now;
    if (!fluffLayer) {
      fluffLayer = document.createElement("div");
      fluffLayer.className = "nf-fluff-layer";
      fluffLayer.setAttribute("data-tr-skip", "");
      fluffLayer.setAttribute("aria-hidden", "true");
      document.body.appendChild(fluffLayer);
    }
    var r = mark.getBoundingClientRect(), col = getComputedStyle(mark).color;
    for (var i = 0; i < (count || 4); i++) {
      var t = document.createElement("i");
      t.className = "nf-tuft";
      var size = 8 + Math.random() * 5;
      t.style.cssText = "left:" + (r.left + r.width * (0.35 + Math.random() * 0.5)).toFixed(1) + "px;top:" +
        (r.top + r.height * (0.15 + Math.random() * 0.5)).toFixed(1) + "px;width:" + size.toFixed(1) + "px;height:" + size.toFixed(1) + "px;" +
        "background-image:url(\"" + tuftSvg(col) + "\")";
      fluffLayer.appendChild(t);
      var dx = (Math.random() - 0.5) * 30, dy = 18 + Math.random() * 22, sw = (Math.random() < 0.5 ? -1 : 1) * (5 + Math.random() * 6);
      var dur = 1500 + Math.random() * 900;
      var a = t.animate([
        { opacity: 0, transform: "translate(0,0) rotate(0deg) scale(0.5)" },
        { opacity: 0.9, transform: "translate(" + (dx * 0.25 + sw) + "px," + (dy * 0.2) + "px) rotate(40deg) scale(1)", offset: 0.18 },
        { opacity: 0.7, transform: "translate(" + (dx * 0.6 - sw) + "px," + (dy * 0.55) + "px) rotate(110deg) scale(0.95)", offset: 0.55 },
        { opacity: 0, transform: "translate(" + dx + "px," + dy + "px) rotate(200deg) scale(0.7)" }
      ], { duration: dur, delay: i * 70, easing: "cubic-bezier(0.25, 0.6, 0.4, 1)", fill: "both" });
      a.onfinish = (function (el) { return function () { el.remove(); }; })(t);
    }
  }
  /* a tuft of down, like a dandelion seed: a soft centre and fine fibres */
  var tuftCache = {};
  function tuftSvg(col) {
    if (tuftCache[col]) return tuftCache[col];
    var rays = "";
    for (var i = 0; i < 9; i++) {
      var a = i / 9 * Math.PI * 2 + 0.3, l = 3.4 + (i % 3) * 0.7;
      rays += "M10 10L" + (10 + Math.cos(a) * l * 2).toFixed(2) + " " + (10 + Math.sin(a) * l * 2).toFixed(2);
    }
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><g fill="none" stroke="' + col + '" stroke-linecap="round">' +
      '<path d="' + rays + '" stroke-width="0.7" stroke-opacity="0.55"/></g><circle cx="10" cy="10" r="1.6" fill="' + col + '" fill-opacity="0.9"/></svg>';
    return (tuftCache[col] = "data:image/svg+xml," + encodeURIComponent(svg));
  }

  /* the feather writes (on copy): the time steps aside, the feather tilts
     like a pen and its tip runs along a looping hand-written line, drawn as
     it goes. The line and the feather's path are the same curve (a looped
     cycloid), so the tip stays on the ink. */
  var writing = false;
  function write() {
    react("write", 1600);
    if (writing || reduced() || !shell) return;
    var cont = open ? shell.querySelector(".nt-head") : shell.querySelector(".nt-peek");
    var mark = cont && cont.querySelector(".nt-mark");
    if (!mark || !mark.animate) return;
    writing = true;
    var cr = cont.getBoundingClientRect(), mr = mark.getBoundingClientRect();
    var tipX = mr.left - cr.left + mr.width * 5.3 / 24, tipY = mr.top - cr.top + mr.height * 22.2 / 24;
    /* x = a·t − b·sin t, y = −b·(1 − cos t): small loops, like joined-up "llll" */
    var a = 1.6, b = 3.0, turns = open ? 9 : 7, N = 90, pts = [];
    for (var i = 0; i <= N; i++) {
      var t = i / N * turns * Math.PI;
      pts.push([a * t - b * Math.sin(t), -b * (1 - Math.cos(t)) - Math.sin(i / N * Math.PI) * 0.8]);
    }
    var minY = 0, maxX = 0;
    for (var j = 0; j < pts.length; j++) { minY = Math.min(minY, pts[j][1]); maxX = Math.max(maxX, pts[j][0]); }
    var pad = 2, W = maxX + pad * 2, H = -minY + pad * 2, d = "";
    for (var k = 0; k < pts.length; k++) d += (k ? "L" : "M") + (pts[k][0] + pad).toFixed(2) + " " + (pts[k][1] - minY + pad).toFixed(2);
    var NS = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(NS, "svg");
    svg.setAttribute("class", "nt-ink");
    svg.setAttribute("width", W.toFixed(1));
    svg.setAttribute("height", H.toFixed(1));
    svg.setAttribute("viewBox", "0 0 " + W.toFixed(2) + " " + H.toFixed(2));
    svg.style.left = (tipX - pad).toFixed(1) + "px";
    svg.style.top = (tipY + minY - pad).toFixed(1) + "px";
    var path = document.createElementNS(NS, "path");
    path.setAttribute("d", d);
    path.setAttribute("pathLength", "1");
    svg.appendChild(path);
    cont.appendChild(svg);
    var DUR = open ? 1150 : 1000;
    var label = open ? null : shell.querySelector(".nt-peek-t");
    if (label) label.animate([{ opacity: 1 }, { opacity: 0, offset: 0.12 }, { opacity: 0, offset: 0.85 }, { opacity: 1 }], { duration: DUR + 700, easing: "ease" });
    var frames = [{ transform: "translate(0px,0px)" }];
    for (var f = 0; f <= N; f += 2) frames.push({ transform: "translate(" + pts[f][0].toFixed(2) + "px," + pts[f][1].toFixed(2) + "px)" });
    var lead = 160, back = 320, total = lead + DUR + back;
    var kf = [{ transform: "translate(0px,0px)", offset: 0 }];
    for (var q = 1; q < frames.length; q++) kf.push({ transform: frames[q].transform, offset: (lead + (q - 1) / (frames.length - 2) * DUR) / total });
    kf.push({ transform: "translate(0px,0px)", offset: 1, easing: "ease-out" });
    mark.animate(kf, { duration: total, easing: "linear" });
    path.animate([{ strokeDashoffset: 1 }, { strokeDashoffset: 1, offset: lead / (lead + DUR) }, { strokeDashoffset: 0 }], { duration: lead + DUR, easing: "linear", fill: "forwards" });
    var fade = svg.animate([{ opacity: 1 }, { opacity: 1, offset: 0.55 }, { opacity: 0 }], { duration: lead + DUR + 900, easing: "ease-in", fill: "forwards" });
    fade.onfinish = function () { svg.remove(); writing = false; };
  }
  function markMarkup() {
    return '<span class="nt-mark" aria-hidden="true">' + FEATHER + "</span>";
  }
  /* the feather leans away from the cursor, as if the cursor blew on it */
  var leanRaf = 0, leanPt = null;
  function leanFrom(e) {
    leanPt = e;
    if (leanRaf) return;
    leanRaf = requestAnimationFrame(function () {
      leanRaf = 0;
      if (!shell) return;
      /* far from the island: nothing to lean, and nothing to measure
         (a measure on every pointermove restyled the panel after a hover) */
      var now = performance.now();
      if (!shell._leanBox || now - shell._leanAt > 500) { shell._leanBox = shell.getBoundingClientRect(); shell._leanAt = now; }
      var sb = shell._leanBox;
      if (leanPt.clientX < sb.left - 160 || leanPt.clientX > sb.right + 160 || leanPt.clientY < sb.top - 160 || leanPt.clientY > sb.bottom + 160) {
        if (shell._leaning) { shell._leaning = false; var gs = shell.querySelectorAll(".nf-lean"); for (var q = 0; q < gs.length; q++) gs[q].style.transform = ""; }
        return;
      }
      shell._leaning = true;
      var marks = shell.querySelectorAll(".nt-mark");
      for (var i = 0; i < marks.length; i++) {
        var r = marks[i].getBoundingClientRect();
        if (!r.width) continue;
        var dx = leanPt.clientX - (r.left + r.width / 2), dy = leanPt.clientY - (r.top + r.height / 2);
        var d = Math.sqrt(dx * dx + dy * dy), k = Math.max(0, 1 - d / 140);
        var lean = -(dx / (Math.abs(dx) + 30)) * 16 * k;
        var g = marks[i].querySelector(".nf-lean");
        if (g) g.style.transform = "rotate(" + lean.toFixed(2) + "deg)";
      }
    });
  }
  function mood() {
    if (!shell) return;
    var k = face.state !== "idle" ? face.state : track.asleep ? "sleep" : "idle";
    shell.setAttribute("data-mood", k);
  }
  function react(kind, ms) {
    face.state = kind;
    mood();
    clearTimeout(face.reactTimer);
    face.reactTimer = setTimeout(function () { face.state = "idle"; mood(); paintPeek(); }, ms);
  }

  /* ── springs ─────────────────────────────────────────────────────────
   * The card's left, top, width, height and corner radius each ride their
   * own spring toward a target. Opening, closing, a tab that changes the
   * height, a resize mid-flight — all just new targets, so the shape is
   * always continuous: it never jumps or grows past where it is going. */
  function Spring(v) { this.x = v; this.v = 0; this.to = v; }
  var SPRING_K = 360, SPRING_D = 29;          /* soft, a hint of overshoot */
  var S = { l: new Spring(0), t: new Spring(0), w: new Spring(104), h: new Spring(30), r: new Spring(15) };
  var springRaf = 0, springLast = 0;
  function settle(sp) { return Math.abs(sp.x - sp.to) < 0.05 && Math.abs(sp.v) < 0.5; }
  function stepAll(now) {
    var dt = springLast ? Math.min(0.05, (now - springLast) / 1000) : 1 / 60;
    springLast = now;
    var n = Math.ceil(dt / 0.004), hh = dt / n, done = true;
    for (var key in S) {
      var sp = S[key];
      for (var i = 0; i < n; i++) {
        sp.v += (-SPRING_K * (sp.x - sp.to) - SPRING_D * sp.v) * hh;
        sp.x += sp.v * hh;
      }
      if (settle(sp)) { sp.x = sp.to; sp.v = 0; } else done = false;
    }
    paintShape();
    if (done) { springRaf = 0; springLast = 0; onSettled(); return; }
    springRaf = requestAnimationFrame(stepAll);
  }
  function animateTo(rect, instant) {
    S.l.to = rect.l; S.t.to = rect.t; S.w.to = rect.w; S.h.to = rect.h; S.r.to = rect.r;
    if (instant || reduced()) {
      for (var k in S) { S[k].x = S[k].to; S[k].v = 0; }
      if (springRaf) cancelAnimationFrame(springRaf);
      springRaf = 0; springLast = 0;
      paintShape();
      onSettled();
      return;
    }
    if (!springRaf) { springLast = 0; springRaf = requestAnimationFrame(stepAll); }
  }
  /* ── the cushion ─────────────────────────────────────────────────────
   * Not a black island: a little pillow. Its sides sag in a touch between
   * plump corners, the fabric is lighter where it is full and darker
   * towards the seam, and a stitched seam runs just inside the edge. When
   * it moves the fabric gives — the sides sag more with the speed and the
   * stitches run along, as if it were being sewn. Drawn in one SVG that
   * follows the springs. */
  var SKIN_PAD = 16, seamRun = 0;
  function f2(n) { return (Math.round(n * 100) / 100).toString(); }
  function cushionPath(x, y, w, h, r, sx, sy) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    var x2 = x + w, y2 = y + h, mx = x + w / 2, my = y + h / 2;
    return "M" + f2(x + r) + " " + f2(y) +
      "Q" + f2(mx) + " " + f2(y + 2 * sx) + " " + f2(x2 - r) + " " + f2(y) +
      "A" + f2(r) + " " + f2(r) + " 0 0 1 " + f2(x2) + " " + f2(y + r) +
      "Q" + f2(x2 - 2 * sy) + " " + f2(my) + " " + f2(x2) + " " + f2(y2 - r) +
      "A" + f2(r) + " " + f2(r) + " 0 0 1 " + f2(x2 - r) + " " + f2(y2) +
      "Q" + f2(mx) + " " + f2(y2 - 2 * sx) + " " + f2(x + r) + " " + f2(y2) +
      "A" + f2(r) + " " + f2(r) + " 0 0 1 " + f2(x) + " " + f2(y2 - r) +
      "Q" + f2(x + 2 * sy) + " " + f2(my) + " " + f2(x) + " " + f2(y + r) +
      "A" + f2(r) + " " + f2(r) + " 0 0 1 " + f2(x + r) + " " + f2(y) + "Z";
  }
  function paintSkin(w, h, r) {
    if (!skin) return;
    var P = SKIN_PAD, card = h > 60;
    /* the sag: a hair on the capsule, a little more on the card, and more
       while the fabric is on the move */
    var speed = Math.min(1, (Math.abs(S.w.v) + Math.abs(S.h.v)) / 2600);
    var base = card ? 2.2 : 0.9;
    var sx = Math.min(h * 0.08, base + speed * (card ? 5 : 2.5)) * Math.min(1, w / 80);
    var sy = Math.min(w * 0.08, base + speed * (card ? 4 : 1.5)) * Math.min(1, h / 40);
    skin.setAttribute("width", f2(w + 2 * P));
    skin.setAttribute("height", f2(h + 2 * P));
    var d = cushionPath(P, P, w, h, r, sx, sy);
    skin.__fill.setAttribute("d", d);
    skin.__shade.setAttribute("d", d);
    skin.__edge.setAttribute("d", d);
    skin.__drop.setAttribute("d", d);
    var ins = card ? 5 : 3.2;
    skin.__seam.setAttribute("d", cushionPath(P + ins, P + ins, w - 2 * ins, h - 2 * ins, Math.max(0, r - ins), sx, sy));
    /* the stitches run while it moves */
    seamRun += speed * 2.2;
    skin.__seam.style.strokeDashoffset = f2(-seamRun);
  }
  var SKIN_SVG =
    '<svg class="nt-skin" aria-hidden="true">' +
      "<defs>" +
        '<radialGradient id="nt-sk-puff" cx="50%" cy="38%" r="75%">' +
          '<stop offset="0" style="stop-color:var(--nt-fab-hi)"/>' +
          '<stop offset="0.62" style="stop-color:var(--nt-fab)"/>' +
          '<stop offset="1" style="stop-color:var(--nt-fab-lo)"/>' +
        "</radialGradient>" +
        '<linearGradient id="nt-sk-edge" x1="0" y1="0" x2="0" y2="1">' +
          '<stop offset="0" style="stop-color:var(--nt-edge-hi)"/>' +
          '<stop offset="0.35" style="stop-color:var(--nt-edge-hi);stop-opacity:0"/>' +
          '<stop offset="1" style="stop-color:var(--nt-edge-lo)"/>' +
        "</linearGradient>" +
      "</defs>" +
      '<path class="nt-sk-drop"/>' +
      '<path class="nt-sk-fill" fill="url(#nt-sk-puff)"/>' +
      '<path class="nt-sk-shade"/>' +
      '<path class="nt-sk-edge" fill="none" stroke="url(#nt-sk-edge)"/>' +
      '<path class="nt-sk-seam" fill="none"/>' +
    "</svg>";

  function paintShape() {
    var s = shell.style, w = Math.max(10, S.w.x), h = Math.max(10, S.h.x);
    var r = Math.max(0, Math.min(S.r.x, h / 2, w / 2));
    s.width = w.toFixed(2) + "px";
    s.height = h.toFixed(2) + "px";
    s.transform = "translate3d(" + S.l.x.toFixed(2) + "px," + S.t.x.toFixed(2) + "px,0)";
    clip.style.borderRadius = r.toFixed(2) + "px";
    paintSkin(w, h, r);
    /* the card's content keeps its own width and stays centred */
    if (bodyW) body.style.transform = "translateX(" + ((w - bodyW) / 2).toFixed(2) + "px)";
  }
  function onSettled() {
    if (!open) {
      shell.classList.remove("is-open", "is-closing");
      body.style.visibility = "hidden";
    }
  }

  function reduced() {
    try { return window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) { return false; }
  }

  /* ── geometry ────────────────────────────────────────────────────── */
  var shell = null, slot = null, body = null, clip = null, skin = null, bodyW = 0, open = false, view = "morph";
  var taps = [];
  /* the capsule takes the free room between the wordmark and the buttons
     on the right; when that gets tight only the cushion stays */
  function fitSlot() {
    var header = slot.parentNode, hr = header.getBoundingClientRect();
    var brand = header.firstElementChild, meta = header.querySelector(".header-meta");
    var cx = hr.left + hr.width / 2, room = alertTop() ? 176 : 112;
    if (brand && brand !== slot) room = Math.min(room, 2 * (cx - brand.getBoundingClientRect().right - 10));
    if (meta) room = Math.min(room, 2 * (meta.getBoundingClientRect().left - cx - 10));
    var compact = room < 86;
    var w = compact ? 44 : Math.round(room);
    if (slot.__w !== w) { slot.style.width = w + "px"; slot.__w = w; }
    shell.classList.toggle("is-compact", compact);
  }
  function capsuleRect() {
    fitSlot();
    var r = slot.getBoundingClientRect();
    return { l: r.left, t: r.top, w: r.width, h: r.height, r: r.height / 2 };
  }
  function cardRect() {
    var vw = window.innerWidth || document.documentElement.clientWidth;
    var vh = window.innerHeight || document.documentElement.clientHeight;
    var c = capsuleRect();
    var w = Math.min(vw - 20, 380);
    if (bodyW !== w) { bodyW = w; body.style.width = w + "px"; }
    var h = Math.min(body.scrollHeight, vh - c.t - 14);
    return { l: (vw - w) / 2, t: c.t, w: w, h: Math.max(h, 96), r: 22 };
  }

  /* ── open / close ────────────────────────────────────────────────── */
  var showTimer = 0;
  function setOpen(v) {
    if (v === open) return;
    open = v;
    clearTimeout(showTimer);
    shell.setAttribute("aria-expanded", open ? "true" : "false");
    if (open) {
      paintView(true);
      shell.classList.remove("is-closing");
      shell.classList.add("is-open");
      body.style.visibility = "visible";
      animateTo(cardRect());
      /* the content comes in once the shape has room for it */
      showTimer = setTimeout(function () { shell.classList.add("is-shown"); }, reduced() ? 0 : 90);
      if (view === "tip") markTipSeen();
      if (view === "share") sniffClipboard();
      if (alerts.render) alerts.render.seen = true;
    } else {
      /* content out first, then the shape folds back into the capsule */
      shell.classList.remove("is-shown");
      shell.classList.add("is-closing");
      if (window.PillowMorph) window.PillowMorph.stop();
      if (alerts.render && alerts.render.seen) { dismissRender(alerts.render); alerts.render = null; paintPeek(); }
      showTimer = setTimeout(function () { animateTo(capsuleRect()); }, reduced() ? 0 : 70);
    }
  }
  /* closed: sit on the slot, follow it on resize */
  function place() {
    if (open) { animateTo(cardRect()); return; }
    if (!springRaf) animateTo(capsuleRect(), true);
    else animateTo(capsuleRect());
  }
  /* the card's height follows its content (tab change, a message) */
  function refit() { if (open) animateTo(cardRect()); }

  /* Warm-up. The first open of a session cost a long frame in After
     Effects: the card, its tabs, its blur and the morph canvas were laid
     out, styled and drawn for the first time. Once, in a quiet moment
     after start-up, the card's content is drawn for a few frames where it
     will open — transparent (.nt-warm), blurred and then sharp, as it
     comes in — while the capsule itself stays as it is. The first real
     open then only shows what is ready. A tap during it just ends it. */
  var warmed = false, warming = false;
  function warmEnd() {
    if (!warming) return;
    warming = false;
    if (window.PillowMorph && !open) window.PillowMorph.stop();
    shell.classList.remove("nt-warm", "nt-warm-sharp");
    if (!open) body.style.visibility = "hidden";
  }
  function warm() {
    if (warmed || open || !shell || document.hidden) return;
    warmed = true;
    warming = true;
    cardRect();
    paintView(true);
    shell.classList.add("nt-warm");
    body.style.visibility = "visible";
    if (window.PillowMorph && view === "morph") window.PillowMorph.start();
    var n = 0;
    (function f() {
      if (!warming) return;
      n++;
      if (n === 2) shell.classList.add("nt-warm-sharp");
      if (n < 5) requestAnimationFrame(f); else warmEnd();
    })();
  }

  /* ── views ───────────────────────────────────────────────────────── */
  function paintPeek() {
    if (!shell) return;
    var el = shell.querySelector(".nt-peek-t"), dot = shell.querySelector(".nt-dot");
    var a = alertTop();
    el.textContent = face.state === "dizzy" ? "whoa…" : a ? a.peek : fmt(dayTotal(today()));
    dot.hidden = !a && !tipUnseen();
    dot.setAttribute("data-k", a ? a.tone : "");
    shell.setAttribute("data-alert", a ? a.tone : "");
  }
  /* the tab pill slides to the active tab on its own spring */
  var pill = { x: new Spring(0), w: new Spring(0), raf: 0, last: 0, ready: false };
  function pillStep(now) {
    var dt = pill.last ? Math.min(0.05, (now - pill.last) / 1000) : 1 / 60;
    pill.last = now;
    var n = Math.ceil(dt / 0.004), hh = dt / n, done = true;
    [pill.x, pill.w].forEach(function (sp) {
      for (var i = 0; i < n; i++) { sp.v += (-520 * (sp.x - sp.to) - 34 * sp.v) * hh; sp.x += sp.v * hh; }
      if (settle(sp)) { sp.x = sp.to; sp.v = 0; } else done = false;
    });
    var el = shell.querySelector(".nt-tab-pill");
    el.style.transform = "translateX(" + pill.x.x.toFixed(2) + "px)";
    el.style.width = pill.w.x.toFixed(2) + "px";
    if (done) { pill.raf = 0; pill.last = 0; return; }
    pill.raf = requestAnimationFrame(pillStep);
  }
  function movePill(instant) {
    var tabs = shell.querySelector(".nt-tabs"), act = tabs.querySelector('[data-nt-tab="' + view + '"]');
    if (!act) return;
    pill.x.to = act.offsetLeft; pill.w.to = act.offsetWidth;
    if (instant || !pill.ready || reduced()) {
      pill.x.x = pill.x.to; pill.w.x = pill.w.to; pill.x.v = pill.w.v = 0; pill.ready = true;
      var el = shell.querySelector(".nt-tab-pill");
      el.style.transform = "translateX(" + pill.x.x + "px)";
      el.style.width = pill.w.x + "px";
      return;
    }
    if (!pill.raf) { pill.last = 0; pill.raf = requestAnimationFrame(pillStep); }
  }
  function paintView(instant) {
    var tabs = shell.querySelectorAll("[data-nt-tab]");
    for (var i = 0; i < tabs.length; i++) tabs[i].classList.toggle("active", tabs[i].getAttribute("data-nt-tab") === view);
    var panes = shell.querySelectorAll("[data-nt-pane]");
    for (var j = 0; j < panes.length; j++) {
      var on = panes[j].getAttribute("data-nt-pane") === view;
      panes[j].hidden = !on;
      if (on && !instant && !reduced() && panes[j].animate) {
        panes[j].animate([{ opacity: 0, transform: "translateY(4px)", filter: "blur(3px)" }, { opacity: 1, transform: "none", filter: "blur(0)" }],
          { duration: 240, easing: "cubic-bezier(0.22, 1, 0.36, 1)" });
      }
    }
    if (view === "today") paintToday();
    if (window.PillowMorph) window.PillowMorph[view === "morph" && open ? "start" : "stop"]();
    if (view === "tip") paintTip();
    if (view === "share") paintShare();
    paintAlerts();
    movePill(instant);
  }
  var DAYS = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
  function paintToday() {
    if (!shell) return;
    var t = today(), total = dayTotal(t);
    $("nt-total").textContent = fmtLong(total);
    var list = [];
    for (var k in t.p) if (t.p.hasOwnProperty(k) && t.p[k] >= 30) list.push([k, t.p[k]]);
    list.sort(function (a, b) { return b[1] - a[1]; });
    var max = list.length ? list[0][1] : 1, html = "";
    for (var i = 0; i < Math.min(4, list.length); i++) {
      html += '<div class="nt-proj"><span class="nt-proj-n" title="' + escHtml(list[i][0]) + '">' + escHtml(list[i][0]) + "</span>" +
        '<span class="nt-proj-bar"><i style="width:' + Math.max(4, list[i][1] / max * 100).toFixed(1) + '%"></i></span>' +
        '<span class="nt-proj-t">' + fmt(list[i][1]) + "</span></div>";
    }
    if (!list.length) html = '<div class="nt-empty">' + (window.csInterface ? "Nothing yet today — open a project and the clock starts." : "Open Pillow inside After Effects to count your time.") + "</div>";
    $("nt-projects").innerHTML = html;
    var wk = "", vals = [], d0 = new Date();
    for (var j = 6; j >= 0; j--) {
      var d = new Date(d0.getFullYear(), d0.getMonth(), d0.getDate() - j);
      vals.push({ d: d, s: dayTotal(db.days[dayKey(d)]) });
    }
    var vmax = 1;
    for (var q = 0; q < vals.length; q++) vmax = Math.max(vmax, vals[q].s);
    for (var w = 0; w < vals.length; w++) {
      var hh = vals[w].s ? Math.max(8, vals[w].s / vmax * 100) : 4;
      wk += '<div class="nt-wk' + (w === 6 ? " is-today" : "") + '" title="' + fmt(vals[w].s) + '"><span><i style="height:' + hh.toFixed(1) + '%"></i></span><b>' + DAYS[vals[w].d.getDay()] + "</b></div>";
    }
    $("nt-week").innerHTML = wk;
    $("nt-actions").textContent = String(t.a || 0);
  }
  function summaryText() {
    var t = today(), lines = ["After Effects today: " + fmtLong(dayTotal(t))];
    var list = [];
    for (var k in t.p) if (t.p.hasOwnProperty(k) && t.p[k] >= 30) list.push([k, t.p[k]]);
    list.sort(function (a, b) { return b[1] - a[1]; });
    for (var i = 0; i < list.length; i++) lines.push("• " + list[i][0] + " — " + fmtLong(list[i][1]));
    lines.push("Pillow actions: " + (t.a || 0));
    return lines.join("\n");
  }
  function paintTip(dir) {
    var i = tipIndex(), tip = TIPS[i], box = $("nt-tip-card");
    $("nt-tip-k").textContent = "Tip " + (i + 1) + " of " + TIPS.length + (db.tipOffset ? "" : " · today");
    $("nt-tip-t").textContent = tip[0];
    $("nt-tip-b").textContent = tip[1];
    if (dir && box.animate && !reduced()) {
      box.animate([{ opacity: 0, transform: "translateX(" + (dir * 14) + "px)" }, { opacity: 1, transform: "none" }],
        { duration: 260, easing: "cubic-bezier(0.22, 1, 0.36, 1)" });
    }
  }
  function markTipSeen() {
    if (!tipUnseen()) return;
    db.tipSeen = dayKey();
    save();
    paintPeek();
  }

  /* Share: send one of your presets as a code, or add a friend's code */
  function presets() { return window.PillowLibrary && window.PillowLibrary.list ? window.PillowLibrary.list() : []; }
  function paintShare() {
    var send = $("nt-send"), keepS = send.value, list = presets(), html = "";
    var F = window.PillowLibrary && window.PillowLibrary.folders ? window.PillowLibrary.folders() : [];
    var fname = {};
    for (var f = 0; f < F.length; f++) fname[F[f].id] = F[f].name;
    for (var i = 0; i < list.length; i++) {
      var p = list[i], where = p.builtin ? "Pillow Presets" : fname[p.folder] || "";
      html += '<option value="' + escHtml(p.id) + '">' + escHtml(p.name) + (where ? " — " + escHtml(where) : "") + "</option>";
    }
    send.innerHTML = html || '<option value="">No presets yet</option>';
    if (keepS) send.value = keepS;
    var sel = $("nt-folder"), keep = sel.value;
    html = "";
    for (var j = 0; j < F.length; j++) if (!F[j].builtin) html += '<option value="' + escHtml(F[j].id) + '">' + escHtml(F[j].name) + "</option>";
    sel.innerHTML = html || '<option value="">My Animations</option>';
    if (keep) sel.value = keep;
  }
  function sendCode() {
    var id = $("nt-send").value, list = presets(), p = null;
    for (var i = 0; i < list.length; i++) if (list[i].id === id) p = list[i];
    if (!p) return;
    shareCode(p).then(function () {
      say("Code for “" + p.name + "” copied — paste it in any chat.", true);
      react("happy", 1100);
    });
  }
  /* a code already in the clipboard fills the field by itself */
  function sniffClipboard() {
    var ta = $("nt-code");
    if (ta.value || !navigator.clipboard || !navigator.clipboard.readText) return;
    try {
      navigator.clipboard.readText().then(function (txt) {
        if (open && view === "share" && !ta.value && /PILLOW-1:/.test(txt || "")) {
          ta.value = txt.trim();
          say("Found a code in your clipboard.", true);
        }
      }, function () {});
    } catch (e) {}
  }
  function say(text, ok) {
    var msg = $("nt-share-msg");
    msg.textContent = text || "";
    msg.className = "nt-share-msg" + (text ? (ok ? " is-ok" : " is-bad") : "");
    refit();
  }
  function addFromCode() {
    var ta = $("nt-code"), code = ta.value.trim();
    if (!code) { say("Paste a code first.", false); return; }
    decode(code).then(function (p) {
      var lib = window.PillowLibrary;
      if (!lib || !lib.add) throw new Error("The Library isn't ready yet.");
      var added = lib.add(p, $("nt-folder").value);
      ta.value = "";
      paintShare();
      say("“" + (added.name || "Preset") + "” is in your Library.", true);
      react("happy", 1300);
    }).catch(function (e) {
      say(e && e.message ? e.message : "That code didn't work.", false);
    });
  }

  /* ── build ───────────────────────────────────────────────────────── */
  /* ── alerts: a render that finished, files that went missing ─────────
   * Every few seconds Pillow asks AE for the render queue and the count of
   * missing footage (pillowWatch). Something new shows on the closed
   * capsule itself: it widens on its spring, a coloured dot and a word
   * ("Render done · 2:14", "3 missing"), and the feather reacts. Open the
   * card for what to do about it. While AE renders, scripts wait, so the
   * finished render is seen on the first look after it. */
  var WATCH_MS = 12000;
  var alerts = { render: null, missing: 0, missingList: [], missingNew: 0, project: "", relink: null, busy: false, update: null };

  /* what the user closed stays closed after After Effects restarts: the
     missing files (per project) and the finished renders they dismissed.
     Only something new brings an alert back. */
  var DKEY = "pillow.alertsDismissed";
  function dLoad() { try { var d = JSON.parse(localStorage.getItem(DKEY) || "null"); if (d && typeof d === "object") return d; } catch (e) {} return {}; }
  function dSave(d) { try { localStorage.setItem(DKEY, JSON.stringify(d)); } catch (e) {} }
  function dMissing(proj) { var d = dLoad(); return (d.missing && d.missing[proj]) || []; }
  function dismissMissing() {
    var d = dLoad(), m = d.missing || {};
    m[alerts.project] = alerts.missingList.slice(0, 300);
    /* a handful of projects is plenty */
    var keys = []; for (var k in m) if (m.hasOwnProperty(k)) keys.push(k);
    while (keys.length > 20) delete m[keys.shift()];
    d.missing = m; dSave(d);
    alerts.missingNew = 0;
  }
  function renderKey(q) { return q.comp + "|" + q.file + "|" + Math.round(q.secs || 0); }
  function dismissRender(R) {
    if (!R) return;
    var d = dLoad(), list = d.render || [];
    for (var i = 0; i < R.items.length; i++) { var k = renderKey(R.items[i]); if (list.indexOf(k) < 0) list.push(k); }
    d.render = list.slice(-60); dSave(d);
  }
  function renderDismissed(q) { var list = dLoad().render || []; return list.indexOf(renderKey(q)) >= 0; }
  var rqSeen = null;
  function alertTop() {
    if (alerts.render) return alerts.render;
    if (alerts.missing > 0 && alerts.missingNew > 0) {
      return { tone: "warn", peek: alerts.missing + (alerts.missing === 1 ? " file missing" : " missing") };
    }
    if (alerts.update) return { tone: "new", peek: "Pillow " + shortVer(alerts.update.version) + " \u2726" };
    return null;
  }
  function clock(sec) {
    sec = Math.max(0, Math.round(sec || 0));
    var h = Math.floor(sec / 3600), m = Math.floor(sec / 60) % 60, s = sec % 60;
    return (h ? h + ":" + pad(m) : m) + ":" + pad(s);
  }
  function shortVer(v) { return String(v).replace(/\.0$/, ""); }
  function baseName(path) { return String(path || "").split(/[\\/]/).pop(); }
  /* a little hop when news arrives: the capsule widens on its spring and
     gets a kick so it lands with a bounce */
  function announce() {
    paintPeek();
    if (open) { paintAlerts(); refit(); return; }
    animateTo(capsuleRect());
    if (!reduced()) { S.h.v += 140; S.w.v += 220; S.t.v -= 40; }
  }
  function watch() {
    if (typeof window.host !== "function" || alerts.busy) return;
    /* missing files and render queue are read only while someone is at
       the panel: a call while AE plays back or renders is a known crash */
    if (document.hidden || (window.PillowPresence && !window.PillowPresence.awake())) return;
    window.host("pillowWatch()", function (r) {
      if (!r || !r.ok || !r.open) return;
      var changed = false, fresh = [];
      var now = {};
      (r.rq || []).forEach(function (q) {
        var key = q.i + "|" + q.comp + "|" + q.file;
        now[key] = q.status;
        var was = rqSeen ? rqSeen[key] : "done";
        var fin = q.status === "done" || q.status === "error" || q.status === "stopped";
        if (rqSeen && fin && was !== q.status && !renderDismissed(q)) fresh.push(q);
      });
      rqSeen = now;
      if (fresh.length) {
        var bad = fresh.filter(function (q) { return q.status !== "done"; });
        var good = fresh.filter(function (q) { return q.status === "done"; });
        var secs = 0;
        good.forEach(function (q) { secs += q.secs || 0; });
        var last = (good.length ? good : fresh)[(good.length ? good : fresh).length - 1];
        alerts.render = bad.length && !good.length
          ? { tone: "err", peek: bad[0].status === "stopped" ? "Render stopped" : "Render failed", items: fresh, last: last }
          : { tone: "ok", peek: "Render done" + (secs ? " · " + clock(secs) : ""), items: fresh, last: last, secs: secs, failed: bad.length };
        react(bad.length && !good.length ? "alarm" : "happy", 1800);
        changed = true;
      }
      var miss = r.missing || 0, list = r.miss || [], proj = r.project || "";
      /* files dismissed earlier and still missing stay quiet; a file that
         came back is forgotten, so if it goes missing again it is news */
      var hidden = dMissing(proj), kept = [], fresh2 = 0;
      for (var m = 0; m < list.length; m++) {
        if (hidden.indexOf(list[m]) >= 0) kept.push(list[m]); else fresh2++;
      }
      if (kept.length !== hidden.length) { var d = dLoad(); d.missing = d.missing || {}; if (kept.length) d.missing[proj] = kept; else delete d.missing[proj]; dSave(d); }
      if (miss !== alerts.missing || fresh2 !== alerts.missingNew || proj !== alerts.project) {
        var more = fresh2 > alerts.missingNew;
        alerts.missing = miss; alerts.missingList = list; alerts.missingNew = fresh2; alerts.project = proj;
        if (!miss) alerts.relink = null;
        if (more) react("alarm", 1400);
        changed = true;
      }
      if (changed) announce();
    });
  }
  function paintAlerts() {
    var box = $("nt-alerts");
    if (!box) return;
    var html = "", R = alerts.render;
    if (R) {
      var what = R.items.length > 1 ? R.items.length + " items" : (R.tone === "ok" && R.last.file ? baseName(R.last.file) : R.last.comp);
      html += '<div class="nt-alert" data-k="' + R.tone + '"><i class="nt-adot"></i><div class="nt-atext"><b>' +
        escHtml(R.tone === "ok" ? "Render done" : R.peek) + "</b><span>" + escHtml(what) +
        (R.tone === "ok" && R.secs ? " · " + clock(R.secs) : "") +
        (R.failed ? " · " + R.failed + " failed" : "") + "</span></div>" +
        (R.tone === "ok" && R.last.file ?
          '<button type="button" class="nt-btn" data-nt-a="folder">Folder</button>' +
          '<button type="button" class="nt-btn nt-btn-main" data-nt-a="play">Watch</button>' : "") +
        '<button type="button" class="nt-x" data-nt-a="x-render" aria-label="Dismiss">×</button></div>';
    }
    if ((alerts.missing > 0 && alerts.missingNew > 0) || alerts.relink) {
      var L = alerts.relink, sub;
      if (alerts.busy) sub = "Looking near the project, in the old folders, Downloads and Desktop…";
      else if (L && L.left && L.left.length) sub = (L.linked ? "Relinked " + L.linked + ". " : "") + "Not found: " + L.left.slice(0, 3).map(escHtml).join(", ") + (L.left.length > 3 ? " +" + (L.left.length - 3) : "");
      else if (L && !alerts.missing) sub = "All files are back — relinked " + L.linked + ".";
      else sub = "Pillow finds just these files and links them back.";
      var n = alerts.missing;
      html += '<div class="nt-alert" data-k="' + (n ? "warn" : "ok") + '"><i class="nt-adot"></i><div class="nt-atext"><b>' +
        (n ? n + (n === 1 ? " file is missing" : " files are missing") : "Files relinked") + "</b><span>" + (alerts.busy || L ? sub : escHtml(sub)) + "</span></div>" +
        (n ? (L && L.left && L.left.length && !alerts.busy
          ? '<button type="button" class="nt-btn" data-nt-a="pick">Choose folder…</button>'
          : '<button type="button" class="nt-btn nt-btn-main" data-nt-a="relink"' + (alerts.busy ? " disabled" : "") + ">" + (alerts.busy ? "Searching…" : "Relink") + "</button>") : "") +
        '<button type="button" class="nt-x" data-nt-a="x-missing" aria-label="Dismiss">×</button></div>';
    }
    var U = alerts.update;
    if (U) {
      var first = String(U.notes || "").split(/\n/)[0];
      html += '<div class="nt-alert" data-k="new"><i class="nt-adot"></i><div class="nt-atext"><b>Pillow ' + escHtml(shortVer(U.version)) +
        " is out</b><span>" + escHtml(first || "A new version is ready.") + "</span></div>" +
        '<button type="button" class="nt-x" data-nt-a="x-update" aria-label="Not now">\u00d7</button>' +
        '<div class="nt-abtns"><button type="button" class="nt-btn" data-nt-a="news">What\u2019s new</button>' +
        '<button type="button" class="nt-btn nt-btn-main" data-nt-a="get">Download</button></div></div>';
    }
    box.innerHTML = html;
    box.hidden = !html;
  }
  function relink(picked) {
    if (alerts.busy) return;
    alerts.busy = true;
    paintAlerts(); refit();
    var call = "pillowAutoRelink(" + (picked ? JSON.stringify(picked) : "") + ")";
    window.host(call, function (r) {
      alerts.busy = false;
      if (!r || !r.ok) {
        alerts.relink = { linked: 0, left: [] };
        if (typeof window.toast === "function") window.toast((r && r.error) || "Relink failed", true);
      } else {
        alerts.relink = r;
        alerts.missing = Math.max(0, alerts.missing - (r.linked || 0));
        if (r.linked) { react("happy", 1600); write(); }
        if (typeof window.toast === "function") window.toast(r.linked ? "Relinked " + r.linked + (r.left.length ? " · " + r.left.length + " still missing" : "") : "Nothing found nearby — choose a folder", !r.linked);
      }
      paintAlerts(); paintPeek(); refit();
      setTimeout(watch, 600);
    });
  }
  function onAlertAction(a) {
    var R = alerts.render;
    if (a === "folder" || a === "play") {
      if (!R) return;
      window.host("pillowRenderReveal(" + R.last.i + "," + JSON.stringify(a) + ")", function (r) {
        if (r && !r.ok && typeof window.toast === "function") window.toast(r.error || "Couldn't open it", true);
      });
    } else if (a === "x-render") { dismissRender(R); alerts.render = null; }
    else if (a === "get") { if (window.PillowUpdate) window.PillowUpdate.download(); }
    else if (a === "news") { setOpen(false); if (window.PillowSettings && window.PillowSettings.open) window.PillowSettings.open("updates"); return; }
    else if (a === "x-update") { if (window.PillowUpdate) window.PillowUpdate.dismiss(); alerts.update = null; }
    else if (a === "x-missing") { dismissMissing(); alerts.relink = null; }
    else if (a === "relink") { relink(); return; }
    else if (a === "pick") {
      window.host("pillowPickFolder()", function (r) { if (r && r.ok && r.path) relink(r.path); });
      return;
    }
    paintAlerts(); paintPeek(); refit();
  }

  var ICON = {
    copy: '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><rect x="5" y="5" width="8" height="8" rx="2" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M3 10.5V4.5A1.5 1.5 0 0 1 4.5 3h6" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>'
  };
  function build() {
    var header = document.querySelector(".header");
    if (!header || $("pl-notch")) return;
    slot = document.createElement("div");
    slot.className = "nt-slot";
    slot.id = "pl-notch-slot";
    header.appendChild(slot);

    shell = document.createElement("div");
    shell.className = "nt-shell";
    shell.id = "pl-notch";
    shell.setAttribute("role", "button");
    shell.setAttribute("aria-label", "Text morph, today, tip of the day, share presets");
    shell.setAttribute("aria-expanded", "false");
    shell.tabIndex = 0;
    shell.innerHTML =
      SKIN_SVG +
      '<div class="nt-clip">' +
      '<div class="nt-peek">' + markMarkup() + '<span class="nt-peek-t">0m</span><i class="nt-dot" hidden></i></div>' +
      '<div class="nt-body">' +
        '<div class="nt-head">' + markMarkup() +
          '<div class="nt-tabs" role="tablist"><span class="nt-tab-pill" aria-hidden="true"></span>' +
            '<button type="button" data-nt-tab="morph">Morph</button>' +
            '<button type="button" data-nt-tab="today">Today</button>' +
            '<button type="button" data-nt-tab="tip">Tip</button>' +
            '<button type="button" data-nt-tab="share">Share</button>' +
          "</div>" +
        "</div>" +
        '<div class="nt-alerts" id="nt-alerts" hidden></div>' +
        '<section data-nt-pane="morph">' +
          '<canvas class="nt-morph-stage" id="nt-morph-stage" aria-label="Morph preview — move the pointer over the word"></canvas>' +
          '<div class="nt-morph-row">' +
            '<div class="nt-seg" id="nt-morph-kind" role="tablist">' +
              '<button type="button" data-morph-kind="text" class="active">Text</button>' +
              '<button type="button" data-morph-kind="layers">Layers</button>' +
            "</div>" +
            '<input class="nt-morph-word" id="nt-morph-word" type="text" maxlength="14" value="Morph" aria-label="Preview word" spellcheck="false" />' +
          "</div>" +
          '<div class="nt-morph-set" data-morph-for="text">' +
            '<label class="nt-morph-sl"><span>Inflate</span><input type="range" id="nt-morph-inflate" min="0" max="100" value="60" /></label>' +
            '<label class="nt-morph-sl"><span>Grow</span><input type="range" id="nt-morph-grow" min="0" max="40" value="12" /></label>' +
            '<label class="nt-morph-sl"><span>Radius</span><input type="range" id="nt-morph-radius" min="20" max="200" value="70" /></label>' +
          "</div>" +
          '<div class="nt-morph-set" data-morph-for="layers" hidden>' +
            '<label class="nt-morph-sl"><span>Grow</span><input type="range" id="nt-morph-lgrow" min="0" max="150" value="60" /></label>' +
            '<label class="nt-morph-sl"><span>Radius</span><input type="range" id="nt-morph-lradius" min="40" max="300" value="120" /></label>' +
            '<label class="nt-morph-sl"><span>Push</span><input type="range" id="nt-morph-push" min="0" max="100" value="100" /></label>' +
          "</div>" +
          '<div class="nt-foot"><button type="button" class="nt-btn" id="nt-morph-remove"><span>Remove</span></button>' +
          '<button type="button" class="nt-btn nt-btn-main" id="nt-morph-apply"><span id="nt-morph-apply-l">Morph Text</span></button></div>' +
        "</section>" +
        '<section data-nt-pane="today" hidden>' +
          '<div class="nt-big"><b id="nt-total">0 min</b><span>in After Effects today</span></div>' +
          '<div class="nt-projects" id="nt-projects"></div>' +
          '<div class="nt-week" id="nt-week"></div>' +
          '<div class="nt-foot"><span>Pillow actions today <b id="nt-actions">0</b></span>' +
          '<button type="button" class="nt-btn" id="nt-copy-day">' + ICON.copy + "<span>Copy summary</span></button></div>" +
        "</section>" +
        '<section data-nt-pane="tip" hidden>' +
          '<div class="nt-tip-card" id="nt-tip-card">' +
            '<div class="nt-tip-k" id="nt-tip-k"></div>' +
            '<div class="nt-tip-t" id="nt-tip-t"></div>' +
            '<div class="nt-tip-b" id="nt-tip-b"></div>' +
          "</div>" +
          '<div class="nt-foot"><span></span><span class="nt-pager">' +
            '<button type="button" class="nt-btn nt-btn-sq" id="nt-tip-prev" aria-label="Previous tip">‹</button>' +
            '<button type="button" class="nt-btn nt-btn-sq" id="nt-tip-next" aria-label="Next tip">›</button></span></div>' +
        "</section>" +
        '<section data-nt-pane="share" hidden>' +
          '<div class="nt-share-block">' +
            '<div class="nt-label">Send a preset</div>' +
            '<div class="nt-share-row"><select class="nt-select" id="nt-send" aria-label="Preset to send"></select>' +
            '<button type="button" class="nt-btn" id="nt-send-btn">' + ICON.copy + "<span>Copy code</span></button></div>" +
            '<div class="nt-hint">The code is plain text — send it in Telegram or any chat.</div>' +
          "</div>" +
          '<div class="nt-share-block">' +
            '<div class="nt-label">Got a code?</div>' +
            '<textarea class="nt-code" id="nt-code" rows="2" spellcheck="false" placeholder="Paste it here — PILLOW-1:…"></textarea>' +
            '<div class="nt-share-row"><select class="nt-select" id="nt-folder" aria-label="Folder"></select>' +
            '<button type="button" class="nt-btn nt-btn-main" id="nt-add"><span>Add to Library</span></button></div>' +
          "</div>" +
          '<div class="nt-share-msg" id="nt-share-msg"></div>' +
        "</section>" +
      "</div>" +
      "</div>";
    document.body.appendChild(shell);
    body = shell.querySelector(".nt-body");
    clip = shell.querySelector(".nt-clip");
    skin = shell.querySelector(".nt-skin");
    skin.__fill = skin.querySelector(".nt-sk-fill");
    skin.__shade = skin.querySelector(".nt-sk-shade");
    skin.__edge = skin.querySelector(".nt-sk-edge");
    skin.__drop = skin.querySelector(".nt-sk-drop");
    skin.__seam = skin.querySelector(".nt-sk-seam");

    /* taps on the capsule open it; on the open card's head (its handle)
       close it. Six fast taps make the cushion dizzy. */
    shell.addEventListener("click", function (e) {
      warmEnd();
      var t = e.target;
      var onHandle = !!(t.closest && (t.closest(".nt-mark") || (t.closest(".nt-head") && !t.closest(".nt-tabs"))));
      if (!open || onHandle) {
        var now = Date.now();
        taps = taps.filter(function (x) { return now - x < 1800; });
        taps.push(now);
        if (taps.length >= 6) {
          taps = [];
          setOpen(false);
          react("dizzy", 2200);
          paintPeek();
          return;
        }
      }
      if (open) { if (onHandle) setOpen(false); return; }
      if (face.state === "dizzy") return;
      setOpen(true);
    });
    shell.addEventListener("keydown", function (e) {
      if (!open && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); setOpen(true); }
    });
    shell.querySelector(".nt-tabs").addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-nt-tab]") : null;
      if (!b || b.getAttribute("data-nt-tab") === view) return;
      view = b.getAttribute("data-nt-tab");
      paintView(false);
      if (view === "tip") markTipSeen();
      if (view === "share") sniffClipboard();
      refit();
    });
    $("nt-copy-day").onclick = function () {
      var ok = copyText(summaryText());
      if (ok) write();
      if (typeof window.toast === "function") window.toast(ok ? "Today’s summary copied" : "Couldn't copy", !ok);
    };
    $("nt-tip-prev").onclick = function () { db.tipOffset = (db.tipOffset || 0) - 1; save(); paintTip(-1); refit(); };
    $("nt-tip-next").onclick = function () { db.tipOffset = (db.tipOffset || 0) + 1; save(); paintTip(1); refit(); };
    $("nt-add").onclick = addFromCode;
    $("nt-alerts").addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-nt-a]") : null;
      if (b && !b.disabled) onAlertAction(b.getAttribute("data-nt-a"));
    });
    $("nt-send-btn").onclick = sendCode;

    document.addEventListener("pointerdown", function (e) {
      poke();
      if (open && !(e.target.closest && e.target.closest("#pl-notch"))) setOpen(false);
    }, true);
    document.addEventListener("keydown", function (e) {
      poke();
      if (open && e.key === "Escape") setOpen(false);
    });
    document.addEventListener("pointermove", leanFrom, { passive: true });
    shell.addEventListener("pointerenter", function () { if (!open) fluff(shell.querySelector(".nt-peek .nt-mark"), 4); });
    shell.addEventListener("pointermove", function (e) {
      var m = e.target.closest ? e.target.closest(".nt-mark") : null;
      if (m) fluff(m, 3);
    });
    window.addEventListener("resize", place);
    if (window.ResizeObserver) {
      var ro = new ResizeObserver(function () { place(); });
      ro.observe(slot);
      var meta = document.querySelector(".header .header-meta");
      if (meta) ro.observe(meta);
    }

    animateTo(capsuleRect(), true);
    paintPeek();
    mood();
    /* the buttons inside are Pillow's own: give them their surface */
    if (window.pillowRescanTactile) setTimeout(window.pillowRescanTactile, 0);
  }

  function init() {
    build();
    wrapHost();
    /* the warm-up once things have settled (and again later if the panel
       was not on screen then) */
    var idle = window.requestIdleCallback || function (fn) { return setTimeout(fn, 60); };
    setTimeout(function () { idle(warm, { timeout: 2000 }); }, 2500);
    if (window.PillowPresence && window.PillowPresence.onWakeEach) window.PillowPresence.onWakeEach(function () { if (!warmed) setTimeout(function () { idle(warm, { timeout: 2000 }); }, 600); });
    setTimeout(function () { watch(); setInterval(watch, WATCH_MS); }, 4000);
    /* back at the panel: one look right away */
    if (window.PillowPresence && window.PillowPresence.onWakeEach) window.PillowPresence.onWakeEach(function () { setTimeout(watch, 300); });
    /* the first look at AE after start-up has settled */
    setTimeout(function () { tick(); setInterval(tick, 45000); }, 12000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", function () { setTimeout(init, 0); });
  else setTimeout(init, 0);

  window.PillowNotch = {
    open: function (tab) { if (tab) view = tab; if (open) { paintView(false); refit(); } else setOpen(true); },
    close: function () { setOpen(false); },
    encode: encode,
    decode: decode,
    share: shareCode,
    copy: copyText,
    _db: db,
    _tick: tick,
    _react: react,
    _S: S,
    _refit: function () { refit(); },
    _watch: watch,
    /* a newer Pillow (js/update.js), or null */
    setUpdate: function (u) {
      var had = alerts.update && alerts.update.version;
      alerts.update = u || null;
      if (!shell) return;
      if (u && had !== u.version) { react("happy", 1600); announce(); }
      else { paintPeek(); if (open) { paintAlerts(); refit(); } else animateTo(capsuleRect()); }
    },
    _alerts: alerts
  };
})();
