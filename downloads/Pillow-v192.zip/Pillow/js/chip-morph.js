/* Pillow — мягкая деформация текста-вордмарка «Pillow» (шапка) вслед за курсором
 *
 * Вордмарк не меняет вид, только форму: пружины тянут его к курсору, а по
 * скорости и смещению курсора он вытягивается вдоль движения и слегка
 * сжимается поперёк (объём сохраняется), чуть наклоняется и крутится.
 * Кадровый цикл живёт только пока пружины не успокоились.
 * Трогается один элемент: .brand-title внутри .header. Иконка (.logo)
 * и кнопка Create (.glass-chip) этим скриптом не затрагиваются.
 */

(function () {
  "use strict";

  var REACH = 44;      // px вокруг чипа, где он уже чувствует курсор
  var PULL = 0.42;     // доля смещения курсора, на которую чип тянется
  var MAX_MOVE = 6;    // px, предел сдвига
  var STRETCH = 0.24;  // предел вытяжки по оси
  var K = 210, C = 15; // жёсткость и демпфирование: лёгкий упругий перелёт

  var reduced = false;
  try {
    reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  } catch (e) {}

  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

  function bind(el) {
    if (!el || el.__plChip || reduced) return;
    el.__plChip = true;

    /* состояние: x,y — сдвиг; sx,sy — растяжение; r — поворот; цель — t* */
    var s = { x: 0, y: 0, sx: 0, sy: 0, r: 0 };
    var v = { x: 0, y: 0, sx: 0, sy: 0, r: 0 };
    var t = { x: 0, y: 0, sx: 0, sy: 0, r: 0 };
    var raf = null, last = 0, near = false, rect = null;
    var px = 0, py = 0, pt = 0;

    /* the wordmark sits still in the header: its box is kept and taken
       again only when the layout around it changes. Measuring on every
       pointermove forced a restyle of the whole panel whenever anything
       else (a hover) had just changed a style. */
    var stale = true;
    function measure() {
      if (!stale && rect) return;
      var tf = el.style.transform;
      if (tf) el.style.transform = "";
      rect = el.getBoundingClientRect();
      if (tf) el.style.transform = tf;
      stale = false;
    }
    if (window.ResizeObserver) {
      var ro = new ResizeObserver(function () { stale = true; });
      ro.observe(el);
      if (el.parentElement) ro.observe(el.parentElement);
      ro.observe(document.documentElement);
    } else stale = true;

    function aim(cx, cy, dvx, dvy) {
      var w = rect.width, h = rect.height;
      var nx = clamp((cx - (rect.left + w / 2)) / (w / 2 + REACH), -1.4, 1.4);
      var ny = clamp((cy - (rect.top + h / 2)) / (h / 2 + REACH), -1.4, 1.4);
      /* быстрое движение добавляет вытяжку вдоль вектора скорости */
      var sp = clamp(dvx / 40, -1, 1), sq = clamp(dvy / 40, -1, 1);
      t.x = clamp(nx * w * PULL, -MAX_MOVE, MAX_MOVE);
      t.y = clamp(ny * h * PULL, -MAX_MOVE, MAX_MOVE);
      t.sx = clamp(Math.abs(nx) * STRETCH * 0.6 + Math.abs(sp) * STRETCH * 0.4, 0, STRETCH);
      t.sy = -t.sx * 0.7 + clamp(Math.abs(ny) * STRETCH * 0.35, 0, STRETCH * 0.35) - Math.abs(sq) * STRETCH * 0.25;
      /* угол: курсор выше/ниже и слева/справа закручивает чип */
      t.r = clamp(nx * ny * -4 + sp * 2, -4, 4);
    }

    function rest() { t.x = t.y = t.sx = t.sy = t.r = 0; }

    function write() {
      var tx = s.x.toFixed(2), ty = s.y.toFixed(2);
      el.style.transform =
        "translate3d(" + tx + "px," + ty + "px,0) rotate(" + s.r.toFixed(2) + "deg) scale(" +
        (1 + s.sx).toFixed(4) + "," + (1 + s.sy).toFixed(4) + ")";
    }

    function tick(now) {
      var dt = Math.min(0.032, (now - last) / 1000 || 0.016);
      last = now;
      var moving = false, k;
      for (k in s) {
        v[k] += (K * (t[k] - s[k]) - C * v[k]) * dt;
        s[k] += v[k] * dt;
        if (Math.abs(v[k]) > 0.01 || Math.abs(t[k] - s[k]) > 0.002) moving = true;
      }
      write();
      if (moving || near) raf = requestAnimationFrame(tick);
      else {
        raf = null;
        for (k in s) { s[k] = 0; v[k] = 0; }
        el.style.transform = "";
        el.style.willChange = "";
      }
    }

    function wake() {
      if (raf) return;
      el.style.willChange = "transform";
      last = performance.now();
      raf = requestAnimationFrame(tick);
    }

    document.addEventListener("pointermove", function (e) {
      if (e.pointerType === "touch") return;
      if (!near) measure();   // замер — только если раскладка вокруг менялась
      var inside =
        e.clientX > rect.left - REACH && e.clientX < rect.right + REACH &&
        e.clientY > rect.top - REACH && e.clientY < rect.bottom + REACH;
      var now = e.timeStamp || performance.now();
      var dtm = Math.max(8, now - pt);
      var dvx = (e.clientX - px) / dtm * 16, dvy = (e.clientY - py) / dtm * 16;
      px = e.clientX; py = e.clientY; pt = now;
      if (inside) { near = true; aim(e.clientX, e.clientY, dvx, dvy); wake(); }
      else if (near) { near = false; rest(); wake(); }
    }, { passive: true });

    document.addEventListener("pointerleave", function () {
      if (near) { near = false; rest(); wake(); }
    });
    window.addEventListener("resize", function () { stale = true; near = false; });
    /* the dock moving between top / left moves the header without resizing it */
    new MutationObserver(function () { stale = true; }).observe(document.documentElement, { attributes: true, attributeFilter: ["data-rail", "lang"] });
  }

  function boot() { bind(document.querySelector(".header .brand-title")); }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
