/* Pillow — finds missing footage on disk, from the panel (Node).
 *
 * One button, no folder to pick. For every missing file Pillow knows its
 * old path (or at least its name) and looks, in this order, until all are
 * found:
 *   1. moved together: once one file turns up somewhere new, the others
 *      from the same old folder tree are tried at the same place (a
 *      project copied to another drive or computer relinks in one go);
 *   2. near: the old folder and the three above it, the project's folder
 *      and the one above;
 *   3. the system's own search index: Spotlight (mdfind) on macOS, Windows
 *      Search on Windows — instant for the user's folders;
 *   4. everywhere: the home folder, then every drive / volume, shallow
 *      folders first, skipping system folders, the Trash and app bundles.
 * Searching runs here, asynchronously, so After Effects never freezes;
 * only the final relink goes to the host.
 *
 * API: PillowFinder.ok, PillowFinder.find(items, project, onProgress, done),
 *      PillowFinder.cancel()
 *   items: [{ id, fname, old }]   done({ found: { id: path }, cancelled, timedOut })
 */
(function () {
  "use strict";
  if (window.PillowFinder) return;

  var req = (window.cep_node && window.cep_node.require) || (typeof window.require === "function" ? window.require : null);
  var fs = null, pathM = null, os = null, cp = null;
  try { fs = req("fs"); pathM = req("path"); os = req("os"); cp = req("child_process"); } catch (e) { fs = null; }
  var WIN = false, MAC = false;
  try { WIN = os.platform() === "win32"; MAC = os.platform() === "darwin"; } catch (eP) {}

  /* Node before 10.10 has no withFileTypes (After Effects 2019 and older) */
  var OLD_NODE = true;
  try { var nv = (typeof process !== "undefined" ? process : window.cep_node.process).versions.node.split("."); OLD_NODE = +nv[0] < 10 || (+nv[0] === 10 && +nv[1] < 10); } catch (eV) { OLD_NODE = false; }
  var BUDGET_MS = 4 * 60 * 1000;          /* the whole search, at most */
  var NEAR_DEPTH = 5;
  var CONCURRENCY = 12;

  /* folders never worth opening */
  var SKIP_ANY = /^(\$recycle\.bin|system volume information|node_modules|appdata|\.trash|\.trashes|\.spotlight-v100|\.fseventsd|\.git)$/i;
  var SKIP_PKG = /\.(app|framework|bundle|plugin|kext|photoslibrary|musiclibrary|tvlibrary|lrdata|lrcat-data)$/i;
  var SKIP_WIN_ROOT = /^(windows|program files|program files \(x86\)|programdata|recovery|perflogs|msocache|intel|amd|nvidia|\$windows\.~bt|\$windows\.~ws|\$winreagent)$/i;
  var SKIP_HOME = /^(library|applications)$/i;
  var TRASH = /[\\\/](\$recycle\.bin|\.trash|\.trashes)[\\\/]/i;

  function segs(p) { return String(p || "").split(/[\\\/]+/); }
  /* NFC first: macOS gives file names decomposed ("й" = "и" + breve),
     After Effects composed - the same name compared unequal before */
  function lower(s) { s = String(s); try { s = s.normalize("NFC"); } catch (e) {} return s.toLowerCase(); }

  var job = null;

  function find(items, project, onProgress, done) {
    if (!fs) { done({ found: {}, unavailable: true }); return; }
    if (job) job.cancelled = true;
    var J = job = {
      cancelled: false, t0: Date.now(), dirs: 0, found: {}, byName: {}, left: 0,
      seen: {}, items: items, onProgress: onProgress || function () {}, finished: false
    };
    var i;
    for (i = 0; i < items.length; i++) {
      var it = items[i];
      it._name = lower(it.fname || "");
      it._old = it.old ? segs(it.old) : null;
      if (!it._name) continue;
      (J.byName[it._name] = J.byName[it._name] || []).push(it);
      J.left++;
    }
    if (!J.left) { finish(J, done); return; }

    var phases = [
      function (next) { walkPhase(J, nearRoots(items, project), NEAR_DEPTH, "near", next); },
      function (next) { indexPhase(J, next); },
      function (next) { walkPhase(J, everyRoots(), 999, "everywhere", next); }
    ];
    var p = 0;
    (function step() {
      if (J.cancelled || !J.left || timeUp(J) || p >= phases.length) { finish(J, done); return; }
      try { phases[p++](step); } catch (eP) { step(); }
    })();
  }

  function timeUp(J) { return Date.now() - J.t0 > BUDGET_MS; }
  function finish(J, done) {
    if (J.finished) return;
    J.finished = true;
    if (job === J) job = null;
    done({ found: J.found, cancelled: J.cancelled, timedOut: !J.cancelled && J.left > 0 && timeUp(J), dirs: J.dirs });
  }
  function report(J, phase) {
    var total = 0, got = 0;
    for (var i = 0; i < J.items.length; i++) { if (J.items[i]._name) total++; if (J.found[J.items[i].id]) got++; }
    try { J.onProgress({ phase: phase, dirs: J.dirs, found: got, total: total }); } catch (e) {}
  }

  function isFile(p) { try { return fs.statSync(p).isFile(); } catch (e) { return false; } }

  /* how many folder names the candidate shares with the old path, from the file up */
  function score(it, cand) {
    if (!it._old) return 0;
    var a = it._old, b = segs(cand), n = 0;
    for (var k = 2; k <= Math.min(a.length, b.length); k++) {
      if (lower(a[a.length - k]) !== lower(b[b.length - k])) break;
      n++;
    }
    return n;
  }

  /* a file with a wanted name turned up */
  function offer(J, full, nameLower) {
    var list = J.byName[nameLower];
    if (!list || TRASH.test(full)) return;
    for (var i = 0; i < list.length; i++) {
      var it = list[i];
      if (J.found[it.id]) {
        /* a better match for an already found name (same folder names) */
        if (score(it, full) > score(it, J.found[it.id])) J.found[it.id] = full;
        continue;
      }
      J.found[it.id] = full;
      J.left--;
      movedTogether(J, it, full);
    }
  }

  /* old ".../Shoot/Day 1/a.mp4" found at "E:/Backup/Shoot/Day 1/a.mp4":
     every other missing file under the old ".../" is tried under "E:/Backup/" */
  function movedTogether(J, it, full) {
    if (!it._old) return;
    var a = it._old, b = segs(full), k = 0;
    while (k < a.length && k < b.length && lower(a[a.length - 1 - k]) === lower(b[b.length - 1 - k])) k++;
    var oldPre = a.slice(0, a.length - k), newPre = b.slice(0, b.length - k);
    if (!oldPre.length || !newPre.length) return;
    for (var i = 0; i < J.items.length; i++) {
      var o = J.items[i];
      if (J.found[o.id] || !o._old || o._old.length <= oldPre.length) continue;
      var same = true;
      for (var s = 0; s < oldPre.length; s++) if (lower(o._old[s]) !== lower(oldPre[s])) { same = false; break; }
      if (!same) continue;
      var cand = newPre.concat(o._old.slice(oldPre.length)).join(pathM.sep);
      if (MAC && cand.charAt(0) !== "/") cand = "/" + cand;
      if (isFile(cand)) { J.found[o.id] = cand; J.left--; }
    }
  }

  /* ── where to look ── */
  function nearRoots(items, project) {
    var roots = [], i;
    function add(p) { if (p) roots.push(p); }
    for (i = 0; i < items.length; i++) {
      if (!items[i].old) continue;
      var d = pathM.dirname(items[i].old);
      for (var up = 0; up < 4 && d; up++) {
        add(d);
        var pd = pathM.dirname(d);
        if (pd === d) break;
        d = pd;
      }
    }
    if (project) { var pdir = pathM.dirname(project); add(pdir); add(pathM.dirname(pdir)); }
    return roots;
  }
  function everyRoots() {
    var roots = [], home = "";
    try { home = os.homedir(); } catch (e) {}
    if (home) roots.push(home);
    if (WIN) {
      for (var c = 67; c <= 90; c++) {          /* C: .. Z: */
        var d = String.fromCharCode(c) + ":\\";
        try { if (fs.existsSync(d)) roots.push(d); } catch (eD) {}
      }
    } else if (MAC) {
      try {
        var v = fs.readdirSync("/Volumes");
        for (var i = 0; i < v.length; i++) {
          var p = "/Volumes/" + v[i], real = p;
          try { real = fs.realpathSync(p); } catch (eR) {}
          if (real !== "/") roots.push(p);
        }
      } catch (eV) {}
      roots.push("/Users/Shared");
    } else {
      roots.push("/");
    }
    return roots;
  }

  /* ── walking: breadth first, shallow folders before deep ones ── */
  function walkPhase(J, roots, maxDepth, phase, next) {
    var queue = [], qi = 0, active = 0, ended = false, lastReport = 0, home = "";
    try { home = os.homedir(); } catch (eH) {}
    /* each phase keeps its own list of opened folders: a depth-limited
       "near" pass must not hide the deeper folders from "everywhere" */
    J.seen = {};
    for (var r = 0; r < roots.length; r++) queue.push({ p: roots[r], d: 0, root: roots[r] });
    function end() { if (ended) return; ended = true; report(J, phase); next(); }
    function pump() {
      if (ended) return;
      if (J.cancelled || !J.left || timeUp(J)) { if (!active) end(); return; }
      while (active < CONCURRENCY && qi < queue.length) {
        var job1 = queue[qi++];
        var key = WIN ? lower(job1.p) : job1.p;
        if (J.seen[key]) continue;
        J.seen[key] = true;
        active++;
        readOne(job1);
      }
      if (!active && qi >= queue.length) end();
      if (qi > 50000 && qi > queue.length / 2) { queue = queue.slice(qi); qi = 0; }
    }
    /* never stall: whatever one folder does (no access, an odd entry, a
       Node too old for withFileTypes, which hands back plain names), the
       walk goes on and the search always ends */
    function readOne(item) {
      var cb = function (err, ents) {
        active--;
        J.dirs++;
        try {
          if (!err && ents) {
            for (var i = 0; i < ents.length; i++) {
              try {
                var e = ents[i], nm = typeof e === "string" ? e : e.name;
                var full = item.p + (/[\\\/]$/.test(item.p) ? "" : pathM.sep) + nm;
                var isDir, isF;
                if (typeof e === "string") {
                  var st = null;
                  try { st = fs.lstatSync(full); } catch (eS) {}
                  if (!st) continue;
                  isDir = st.isDirectory(); isF = st.isFile() || st.isSymbolicLink();
                } else { isDir = e.isDirectory(); isF = e.isFile() || e.isSymbolicLink(); }
                if (isDir) {
                  if (item.d >= maxDepth || nm.charAt(0) === "." || SKIP_ANY.test(nm) || SKIP_PKG.test(nm)) continue;
                  if (WIN && item.d === 0 && /^[A-Z]:\\$/i.test(item.root) && SKIP_WIN_ROOT.test(nm)) continue;
                  if (item.d === 0 && item.root === home && SKIP_HOME.test(nm)) continue;
                  queue.push({ p: full, d: item.d + 1, root: item.root });
                } else if (isF) {
                  var low = lower(nm);
                  if (J.byName[low]) offer(J, full, low);
                }
              } catch (eE) {}
            }
          }
          var now = Date.now();
          if (now - lastReport > 250) { lastReport = now; report(J, phase); }
        } catch (eAll) {}
        pump();
      };
      try {
        if (OLD_NODE) fs.readdir(item.p, cb);
        else fs.readdir(item.p, { withFileTypes: true }, cb);
      } catch (eR) {
        try { fs.readdir(item.p, cb); } catch (eR2) { setTimeout(function () { cb(eR2, null); }, 0); }
      }
    }
    report(J, phase);
    pump();
  }

  /* ── the system's search index ── */
  function indexPhase(J, next) {
    var names = [];
    for (var n in J.byName) {
      if (!J.byName.hasOwnProperty(n)) continue;
      var waiting = false, L = J.byName[n];
      for (var i = 0; i < L.length; i++) if (!J.found[L[i].id]) waiting = true;
      if (waiting && !/["\\]/.test(n)) names.push(n);
    }
    if (!names.length || (!MAC && !WIN)) { next(); return; }
    report(J, "index");
    var batches = [], b;
    for (b = 0; b < names.length; b += 40) batches.push(names.slice(b, b + 40));
    var bi = 0;
    (function one() {
      if (J.cancelled || !J.left || bi >= batches.length) { next(); return; }
      var batch = batches[bi++], cmd, args;
      if (MAC) {
        var q = [];
        for (var k = 0; k < batch.length; k++) q.push('kMDItemFSName == "' + batch[k] + '"c');
        cmd = "mdfind"; args = [q.join(" || ")];
      } else {
        var w = [];
        for (var m = 0; m < batch.length; m++) w.push("System.FileName = '" + batch[m].replace(/'/g, "''") + "'");
        var ps =
          "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8;" +
          "$c = New-Object -ComObject ADODB.Connection;" +
          "$c.Open(\"Provider=Search.CollatorDSO;Extended Properties='Application=Windows';\");" +
          "$r = $c.Execute(\"SELECT System.ItemPathDisplay FROM SystemIndex WHERE " + w.join(" OR ").replace(/"/g, '`"') + "\");" +
          "while (-not $r.EOF) { $r.Fields.Item('System.ItemPathDisplay').Value; $r.MoveNext() }";
        cmd = "powershell.exe"; args = ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps];
      }
      try {
        cp.execFile(cmd, args, { timeout: 20000, maxBuffer: 32 * 1024 * 1024, windowsHide: true, encoding: "utf8" }, function (err, out) {
          try {
            var lines = String(out || "").split(/\r?\n/);
            for (var i = 0; i < lines.length; i++) {
              var p = lines[i].replace(/^\s+|\s+$/g, "");
              if (!p || !isFile(p)) continue;
              offer(J, p, lower(pathM.basename(p)));
            }
            report(J, "index");
          } catch (eOut) {}
          one();
        });
      } catch (eX) { one(); }
    })();
  }

  window.PillowFinder = {
    ok: !!fs,
    find: find,
    cancel: function () { if (job) job.cancelled = true; },
    busy: function () { return !!job; }
  };
})();
