/* Pillow — is there a newer Pillow?
 *
 * Pillow asks <server>/version (js/config.js) a little after start and
 * then every few hours. The server answers with the latest version, a few
 * lines of what's new and the download page:
 *   { "version": "2.4.0", "notes": "…", "url": "https://…" }
 * When it is newer than this Pillow, the notch capsule says so on its own
 * ("Pillow 2.4 ✦") — the card has Download and What's new — and Settings →
 * Updates shows the notes. Pillow never downloads or installs anything by
 * itself: Download opens the page in the browser. "Not now" on the notch
 * hides that version until the next one.
 */
(function () {
  "use strict";
  if (window.PillowUpdate) return;

  var KEY = "pillow.update", HOURS = 6;
  var state = { latest: null, checked: 0, error: "" };
  var root = null, relayout = null;
  function cfg() { return window.PILLOW_CONFIG || {}; }
  function current() { return typeof PILLOW_VERSION !== "undefined" ? PILLOW_VERSION : "0"; }
  function load() { try { return JSON.parse(localStorage.getItem(KEY) || "{}") || {}; } catch (e) { return {}; } }
  function store(o) { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} }

  /* "2.10.0" > "2.9.3" */
  function newer(a, b) {
    var x = String(a).split(/[.\-]/), y = String(b).split(/[.\-]/);
    for (var i = 0; i < Math.max(x.length, y.length); i++) {
      var p = parseInt(x[i], 10) || 0, q = parseInt(y[i], 10) || 0;
      if (p !== q) return p > q;
    }
    return false;
  }
  function openUrl(url) {
    if (!url) return;
    try { if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) { window.cep.util.openURLInDefaultBrowser(url); return; } } catch (e) {}
    window.open(url, "_blank");
  }
  function available() {
    var l = state.latest;
    return l && l.version && newer(l.version, current()) ? l : null;
  }

  function tellNotch() {
    var l = available(), saved = load();
    if (!window.PillowNotch || !window.PillowNotch.setUpdate) return;
    window.PillowNotch.setUpdate(l && saved.dismissed !== l.version ? l : null);
  }

  function check(manual) {
    var server = String(cfg().server || "").replace(/\/+$/, "");
    if (!server || !window.fetch) { state.error = "off"; paint(); return; }
    var ctl = window.AbortController ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctl) ctl.abort(); }, 10000);
    if (manual) { state.error = ""; paint("checking"); }
    fetch(server + "/version", { cache: "no-store", signal: ctl ? ctl.signal : undefined })
      .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
      .then(function (j) {
        clearTimeout(timer);
        if (!j || !j.version) throw new Error("no version");
        state.latest = { version: String(j.version), notes: String(j.notes || "").slice(0, 600), url: String(j.url || "") };
        state.checked = Date.now(); state.error = "";
        var saved = load(); saved.latest = state.latest; saved.checked = state.checked; store(saved);
        paint(); tellNotch();
        if (manual && !available() && typeof window.toast === "function") window.toast("Pillow is up to date");
      })
      .catch(function () {
        clearTimeout(timer);
        state.error = "net"; paint();
        if (manual && typeof window.toast === "function") window.toast("Couldn't reach the update server", true);
      });
  }

  function paint(busy) {
    if (!root) return;
    var line = root.querySelector("#pl-up-line"), notes = root.querySelector("#pl-up-notes"), btn = root.querySelector("#pl-up-check");
    var meta = document.getElementById("pl-set-up-val"), l = available();
    if (busy) { line.textContent = "Checking…"; return; }
    if (l) {
      line.innerHTML = "<b>Pillow " + esc(l.version) + "</b> is out · you have " + esc(current());
      notes.textContent = l.notes || "";
      notes.hidden = !l.notes;
      btn.textContent = "Download";
      btn.hidden = false;
      if (meta) meta.textContent = "New";
    } else {
      line.textContent = "Pillow " + current() + (state.error === "off" ? "" : state.checked ? " · up to date" : "");
      notes.hidden = true;
      btn.textContent = "Check now";
      btn.hidden = state.error === "off";
      if (meta) meta.textContent = current();
    }
    if (relayout) relayout();
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

  function mount(panel, layout) {
    root = panel;
    relayout = layout;
    var btn = panel.querySelector("#pl-up-check");
    if (btn && !btn.__up) {
      btn.__up = true;
      btn.addEventListener("click", function () {
        var l = available();
        if (l) openUrl(l.url); else check(true);
      });
    }
    paint();
  }

  function init() {
    var saved = load();
    if (saved.latest) { state.latest = saved.latest; state.checked = saved.checked || 0; }
    if (!cfg().server) state.error = "off";
    /* the notch is built a moment after start */
    setTimeout(tellNotch, 3000);
    var due = Math.max(25000, (state.checked + HOURS * 3600e3) - Date.now());
    setTimeout(function () { check(false); setInterval(function () { check(false); }, HOURS * 3600e3); }, Math.min(due, HOURS * 3600e3));
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();

  window.PillowUpdate = {
    mount: mount,
    check: function () { check(true); },
    download: function () { var l = available(); if (l) openUrl(l.url); },
    dismiss: function () { var l = available(), s = load(); if (l) { s.dismissed = l.version; store(s); } tellNotch(); },
    _newer: newer,
    _state: state
  };
})();
