/* Pillow — is anyone looking at the panel?
 *
 * The live previews (Curves dot, Bounce graph, Morph, 3D Ring) draw every
 * frame. While the person works in After Effects itself — the panel has
 * lost focus and the pointer is elsewhere — that is CPU taken from AE for
 * nothing. Loops ask awake() each frame, stop when it says no, and are
 * woken again by onWake() the moment the pointer or focus comes back.
 *
 * Asleep: the panel is hidden, or it has had neither focus nor the pointer
 * for SLEEP_MS.
 * API: PillowPresence.awake() / onWake(fn) (one-shot)
 */
(function () {
  "use strict";
  if (window.PillowPresence) return;

  var SLEEP_MS = 2000;
  var inside = true, focused = true, leftAt = 0, waiters = [], always = [], wasAwake = true;
  try { focused = document.hasFocus(); } catch (e) {}

  function now() { return window.performance ? performance.now() : Date.now(); }
  function awake() {
    if (document.hidden) return false;
    if (inside || focused) return true;
    return now() - leftAt < SLEEP_MS;
  }
  function wake() {
    if (!awake()) return;
    var w = waiters; waiters = [];
    for (var i = 0; i < w.length; i++) { try { w[i](); } catch (e) {} }
    /* persistent listeners: once per return to the panel */
    if (!wasAwake) { for (var j = 0; j < always.length; j++) { try { always[j](); } catch (e2) {} } }
    wasAwake = true;
  }
  /* asleep is noticed lazily, by whoever asks */
  setInterval(function () { if (!awake()) wasAwake = false; }, 1000);
  function away() { if (!inside && !focused) leftAt = now(); }

  document.addEventListener("pointermove", function () { if (!inside) { inside = true; wake(); } }, { passive: true });
  document.addEventListener("pointerdown", function () { inside = true; wake(); }, { passive: true });
  document.addEventListener("keydown", function () { focused = true; wake(); });
  document.documentElement.addEventListener("pointerleave", function () { inside = false; away(); });
  document.addEventListener("mouseleave", function () { inside = false; away(); });
  window.addEventListener("blur", function () { focused = false; away(); });
  window.addEventListener("focus", function () { focused = true; wake(); });
  document.addEventListener("visibilitychange", function () { if (!document.hidden) wake(); });

  window.PillowPresence = {
    awake: awake,
    onWake: function (fn) { if (waiters.indexOf(fn) < 0) waiters.push(fn); },
    onWakeEach: function (fn) { if (always.indexOf(fn) < 0) always.push(fn); }
  };
})();
