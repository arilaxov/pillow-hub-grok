#!/bin/bash
defaults write com.adobe.CSXS.9  PlayerDebugMode 1
defaults write com.adobe.CSXS.10 PlayerDebugMode 1
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
echo "PlayerDebugMode enabled for CSXS 9–12."
echo "Restart After Effects."
read -p "Press Enter to close…"
